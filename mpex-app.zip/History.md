
1.0.1 / 2017-01-04
==================

  * Merged in double-post-fix (pull request #110)
  * README.md edited online with Bitbucket
  * README.md edited online with Bitbucket
  * Code cleanup, added exception messages to error formatter
  * Fixed issue for bulk wallet creation with card proxy number
  * Merge branches 'double-post-fix' and 'double-post-fix' of bitbucket.org:matchmove/mpex-app into double-post-fix
  * CTRM-759 - Update cashout endpoints to do proper type check before post and before updating db
  * Client side validation for card proxy number
  * Fixed Single wallet fatal error issue for blank card proxy
  * Merge branch 'double-post-fix' of https://bitbucket.org/matchmove/mpex-app into double-post-fix
  * Exceptions added to error formatter
  * [CTRM-758] The post on the backend fixed to allow conditional values by checking typeof value posted and handlig a conditional
  * Bulk wallet creation
  * CTRM-654- Bulk wallet creation with card proxy number
  * Simple code for curent fix
  * Intermediate commit for teh fix
  * Merged in CTRM-654_1 (pull request #108)
  * Merged in MPEX-209_1 (pull request #106)
  * CTRM-654: config entries for Card Creation feature
  * CTRM-654: handle card creation on wallet for single workflow
  * CTRM-654: added card_proxy_number headers for bulk wallet creation and CSV parser to ignore proxy number validation if left empty when CARD_CREATION_ON_WALLET=optional
  * CTRM-654: Added CARD_CREATION_ON_WALLET feature for Wallet Create Single worklfow
  * Merge branch 'master' of https://bitbucket.org/matchmove/mpex-app
  * README.md edited online with Bitbucket
  * README.md edited online with Bitbucket
  * Reverting changes in agent migration script
  * MPEX-209: Fixed Cashout transaction issue
  * FLXM-969: Validation added to email

1.0.0 / 2016-12-06
==================

  * README.md edited online with Bitbucket
  * Merged in MPEX-230 (pull request #101)
  * MPEX-231: Fixed tokens and migrations for agents table
  * Merged in FLXM-900 (pull request #95)
  * Merged in MPEX-230 (pull request #100)
  * Merged in MPEX-209 (pull request #99)
  * MPEX-230, MPEX-227: Fixed OTP Expired message display and reports text
  * MPEX-209: Added logging
  * Merged in HAV-439 (pull request #98)
  * [HAV-439][Bug-Havells-UAT] [AdminNet- web-hav-ad-1.0.0] Mpex Cash Into the wrong destination
  * Merged in HAV-439 (pull request #96)
  * [HAV-439][Bug-Havells-UAT] [AdminNet- web-hav-ad-1.0.0] Mpex Cash In to the wrong destination
  * Merged in MPEX-225 (pull request #94)
  * FLXM-900: Added new field in agents and fixed agent report
  * MPEX-225: Fixed status message on cashout reports
  * Merged in MPEX-222 (pull request #93)
  * MPEX-226: Cashin validation fix
  * Fixed animation and blank page issues for single and bulk wallet creation
  * README.md edited online with Bitbucket
  * README.md edited online with Bitbucket
  * Merged in FLXM-911 (pull request #92)
  * FLXM-911 update
  * Merged in FLXM-911 (pull request #90)
  * added language tokens
  * Merge branch 'master' of https://bitbucket.org/matchmove/mpex-app into FLXM-911
  * Condition update
  * Update the migrations to be single and fix the syntax
  * FLXM-910: Validation fix on cashin email field
  * MPEX-209: Fixed email validation on agent create and cardholder creation
  * FLXM-911: Fixed issue of last name saving into preferred name field
  * Merged in FLXM-907 (pull request #89)
  * Inline validations for single workflow from config
  * Merged in fund-category-load (pull request #88)
  * Merged in ui-fixes (pull request #87)
  * [FEATURE] Update the workflow to include categories and card load for single user workflow
  * [MPEX-214][UI] UI fixes and text fixes from the ticket
  * FLXM-907: Client side validation for all single workflows
  * Merged in auth-patch-1 (pull request #86)
  * Update package.json to include new relic install
  * Merged in auth-patch-1 (pull request #85)
  * Add monitoring
  * Merged in FLXM-904 (pull request #82)
  * Merged in oauth-refactor (pull request #84)
  * Add walletcreate single wrkflw error record into mpex DB
  * Merged in oauth-refactor (pull request #83)
  * fix walletCreateBulk workflow csvparser and errorformatter
  * Merged in auth-patch-1 (pull request #81)
  * FLXM-904: Display readable status message on all reports
  * Update the semicolorn
  * Merged in FLXM-897 (pull request #80)
  * added missing break statement
  * Merge branch 'master' of https://bitbucket.org/matchmove/mpex-app into FLXM-897
  * Fixed Bulk upload validation issue
  * Merged in auth-patch (pull request #79)
  * Update the include of the export
  * Update exported vairables to be distinct from local usage
  * UPdate the services and the headers
  * Update the case value
  * Update the redundant initialization in object
  * Update the operation to use based on client config
  * Client side changes
  * Update the response from API to incldue conditional for no emails
  * Update the config and hsot
  * Patch for the application auth flow
  * FIX : rework the application to allow split deploy
  * Merged in MPEX-199 (pull request #78)
  * MPEX-199 fix the list report fields and seeds file
  * MPEX-199 fix last_login and login_count for agent logins
  * Merged in MPEX-199 (pull request #77)
  * Removed redundant message
  * Update the error message for used tokens
  * Merged in MPEX-190 (pull request #76)
  * MPEX-190 fix the password reset workflow
  * Merged in MPEX-177 (pull request #75)
  * MPEX-177 fix the duplicate commas
  * Merged in MPEX-196 (pull request #74)
  * Merged in MPEX-177 (pull request #73)
  * README.md edited online with Bitbucket
  * README.md edited online with Bitbucket
  * Miscellaneous fixes on tickets
  * README.md edited online with Bitbucket
  * README.md edited online with Bitbucket
  * README.md edited online with Bitbucket
  * MPEX-177 fix parser validation for mutually exclusive fields and file types
  * Merged in MPEX-156 (pull request #71)
  * Merged in dashboard-fix (pull request #72)
  * MPEX-156 MPEX-188 fix the debit limit reached for single cashout
  * Dashboard widget
  * MPEX-156 fix the uploader box for results page in bulk workflows
  * Merged in MPEX-188 (pull request #68)
  * Resolve conflicts, remove gravatar from cardholder and agent
  * Merged in MPEX-187 (pull request #70)
  * MPEX-187 fix the dialog layout and title text
  * Merged in MPEX-184 (pull request #69)
  * MPEX-184 fix the error msg in single cashout cancel and invalid OTP entry
  * MPEX-188
  * Merged in MPEX-156 (pull request #67)
  * MPEX-156 handle session timeout upon errors
  * Merged in satellizer-fix (pull request #66)
  * satellizer-fix MPEX-194 fix the list template
  * Merged in satellizer-fix (pull request #65)
  * satellizer-fix MPEX-194 fix the loading spinner
  * Merged in MPEX-191 (pull request #64)
  * Merged in satellizer-fix (pull request #63)
  * MPEX-191:Reports cleanup and fix for list agents
  * satellizer-fix update login paths for reloads
  * satellizer-fix control popup for 500 504 bulk operations
  * satellizer-fix control popup error msg for bulk cashout
  * Update the application to test , build upstream
  * Merged in MPEX-191 (pull request #62)
  * User reports
  * Update the navigation item
  * Update the redundant secions
  * Removed redundancies
  * Merged in MPEX-191 (pull request #61)
  * Cardholder reports
  * Cashout reports, formatted date display
  * Merged in MPEX-191 (pull request #60)
  * MPEX-191: Cashout reports
  * Merged in feature-reports (pull request #59)
  * Resolve conflicts
  * Cashin reports: added rownumber
  * Cashin Reports with Pagination
  * Merged in MPEX-156 (pull request #58)
  * Merged in MPEX-183 (pull request #57)
  * Merged in MPEX-125 (pull request #56)
  * MPEX-156 MPEX-181 fix the satellizer configs
  * MPEX-183 remove redundant option text
  * MPEX-183 fix the role required attribute in agent create
  * MPEX-125 change in reset mail receipt endpoint fix for MPEX-98
  * MPEX-125 resolve conflicts and few updates
  * MPEX-125 Single cashout workflow client side files
  * MPEX-125 Single cashout server side files
  * Merged in MPEX-172 (pull request #55)
  * MPEX-172: Error handling for bulk cashout
  * MPEX-156 add satellizer library for client token mgmt
  * MPEX-156 remove phased out angular-storage bower lib
  * Merged in MPEX-167 (pull request #54)
  * MPEX-167 update request path in agent create controller
  * MPEX-167 update seed files for agents and limits
  * Merged in MPEX-167 (pull request #53)
  * Merged in MPEX-167 (pull request #52)
  * MPEX-167 add cardholders en json file
  * Merged in MPEX-167 (pull request #51)
  * Merge branch 'master' of https://bitbucket.org/matchmove/mpex-app into MPEX-167
  * MPEX-167 add acl.json file server side
  * Merged in MPEX-160 (pull request #49)
  * Merged in MPEX-198 (pull request #50)
  * MPEX-167 client side files for ACL
  * MPEX-167 server side file changes
  * Email for forgot password and new agent reset link
  * MPEX-160
  * Merged in MPEX-132 (pull request #48)
  * Update the validations for MPEX-132
