var Cashin = require('../models/Cashin');
var request = require('request');
var JSONError = require('../services/JSONError');



/**
 * POST /cashout data into DB
 */
exports.bulkCashinPost = function(req, res) {
  // Generate unique payment ref id
  var payment_ref_code = 1;
  console.log("PAYMENT REF CODE " + payment_ref_code);
  var now = new Date();
  payment_ref_code += now.getTime();
  // Validation
  if(typeof req.body.user_email !== 'undefined'){
    req.checkBody("user_email", 'required_field_empty:: Valid email required').notEmpty();
  }
  if (typeof req.body.user_mobile !== 'undefined'){
    req.checkBody("user_country_code", 'required_field_empty:: Valid mobile country code required').notEmpty();
    req.checkBody("user_mobile", 'required_field_empty:: Valid mobile required').notEmpty();
  }
  req.checkBody("amount", 'required_field_empty:: Valid amount required').notEmpty();
  
  // Sanitize
  var errors = req.validationErrors();
  if (errors) {
      var err = new JSONError(400, JSON.stringify(errors));
      
  }

  // Store record in DB
  var record_id = '';
  Cashin.forge().save({
    "user_country_code": req.body.user_country_code || null,
    "user_mobile": req.body.user_mobile || null,
    "user_email": req.body.user_email || null,
    "amount": req.body.amount,
    "hash_id": req.body.file_hash_id || null,
    "transaction_status":'submitted',
    "agent_id": req.logged_in_agent_id,
    "mpex_ref_id": payment_ref_code
  }).then(function(SaveResponse) {
      console.log("Insert success");
      res.send({data_insert:'first step done'});
  }).catch(function(SaveErr) {
//var err = new JSONError(400, JSON.stringify({message: 'data insert failed',error : SaveErr}));
       console.log("insert error" + SaveErr);
    });
 
};


/**
 *GET /cashout transaction
*/
 
exports.cashinGet = function(req, res) {
    
    Cashin.forge({'id': req.params.id}).fetch()
         .then(function(cashin) {
      res.send({"status" : cashin.get('transaction_status')});
    }, function(error){
      res.send(error);
    });

          
};


/**
 *PUT /update cashout transaction
*/
 
exports.cashinPut = function(req, res) {
  
  var cashin = new Cashin({ id: req.params.id});
  cashin.save({
      transaction_status: req.body.transaction_status,
      
    }, { patch: true })
  .then(function(data){
    return res.send({"message" : "Transaction updated"});
  });
}




