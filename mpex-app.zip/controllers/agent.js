/**
* Agents controller
*/
// include node libraries
var async = require('async');
var crypto = require('crypto');
var nodemailer = require('nodemailer');
var mandrillTransport = require('nodemailer-mandrill-transport');
var request = require('request');
var qs = require('querystring');
var config = require('config');

// include models
var Agent = require('../models/Agent');
var Limit = require('../models/Limit');
var bookshelf = require('../config/bookshelf');

var Agents = bookshelf.Collection.extend({
    model: Agent
  });

// include services and 3rd party Apps
var authService = require('../services/authentication');
var JSONError = require('../services/JSONError');

  /**
   * POST /login
   * Sign in with email and password
   */
  exports.loginPost = function(req, res, next) {
    req.assert('email', 'Email is not valid').isEmail();
    req.assert('email', 'Email cannot be blank').notEmpty();
    req.assert('password', 'Password cannot be blank').notEmpty();
    req.sanitize('email').normalizeEmail({ remove_dots: false });

    var errors = req.validationErrors();

    if (errors) {
      return res.status(400).send(errors);
    }

    Agent.forge()
      .query('where', 'email' , '=', req.body.email )
      .fetch({
          withRelated: ['limit']
        })
      .then(function(agent) {
        if (!agent) {
          return res.status(401).send({ msg: 'The email address ' + req.body.email + ' is not associated with any account. ' +
          'Double-check your email address and try again.'
          });
        }
        agent.comparePassword(req.body.password, function(err, isMatch) {
          if (!isMatch) {
            return res.status(401).send({ msg: 'Invalid email or password' });
          }
           var allowed_groups = [];
           var limits = agent.relations.limit.attributes;
          if (limits.card_holder_creation_allowed == '1'){
            allowed_groups.push('card_holder_creation_allowed_single');
            allowed_groups.push('card_holder_creation_allowed_bulk');
          }
          if (limits.cash_in_allowed == '1'){
            allowed_groups.push('cash_in_allowed_single');
            allowed_groups.push('cash_in_allowed_bulk');
          }
          if (limits.cash_out_allowed == '1'){
            allowed_groups.push('cash_out_allowed_single');
            allowed_groups.push('cash_out_allowed_bulk');
          }
          if (limits.agent_creation_allowed == '1'){
            allowed_groups.push('agent_creation_allowed')
          }
          var timestmp = new Date();
          var lst_login = timestmp.getFullYear() + ':' + (timestmp.getMonth()+1) + ':' + timestmp.getDate();
          lst_login += ' '+ timestmp.getHours() + ':' + timestmp.getMinutes() + ':' + timestmp.getSeconds();
          var lgn_count = (agent.attributes.login_count === null)? 1 : parseInt(agent.attributes.login_count) + 1;
          agent.set('login_count', lgn_count);
          agent.set('last_login', lst_login);
          agent.save(agent.changed, { patch: true })
            .then(function(updatedAgent) {
              res.send({ token: authService.generateToken(agent, allowed_groups), agent: agent.toJSON(), groups: allowed_groups});
            }, function(errorUpdate){
              var error = new JSONError(400, JSON.stringify(errorUpdate));
              next(error);
            });
        });
      });
  };

/**
 * POST /signup
 */
exports.signupPost = function(req, res, next) {
  req.assert('name', 'Name cannot be blank').notEmpty();
  req.assert('email', 'Email is not valid').isEmail();
  req.assert('email', 'Email cannot be blank').notEmpty();
  req.assert('password', 'Password must be at least 4 characters long').len(4);
  req.sanitize('email').normalizeEmail({ remove_dots: false });

  var errors = req.validationErrors();

  if (errors) {
    return res.status(400).send(errors);
  }

  new Agent({
    name: req.body.name,
    email: req.body.email,
    password: req.body.password
  }).save()
    .then(function(agent) {
        res.send({ token: authService.generateToken(agent), agent: agent });
    })
    .catch(function(err) {
      if (err.code === 'ER_DUP_ENTRY' || err.code === '23505') {
        return res.status(400).send({ msg: 'The email address you have entered is already associated with another account.' });
      }
    });
};


/**
 * PUT /account
 * Update profile information OR change password.
 */
exports.accountPut = function(req, res, next) {
  if ('password' in req.body) {
    req.assert('password', 'Password must be at least 4 characters long').len(4);
    req.assert('confirm', 'Passwords must match').equals(req.body.password);
  } else {
    req.assert('email', 'Email is not valid').isEmail();
    req.assert('email', 'Email cannot be blank').notEmpty();
    req.sanitize('email').normalizeEmail({ remove_dots: false });
  }

  var errors = req.validationErrors();

  if (errors) {
    return res.status(400).send(errors);
  }

  var agent = new Agent({ id: req.user.id });
  if ('password' in req.body) {
    agent.save({ password: req.body.password }, { patch: true });
  } else {
    agent.save({
      email: req.body.email,
      name: req.body.name,
      gender: req.body.gender,
      location: req.body.location,
      website: req.body.website
    }, { patch: true });
  }
  agent.fetch().then(function(agent) {
    if ('password' in req.body) {
      res.send({ msg: 'Your password has been changed.' });
    } else {
      res.send({ agent: agent, msg: 'Your profile information has been updated.' });
    }
    res.redirect('/account');
  }).catch(function(err) {
    if (err.code === 'ER_DUP_ENTRY') {
      res.status(409).send({ msg: 'The email address you have entered is already associated with another account.' });
    }
  });
};

/**
 * DELETE /account
 */
exports.accountDelete = function(req, res, next) {
  new Agent({ id: req.agent.id }).destroy().then(function(agent) {
    res.send({ msg: 'Your account has been permanently deleted.' });
  });
};

/**
 * GET /unlink/:provider
 */
exports.unlink = function(req, res, next) {
  new Agent({ id: req.agent.id })
    .fetch()
    .then(function(agent) {
      switch (req.params.provider) {
        case 'facebook':
          agent.set('facebook', null);
          break;
        case 'google':
          agent.set('google', null);
          break;
        case 'twitter':
          agent.set('twitter', null);
          break;
        case 'vk':
          agent.set('vk', null);
          break;
        default:
        return res.status(400).send({ msg: 'Invalid OAuth Provider' });
      }
      agent.save(agent.changed, { patch: true }).then(function() {
      res.send({ msg: 'Your account has been unlinked.' });
      });
    });
};

/**
 * POST /forgot
 */
exports.forgotPost = function(req, res, next) {
  //console.log("Forgot email " + req.body.email);
  req.assert('email', 'Email is not valid').isEmail();
  req.assert('email', 'Email cannot be blank').notEmpty();
  req.sanitize('email').normalizeEmail({ remove_dots: false });

  var errors = req.validationErrors();

  if (errors) {
    return res.status(400).send(errors);
  }

  async.waterfall([
    function(done) {
      crypto.randomBytes(16, function(err, buf) {
        var token = buf.toString('hex');
        done(err, token);
      });
    },
    function(token, done) {
     // console.log("email from client " + req.body.email);
      new Agent({ email: req.body.email })
        .fetch()
        .then(function(agent) {
          if (!agent) {
            return res.status(400).send({ msg: 'The email address ' + req.body.email + ' is not associated with any account.' });
          }
          agent.set('password_reset_token', token);
          agent.set('password_reset_expires', new Date(Date.now() + 86400000)); // expire in 1 day
          agent.save(agent.changed, { patch: true }).then(function() {
            done(null, token, agent.toJSON());
          });
        });
    },
    function(token, agent, done) {
      var transport = nodemailer.createTransport(mandrillTransport({
        auth: {
          apiKey: config.get('MANDRILL.API_KEY')
        }
      }));
      var resetEndpoint = config.get('APPLICATION_HOST') + config.get('MANDRILL.RESET_MAIL_RECEIPT_ENDPOINT');
      var mailOptions = {
        mandrillOptions: {
          template_name: config.get('MANDRILL.TEMPLATE_KEYS.REGISTRATION'),
          template_content: [{
                      "name": "MPEX Forgot password",
                      "content": ""
                  }],
          message:{
            "from_email": 'admin@mpex-matchmove.com',
            "to": [{
              "email": agent.email
            }],
            "subject": "Forgot Password - Reset your Password using the link provided",
            "merge": true,
            "merge_language": "mailchimp",
            "global_merge_vars": [{
                    "name": "TOKEN",
                    "content": token
                },
                {
                  "name": "ENDPOINT",
                  "content": resetEndpoint
                }],
            "tags": [
                "password-forgot"
            ],
          }
        }
      };

      transport.sendMail(mailOptions, function(err, info) {
          if (err) {
            var errRes = new JSONError(400, { statusText: JSON.stringify(err) });
            next(errRes);
          } else {
            res.status(200).send({"status": info.accepted.status});
          }
        });
    }
  ]);
};

/**
 * POST /auth/resetpassword
 */
exports.resetPost = function(req, res, next) {
  req.assert('password', 'Password must be at least 4 characters long').len(4);
  req.assert('confirm', 'Passwords must match').equals(req.body.password);

  var errors = req.validationErrors();

  if (errors) {
      return res.status(400).send(errors);
  }
  async.waterfall([
    function(done) {
      new Agent({ password_reset_token: req.params.token })
        //.where('password_reset_expires', '<', new Date())
        .where('password_reset_token', '=', req.params.token)
        .fetch()
        .then(function(agent) {
          if (!agent) {
          // return res.status(400).send({ statusText: 'Password reset token is invalid or has expired.' });
          var err = new JSONError(400, 'Password reset token is invalid or has expired.');
          next(err);
          }
          agent.set('password', req.body.password);
          agent.set('password_reset_token', null);
          agent.set('password_reset_expires', null);
          agent.save(agent.changed, { patch: true })
            .then(function(updatedAgent) {
              return res.status(200).send({statusText: "Your password was reset successfully!"})
            }, function(error){
              var err = new JSONError(400, JSON.stringify(error));
              next(err);
            });
        });
    }
  ]);
};
/**
   * GET agent/limits
   */
  exports.agentLimitsHandler = function(req, res, next){
    // VALIDATION
    req.assert('id', 'Userid cannot be empty and needs to be an integer').notEmpty().isInt();
    // SANITIZATION

    var errors = req.validationErrors();
    if (errors) {
        return res.status(400).send(errors);
    }
    var method = req.route.methods;
    if(method.get === true){
        // get handler here
        Limit.forge({'id': req.params.id}).fetch({
          withRelated: ['agent']
        }).then(function(limit) {
          res.send(limit);
        }, function(error){
          res.send(error);
        });
      }else if(method.post === true ){
         //console.log('POST');
        // post handler here
        Limit.forge().save(req.body).then(function(limit) {
          res.send(limit);
        }, function(error){
          res.send(error);
        });
      }else if(method.put === true ){
        //console.log('PUT');
        //put handler here
        Limit.forge({'id': req.params.id}).save(req.body).then(function(limit) {
          res.send(limit);
        }, function(error){
          res.send(error);
        });
      }
    };

  /**
   * Agent Create/Update Handler
   */


  exports.agentHandler = function(req, res, next){
    var method = req.route.methods;

    req.body.agent.created_agent_id = req.logged_in_agent_id;

      if(method.get === true){
        // get handler here
        Agents.forge()
          .query('where', 'id', '=', req.params.id)
          .fetch({
          withRelated: ['limit']
        })
          .then(function (collection) {
            res.json({error: false, data: collection.toJSON()});
          })
          .catch(function (err) {
            res.status(500).json({error: true, data: {message: err.message}});
          });
      }else if(method.post === true){
        //console.log(req.headers);
        // VALIDATION
        req.checkBody("agent.email", 'required_field_empty:: Valid email required').notEmpty();
        req.checkBody("agent.email", 'field_invalid_format:: Valid email required').isEmail();
        req.checkBody("agent.user_role", 'required_field_empty:: user Role is required').notEmpty();
        req.checkBody("agent.last_name", 'required_field_empty:: last Name is required').notEmpty();
        req.checkBody("agent.first_name", 'required_field_empty:: first Name is required').notEmpty();

        // SANITIZATION
        req.sanitize(req.body.agent.email).normalizeEmail({ remove_dots: false });
        // Handle errors
        var errors = req.validationErrors();
        if (errors) {
            return res.status(400).send(errors);
        }

        // post handler here
        // save new agent and his associated limits
        // generate passwordreset token
        // store the reset token expiry into DB
        // send mail
        async.waterfall([
          function(done){
            // save agent
            Agent.forge().save(req.body.agent)
              .then(function(agent){
                done(null, agent.toJSON())
              })
          },
          function(agent, done){
            // save limits
            req.body.limit.agent_id = agent.id;
            Limit.forge().save(req.body.limit)
            .then(function(limit){
              done(null, agent, limit.toJSON());
            })
          },
          function(agent, limits, done){
            // generate token
            crypto.randomBytes(16, function(err, buf) {
                var token = buf.toString('hex');
                done(err, agent, limits, token);
              });
          },
          function(agent, limits, token, done){
            // save token expiry in DB and send mail
            new Agent({ email: req.body.agent.email })
              .fetch()
              .then(function(fetchedAgent) {
                fetchedAgent.set('password_reset_token', token);
                fetchedAgent.set('password_reset_expires', new Date(Date.now() + (3600000*24))); // expire in 1 day
                fetchedAgent.save(fetchedAgent.changed, { patch: true }).then(function() {
                  var expiryupdated = true;
                  done(null, agent, limits, token, expiryupdated);
                });
              });
          },
          function(agent, limits, token, expiryupdated, done){
            var transport = nodemailer.createTransport(mandrillTransport({
                auth: {
                  apiKey: config.get('MANDRILL.API_KEY')
                }
              }));
              var resetEndpoint = config.get('APPLICATION_HOST') + config.get('MANDRILL.RESET_MAIL_RECEIPT_ENDPOINT');
              var mailOptions = {
                mandrillOptions: {
                  template_name: config.get('MANDRILL.TEMPLATE_KEYS.REGISTRATION'),
                  template_content: [{
                      "name": "MPEX New Agent resistration",
                      "content": ""
                  }],
                  message:{
                    "from_email": 'admin@mpex-matchmove.com',
                    "to": [{
                      "email": agent.email
                    }],
                    "subject": "New Agent Registration - Reset your Password",
                    "merge": true,
                    "merge_language": "mailchimp",
                    "global_merge_vars": [{
                            "name": "TOKEN",
                            "content": token
                        },
                        {
                          "name": "ENDPOINT",
                          "content": resetEndpoint
                        }],
                    "tags": [
                        "password-resets"
                    ],
                  }
                },
              };

              transport.sendMail(mailOptions, function(err, info) {
                  if (err) {
                     var errRes = new JSONError(400, { statusText: JSON.stringify(err) });
                      next(errRes);
                  } else {
                    // console.log(info);
                    res.status(200).send(info)
                  }
                });
          }
        ]);
      }
  }

/**
 * POST /validate agent
 */
exports.validateAgent = function(req, res, next) {
  req.assert('email', 'Email is not valid').isEmail();
  req.assert('email', 'Email cannot be blank').notEmpty();
  //req.assert('mobile', 'Mobile cannot be blank').notEmpty();
  req.sanitize('email').normalizeEmail({ remove_dots: false });

  var errors = req.validationErrors();

  if (errors) {
    return res.status(400).send(errors);
  }

  new Agent({ email: req.body.email })
      .fetch()
      .then(function(agent) {
        if (!agent) {
          return res.status(401).send({ msg: 'The email address ' + req.body.email + ' is not associated with any account. ' +
          'Double-check your email address and try again.'
          });
        }
        res.send({ agent: agent.toJSON() });
      });
};
