var Cashout = require('../models/Cashout');
var request = require('request');



/**
 * POST /cashout data into DB
 */
exports.cashoutPost = function(req, res) {
  new Cashout({
    "user_country_code": req.body.user_country_code,
    "user_mobile": req.body.user_mobile,
    "user_email": req.body.user_email,
    "amount": req.body.amount,
    "description":req.body.description,
    "file_hash_id": req.body.file_hash_id,
    "transaction_status":req.body.transaction_status
  }).save()
    .then(function(res) {
        res.send({message: 'data insert success'});
    })
    .catch(function(err) {
        res.send({message: 'data insert failed',error : err});
    });

  
};


/**
 *GET /cashout transaction
*/
 
exports.cashoutGet = function(req, res) {
   res.send({transactionStatus : "success"});
  
          
};


/**
 *PUT /update cashout transaction
*/
 
exports.cashoutPut = function(req, res) {
  
  var cashout = new Cashout({ id: req.params.id});
  cashout.save({
      transaction_status: req.body.transaction_status,
      
    }, { patch: true })
  .then(function(data){
    return res.send({"message" : "Transaction updated"});
  });
}




