'use strict';

var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');

var $ = require('gulp-load-plugins')({
    pattern: ['gulp-*', 'main-bower-files', 'uglify-save-license', 'del']
});

gulp.task('config', function () {
    gulp.src(['config.*.json'])
        .pipe($.ngConstant({
            templatePath: "gulp/config.tpl.ejs"
        }))
        .pipe($.removeContent({ match: "import angular from 'angular';" }))
        .pipe($.removeContent({ match: "const env = " }))
        .pipe($.removeContent({ match: "export default env;" }))
        .pipe($.removeEmptyLines())
        .pipe($.concat('tmpConfig.js'))
        .pipe($.rename('index.constants.js'))        
        .pipe(gulp.dest(conf.paths.src +'/app/'));
});