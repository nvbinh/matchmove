var crypto = require('crypto');
var bcrypt = require('bcrypt-nodejs');
var bookshelf = require('../config/bookshelf');

var Activity = bookshelf.Model.extend({
  tableName: 'activities',
  user: function() {
    return this.belongsTo(User);
  },

  getActivity: function(id, activity_type, items_per_page , page) {
    if (typeof id !== 'undefined' && id.length) {
      return new Activity({'activity_id': id})
        .fetch()
        .then(function(model) {
          console.log(model.get('activity_name'));
        });
    } else {
      return new Activity()
        .fetchAll()
        .then(function(model) {
          console.log(model.get('activity_name'));
        });
    }
  },

  writeActivity: function (id, activity_type , data) {
    if (typeof id === 'undefined' || id.length < 0) {
      return;
    }
    if (typeof activity_type === 'undefined' || activity_type.length < 0) {
      return;
    }
    if (typeof data === 'undefined' || data === null) {
      return;
    }
    return new Activity({'user_id': id, 'activity_type': activity_type, 'date_time': data.date_time, 'ip': data.ip, 'detail': data.detail}).save().then(function(model) {
      console.log(model);
    });
  }

});

module.exports = Activity;
