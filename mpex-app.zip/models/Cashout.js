var bookshelf = require('../config/bookshelf');
var Agent = require('./Agent');
var Hash = require('./Hash');

var Cashout = bookshelf.Model.extend({
  tableName: 'cashouts',
  hasTimestamps: true,
  agent: function(){
    return this.belongsTo(Agent);
  },
  hash: function(){
    return this.belongsTo(Hash);
  }

});
module.exports = Cashout;