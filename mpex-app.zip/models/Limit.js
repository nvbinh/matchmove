var bookshelf = require('../config/bookshelf');
var Agent = require('./Agent');
bookshelf.plugin('registry');

var Limit = bookshelf.Model.extend({
  tableName: 'limits',
  hasTimestamps: true,
  agent: function() {
    return this.belongsTo('Agent');
  }
});

module.exports = bookshelf.model('Limit', Limit);
