var bookshelf = require('../config/bookshelf');
var Agent = require('./Agent');
var Hash = require('./Hash');

var Cashin = bookshelf.Model.extend({
  tableName: 'cashins',
  hasTimestamps: true,
  agent: function(){
    return this.belongsTo(Agent);
  },
  hash: function(){
  	return this.belongsTo(Hash);
  }

});
module.exports = Cashin;
