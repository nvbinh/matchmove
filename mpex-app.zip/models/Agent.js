var crypto = require('crypto');
var bcrypt = require('bcrypt-nodejs');
var bookshelf = require('../config/bookshelf');
var Limit = require('./Limit');
var Hash = require('./Hash');
var Cashin = require('./Cashin');
var Cashout = require('./Cashout');
var Cardholder = require('./Cardholder');
bookshelf.plugin('registry');

var Agent = bookshelf.Model.extend({
  tableName: 'agents',
  hasTimestamps: true,
  limit: function(){
    return this.hasOne('Limit');
  },
  hash: function(){
    return this.hasMany('Hash');
  },
  cashin: function(){
    return this.hasMany('Cashin');
  },
  cashout: function(){
    return this.hasMany('Cashout');
  },
  cardholder: function(){
    return this.hasMany('Cardholder');
  },

  initialize: function() {
    this.on('saving', this.hashPassword, this);
  },

  hashPassword: function(model, attrs, options) {
    var password = options.patch ? attrs.password : model.get('password');
    if (!password) { return; }
    return new Promise(function(resolve, reject) {
      bcrypt.genSalt(10, function(err, salt) {
        bcrypt.hash(password, salt, null, function(err, hash) {
          if (options.patch) {
            attrs.password = hash;
          }
          model.set('password', hash);
          resolve();
        });
      });
    });
  },

  comparePassword: function(password, done) {
    var model = this;
    bcrypt.compare(password, model.get('password'), function(err, isMatch) {
      done(err, isMatch);
    });
  },

  hidden: ['password', 'passwordResetToken', 'passwordResetExpires', 'updated_at'],

  virtuals: {
    // gravatar: function() {
    //   if (!this.get('email')) {
    //     return 'https://gravatar.com/avatar/?s=200&d=retro';
    //   }
    //   var md5 = crypto.createHash('md5').update(this.get('email')).digest('hex');
    //   return 'https://gravatar.com/avatar/' + md5 + '?s=200&d=retro';
    // }
  }
});

module.exports = bookshelf.model('Agent',Agent);
