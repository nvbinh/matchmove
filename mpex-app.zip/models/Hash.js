var bookshelf = require('../config/bookshelf');
var Agent = require('./Agent');
var Cashin = require('./Cashin');
var Cashout = require('./Cashout');
var Cardholder = require('./Cardholder');

var Hash = bookshelf.Model.extend({
  tableName: 'hashes',
  hasTimestamps: true,
  agent: function() {
    return this.belongsTo(Agent);
  },
  cashin: function(){
  	return this.hasMany(Cashin);
  },
  cashout: function(){
  	return this.hasMany(Cashout);
  },
  cardholder: function(){
  	return this.hasMany(Cardholder);
  }
});

module.exports = Hash;
