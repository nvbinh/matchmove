var crypto = require('crypto');
var bcrypt = require('bcrypt-nodejs');
var bookshelf = require('../config/bookshelf');
var Agent = require('./Agent');
var Hash = require('./Hash');

var Cardholder = bookshelf.Model.extend({
  tableName: 'cardholders',
  hasTimestamps: true,
  agent: function(){
    return this.belongsTo(Agent);
  },
  hash: function(){
    return this.belongsTo(Hash);
  },
  initialize: function() {
    this.on('saving', this.hashPassword, this);
  },

  hashPassword: function(model, attrs, options) {
    var password = options.patch ? attrs.password : model.get('password');
    if (!password) { return; }
    return new Promise(function(resolve, reject) {
      bcrypt.genSalt(10, function(err, salt) {
        bcrypt.hash(password, salt, null, function(err, hash) {
          if (options.patch) {
            attrs.password = hash;
          }
          model.set('password', hash);
          resolve();
        });
      });
    });
  },

  hidden: ['password', 'error'],

  virtuals: {
    // gravatar: function() {
    //   if (!this.get('email')) {
    //     return 'https://gravatar.com/avatar/?s=200&d=retro';
    //   }
    //   var md5 = crypto.createHash('md5').update(this.get('email')).digest('hex');
    //   return 'https://gravatar.com/avatar/' + md5 + '?s=200&d=retro';
    // }
  }

});

module.exports = Cardholder;
