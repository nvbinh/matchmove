exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cardholders', function(table){
      table.string('card_proxy_number');
    })
  ])
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cardholders', function(table){

      knex.schema.hasColumn('cardholders', 'card_proxy_number') .then(function (exists)
      {
        if(exists)
        {
        table.dropColumn('card_proxy_number');
        }
      })
    })
  ])
};
