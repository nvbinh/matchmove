exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('users')
  ])
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.createTable('users', function(table) {
      table.increments('id').primary();
      table.string('firstName');
      table.string('lastName');
      table.string('email').unique();
      table.string('password');
      table.string('passwordResetToken');
      table.dateTime('passwordResetExpires');
      table.dateTime('lastLogin');
      table.string('loginCount');
      table.string('gender');
      table.string('location');
      table.string('picture');
      table.string('userRole');
      table.timestamps();
    })
  ]);
};
