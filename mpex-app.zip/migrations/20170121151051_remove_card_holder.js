
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('card_holder')
  ])
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.createTable('card_holder', function(table){
      table.increments('id').primary();
      table.string('email');
      table.string('first_name');
      table.string( 'last_name' );
      table.string('preferred_name');
      table.integer('mobile');
      table.string('password');
      table.string('status');
      table.string('filehash_id');
      table.timestamps();
    })
  ]);
};
