exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.createTable('agents', function(table) {
      table.increments('id').primary();
      table.string('first_name');
      table.string('last_name');
      table.string('email').unique();
      table.string('password');
      table.string('password_reset_token');
      table.dateTime('password_reset_expires');
      table.dateTime('last_login');
      table.string('login_count');
      table.integer('agent_id').unsigned().references('agents.id');
      table.string('gender');
      table.string('location');
      table.string('picture');
      table.string('user_role');
      table.timestamps();
    })
  ]);
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('agents')
  ])
};
