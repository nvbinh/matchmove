
exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('cardholders')
  ])
};
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.createTable('cardholders', function(table){
      table.increments('id').primary();
      table.string('email');
      table.string('first_name');
      table.string( 'last_name' );
      table.string('preferred_name');
      table.string('mobile_country_code');
      table.string('mobile');
      table.string('response_code');
      table.text('response_text');
      table.integer('hash_id').unsigned().nullable().references('hashes.id');
      table.integer('agent_id').unsigned().references('agents.id');
      table.timestamps();
    })
  ]);
};

