
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cardholders', function(table){
      table.string('user_state');
    })
  ])
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cardholders', function(table){

      knex.schema.hasColumn('cardholders', 'user_state') .then(function (exists)
      {
        if(exists)
        {
        table.dropColumn('user_state');
        }
      })
    })
  ])  
};
