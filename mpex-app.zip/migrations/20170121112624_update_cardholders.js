
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cardholders', function(table){
      table.string('user_type');
    })
  ])
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cardholders', function(table){

      knex.schema.hasColumn('cardholders', 'user_type') .then(function (exists)
      {
        if(exists)
        {
        table.dropColumn('user_type');
        }
      })
    })
  ])  
};
