exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('cashout')
  ])
};

exports.down = function(knex, Promise) {
    return Promise.all([
        knex.schema.createTable('cashout', function(table) {
        table.increments();
        table.string('user_country_code');
        table.string('user_mobile');
        table.string('user_email');
        table.string('amount');
        table.string('description');
        table.string('file_hash_id');
        table.string('transaction_status');
        
        })
    ]);
};
