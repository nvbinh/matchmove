
exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('cashins')
  ])
};
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.createTable('cashins', function(table) {
      table.increments('id').primary();
      table.string('user_country_code');
      table.string('user_mobile');
      table.string('user_email');
      table.string('amount');
      table.string('response_code');
      table.text('response_text');
      table.string('mpex_ref_id');
      table.string('ih_ref_id');
      table.integer('hash_id').unsigned().nullable().references('hashes.id');
      table.integer('agent_id').unsigned().references('agents.id');
      table.timestamps();
    })
  ]);
};

