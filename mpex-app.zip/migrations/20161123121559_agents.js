
exports.up = function(knex, Promise) {
   return Promise.all([
    knex.schema.table('agents', function(table){
      table.dropForeign('agent_id');
      table.dropColumn('agent_id');
      table.integer('created_agent_id').unsigned().references('agents.id');
      table.string('created_agent_email');

    })
  ])
};

exports.down = function(knex, Promise) {
    return Promise.all([
        knex.schema.table('agents', function(table){
           table.dropForeign('created_agent_id');
          table.dropColumn('created_agent_id');
          table.dropColumn('created_agent_email');
        })
  ])
};
