
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cashins', function(table){
      table.string('category');
      table.integer('card_load');
    })
  ])
};

exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.table('cashins', function(table){
      table.dropColumn('category');
      table.dropColumn('card_load');
    })
  ])
};
