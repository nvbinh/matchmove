exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('limits')
  ])
};
exports.up = function(knex, Promise) {
  return Promise.all([
    knex.schema.createTable('limits', function(table){
      table.increments('id').primary();
      table.string('agent_creation_allowed');
      table.string('card_holder_creation_allowed');
      table.string( 'cash_in_allowed' );
      table.string('cash_out_allowed');
      table.json('details');
      table.integer('agent_id').unsigned().references('agents.id');
      table.timestamps();
    })
  ]);
};


