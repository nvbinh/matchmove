
exports.down = function(knex, Promise) {
  return Promise.all([
    knex.schema.dropTable('hashes')
  ])
};
exports.up = function(knex, Promise) {
   return Promise.all([
    knex.schema.createTable('hashes', function(table){
      table.increments('id').primary();
      table.integer('agent_id').unsigned().references('agents.id');
      table.string('record_hash');
      table.string('record_status');
      table.timestamps();
    })
  ]);
};

