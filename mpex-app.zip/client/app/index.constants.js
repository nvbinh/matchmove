(function ()
{
    'use strict';
    angular
        .module('admin')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('CLIENT_ID', "f3d259ddd3ed8ff3843839b")
        .constant('CLIENT_SECRET', "4c7f6f8fa93d59c45502c0ae8c4a95b")
        .constant('GRANT_TYPE', "password")
        .constant('BRANDING', {"name":"MatchMove","colorPrimary":"#09f","colorAccent":"#09f","logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"})
        .constant('CSV_UPLOAD_FILE_PARAMS', {"FILE_SIZE":"8388608","ALLOWED_FILE_TYPES":["text/csv","application/vnd.ms-excel","application/csv"]})
})();

(function ()
{
    'use strict';
    angular
        .module('app.actions.cashin')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"Flexm","colorPrimary":"#3582a9","colorAccent":"#3582a9","logo":"https://vcard-assets.s3.amazonaws.com/sg/assets/multi-card-flexm/img/logo-v2-white.png"})
        .constant('CASHIN', {"LOAD_TO_CARD_SUPPORT":true,"LOAD_TO_CARD_OPTIONAL":true,"FUND_CATEGORY_SUPPORT":true,"FUND_CATEGORIES":[{"category_code":"HAVGOLD","category_description":"Havells Gold Incentive"},{"category_code":"HAVTRAVEL","category_description":"Havells Travel Incentive"}]})
        .constant('CASHIN_BULK', {"RESPONSE_FIELDS":{"mobile_country_code":{"display":"no"},"mobile":{"display":"yes"},"email":{"display":"yes"},"amount":{"display":"yes"},"status":{"display":"no"},"statusText":{"display":"yes"}}})
})();

(function ()
{
    'use strict';
    angular
        .module('app.actions.cashout')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"MatchMove","colorPrimary":"#09f","colorAccent":"#09f","logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"})
        .constant('CASHOUT', {"CARD_UNLOAD_SUPPORT":true,"CARD_UNLOAD_OPTIONAL":true,"FUND_CATEGORY_SUPPORT":true,"FUND_CATEGORIES":[{"category_code":"HAVGOLD","category_description":"Havells Gold Incentive"},{"category_code":"HAVTRAVEL","category_description":"Havells Travel Incentive"}]})
        .constant('CASHOUT_BULK', {"RESPONSE_FIELDS":{"mobile_country_code":{"display":"no"},"mobile":{"display":"yes"},"email":{"display":"yes"},"amount":{"display":"yes"},"status":{"display":"no"},"statusText":{"display":"yes"}}})
})();

(function ()
{
    'use strict';
    angular
        .module('app.actions.CreateWalletUser')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"Havells","colorPrimary":"#fff","colorAccent":"#fff","logo":"https://vcard-assets.s3.amazonaws.com/in/assets/havells/img/app/logo.png"})
        .constant('CARDHOLDER_CREATE', {"SIGNUP_TYPE":"email","CARD_CREATION_ON_WALLET":"no","USER_STATE":"post","USER_TYPE":[{"code":"Indian","description":"Indian National"},{"code":"Foreigner","description":"Foreign National"}],"RESPONSE_FIELDS":{"email":{"display":"yes"},"first_name":{"display":"yes"},"last_name":{"display":"yes"},"preferred_name":{"display":"no"},"mobile_country_code":{"display":"no"},"mobile":{"display":"yes"},"status":{"display":"no"},"statusText":{"display":"yes"}},"RESPONSE_FIELDS_MOBILEONLY":{"email":{"display":"no"},"first_name":{"display":"yes"},"last_name":{"display":"yes"},"preferred_name":{"display":"no"},"mobile_country_code":{"display":"no"},"mobile":{"display":"yes"},"password":{"display":"no"},"status":{"display":"no"},"statusText":{"display":"yes"}}})
})();

(function ()
{
    'use strict';
    angular
        .module('app.auth')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"MatchMove","colorPrimary":"#09f","colorAccent":"#09f","logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"})
})();

(function ()
{
    'use strict';
    angular
        .module('app.auth.login')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"MatchMove","colorPrimary":"#09f","colorAccent":"#09f","logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"})
})();

(function ()
{
    'use strict';
    angular
        .module('app.users.create')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"MatchMove","colorPrimary":"#09f","colorAccent":"#09f","logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"})
        .constant('AGENT_PASSWORD', "Mmg@123456")
        .constant('DEFAULT_LIMITS', {"CASH_IN":{"LIFETIME":{"VALUE":1000000,"COUNT":10000},"MONTHLY":{"VALUE":100000,"COUNT":1000},"WEEKLY":{"VALUE":10000,"COUNT":100},"DAILY":{"VALUE":1000,"COUNT":10}},"CASH_OUT":{"LIFETIME":{"VALUE":1000000,"COUNT":10000},"MONTHLY":{"VALUE":100000,"COUNT":1000},"WEEKLY":{"VALUE":10000,"COUNT":100},"DAILY":{"VALUE":1000,"COUNT":10}},"CARDHOLDER_CREATE":{"LIFETIME":{"VALUE":0,"COUNT":5000},"MONTHLY":{"VALUE":0,"COUNT":500},"WEEKLY":{"VALUE":0,"COUNT":50},"DAILY":{"VALUE":0,"COUNT":5}}})
})();

(function ()
{
    'use strict';
    angular
        .module('app.users')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"MatchMove","colorPrimary":"#09f","colorAccent":"#09f","logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"})
})();

(function ()
{
    'use strict';
    angular
        .module('app.core')
        .constant('API_BASE', "http://localhost:8081/api/v1/")
        .constant('BRANDING', {"name":"Havells","colorPrimary":"#fff","colorAccent":"#fff","logo":"https://vcard-assets.s3.amazonaws.com/in/assets/havells/img/app/logo.png"})
        .constant('INPUT_FIELD_SPECS', {"CASH_OUT":[{"field_name":"MOBILE_COUNTRY_CODE","field_reqd":"no","field_validation":"\\d{2,2}"},{"field_name":"MOBILE","field_reqd":"no","field_validation":"\\d{10,10}"},{"field_name":"EMAIL","field_reqd":"no","field_validation":"[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"},{"field_name":"AMOUNT","field_reqd":"yes","field_validation":"\\d{1,10}"},{"field_name":"DESCRIPTION","field_reqd":"no","field_validation":""}],"CASH_IN":[{"field_name":"MOBILE_COUNTRY_CODE","field_reqd":"no","field_validation":"\\d{2,2}"},{"field_name":"MOBILE","field_reqd":"no","field_validation":"[\\d]{10,10}"},{"field_name":"EMAIL","field_reqd":"no","field_validation":"[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"},{"field_name":"AMOUNT","field_reqd":"yes","field_validation":"\\d{1,10}"},{"field_name":"DESCRIPTION","field_reqd":"no","field_validation":""}],"CARDHOLDER_CREATE":[{"field_name":"EMAIL","field_reqd":"yes","field_validation":"[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"},{"field_name":"FIRST_NAME","field_reqd":"yes","field_validation":"[a-zA-Z\\s]{1,25}"},{"field_name":"LAST_NAME","field_reqd":"yes","field_validation":"[a-zA-Z\\s]{1,25}"},{"field_name":"PREFERRED_NAME","field_reqd":"yes","field_validation":"[a-zA-Z\\s]{1,25}"},{"field_name":"MOBILE_COUNTRY_CODE","field_reqd":"yes","field_validation":"\\d{2,2}"},{"field_name":"MOBILE","field_reqd":"yes","field_validation":"\\d{10,10}"},{"field_name":"USER_TYPE","field_reqd":"yes","field_validation":"(Foreigner|Indian)"}],"CARDHOLDER_CREATE_MOBILEONLY":[{"field_name":"FIRST_NAME","field_reqd":"yes","field_validation":"[a-zA-Z\\s]{1,25}"},{"field_name":"LAST_NAME","field_reqd":"yes","field_validation":"[a-zA-Z\\s]{1,25}"},{"field_name":"PREFERRED_NAME","field_reqd":"yes","field_validation":"[a-zA-Z\\s]{1,25}"},{"field_name":"MOBILE_COUNTRY_CODE","field_reqd":"yes","field_validation":"\\d{2,2}"},{"field_name":"MOBILE","field_reqd":"yes","field_validation":"[\\d]{10,10}"}]})
})();
