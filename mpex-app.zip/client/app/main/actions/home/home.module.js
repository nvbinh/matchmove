(function ()
{
    'use strict';

    angular
        .module('app.actions.home', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.actions_home', {
            url      : '/actions/home',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/home/home.html',
                    controller : 'HomeController as vm'
                }
            },
            resolve  : {
                Home   : function (msApi)
                {
                    return msApi.resolve('home.dashboard@get');
                }
            },
            bodyClass: 'profile'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/dashboard/home');

        // Api
        msApiProvider.register('home.dashboard', ['app/data/e-commerce/dashboard.json']);
        msApiProvider.register('home.products', ['app/data/e-commerce/products.json']);
        msApiProvider.register('home.product', ['app/data/e-commerce/product.json']);
        msApiProvider.register('home.orders', ['app/data/e-commerce/orders.json']);
        msApiProvider.register('home.statuses', ['app/data/e-commerce/statuses.json']);
        msApiProvider.register('home.order', ['app/data/e-commerce/order.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('dashboard.home', {
            title : 'Home',
            icon  : 'icon-account',
            state : 'app.actions_home',
            weight: 6
        });
    }

})();
