(function ()
{
    'use strict';

    angular
        .module('app.actions.cashin', [])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, API_BASE)
    {
        $stateProvider.state('app.actions.cashin',{
            url      : '/cashin',
            abstract: true,
            bodyClass: 'cashin'
        });

        $stateProvider.state('app.actions.cashin.single',{
            url      : '/single',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/cashin/cashin-single.html',
                    controller : 'CashinController as vm'
                }
            },
            bodyClass: 'cashin',
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('cash_in_allowed_single')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            }
        });

        $stateProvider.state('app.actions.cashin.bulk',{
            url      : '/bulk',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/cashin/cashin-bulk.html',
                    controller : 'CashinController as vm'
                }
            },
            bodyClass: 'cashin',
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('cash_in_allowed_bulk')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            }
        });

         //msAPI
        msApiProvider.register('app.actions.cashin.bulk', [ API_BASE + 'cashinEPbulk']);
        // msApiProvider.register('app.actions_cashin_bulk/:id', [ API_BASE + 'cashin/bulk/:id',{id:'@id'}]);
        msApiProvider.register('app.actions.cashin.single', [ API_BASE + 'cashinEP']);
        //msApiProvider.register('app.actions_cashout/:id',[API_BASE +'cashout/:id',{id:1}]);
        msApiProvider.register('app.actions.cashin/:id',[API_BASE +'cashin/:id',{id:'@id'}]);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/actions/cashin');
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
