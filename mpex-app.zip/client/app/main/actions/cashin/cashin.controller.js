(function () {
  'use strict';

  angular
    .module('app.actions.cashin')
    .controller('CashinController', CashinController);

  /** @ngInject */
  function CashinController($translate, md5, msApi, $mdDialog, $state, $timeout, CASHIN_BULK, CASHIN, CSV_UPLOAD_FILE_PARAMS, INPUT_FIELD_SPECS, $filter, mmErrorFormatter, msNavigationService, AclService) {
    var vm = this;
    var fileHash = "";
    vm.cashIn = {};
    vm.cashIn.type = true; // type false represents phone number input, true > email input
    vm.postData = {};
    vm.submitClicked = false;
    vm.response = {};
    vm.filteredResponse = [];
    vm.configCashin = angular.fromJson(CASHIN_BULK);
    vm.configCashinAdditional = angular.fromJson(CASHIN);
    if (vm.configCashinAdditional.LOAD_TO_CARD_SUPPORT) {
      vm.loadToCardSupport = vm.configCashinAdditional.LOAD_TO_CARD_SUPPORT;
      vm.loadToCardSupportOptional = vm.configCashinAdditional.LOAD_TO_CARD_OPTIONAL;
      if (vm.loadToCardSupport && !vm.loadToCardSupportOptional) {
        vm.cashIn.card_load = 1;
      }
    }
    if (vm.configCashinAdditional.FUND_CATEGORY_SUPPORT) {
      vm.fundCategorySupport = vm.configCashinAdditional.FUND_CATEGORY_SUPPORT;
      if (vm.fundCategorySupport) {
        vm.fundCategories = vm.configCashinAdditional.FUND_CATEGORIES;
      }
    }
    vm.responseFields = vm.configCashin.RESPONSE_FIELDS;
    vm.csvUploadFileParams = angular.fromJson(CSV_UPLOAD_FILE_PARAMS);
    vm.setValidationParams = setValidationParams();
    vm.displayFields = [];
    vm.submitResults = false;

    angular.forEach(vm.responseFields, function (val, key) {
      if (val.display === 'yes') {
        this.push($filter('uppercase')(key));
      }
    }, vm.displayFields);
    vm.validData = true;
    vm.errorMessage = "";
    vm.fileSelected = false;
    vm.csv = {
      operation: 'CASH_IN', // CASH_OUT, CASH_IN, CARDHOLDER_CREATE
      content: null,
      header: false,
      headerVisible: false,
      enclosingQuotes: true,
      separator: ',',
      separatorVisible: false,
      result: null,
      encoding: 'ISO-8859-1',
      encodingVisible: false,
      acceptSize: vm.csvUploadFileParams.FILE_SIZE,
      allowedTypes: vm.csvUploadFileParams.ALLOWED_FILE_TYPES
    };

    // Public facing functions
    vm.acceptTypeCallback = acceptTypeCallback;
    vm.CsvHandler = CsvHandler;
    vm.cashinSingleSubmit = cashinSingleSubmit;
    vm.pageReload = pageReload;

    function acceptTypeCallback(retObj) {
      //error in the file uploaded, display message
      vm.validData = false;
      vm.errorMessage = retObj.errorMessage;

    }

    function pageReload() {
      $timeout(function () {
        $state.go('.', {}, { reload: true })
      }, 500);
    }

    function CsvHandler() {
      resetFlags();
      var now = new Date();
      fileHash = md5.createHash(vm.csv.result.filename + now.getTime());
      if (!vm.csv.result.validdata) {
        vm.errorMessage = $translate.instant('CASHIN.BULK.INVALID_RECORDS');
      }
    }

    function resetFlags() {
      vm.errorMessage = "";
      vm.submitClicked = false;
    }

    vm.cashinBulkSubmit = function (fileJson) {
      vm.submitClicked = true;
      vm.progressIndicator = true;
      var cashinArr = [];
      for (var i = 0; i < fileJson.length; i++) {
        var cashinObj = {};
        if (fileJson[i].data) {
          for (var j = 0; j < fileJson[i].data.length; j++) {
            cashinObj[fileJson[i].data[j].fld_name.toLowerCase()] = fileJson[i].data[j];
          }
          cashinArr.push(cashinObj);
        }
      }
      processTransaction(cashinArr);
    }

    function processTransaction(cashinArr) {

      msApi.request('app.actions.cashin.bulk@save', { data: cashinArr, hash_id: fileHash, decoded: { role: 'cash_in_allowed_bulk' } },
        function (response) {
          vm.progressIndicator = false;
          vm.submitResults = true;
          for (var item in response.results) {
            response.results[item].statusText.value = mmErrorFormatter.statusMessage(response.results[item].status.value, response.results[item].statusText.value);
          }
          angular.forEach(response.results, function (value, key) {
            this.push(angular.merge(value, vm.responseFields));
          }, vm.filteredResponse);

        }, function (error) {
          vm.progressIndicator = false;
          vm.loginPath = '.';
          var textmsg = mmErrorFormatter.statusMessage(error.status, error.statusText);
          vm.progressIndicator = false;
          if (error.status === 401) {
            $mdDialog.show(
              $mdDialog.alert()
                .parent(angular.element(document.querySelector('#popupContainer')))
                .clickOutsideToClose(function () {
                  $mdDialog.hide();
                })
                .title($translate.instant('CASHIN.BULK.TITLE'))
                .textContent(textmsg)
                .ariaLabel('Bulk cashin Failure Dialog')
                .ok('OK')
                .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
            );
            $timeout(function () {
              $state.go('app.auth_login', {}, { reload: true })
            }, 5000);
          }
        });
    }

    function cashinSingleSubmit() {
      vm.progressIndicator = true;

      vm.postData = {};
      vm.postData.user_email = vm.cashIn.user_email;
      vm.postData.user_mobile = vm.cashIn.user_mobile;
      vm.postData.user_country_code = vm.cashIn.user_country_code;
      vm.postData.amount = vm.cashIn.amount;
      if (vm.cashIn.card_load) {
        vm.postData.card_load = vm.cashIn.card_load;
      }
      if (vm.cashIn.category) {
        vm.postData.category = vm.cashIn.category;
      }

      msApi.request('app.actions.cashin.single@save',
        { data: vm.postData, decoded: { role: 'cash_in_allowed_single' } },
        function (response) {
          vm.progressIndicator = false;
          $mdDialog.show(
            $mdDialog.alert()
              .parent(angular.element(document.querySelector('#popupContainer')))
              .clickOutsideToClose(function () {
                $mdDialog.hide();
              })
              .title($translate.instant('CASHIN.SINGLE.TITLE'))
              .textContent($translate.instant('CASHIN.SINGLE.SUCCESS.200'))
              .ariaLabel('CashIn Single Success Dialog')
              .ok('Got it!')
              .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
          );
          $timeout(function () {
            $state.go('.', {}, { reload: true })
          }, 5000);
        }, function (error) {
          var textmsg = mmErrorFormatter.statusMessage(error.status, error.statusText);
          vm.progressIndicator = false;
          $mdDialog.show(
            $mdDialog.alert()
              .parent(angular.element(document.querySelector('#popupContainer')))
              .clickOutsideToClose(function () {
                $mdDialog.hide();
              })
              .title($translate.instant('CASHIN.SINGLE.TITLE'))
              .textContent(textmsg)
              .ariaLabel('CashIn Single Failure Dialog')
              .ok('OK')
              .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
          );
          $timeout(function () {
            $state.go('.', {}, { reload: true })
          }, 5000);
        });
    }

    function setValidationParams() {
      //var validationParams= angular.fromJson(INPUT_FIELD_SPECS).CASH_IN;
      vm.validationPattern = {};
      vm.validationPattern.email = getFieldValidation("email");
      vm.validationPattern.countryCode = getFieldValidation("mobile_country_code");
      vm.validationPattern.mobile = getFieldValidation("mobile");
      vm.validationPattern.amount = getFieldValidation("amount");

    }

    function getFieldValidation(fieldName) {
      var validationParams = angular.fromJson(INPUT_FIELD_SPECS).CASH_IN;
      for (var i = 0; i < validationParams.length; i++) {
        if (validationParams[i].field_name.toLowerCase() === fieldName) {
          return validationParams[i].field_validation;
        }

      }
    }
  }
})();
