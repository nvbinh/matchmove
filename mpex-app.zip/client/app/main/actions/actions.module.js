(function ()
{
    'use strict';

    angular
        .module('app.actions', [
            'app.actions.CreateWalletUser',
            'app.actions.cashin',
            'app.actions.cashout',
            'app.actions.home',
            'angular-storage',
            'mm.acl',
            'ngFileUpload',
            'md.data.table',
            'angular-md5'
        ])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider, msNavigationServiceProvider, $translatePartialLoaderProvider)
    {
        $stateProvider.state('app.actions',{
            url      : '/actions',
            abstract: true,
            bodyClass: 'cashin',
            resolve: {
                auth: function($auth, $q, $state){
                   if( !$auth.isAuthenticated()){
                       return $q.reject('Unauthorized');
                   }
                },
                'acl' : function($q, AclService, store){
                    var aclData = {
                        groups: store.get('groups')
                    };
                    AclService.setAbilities(aclData);
                    AclService.attachRole('groups');
                }
            }
        });
        // Navigation
        msNavigationServiceProvider.saveItem('actions', {
            title : 'ACTIONS',
            group : true,
            weight: 3
        });
        $translatePartialLoaderProvider.addPart('app/core/services/mm-error-formatter');
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
