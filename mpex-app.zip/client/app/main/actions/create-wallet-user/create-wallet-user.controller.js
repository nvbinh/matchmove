(function () {
  'use strict';

  // register the controller as CreateWalletUserController
  angular
    .module('app.actions.CreateWalletUser')
    .controller('CreateWalletUserController', CreateWalletUserController);

  /**
   * CreateWalletUserController constructor
   */
  function CreateWalletUserController($mdDialog, $translate, msApi, $timeout, $state, CARDHOLDER_CREATE, CSV_UPLOAD_FILE_PARAMS, $filter, md5, mmErrorFormatter, INPUT_FIELD_SPECS) {
    var vm = this;
    vm.fileHash = "";
    
    // view model bindings
    vm.title = 'create-wallet-user';
    vm.basicForm = {};
    vm.response = {};
    vm.filteredResponse = [];
    vm.cardCreateAllowed = false;
    vm.configCardHolder = angular.fromJson(CARDHOLDER_CREATE);

    // vm.configCardHolder.SIGNUP_TYPE 
    // supports two values 
    // - email  : The user will use email to login
    // - mobile : The user will use mobile number to login
    if (vm.configCardHolder.SIGNUP_TYPE === 'mobile') {
      vm.responseFields = vm.configCardHolder.RESPONSE_FIELDS_MOBILEONLY;
    }
    else {
      vm.responseFields = vm.configCardHolder.RESPONSE_FIELDS;
    }

    // vm.configCardHolder.CARD_CREATION_ON_WALLET 
    // supports three values 
    // - yes      : It means for all records creation of proxy number for creation of physical card is a mandate
    // - no       : It means that for all recrods creation of proxy number for creation of physical card wont be required
    // - optional : It means that its the operator's choice as to whether a particular record requires card creation or not.
    if (vm.configCardHolder.CARD_CREATION_ON_WALLET === 'yes' || vm.configCardHolder.CARD_CREATION_ON_WALLET === 'optional') {
      vm.cardCreateAllowed = true;
    }

    // vm.configCardHolder.USER_TYPE 
    // Optional config which if defined means that the user can be of multiple Types like local , foreigner or any other client specifc types that exists
    // Currently supported configurations are indian and foreigner for india stack only
    if(vm.configCardHolder.USER_TYPE) {
      vm.userTypeEnabled = true;
      vm.userTypesAvailable = vm.configCardHolder.USER_TYPE;
    }

    if(vm.configCardHolder.USER_STATE) {
      switch (vm.configCardHolder.USER_STATE) {
        case 'pre':
            vm.userState = 'pre_kyc';
            break;
        case 'post':
            vm.userState = 'post_kyc';
            break;
        case 'optional':
            vm.userState = 'optional';
            vm.basicForm.user_state = 'post_kyc';
            break;
      }
    }

    vm.csvUploadFileParams = angular.fromJson(CSV_UPLOAD_FILE_PARAMS);
    vm.displayFields = [];
    vm.submitResults = false;
    vm.setValidationParams = setValidationParams();

    angular.forEach(vm.responseFields, function (val, key) {
      if (val.display === 'yes') {
        this.push($filter('uppercase')(key));
      }
    }, vm.displayFields);
    // exit;
    vm.validData = true;
    vm.errorMessage = "";
    vm.fileSelected = false;
    vm.csv = {
      content: null,
      header: false,
      headerVisible: false,
      enclosingQuotes: true,
      separator: ',',
      separatorVisible: false,
      result: null,
      encoding: 'ISO-8859-1',
      encodingVisible: false,
      acceptSize: vm.csvUploadFileParams.FILE_SIZE,
      allowedTypes: vm.csvUploadFileParams.ALLOWED_FILE_TYPES
    };
    if (vm.configCardHolder.SIGNUP_TYPE === 'mobile') {
      vm.csv.operation = 'CARDHOLDER_CREATE_MOBILEONLY';
    }
    else {
      vm.csv.operation = 'CARDHOLDER_CREATE';
    }

    // public API
    vm.CsvHandler = CsvHandler;
    vm.buildJson = buildJson;
    vm.acceptTypeCallback = acceptTypeCallback;
    vm.reset = reset;
    vm.submitFileJson = submitFileJson;
    vm.submitCreateWalletUserSingle = submitCreateWalletUserSingle;
    vm.pageReload = pageReload;

    // Method implementations

    function reset() {
      vm.errorMessage = "";
      //vm.csv.result = null;
      vm.validData = true;
    }

    function pageReload() {
      $timeout(function () {
        $state.go('.', {}, { reload: true })
      }, 500);
    }

    //called only when file valid and submit clicked
    function submitFileJson(fileJson) {
      var cardholder = vm.buildJson(fileJson);
      vm.progressIndicator = true;


      msApi.request('app.actions.CreateWalletUser.bulk@save', { data: cardholder, hash_id: vm.fileHash, decoded: { role: 'card_holder_creation_allowed_bulk' } }, function (response) {
        vm.progressIndicator = false;
        vm.submitResults = true;
        for (var item in response.results) {
          response.results[item].statusText.value = mmErrorFormatter.statusMessage(response.results[item].status.value, response.results[item].statusText.value);
        }
        angular.forEach(response.results, function (value, key) {
          this.push(angular.merge(value, vm.responseFields));
        }, vm.filteredResponse);
      }, function (error) {
        var textmsg = mmErrorFormatter.statusMessage(error.status, error.statusText);
        vm.progressIndicator = false;
        if (error.status === 401) {
          $mdDialog.show(
            $mdDialog.alert()
              .parent(angular.element(document.querySelector('#popupContainer')))
              .clickOutsideToClose(function () {
                $mdDialog.hide();
              })
              .title($translate.instant('CREATE_WALLET_USER.BULK.TITLE'))
              .textContent(textmsg)
              .ariaLabel('Wallet User Bulk Failure Dialog')
              .ok('OK')
              .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
          );
          $timeout(function () {
            $state.go('app.auth_login', {}, { reload: true })
          }, 5000);
        }

      })
    }

    function buildJson(fileJson) {
      var cardHolderArr = [];
      if (vm.configCardHolder.SIGNUP_TYPE === 'mobile') {
        for (var i = 0; i < fileJson.length; i++) {
          if (fileJson[i].data) {
            var carholder = {};
            carholder.first_name = fileJson[i].data[0];
            carholder.last_name = fileJson[i].data[1];
            carholder.preferred_name = fileJson[i].data[2];
            carholder.mobile_country_code = fileJson[i].data[3];
            carholder.mobile = fileJson[i].data[4];
            if(vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET !== 'no') {
              carholder.user_type = fileJson[i].data[5];
              carholder.user_state = fileJson[i].data[6];
              carholder.card_proxy_number = fileJson[i].data[7];
            } else if(vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_type = fileJson[i].data[5];
              carholder.user_state = fileJson[i].data[6];
            } else if(vm.userTypeEnabled && vm.userState !== 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_type = fileJson[i].data[5];
              carholder.user_state = {"fld_name":"USER_STATE","value":vm.userState};
            } else if(vm.userTypeEnabled && vm.userState !== 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET !== 'no') {
              carholder.user_type = fileJson[i].data[5];
              carholder.user_state = {"fld_name":"USER_STATE","value":vm.userState};
              carholder.card_proxy_number = fileJson[i].data[6];
            } else if(!vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET !== 'no') {
              carholder.user_state = fileJson[i].data[5];
              carholder.card_proxy_number = fileJson[i].data[6];
            } else if(!vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_state = fileJson[i].data[5];
            } else if(!vm.userTypeEnabled && vm.userState !== 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_state = {"fld_name":"USER_STATE","value":vm.userState};
            } else if(!vm.userTypeEnabled && vm.userState !== 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET !== 'no') {
              carholder.user_state = {"fld_name":"USER_STATE","value":vm.userState};
              carholder.card_proxy_number = fileJson[i].data[5];
            }
            
            // if(vm.configCardHolder.CARD_CREATION_ON_WALLET ==
            
            cardHolderArr.push(carholder);
          }
        }
      }
      else {
        for (var i = 0; i < fileJson.length; i++) {
          if (fileJson[i].data) {
            var carholder = {};
            carholder.email = fileJson[i].data[0];
            carholder.first_name = fileJson[i].data[1];
            carholder.last_name = fileJson[i].data[2];
            carholder.preferred_name = fileJson[i].data[3];
            carholder.mobile_country_code = fileJson[i].data[4];
            carholder.mobile = fileJson[i].data[5];
            if(vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET !== 'no') {
              carholder.user_type = fileJson[i].data[6];
              carholder.user_state = fileJson[i].data[7];
              carholder.card_proxy_number = fileJson[i].data[8];
            } else if(vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_type = fileJson[i].data[6];
              carholder.user_state = fileJson[i].data[7];
            } else if(vm.userTypeEnabled && vm.userState !== 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_type = fileJson[i].data[6];
              carholder.user_state = {"fld_name":"USER_STATE","value":vm.userState};
            } else if(!vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET !== 'no') {
              carholder.user_state = fileJson[i].data[6];
              carholder.card_proxy_number = fileJson[i].data[7];
            } else if(!vm.userTypeEnabled && vm.userState === 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_state = fileJson[i].data[6];
            } else if(!vm.userTypeEnabled && vm.userState !== 'optional' && vm.configCardHolder.CARD_CREATION_ON_WALLET === 'no') {
              carholder.user_state = {"fld_name":"USER_STATE","value":vm.userState};
            }
            cardHolderArr.push(carholder);
          }
        }
      }
      return cardHolderArr;
    }


    function acceptTypeCallback(retObj) {
      //error in the file uploaded, display message
      vm.validData = false;
      vm.errorMessage = retObj.errorMessage;

    }


    function CsvHandler() {
      var now = new Date();
      vm.fileHash = md5.createHash(vm.csv.result.filename + now.getTime());
      if (!vm.csv.result.validdata) {
        vm.errorMessage = $translate.instant('CREATE_WALLET_USER.BULK.INVALID_RECORDS');
      }
      else {
        vm.errorMessage = "";
      }
    }

    function submitCreateWalletUserSingle() {
      vm.progressIndicator = true;
      vm.postData = {};
      vm.postData.email = vm.basicForm.email;
      vm.postData.first_name = vm.basicForm.first_name;
      vm.postData.last_name = vm.basicForm.last_name;
      vm.postData.preferred_name = vm.basicForm.preferred_name;
      vm.postData.mobile = vm.basicForm.mobile
      vm.postData.mobile_country_code = vm.basicForm.mobile_country_code;
      if(vm.configCardHolder.USER_STATE) {
        switch (vm.configCardHolder.USER_STATE) {
          case 'pre':
              vm.postData.user_state = 'pre_kyc';
              break;
          case 'post':
              vm.postData.user_state = 'post_kyc';
              break;
          case 'optional':
              vm.postData.user_state = vm.basicForm.user_state;
              break;
        }
      }

      if(vm.configCardHolder.USER_TYPE) {
        vm.postData.user_type = vm.basicForm.user_type;
      }

      if (vm.cardCreateAllowed && typeof (vm.basicForm.card_proxy_number) !== 'undefined') {
        vm.postData.card_proxy_number = "PY" + vm.basicForm.card_proxy_number;
      }

      msApi.request('app.actions.CreateWalletUser.single@save', { data: vm.postData, decoded: { role: 'card_holder_creation_allowed_single' } }, function (response) {
        vm.progressIndicator = false;
        $mdDialog.show(
          $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(function () {
              $mdDialog.hide();
            })
            .title($translate.instant('CREATE_WALLET_USER.SINGLE.TITLE'))
            .textContent($translate.instant('CREATE_WALLET_USER.SINGLE.SUCCESS.200'))
            .ariaLabel('Wallet User Single Success Dialog')
            .ok($translate.instant('CREATE_WALLET_USER.SINGLE.LABEL.OK'))
            .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
        );
        $timeout(function () {
          $state.go('.', {}, { reload: true })
        }, 5000);
      }, function (error) {
        var textmsg = mmErrorFormatter.statusMessage(error.status, error.statusText);
        vm.progressIndicator = false;
        $mdDialog.show(
          $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(function () {
              $mdDialog.hide();
            })
            .title($translate.instant('CREATE_WALLET_USER.SINGLE.TITLE'))
            .textContent(textmsg)
            .ariaLabel('Wallet User Single Failure Dialog')
            .ok('OK')
            .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
        );
        $timeout(function () {
          $state.go('.', {}, { reload: true })
        }, 5000);
      })
    }

    function setValidationParams() {
      var validationParams = [];
      if (vm.configCardHolder.SIGNUP_TYPE === 'mobile') {
        validationParams = angular.fromJson(INPUT_FIELD_SPECS).CARDHOLDER_CREATE_MOBILEONLY;
      }
      else {
        validationParams = angular.fromJson(INPUT_FIELD_SPECS).CARDHOLDER_CREATE;
      }
      vm.validationPattern = {};
      for (var i = 0; i < validationParams.length; i++) {
        if (validationParams[i].field_name.toLowerCase() === "email") {
          vm.validationPattern.email = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "first_name") {
          vm.validationPattern.firstName = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "last_name") {
          vm.validationPattern.lastName = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "preferred_name") {
          vm.validationPattern.prefName = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "mobile_country_code") {
          vm.validationPattern.countryCode = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "mobile") {
          vm.validationPattern.mobile = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "user_state") {
          vm.validationPattern.user_state = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "user_type") {
          vm.validationPattern.user_type = new RegExp('^' + validationParams[i].field_validation + '$');
        }
        else if (validationParams[i].field_name.toLowerCase() === "card_proxy_number") {
          vm.validationPattern.card_proxy_number = new RegExp('^' + validationParams[i].field_validation + '$');
        }

      }
    }

  }

})();
