(function ()
{
    'use strict';

    angular
        .module('app.actions.CreateWalletUser', [])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, API_BASE)
    {
 
        $stateProvider.state('app.actions.CreateWalletUser',{
            url      : '/create-wallet-user',
            abstract: true,
            bodyClass: 'profile'
        });

        $stateProvider.state('app.actions.CreateWalletUser.single', {
            url      : '/single',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/create-wallet-user/create-wallet-user-single.html',
                    controller : 'CreateWalletUserController as vm'
                }
            },

            bodyClass: 'profile',
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('card_holder_creation_allowed_single')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            }
        })
        .state('app.actions.CreateWalletUser.bulk', {
            url      : '/bulk',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/create-wallet-user/create-wallet-user-bulk.html',
                    controller : 'CreateWalletUserController as vm'
                }
            },

            bodyClass: 'profile',
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('card_holder_creation_allowed_bulk')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            }
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/actions/create-wallet-user');
        $translatePartialLoaderProvider.addPart('app/core/directives/mm-csv-parser');
        // Api
        // msApiProvider.register('app.actions_CreateWalletUser_bulk', [API_BASE + 'process-json']);
        msApiProvider.register('app.actions.CreateWalletUser.single', [API_BASE + 'walletuserEP']);
        msApiProvider.register('app.actions.CreateWalletUser.bulk', [API_BASE + 'walletuserEPBulk']);
        
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
