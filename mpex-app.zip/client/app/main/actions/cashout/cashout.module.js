(function ()
{
    'use strict';

    angular
        .module('app.actions.cashout', [])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, API_BASE)
    {
        $stateProvider.state('app.actions.cashout',{
            url      : '/cashout',
            abstract : true,
            bodyClass: 'cashout'
        });
        $stateProvider.state('app.actions.cashout.single',{
            url      : '/single',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/cashout/cashout-single.html',
                    controller : 'CashoutController as vm'
                }
            },
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('cash_out_allowed_single')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            },
            bodyClass: 'cashout'
        });
        $stateProvider.state('app.actions.cashout.bulk',{
            url      : '/bulk',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/actions/cashout/cashout-bulk.html',
                    controller : 'CashoutController as vm'
                }
            },
            bodyClass: 'cashout',
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('cash_out_allowed_bulk')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            }
        });

         //msAPI
        msApiProvider.register('app.actions.cashout.single', [ API_BASE + 'cashoutEP', null, {'getOTP': {'method':'POST'}, 'verifyOTP': {'method':'PUT'}}]);
        msApiProvider.register('app.actions.cashout.bulk', [ API_BASE + 'cashoutEPBulk']);
        //msApiProvider.register('app.actions_cashout/:id',[API_BASE +'cashout/:id',{id:1}]);
        // msApiProvider.register('app.actions_cashout/:id',[API_BASE +'cashout/:id',{id:'@id'}]);


        // Translation
        $translatePartialLoaderProvider.addPart('app/main/actions/cashout');
        $translatePartialLoaderProvider.addPart('app/core/directives/mm-csv-parser');
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
