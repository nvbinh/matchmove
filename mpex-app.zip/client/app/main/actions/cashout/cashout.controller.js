(function ()
{
    'use strict';

    angular
        .module('app.actions.cashout')
        .controller('CashoutController', CashoutController);

    /** @ngInject */
    function CashoutController($scope, md5, msApi, $translate, $mdDialog, $state, $timeout, CASHOUT_BULK, CSV_UPLOAD_FILE_PARAMS, $filter, mmErrorFormatter, store,INPUT_FIELD_SPECS){
      var vm = this;
      vm.displayStatus = false;
      vm.transInProgress = false;
      var fileHash = "";
      vm.cashOut = {};
      vm.cashOutOTP = {};
      vm.cashOut.type = true; // type false represents phone number input, true represents email input
      vm.postData = {};
      vm.response = {};
      vm.filteredResponse = [];
      vm.configCashout = angular.fromJson(CASHOUT_BULK);
      vm.responseFields = vm.configCashout.RESPONSE_FIELDS;
      vm.csvUploadFileParams = angular.fromJson(CSV_UPLOAD_FILE_PARAMS);
      vm.displayFields = [];
      vm.submitResults = false;
      vm.setValidationParams = setValidationParams();

      

      angular.forEach(vm.responseFields, function(val, key){
        if(val.display === 'yes'){
          this.push($filter('uppercase')(key));
        }
      }, vm.displayFields);

      vm.validData = true;
      vm.errorMessage = "";
      vm.fileSelected = false;
      vm.csv = {
            operation: 'CASH_OUT', // CASH_OUT, CASH_IN, CARDHOLDER_CREATE
            content: null,
            header: false,
            headerVisible: false,
            enclosingQuotes: true,
            separator: ',',
            separatorVisible: false,
            result: null,
            encoding: 'ISO-8859-1',
            encodingVisible: false,
            acceptSize: vm.csvUploadFileParams.FILE_SIZE,
            allowedTypes: vm.csvUploadFileParams.ALLOWED_FILE_TYPES
        };

      // Public API
      vm.acceptTypeCallback = acceptTypeCallback;
      vm.CsvHandler = CsvHandler;
      vm.cashoutSingleSubmit = cashoutSingleSubmit;
      vm.submitOtp = submitOtp;
      vm.pageReload = pageReload;

      function acceptTypeCallback(retObj){
        //error in the file uploaded, display message
        vm.validData = false;
        vm.errorMessage = retObj.errorMessage;

      }

      function CsvHandler(){
        var now = new Date();
          fileHash = md5.createHash(vm.csv.result.filename + now.getTime());
          if(!vm.csv.result.validdata) {
            vm.errorMessage = $translate.instant('CASHOUT.BULK.INVALID_RECORDS');
          }
          else {
            vm.errorMessage = "";
          }
      }

     vm.submitData = function(fileJson){
        vm.submitClicked = true;
        vm.progressIndicator = true;
        var cashoutArr = [];
        for (var i = 0; i < fileJson.length; i++) {
          var cashout = {};
          if (fileJson[i].data) {
            for (var j=0; j<fileJson[i].data.length;j++)
            {
            cashout[(fileJson[i].data[j].fld_name).toLowerCase()] = fileJson[i].data[j];

            }
            cashout.file_hash_id = fileHash;
            cashout.transaction_status = "Submitted";
            cashoutArr.push(cashout);
           }
        }
        processTransaction(cashoutArr);
      }

      function pageReload(){
        $timeout(function(){
            $state.go('.', {}, {reload:true})
        }, 500);
      }

      function processTransaction(cashoutArr)
      {

         msApi.request('app.actions.cashout.bulk@save', {data: cashoutArr, hash_id:fileHash, decoded: {role: 'cash_out_allowed_bulk'}},
          function(response){
            vm.progressIndicator = false;
             vm.submitResults = true;
             for (var item in response.results)
            {
              response.results[item].statusText.value= mmErrorFormatter.statusMessage(response.results[item].status.value,response.results[item].statusText.value);
            }
             angular.forEach(response.results, function(value, key){
                this.push(angular.merge( value, vm.responseFields));
             }, vm.filteredResponse);

            },function(error){
             vm.progressIndicator = false;
             vm.loginPath = '.';
              var textmsg = mmErrorFormatter.statusMessage(error.status,error.statusText);
              vm.progressIndicator = false;
              if (error.status === 401){
                $mdDialog.show(
                  $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(function(){
                        $mdDialog.hide();
                    })
                    .title($translate.instant('CASHOUT.BULK.TITLE'))
                    .textContent(textmsg)
                    .ariaLabel('Bulk cashout Failure Dialog')
                    .ok('OK')
                    .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
                );
                $timeout(function(){
                    $state.go('app.auth_login', {}, {reload:true})
                }, 4000);
              }
            });
      }

  function submitOtp(otp){
     // $mdDialog.hide(otp, {'vm.otpProgressIndicator': true});

     if (otp !== 'Cancelled'){
        vm.otpProgressIndicator = true;
      msApi.request('app.actions.cashout.single@verifyOTP',
        {data: {token: store.get('token'), otp: vm.cashOutOTP.otp.toString(), record_id: store.get('record_id')},
         decoded:{"role": "cash_out_allowed_single"}},
        function(verifyOTPResponse){
          vm.otpProgressIndicator = false;
          $mdDialog.show(
            $mdDialog.alert()
              .parent(angular.element(document.querySelector('#popupContainer')))
              .clickOutsideToClose(function(){
                  $mdDialog.hide();
              })
              .title($translate.instant('CASHOUT.SINGLE.TITLE'))
              .textContent($translate.instant('CASHOUT.SINGLE.SUCCESS.200'))
              .ariaLabel('Cashout Single Success Dialog')
              .ok('Got it!')
              .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
          );
          $timeout(function(){
            $state.go('.', {}, {reload:true})
          }, 5000);
        },
        function(verifyOTPError){
          var textmsg =  mmErrorFormatter.statusMessage(verifyOTPError.status,verifyOTPError.statusText);
          vm.otpProgressIndicator = false;
          $mdDialog.show(
            $mdDialog.alert()
              .parent(angular.element(document.querySelector('#popupContainer')))
              .clickOutsideToClose(function(){
                  $mdDialog.hide();
              })
              .title($translate.instant('CASHOUT.SINGLE.TITLE'))
              .textContent(textmsg)
              .ariaLabel('CashOut Single Failure Dialog')
              .ok('OK')
              .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
          );
          $timeout(function(){
            $state.go('.', {}, {reload:true})
        }, 5000);
        })
     } else{
        // handle the OTP cancel button click
          var textmsg = mmErrorFormatter.statusMessage(400, 'agent_cancelled_otp_dialog');
          vm.parentProgressIndicator = false;
              $mdDialog.show(
                $mdDialog.alert()
                  .parent(angular.element(document.querySelector('#popupContainer')))
                  .clickOutsideToClose(function(){
                      $mdDialog.hide();
                  })
                  .title($translate.instant('CASHOUT.SINGLE.TITLE'))
                  .textContent(textmsg)
                  .ariaLabel('CashOut Single Failure Dialog')
                  .ok('OK')
                  .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
              );
              $timeout(function(){
                $state.go('.', {}, {reload:true})
            }, 5000);
     }

  }

    /**
    * Function for single cashout workflow
    *
    */
    function cashoutSingleSubmit(){
        vm.postData = {};
        vm.postData.email = vm.cashOut.email;
        vm.postData.mobile = vm.cashOut.mobile;
        vm.postData.mobile_country_code = vm.cashOut.mobile_country_code;
        vm.postData.amount = vm.cashOut.amount;
        vm.parentProgressIndicator = true;
        msApi.request('app.actions.cashout.single@getOTP',
          {data: vm.postData, decoded: {"role": "cash_out_allowed_single"} },
          function(postResponse){
            store.set('token', angular.fromJson(postResponse).statusText.token);
            store.set('record_id', angular.fromJson(postResponse).statusText.record_id);
            vm.parentProgressIndicator = false;
            // show a popup dialog for capturing the OTP
            $mdDialog.show({
                scope: $scope,
                fullscreen:true,
                templateUrl: 'cashout-otp.html',
                clickOutsideToClose: false
              }
            ).then(function(otp) {
                // handle the otp verify in submitOTP fn
            }, function(er) {});
          }, function(error){
            var textmsg =  mmErrorFormatter.statusMessage(error.status,error.statusText);
            vm.parentProgressIndicator = false;
                  $mdDialog.show(
                    $mdDialog.alert()
                      .parent(angular.element(document.querySelector('#popupContainer')))
                      .clickOutsideToClose(function(){
                          $mdDialog.hide();
                      })
                      .title($translate.instant('CASHOUT.SINGLE.TITLE'))
                      .textContent(textmsg)
                      .ariaLabel('CashOut Single Failure Dialog')
                      .ok('OK')
                      .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
                  );
                  $timeout(function(){
                    $state.go('.', {}, {reload:true})
                }, 5000);
          });
    }

    function setValidationParams(){
      vm.countryCodePattern = getFieldValidation("mobile_country_code");
      vm.mobilePattern = getFieldValidation("mobile");
    }

    function getFieldValidation(fieldName)
    {
        var validationParams= angular.fromJson(INPUT_FIELD_SPECS).CASH_OUT;
        for (var i=0; i<validationParams.length;i++)
          {
            if(validationParams[i].field_name.toLowerCase() === fieldName)
            {
              return validationParams[i].field_validation;
            }
          
          }
    }

    };
})();
