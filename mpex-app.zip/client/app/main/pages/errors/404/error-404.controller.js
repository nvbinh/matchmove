(function ()
{
    'use strict';

    angular
        .module('app.pages.error-404')
        .controller('Error404Controller', Error404Controller);

    /** @ngInject */
    function Error404Controller()
    {
        // Data

        // Methods

        //////////
    }
})();