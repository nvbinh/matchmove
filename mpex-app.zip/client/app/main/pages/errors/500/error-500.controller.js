(function ()
{
    'use strict';

    angular
        .module('app.pages.error-500')
        .controller('Error500Controller', Error500Controller);

    /** @ngInject */
    function Error500Controller()
    {
        // Data

        // Methods

        //////////
    }
})();