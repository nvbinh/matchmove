(function () {
  'use strict';

  // register the controller as CardholdersController
  angular
    .module('app.reports.cardholders')
    .controller('CardholdersController', CardholdersController);

  /**
   * CardholdersController constructor
   */
  function CardholdersController(msApi, $filter, $translate, mmErrorFormatter, CARDHOLDER_CREATE) {
    var vm = this;
    vm.limitOptions = [5, 10, 25, 50, 100];
    vm.page = 1;
    vm.limit = 5;
    vm.options = {
      rowSelection: true,
      multiSelect: true,
      autoSelect: true,
      decapitate: false,
      largeEditDialog: false,
      boundaryLinks: false,
      limitSelect: true,
      pageSelect: true
    };
    vm.configCardHolder = angular.fromJson(CARDHOLDER_CREATE);
    if (vm.configCardHolder.CARD_CREATION_ON_WALLET === 'yes' || vm.configCardHolder.CARD_CREATION_ON_WALLET === 'optional') {
      vm.displayCardProxy = true;
    }

    vm.getData = getData;
    getData();

    function getData() {
      var offset_val = (vm.page - 1) * vm.limit;
      msApi.request('app.reports_cardholders@get',
        { limit: vm.limit, offset: offset_val, from_date: '2010-01-01', to_date: new Date().toISOString },
        function (response) {
          if (response.data !== null && response.data.length > 0) {
            for (var i = 0; i < response.data.length; i++) {
              response.data[i].id = (i + 1) + offset_val;
              response.data[i].response_text = mmErrorFormatter.statusMessage(response.data[i].response_code, response.data[i].response_text);
              response.data[i].created_at = $filter('date')(response.data[i].created_at, 'dd/MM/yyyy');
              response.data[i].updated_at = $filter('date')(response.data[i].updated_at, 'dd/MM/yyyy');
            }
            vm.cardholderList = response.data;
            vm.totalRecords = response.recordDetails[0].totalRecs;
            vm.header = getTableHeaders(Object.keys(vm.cardholderList[0]));
          }
          else {
            vm.processedDataisEmpty = true;
          }
        },
        function (error) {
          console.log("error " + angular.toJson(error));
        }

      );

    } //end function getData

    function getTableHeaders(keys) {
      var tableHeaders = [];
      for (var i = 0; i < keys.length; i++) {
        switch (keys[i]) {
          case "id":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.ID'));
            break;
          case "email":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.EMAIL'));
            break;
          case "first_name":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.FIRST_NAME'));
            break;
          case "last_name":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.LAST_NAME'));
            break;
          case "preferred_name":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.PREFERRED_NAME'));
            break;
          case "mobile_country_code":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.COUNTRY_CODE'));
            break;
          case "mobile":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.MOBILE_NUMBER'));
            break;
          case "user_type":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.USER_TYPE'));
            break;
          case "user_state":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.USER_STATE'));
            break;
          case "response_code":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.RESPONSE_CODE'));
            break;
          case "response_text":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.RESPONSE_TEXT'));
            break;
          case "agent_id":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.AGENT_ID'));
            break;
          case "agents_email":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.AGENT_EMAIL'));
            break;
          case "created_at":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.CREATED_DATE'));
            break;
          case "updated_at":
            tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.LAST_UPDATED_DATE'));
            break;
          case "card_proxy_number":
            if (vm.displayCardProxy) {

              tableHeaders.push($translate.instant('CARDHOLDER_REPORTS.TABLE_HEADER.CARD_PROXY_NUMBER'));
            }
            break;
          default:
            tableHeaders.push(keys[i]);
        }

      }
      return tableHeaders;

    } //end getTableHeaders
  }

})();
