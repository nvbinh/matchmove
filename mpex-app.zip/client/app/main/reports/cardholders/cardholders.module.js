(function ()
{
    'use strict';

    angular
        .module('app.reports.cardholders', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, API_BASE)
    {
        $stateProvider.state('app.reports.cardholders', {
            url      : '/cardholders',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/reports/cardholders/cardholders.html',
                    controller : 'CardholdersController as vm'
                }
            },
            resolve  : {
               
            },
            bodyClass: 'profile'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/reports/cardholders');

        // Api
        msApiProvider.register('app.reports_cardholders', [API_BASE + 'reports/cardholders']);
      
        // Navigation
        
    }

})();
