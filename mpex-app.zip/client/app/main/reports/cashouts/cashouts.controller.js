(function () {
  'use strict';

  // register the controller as CashoutsController
  angular
    .module('app.reports.cashouts')
    .controller('CashoutsController', CashoutsController);

  /**
   * CashoutsController constructor
   */
  function CashoutsController(msApi, $filter, $translate, mmErrorFormatter) {
    var vm = this;
    vm.limitOptions = [5, 10, 25, 50, 100];
    vm.page = 1;
    vm.limit = 5;
    vm.options = {
      rowSelection: true,
      multiSelect: true,
      autoSelect: true,
      decapitate: false,
      largeEditDialog: false,
      boundaryLinks: false,
      limitSelect: true,
      pageSelect: true
    };

    vm.getData = getData;
    getData();

    function getData() {
      var offset_val = (vm.page - 1) * vm.limit;
      msApi.request('app.reports_cashouts@get',
        { limit: vm.limit, offset: offset_val, from_date: '2010-01-01', to_date: new Date().toISOString },
        function (response) {
          if (response.data !== null && response.data.length > 0) {
            for (var i = 0; i < response.data.length; i++) {
              response.data[i].id = (i + 1) + offset_val;
              response.data[i].response_text = mmErrorFormatter.statusMessage(response.data[i].response_code, response.data[i].response_text);
              response.data[i].created_at = $filter('date')(response.data[i].created_at, 'dd/MM/yyyy');
              response.data[i].updated_at = $filter('date')(response.data[i].updated_at, 'dd/MM/yyyy');
            }
            vm.cashoutList = response.data;
            var test = angular.toJson(response.recordDetails);
            vm.totalRecords = response.recordDetails[0].totalRecs;
            vm.header = getTableHeaders(Object.keys(vm.cashoutList[0]));
          }
          else {
            vm.processedDataisEmpty = true;
          }
        },
        function (error) {
          console.log("error");
        }

      );

    } //end function getData

    function getTableHeaders(keys) {
      var tableHeaders = [];
      for (var i = 0; i < keys.length; i++) {
        switch (keys[i]) {
          case "id":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.ID'));
            break;
          case "user_country_code":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.COUNTRY_CODE'));
            break;
          case "user_mobile":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.MOBILE_NUMBER'));
            break;
          case "user_email":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.EMAIL'));
            break;
          case "amount":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.AMOUNT'));
            break;
          case "response_code":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.RESPONSE_CODE'));
            break;
          case "response_text":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.RESPONSE_TEXT'));
            break;
          case "mpex_ref_id":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.MPEX_REF_ID'));
            break;
          case "ih_ref_id":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.IH_REF_ID'));
            break;
          case "agent_id":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.AGENT_ID'));
            break;
          case "agents_email":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.AGENT_EMAIL'));
            break;
          case "created_at":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.CREATED_DATE'));
            break;
          case "updated_at":
            tableHeaders.push($translate.instant('CASHOUT_REPORTS.TABLE_HEADER.LAST_UPDATED_DATE'));
            break;
          default:
            tableHeaders.push(keys[i]);
        }

      }
      return tableHeaders;

    } //end getTableHeaders
  }

})();
