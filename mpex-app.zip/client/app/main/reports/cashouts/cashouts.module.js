(function ()
{
    'use strict';

    angular
        .module('app.reports.cashouts', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider, API_BASE)
    {
        $stateProvider.state('app.reports.cashouts', {
            url      : '/cashouts',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/reports/cashouts/cashouts.html',
                    controller : 'CashoutsController as vm'
                }
            },
            resolve  : {
              
            },
            bodyClass: 'reports'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/reports/cashouts');

        // Api
        msApiProvider.register('app.reports_cashouts', [ API_BASE + 'reports/cashouts']);

        // Navigation
        

    }

})();
