(function ()
{
    'use strict';

    angular
        .module('app.reports.cashins', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider, API_BASE)
    {
        $stateProvider.state('app.reports.cashins', {
            url      : '/cashins',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/reports/cashins/cashins.html',
                    controller : 'CashinsController as vm'
                }
            },
            resolve  : {

            },
            bodyClass: 'reports'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/reports/cashins');

        // Api
        msApiProvider.register('app.reports_cashins', [ API_BASE + 'reports/cashins']);

        // Navigation

    }

})();
