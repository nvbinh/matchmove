(function ()
{
    'use strict';

    angular
        .module('app.reports', [
            'app.reports.cashins',
            'app.reports.cashouts',
            'app.reports.cardholders',
            'angular-storage',
            'mm.acl'
        ])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider)
    {

        // Navigation
      /*  msNavigationServiceProvider.saveItem('reports', {
            title : 'REPORTS',
            group : true,
            weight: 4
        });
        msNavigationServiceProvider.saveItem('reports.cashin', {
            title : 'Cash In',
            icon: 'icon-import',
            state : 'app.reports_cashins',
            weight: 11
        });
        msNavigationServiceProvider.saveItem('reports.cashout', {
            title : 'Cash Out',
            icon: 'icon-export',
            state : 'app.reports_cashouts',
            weight: 12
        });
        msNavigationServiceProvider.saveItem('reports.agents', {
            title : 'Agent Creation',
            icon: 'icon-human-child',
            state : 'app.reports_agents',
            weight: 13
        */
        $stateProvider.state('app.reports',{
            url      : '/reports',
            abstract: true,
            bodyClass: 'profile',
            resolve: {
                auth: function($auth, $q, $state){
                   if( !$auth.isAuthenticated()){
                       return $q.reject('Unauthorized');
                   }
                },
                'acl' : function($q, AclService, store){
                    var aclData = {
                        groups: store.get('groups')
                    };
                    AclService.setAbilities(aclData);
                    AclService.attachRole('groups');
                }
            }
        });
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
