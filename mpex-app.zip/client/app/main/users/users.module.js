(function ()
{
    'use strict';

    angular
        .module('app.users', [
            'app.users.create',
            'app.users.detail',
            'app.users.list',
            'angular-storage',
            'mm.acl'
        ])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider)
    {
        $stateProvider.state('app.users', {
            url      : '/users',
            abstract: true,
            bodyClass: 'forms',
            resolve: {
                auth: function($auth, $q, $state){
                   if( !$auth.isAuthenticated()){
                       return $q.reject('Unauthorized');
                   }
                },
                'acl' : function($q, AclService, store){
                    var aclData = {
                        groups: store.get('groups')
                    };
                    AclService.setAbilities(aclData);
                    AclService.attachRole('groups');
                }
            }
        });
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
