(function ()
{
    'use strict';

    angular
        .module('app.users.create', [])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, API_BASE)
    {
        $stateProvider.state('app.users.create', {
            url      : '/create',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/users/create/create.html',
                    controller : 'CreateController as vm'
                }
            },
            resolve  : {
                'acl' : function($q, AclService, store){
                  if(AclService.can('agent_creation_allowed')){
                    // Has proper permissions
                    return true;
                  } else {
                    // Does not have permission
                    return $q.reject('Unauthorized');
                  }
                }
            },
            bodyClass: 'forms'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/users/create');

        // Api
        msApiProvider.register('app.users.create', [ API_BASE + 'agents']);


    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
