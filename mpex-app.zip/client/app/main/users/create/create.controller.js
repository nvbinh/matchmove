(function ()
{
    'use strict';

    angular
        .module('app.users.create')
        .controller('CreateController', CreateController);

    /** @ngInject */
    function CreateController($mdDialog, msApi, $translate, $state, $timeout, DEFAULT_LIMITS, AGENT_PASSWORD,store)
    {
        var vm = this;

        // Data
        vm.horizontalStepper = {
            step1: {},
            step2: {},
            step3: {}
        };

        vm.userRoles = ('Admin User Moderator').split(' ').map(function (role)
        {
            return {name: role};
        });

        // Public Methods
        vm.submitHorizontalStepper = submitHorizontalStepper;
        vm.submitPostData = submitPostData;

        /**
         * Submit horizontal stepper data
         * @param event
         */
        function submitHorizontalStepper(event)
        {
            // API call here to send the form to the server
            submitPostData(vm.horizontalStepper);

            // Reset the form model
            vm.horizontalStepper = {
                step1: {},
                step2: {},
                step3: {}
            };
        }

        // Method definitions
        /**
         * Submit Post Data
         *
         * @param none - taking form values from vm
         */
        function submitPostData (data){

            var user_role_map = {'Admin':1, 'User':2, 'Moderator':3};
            vm.postData = {};
            vm.postData.agent = {};
            vm.postData.agent.first_name = data.step1.firstName;
            vm.postData.agent.last_name = data.step1.lastName;
            vm.postData.agent.email = data.step1.email;
            vm.postData.agent.user_role = data.step1.userRole;
             //saving a default password for now.
            vm.postData.agent.password = AGENT_PASSWORD;
            vm.postData.agent.created_agent_email = store.get('agent').email;
            vm.postData.limit = {};
            vm.postData.limit.agent_creation_allowed = user_role_map[data.step1.userRole];
            vm.postData.limit.card_holder_creation_allowed = data.step2.cardHolderCreationAllowed || null;
            vm.postData.limit.cash_in_allowed = data.step2.cashInAllowed || null;
            vm.postData.limit.cash_out_allowed = data.step2.cashOutAllowed || null;
            vm.postData.limit.details = arrangeLimitsJson(data.step3);


           msApi.request('app.users.create@save',
                    vm.postData,
                    function(response){
                        $mdDialog.show(
                          $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(function(){
                                $mdDialog.hide();
                            })
                            .title($translate.instant('AGENT_CREATE.TITLE'))
                            .textContent($translate.instant('AGENT_CREATE.SUCCESS.200'))
                            .ariaLabel('Agent Create Success Dialog')
                            .ok('Got it!')
                            .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
                        );
                        $timeout(function(){
                          $state.go('.', {}, {reload:true})
                        }, 5000);
                    },
                    function(error){
                        var textmsg = '';
                        var reloadPath = '.';
                        if(error.status === 401){
                            textmsg  = $translate.instant('AGENT_CREATE.ERROR.401.UNAUTHORIZED');
                            reloadPath = 'app.auth_login'
                        }else {
                          textmsg = $translate.instant('AGENT_CREATE.ERROR.FALLBACK');
                        }
                        vm.loginFailure = true;
                        $mdDialog.show(
                          $mdDialog.alert()
                            .parent(angular.element(document.querySelector('#popupContainer')))
                            .clickOutsideToClose(function(){
                                $mdDialog.hide();
                            })
                            .title($translate.instant('AGENT_CREATE.TITLE'))
                            .textContent(textmsg)
                            .ariaLabel('Agent Create Failure Dialog')
                            .ok('OK')
                            .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
                        );
                        $timeout(function(){
                          $state.go(reloadPath, {}, {reload:true})
                        }, 5000);
                    });
        }

        /**
         * Private Function arrangeLimitsJson
         * param formData in step3
         */
        function arrangeLimitsJson(limits){
            var retObj = {};
            var configDefaults = angular.fromJson(DEFAULT_LIMITS);
          retObj.limits = {
            "cashInAllowed":{
              "lifetime":{
                "value":{
                  "allowed": limits.cashInAllowed_lifetime_value || configDefaults.CASH_IN.LIFETIME.VALUE,
                  "used":0,
                  "remaining": limits.cashInAllowed_lifetime_value || configDefaults.CASH_IN.LIFETIME.VALUE
                },
                "count":{
                  "allowed": limits.cashInAllowed_lifetime_count || configDefaults.CASH_IN.LIFETIME.COUNT,
                  "used":0,
                  "remaining": limits.cashInAllowed_lifetime_count || configDefaults.CASH_IN.LIFETIME.COUNT
                }
              },
              "monthly":{
                "value":{
                  "allowed": limits.cashInAllowed_monthly_value || configDefaults.CASH_IN.MONTHLY.VALUE,
                  "used":0,
                  "remaining": limits.cashInAllowed_monthly_value || configDefaults.CASH_IN.MONTHLY.VALUE
                },
                "count":{
                  "allowed": limits.cashInAllowed_monthly_count || configDefaults.CASH_IN.MONTHLY.COUNT,
                  "used":0,
                  "remaining": limits.cashInAllowed_monthly_count || configDefaults.CASH_IN.MONTHLY.COUNT
                }
              },
              "weekly":{
                "value":{
                  "allowed": limits.cashInAllowed_weekly_value || configDefaults.CASH_IN.WEEKLY.VALUE,
                  "used":0,
                  "remaining": limits.cashInAllowed_weekly_value || configDefaults.CASH_IN.WEEKLY.VALUE
                },
                "count":{
                  "allowed": limits.cashInAllowed_weekly_count || configDefaults.CASH_IN.WEEKLY.COUNT,
                  "used":0,
                  "remaining": limits.cashInAllowed_weekly_count || configDefaults.CASH_IN.WEEKLY.COUNT
                }
              },
              "daily":{
                "value":{
                  "allowed": limits.cashInAllowed_daily_value || configDefaults.CASH_IN.DAILY.VALUE,
                  "used":0,
                  "remaining": limits.cashInAllowed_daily_value || configDefaults.CASH_IN.DAILY.VALUE
                },
                "count":{
                  "allowed": limits.cashInAllowed_daily_count || configDefaults.CASH_IN.DAILY.COUNT,
                  "used":0,
                  "remaining": limits.cashInAllowed_daily_count || configDefaults.CASH_IN.DAILY.COUNT
                }
              }
            },
            "cashOutAllowed":{
              "lifetime":{
                "value":{
                  "allowed": limits.cashOutAllowed_lifetime_value || configDefaults.CASH_OUT.LIFETIME.VALUE,
                  "used":0,
                  "remaining": limits.cashOutAllowed_lifetime_value || configDefaults.CASH_OUT.LIFETIME.VALUE
                },
                "count":{
                  "allowed": limits.cashOutAllowed_lifetime_count || configDefaults.CASH_OUT.LIFETIME.COUNT,
                  "used":0,
                  "remaining": limits.cashOutAllowed_lifetime_count || configDefaults.CASH_OUT.LIFETIME.COUNT
                }
              },
              "monthly":{
                "value":{
                  "allowed": limits.cashOutAllowed_monthly_value || configDefaults.CASH_OUT.MONTHLY.VALUE,
                  "used":0,
                  "remaining": limits.cashOutAllowed_monthly_value || configDefaults.CASH_OUT.MONTHLY.VALUE
                },
                "count":{
                  "allowed": limits.cashOutAllowed_monthly_count || configDefaults.CASH_OUT.MONTHLY.COUNT,
                  "used":0,
                  "remaining": limits.cashOutAllowed_monthly_count || configDefaults.CASH_OUT.MONTHLY.COUNT
                }
              },
              "weekly":{
                "value":{
                  "allowed": limits.cashOutAllowed_weekly_value || configDefaults.CASH_OUT.WEEKLY.VALUE,
                  "used":0,
                  "remaining": limits.cashOutAllowed_weekly_value || configDefaults.CASH_OUT.WEEKLY.VALUE
                },
                "count":{
                  "allowed": limits.cashOutAllowed_weekly_count || configDefaults.CASH_OUT.WEEKLY.COUNT,
                  "used":0,
                  "remaining": limits.cashOutAllowed_weekly_count || configDefaults.CASH_OUT.WEEKLY.COUNT
                }
              },
              "daily":{
                "value":{
                  "allowed": limits.cashOutAllowed_daily_value || configDefaults.CASH_OUT.DAILY.VALUE,
                  "used":0,
                  "remaining": limits.cashOutAllowed_daily_value || configDefaults.CASH_OUT.DAILY.VALUE
                },
                "count":{
                  "allowed": limits.cashOutAllowed_daily_count || configDefaults.CASH_OUT.DAILY.COUNT,
                  "used":0,
                  "remaining": limits.cashOutAllowed_daily_count || configDefaults.CASH_OUT.DAILY.COUNT
                }
              }
            },
            "cardHolderCreationAllowed":{
              "lifetime":{
                "value":{
                  "allowed": limits.cardHolderCreationAllowed_lifetime_value || configDefaults.CARDHOLDER_CREATE.LIFETIME.VALUE,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_lifetime_value || configDefaults.CARDHOLDER_CREATE.LIFETIME.VALUE
                },
                "count":{
                  "allowed": limits.cardHolderCreationAllowed_lifetime_count || configDefaults.CARDHOLDER_CREATE.LIFETIME.COUNT,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_lifetime_count || configDefaults.CARDHOLDER_CREATE.LIFETIME.COUNT
                }
              },
              "monthly":{
                "value":{
                  "allowed": limits.cardHolderCreationAllowed_monthly_value || configDefaults.CARDHOLDER_CREATE.MONTHLY.VALUE,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_monthly_value || configDefaults.CARDHOLDER_CREATE.MONTHLY.VALUE
                },
                "count":{
                  "allowed": limits.cardHolderCreationAllowed_monthly_count || configDefaults.CARDHOLDER_CREATE.MONTHLY.COUNT,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_monthly_count || configDefaults.CARDHOLDER_CREATE.MONTHLY.COUNT
                }
              },
              "weekly":{
                "value":{
                  "allowed": limits.cardHolderCreationAllowed_weekly_value || configDefaults.CARDHOLDER_CREATE.WEEKLY.VALUE,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_weekly_value || configDefaults.CARDHOLDER_CREATE.WEEKLY.VALUE
                },
                "count":{
                  "allowed": limits.cardHolderCreationAllowed_weekly_count || configDefaults.CARDHOLDER_CREATE.WEEKLY.COUNT,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_weekly_count || configDefaults.CARDHOLDER_CREATE.WEEKLY.COUNT
                }
              },
              "daily":{
                "value":{
                  "allowed": limits.cardHolderCreationAllowed_daily_value || configDefaults.CARDHOLDER_CREATE.DAILY.VALUE,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_daily_value || configDefaults.CARDHOLDER_CREATE.DAILY.VALUE
                },
                "count":{
                  "allowed": limits.cardHolderCreationAllowed_daily_count || configDefaults.CARDHOLDER_CREATE.DAILY.COUNT,
                  "used":0,
                  "remaining": limits.cardHolderCreationAllowed_daily_count || configDefaults.CARDHOLDER_CREATE.DAILY.COUNT
                }
              }
            }
          };
          return angular.toJson(retObj);
        }
    }

})();
