(function ()
{
    'use strict';

    angular
        .module('app.users.list', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider, API_BASE)
    {
        // State
        $stateProvider.state('app.users.list', {
            url      : '/list',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/users/list/list.html',
                    controller : 'ListController as vm'
                }
            },
            resolve  : {
            },
            bodyClass: 'list'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/users/list');

        // Api
        msApiProvider.register('app.users_list', [API_BASE + 'reports/list']);

        // Navigation
        // msNavigationServiceProvider.saveItem('users.list', {
        //     title : 'List',
        //     icon  : 'icon-magnify',
        //     state : 'app.users_list',
        //     weight: 7
        // });
    }

})();
