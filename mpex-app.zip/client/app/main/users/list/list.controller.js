(function () {
  'use strict';

  angular
    .module('app.users.list')
    .controller('ListController', ListController);

  /** @ngInject */
  function ListController(msApi, $filter, $translate) {
    var vm = this;
    vm.limitOptions = [5, 10, 25, 50, 100];
    vm.page = 1;
    vm.limit = 5;
    vm.options = {
      rowSelection: true,
      multiSelect: true,
      autoSelect: true,
      decapitate: false,
      largeEditDialog: false,
      boundaryLinks: false,
      limitSelect: true,
      pageSelect: true
    };

    vm.getData = getData;
    getData();

    /** Get Data */

    function getData() {
      var offset_val = (vm.page - 1) * vm.limit;
      msApi.request('app.users_list@get',
        { limit: vm.limit, offset: offset_val, from_date: '2010-01-01', to_date: new Date().toISOString },
        function (response) {

          if (response.data !== null && response.data.length > 0) {
            for (var i = 0; i < response.data.length; i++) {
              response.data[i].thisagent_id = response.data[i].id;
              response.data[i].id = (i + 1) + offset_val;
              response.data[i].last_login = $filter('date')(response.data[i].last_login, 'dd/MM/yyyy');
              response.data[i].created_at = $filter('date')(response.data[i].created_at, 'dd/MM/yyyy');
            }
            vm.usersList = response.data;
            vm.totalRecords = response.recordDetails[0].totalRecs;
            vm.header = getTableHeaders(Object.keys(vm.usersList[0]));
          }
          else {
            vm.processedDataisEmpty = true;
          }
        },
        function (error) {
          console.log("error " + angular.toJson(error));
        }

      );

    } //end function getData
    function getTableHeaders(keys) {
      var tableHeaders = [];
      for (var i = 0; i < keys.length; i++) {
        switch (keys[i]) {
          case "id":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.ID'));
            break;
          case "thisagent_id":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.CURRENT_AGENT_ID'));
            break;
          case "first_name":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.FIRST_NAME'));
            break;
          case "last_name":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.LAST_NAME'));
            break;
          case "email":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.EMAIL'));
            break;
          case "last_login":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.LAST_LOGIN'));
            break;
          case "login_count":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.LOGIN_COUNT'));
            break;
          case "created_agent_email":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.CREATED_BY'));
            break;
          case "user_role":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.USER_ROLE'));
            break;
          case "created_at":
            tableHeaders.push($translate.instant('USER_REPORTS.TABLE_HEADER.CREATED_AT'));
        }

      }
      return tableHeaders;

    } //end getTableHeaders


  } //end ListController

})();
