(function ()
{
    'use strict';

    angular
        .module('app.users.detail', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider, API_BASE)
    {
        // State
        $stateProvider.state('app.users_detail', {
            url      : '/users/detail',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/users/detail/detail.html',
                    controller : 'UserDetailController as vm'
                }
            },
            resolve  : {
                // Activities   : function (msApi)
                // {
                //     return msApi.resolve('detail.activities@get');
                // }
            },
            bodyClass: 'detail'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/users/detail');

        // Api
        msApiProvider.register('app.user_limit/:id',[API_BASE +'users/:id', {id:'@id'}]);

        // Navigation
        // msNavigationServiceProvider.saveItem('users.detail', {
        //     title : 'Detail',
        //     icon  : 'icon-magnify',
        //     state : 'app.users_detail',
        //     weight: 7
        // });
    }

})();
