(function () {
    'use strict';

    angular
        .module('app.users.detail')
        .controller('UserDetailController', UserDetailController);

    /** @ngInject */
    function UserDetailController(msApi, store) {
        var vm = this;

        // Data
        vm.currentUser = store.get('users');
        vm.usersData = null;

        if (vm.currentUser) {
            msApi.request('app.user_limit/:id@get',
                { 'id': vm.currentUser.id },
                function (response) {
                    if (response.data.length > 0) {
                        vm.usersData = response.data[0];
                    }
                },
                function (error) {
                    console.log(error);
                }
            );
        }

        // Methods
        vm.convertText = convertText;

        function convertText(value) {
            var ret = "No";
            if (value && Boolean(parseInt(value))) {
                ret = "Yes";
            }
            return ret;
        }
        //////////
    }

})();
