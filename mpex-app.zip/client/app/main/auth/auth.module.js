(function ()
{
    'use strict';

    angular
        .module('app.auth', [
            'app.auth.login',
            'app.auth.lock',
            'app.auth.forgot-password',
            'app.auth.reset-password'
        ])
        .config(config);

    /** @ngInject */
    function config()
    {
      
    }
})();
