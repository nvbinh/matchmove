(function () {
    'use strict';

    angular
        .module('app.auth.forgot-password')
        .controller('ForgotPasswordController', ForgotPasswordController);

    /** @ngInject */
    function ForgotPasswordController(BRANDING, msApi, $mdDialog, $timeout, $translate) {
        var vm = this;
        vm.branding = BRANDING;
        // Data

        // Methods
        vm.sendResetLink = function () {
            vm.postData = {};
            vm.postData.email = vm.form.email;
            msApi.request('app.auth_forgot_password@save', vm.postData,
                function (response) {
                    showDialog($translate.instant('FORGOTPASSWORD.MAIL_SENT'));
                },
                function (error) {
                    if (error.status == 400) {
                        showDialog($translate.instant('FORGOTPASSWORD.EMAIL_NOT_FOUND'));
                    }
                    else {
                        showDialog($translate.instant('FORGOTPASSWORD.MAIL_NOT_SENT'));
                    }
                }
            );

        }

        function showDialog(statusText) {
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#forgotPasswordForm')))
                    .clickOutsideToClose(function () {
                        $mdDialog.hide();
                    })
                    .title($translate.instant('FORGOTPASSWORD.TITLE'))
                    .textContent(statusText)
                    .ariaLabel('Forgot password dialog')
                    .ok('OK')
                    .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
            );
        }

    }
})();
