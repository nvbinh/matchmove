(function () {
    'use strict';

    angular
        .module('app.auth.reset-password')
        .controller('ResetPasswordController', ResetPasswordController);

    /** @ngInject */
    function ResetPasswordController(BRANDING, msApi, $mdDialog, $translate, $state, $stateParams, $timeout) {
        var vm = this;
        vm.branding = BRANDING;
        // Data

        // Methods
        vm.resetPassword = function () {
            vm.postData = {};
            vm.postData.password = vm.form.newpassword;
            vm.postData.confirm = vm.form.passwordConfirm;
            vm.postData.token = $stateParams.token;
            msApi.request('app.auth_reset_password@save', vm.postData,
                function (response) {
                    showDialog(response.statusText);
                    $timeout(function () {
                        $state.go('app.auth_login', {}, { reload: true });
                    }, 3000);
                }, function (error) {
                    showDialog("ERROR: " + error.statusText);
                }
            );
        };

        function showDialog(statusText) {
            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#reset-password-form')))
                    .clickOutsideToClose(function () {
                        $mdDialog.hide();
                    })
                    .title($translate.instant('RESETPASSWORD.TITLE'))
                    .textContent(statusText)
                    .ariaLabel('Reset password dialog')
                    .ok('OK')
                    .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
            );
        }
        //////////
    }
})();
