(function ()
{
    'use strict';

    angular
        .module('app.auth.login', [
                'angular-storage'
            ])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider, API_BASE)
    {
        // State
        $stateProvider.state('app.auth_login', {
            url      : '/auth/login',
            views    : {
                'main@'                          : {
                    templateUrl: 'app/core/layouts/content-only.html',
                    controller : 'MainController as vm'
                },
                'content@app.auth_login': {
                    templateUrl: 'app/main/auth/login/login.html',
                    controller : 'LoginController as vm'
                }
            },
            resolve: {
                clear: function (Authentication)
                {
                    Authentication.ClearCredentials();
                }
            },
            bodyClass: 'login'
        });

        // Api
        msApiProvider.register('app.auth_login', [ API_BASE + 'login']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/auth/login');

    }

})();
