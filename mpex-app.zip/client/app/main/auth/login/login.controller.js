(function () {
    'use strict';

    angular
        .module('app.auth.login')
        .controller('LoginController', LoginController);

    /** @ngInject */
    function LoginController(API_BASE, BRANDING, msApi, $state, Authentication, store, $timeout, AclService, $auth) {
        // Data
        var vm = this;
        vm.branding = BRANDING;
        vm.form = {};
        vm.loginFailure = {};

        // Methods
        function init() {
        }

        function login(email, pass) {
            // vm.loginFailure = false;
            $auth.login({ email: email, password: pass });

            msApi.request('app.auth_login@save',
                { email: email, password: pass },
                function (response) {
                    //store.set('token', response.token);
                    store.set('agent', response.agent);
                    store.set('groups', response.groups);
                    Authentication.SetCredentials(response.token);
                    var aclData = {
                        groups: store.get('groups')
                    };
                    AclService.setAbilities(aclData);
                    AclService.attachRole('groups');
                    $state.go('app.dashboard.home');
                },
                function (error) {
                    vm.loginFailure.authError = true;
                    $timeout(function () {
                        vm.loginFailure.authError = false;

                    }, 2000);
                });

        }

        vm.login = login;
        vm.init = init;
        // //////////
        // Initialize scope


        //////////
    }
})();
