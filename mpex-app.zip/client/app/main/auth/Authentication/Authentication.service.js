(function () {
  'use strict';

  // register the service as AuthenticationService
  angular
    .module('app.auth.login')
    .factory('Authentication', Authentication);

  // add Authentication dependencies to inject
  // Authentication.$inject = [''];

  /**
   * Authentication factory constructor
   * AngularJS will instantiate a singleton which is
   * an object that has the members of this factory
   */
  function Authentication($http, store, $auth) {
    // factory members
    var name = 'Authentication';

    // public API
    return {
      name: name,
      doSomething: doSomething,
      SetCredentials: SetCredentials,
      ClearCredentials:ClearCredentials
    };

    // factory function definitions
    function doSomething() {
      return name;
    }

    // factory function Set Credentials
    function SetCredentials(jwtToken) {
        
        store.set('globalsTo', jwtToken);
        $http.defaults.headers.common['Authorization'] = 'Bearer ' + jwtToken; // jshint ignore:line
        $http.defaults.headers.post['Authorization'] = 'Bearer ' + jwtToken; // jshint ignore:line
        $http.defaults.headers.put['Authorization'] = 'Bearer ' + jwtToken; // jshint ignore:line

    }

    function ClearCredentials() {
        
        $http.defaults.headers.common.Authorization = 'Bearer';
        store.remove('agent');
        store.remove('groups');
        store.remove('globalsTo');
        store.remove('mpacl');
        store.remove('record_id');
        store.remove('token');
        $auth.logout();
    }
  }

})();
