'use strict';
/*
describe('Factory: Authentication', function () {

  // load the resource's module
  beforeEach(module('admin'));

  // instantiate service
  var resource;

  beforeEach(inject(function (_Authentication_) {
    resource = _Authentication_;
  }));

  it('should be defined', function () {
    Should.exist(resource);
  });

  it('should be a resource object', function () {
    resource.doSomething().should.equal('Authentication');
  });

});
*/