(function () {
    'use strict';

    angular
        .module('app.dashboard.home')
        .controller('HomeController', HomeController);

    /** @ngInject */
    function HomeController(msApi, $translate) {

        var vm = this;
        // Data
        //vm.Home = Home;

        // vm.widget1 = vm.Home.widget1;
        //vm.widget2 = vm.Home.widget2;
        // vm.widget3 = vm.Home.widget3;

        // vm.widget3 ={};
        // vm.widget3.data = {};
        // vm.widget3.data.count = 20;
        // vm.widget3.data.label = "Cardholder";
        // vm.widget3.extra = {};
        // vm.widget3.extra.label = "Count"
        // vm.widget3.extra.count = "100"

        // Methods

        /////////
        vm.widget1 = getCashinData;
        vm.widget2 = getCashoutData;
        vm.widget3 = getCardholderData;

        function getCashinData() {
            vm.widget1 = {};
            vm.widget1.title = $translate.instant('WIDGET1.TITLE');
            vm.widget1.data = {};
            vm.widget1.data.label = $translate.instant('WIDGET1.DATA.LABEL');

            msApi.request('app.dashboard_cashins@get',
                { from_date: '2010-01-01', to_date: new Date().toISOString },
                function (response) {
                    vm.widget1.data.count = response.data[0].totalRecs;

                },
                function (error) {
                    console.log("error" + angular.toJson(error));
                }

            );
        }


        function getCashoutData() {
            vm.widget2 = {};
            vm.widget2.title = $translate.instant('WIDGET2.TITLE');
            vm.widget2.data = {};
            vm.widget2.data.label = $translate.instant('WIDGET2.DATA.LABEL');


            msApi.request('app.dashboard_cashouts@get',
                { from_date: '2010-01-01', to_date: new Date().toISOString },
                function (response) {
                    vm.widget2.data.count = response.data[0].totalRecs;
                },
                function (error) {
                    console.log("error" + angular.toJson(error));
                }

            );
        }

        function getCardholderData() {
            vm.widget3 = {};
            vm.widget3.title = $translate.instant('WIDGET3.TITLE');
            vm.widget3.data = {};
            vm.widget3.data.label = $translate.instant('WIDGET3.DATA.LABEL');

            msApi.request('app.dashboard_cardholders@get',
                { from_date: '2010-01-01', to_date: new Date().toISOString },
                function (response) {
                    vm.widget3.data.count = response.data[0].totalRecs;
                }
            );
        }

        function getPrefundingData() {
            // vm.widget4 = {};
            // vm.widget4.title = $translate.instant('WIDGET3.TITLE');
            // vm.widget3.data = {};
            // vm.widget3.data.label = $translate.instant('WIDGET3.DATA.LABEL');

            msApi.request('app.dashboard_limits@get', {} ,
                function (response) {
                    vm.isAdmin = true;
                    vm.adminWidgetData = response;
                    // vm.widget3.data.count = response.data[0].totalRecs;
                },
                function(error){
                    vm.isAdmin = false;
                }
            );
        }

        getCashinData();
        getCashoutData();
        getCardholderData();
        getPrefundingData();

    }

})();
