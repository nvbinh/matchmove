(function ()
{
    'use strict';

    angular
        .module('app.dashboard.home', ['angular-storage', 'mm.acl'])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider,API_BASE)
    {
        $stateProvider.state('app.dashboard.home', {
            url      : '/home',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/dashboard/home/home.html',
                    controller : 'HomeController as vm'
                }
            },
            resolve  : {
                // Home   : function (msApi)
                // {
                //     return msApi.resolve('home.dashboard@get');
                // },
                'acl' : function($q, AclService, store){
                    var aclData = {
                        groups: store.get('groups')
                    };
                    AclService.setAbilities(aclData);
                    AclService.attachRole('groups');
                }
            },
            bodyClass: 'profile'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/dashboard/home');

        // Api
        msApiProvider.register('app.dashboard_cashins', [API_BASE + 'dashboard/cashins']);
        msApiProvider.register('app.dashboard_cashouts', [API_BASE + 'dashboard/cashouts']);
        msApiProvider.register('app.dashboard_cardholders', [API_BASE + 'dashboard/cardholders']);

        msApiProvider.register('app.dashboard_limits', [API_BASE + 'prefunding']);
        // Navigation
        msNavigationServiceProvider.saveItem('dashboard.home', {
            title : 'Home',
            icon  : 'icon-account',
            state : 'app.dashboard.home',
            weight: 6
        });
    }

})();
