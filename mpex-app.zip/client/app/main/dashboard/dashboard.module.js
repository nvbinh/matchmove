(function ()
{
    'use strict';

    angular
        .module('app.dashboard', [
            'app.dashboard.home'
        ])
        .config(config)
        .run(runBlock);

    /** @ngInject */
    function config($stateProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.dashboard', {
            url      : '/dashboard',
            resolve  : {
                auth: function($auth, $q, $state){
                   if( !$auth.isAuthenticated()){
                       return $q.reject('Unauthorized');
                   }
                }
            },
            bodyClass: 'profile'
        });

        // Navigation
        msNavigationServiceProvider.saveItem('dashboard', {
            title : 'DASHBOARD',
            group : true,
            weight: 2
        });
    }
    function runBlock($rootScope, $state )
    {
        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if(error === 'Unauthorized'){
              $state.go('app.auth_login');
            }
          })
    }
})();
