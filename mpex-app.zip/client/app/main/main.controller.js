(function ()
{
    'use strict';

    angular
        .module('admin')
        .controller('MainController', MainController);

    /** @ngInject */
    function MainController($scope, $rootScope, BRANDING, msNavigationService, AclService)
    {
        // Data

        //////////

        // Remove the splash screen
        $scope.$on('$viewContentAnimationEnded', function (event)
        {
            if ( event.targetScope.$id === $scope.$id )
            {
                $rootScope.$broadcast('msSplashScreen::remove');
            }
        });

        function allowedURLs(workflow){
            var allowed = false;
            switch (workflow){
                case 'cashin':
                    allowed = !AclService.can('cash_in_allowed_single') && !AclService.can('cash_in_allowed_bulk');
                    break;
                case 'cashout':
                    allowed = !AclService.can('cash_out_allowed_single') && !AclService.can('cash_out_allowed_bulk');
                    break;
                case 'walletUser':
                    allowed = !AclService.can('card_holder_creation_allowed_single') && !AclService.can('card_holder_creation_allowed_bulk');
                    break;
                case 'agentCreate':
                    allowed = !AclService.can('agent_creation_allowed')
                    break;

            }
            return allowed;
        }

        //ACTION Navigations
        // CashIn Navigation
        msNavigationService.saveItem('actions.cashin', {
            title : 'CASHIN.MENUS.TITLE_CASH_IN',
            icon: 'icon-basket-fill',
            weight: 4,
            hidden: function () {
                  return allowedURLs('cashin');
              }
        });
        msNavigationService.saveItem('actions.cashin.single', {
            title : 'CASHIN.MENUS.TITLE_SINGLE',
            icon: 'icon-numeric-1-box-outline',
            state : 'app.actions.cashin.single',
            weight: 10
        });
        msNavigationService.saveItem('actions.cashin.bulk', {
            title : 'CASHIN.MENUS.TITLE_BULK',
            icon: 'icon-numeric-9-box-multiple-outline',
            state : 'app.actions.cashin.bulk',
            weight: 10
        });

        // CashOut Navigation
        msNavigationService.saveItem('actions.cashout', {
            title : 'CASHOUT.MENUS.TITLE_CASHOUT',
            icon: 'icon-basket-unfill',
            weight: 5,
            hidden: function () {
                  return allowedURLs('cashout');
              }
        });
        msNavigationService.saveItem('actions.cashout.single', {
            title : 'CASHOUT.MENUS.TITLE_SINGLE',
            icon: 'icon-numeric-1-box-outline',
            state : 'app.actions.cashout.single',
            weight: 10
        });
        msNavigationService.saveItem('actions.cashout.bulk', {
            title : 'CASHOUT.MENUS.TITLE_BULK',
            icon: 'icon-numeric-9-box-multiple-outline',
            state : 'app.actions.cashout.bulk',
            weight: 10
        });

        // Wallet Create Navigation
        msNavigationService.saveItem('actions.CreateWalletUser', {
            title : 'CREATE_WALLET_USER.MENUS.TITLE_WALLET_USER',
            icon: 'icon-account-multiple-plus',
            weight: 5,
            hidden: function () {
                  return allowedURLs('walletUser');
              }
        });
        msNavigationService.saveItem('actions.CreateWalletUser.single', {
            title : 'CREATE_WALLET_USER.MENUS.TITLE_SINGLE',
            icon: 'icon-numeric-1-box-outline',
            state : 'app.actions.CreateWalletUser.single',
            weight: 10
        });
        msNavigationService.saveItem('actions.CreateWalletUser.bulk', {
            title : 'CREATE_WALLET_USER.MENUS.TITLE_BULK',
            icon: 'icon-numeric-9-box-multiple-outline',
            state : 'app.actions.CreateWalletUser.bulk',
            weight: 10
        });

        //REPORTS Navigation
        // Navigation
        msNavigationService.saveItem('reports', {
            title : 'REPORTS',
            group : true,
            weight: 4
        });
        msNavigationService.saveItem('reports.cashin', {
            title : 'Cash In',
            icon: 'icon-import',
            state : 'app.reports.cashins',
            weight: 11,
            hidden: function () {
                  return allowedURLs('cashin');
              }
        });
        msNavigationService.saveItem('reports.cashout', {
            title : 'Cash Out',
            icon: 'icon-export',
            state : 'app.reports.cashouts',
            weight: 12,
            hidden: function () {
                  return allowedURLs('cashout');
              }
        });
        msNavigationService.saveItem('reports.cardholders', {
            title : 'Wallet Creation',
            icon: 'icon-wallet-membership',
            state : 'app.reports.cardholders',
            weight: 13,
            hidden: function () {
                  return allowedURLs('walletUser'); // must be a boolean value
              }
        });

        // Agents Navigation
         msNavigationService.saveItem('users', {
            title : 'ADMINISTRATION',
            group : true,
            weight: 5,
            hidden: function () {
                  return allowedURLs('agentCreate'); // must be a boolean value
              }
        });
        msNavigationService.saveItem('users.create', {
            title : 'Create Agent',
            icon  : 'icon-account-plus',
            state : 'app.users.create',
            weight: 6,
            hidden: function () {
                  return allowedURLs('agentCreate'); // must be a boolean value
              }
        });
         msNavigationService.saveItem('users.list', {
            title : 'Agents List',
            icon  : 'icon-account-multiple',
            state : 'app.users.list',
            weight: 7,
            hidden: function () {
                  return allowedURLs('agentCreate'); // must be a boolean value
              }
        });
    }
})();
