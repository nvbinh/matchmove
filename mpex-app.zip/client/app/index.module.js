(function ()
{
    'use strict';

    /**
     * Main module of the App
     * Define your application mdoules and external dependencies here.
     */
    angular
        .module('admin', [
            // Satellizer
            'satellizer',

            // Core
            'app.core',

            // Navigation
            'app.navigation',

            // Toolbar
            'app.toolbar',

            // Quick panel
            'app.quick-panel',

            // Auth
            'app.auth',

            // Actions
            'app.actions',

            // Dashboard
            'app.dashboard',

            // Reports
            'app.reports',
            //
            // // Pages
            // 'app.pages',

            'app.users'
        ]);
})();
