(function ()
{
    'use strict';

    angular
        .module('app.core',
            [
                'ngAnimate',
                'ngAria',
                'ngCookies',
                'ngMessages',
                'ngResource',
                'ngSanitize',
                'ngMaterial',
                'md.data.table',
                'pascalprecht.translate',
                'ui.router',
                'angular-storage',
                'mm.acl'
            ]);
})();