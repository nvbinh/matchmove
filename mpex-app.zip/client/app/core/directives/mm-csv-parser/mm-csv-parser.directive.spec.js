/*
'use strict';

describe('Directive: mmCsvParser', function () {

  // load the directive's module
  beforeEach(module('adminApp'));

  var element, scope;

  beforeEach(inject(function ($rootScope, $compile) {
    scope = $rootScope.$new();
    element = angular.element('<mm-csv-parser></mm-csv-parser>');
    element = $compile(element)(scope);
  }));

  it('should set the element text', function () {
    element.text().should.equal('this is the mmCsvParser directive');
  });
});
*/