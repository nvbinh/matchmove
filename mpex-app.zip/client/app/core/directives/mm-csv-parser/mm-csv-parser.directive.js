(function () {
  'use strict';

  /**
   * usage:
   *
   * Use an options array as below in your controller
   * vm.csv = {
            operation: 'CASH_OUT', // CASH_OUT, CASH_IN, CARDHOLDER_CREATE
            content: null,
            header: false,
            headerVisible: false,
            enclosingQuotes: true,
            separator: ',',
            separatorVisible: false,
            result: null,
            encoding: 'ISO-8859-1',
            encodingVisible: false,
            acceptSize: 1000,
            allowedTypes: ['text/csv', 'application/vnd.ms-excel', 'application/csv']
        };
  Also load the relevant translations as below in your module file
      $translatePartialLoaderProvider.addPart('app/core/directives/mm-csv-parser');

    The results should be handled in your controller like this
    callback = "vm.CsvHandler"

    eg: vm.CsvHandler = function(){
            console.log('file here...');
            console.log(vm.csv.result);
        }

The usage in template is like this:
<mm-csv-parser
    class="import"
    operation="vm.csv.operation"
    content="vm.csv.content"
    header="vm.csv.header"
    header-visible="vm.csv.headerVisible"
    enclosing-quotes="vm.csv.enclosingQuotes"
    separator="vm.csv.separator"
    separator-visible="vm.csv.separatorVisible"
    result="vm.csv.result"
    encoding="vm.csv.encoding"
    encoding-visible="vm.csv.encodingVisible"
    callback = "vm.CsvHandler"
    accept-size="vm.csv.acceptSize"
    accept-type-callback="vm.acceptTypeCallback"
    allowed-types="vm.csv.allowedTypes"></mm-csv-parser>

where vm.csv.* are the options as defined in the controller and
where the callbacks defined in the controller are

        vm.acceptTypeCallback = function(returnObj){
            //when this fucntion is retrned, there is an error in file size or mismatch in allowed types
            //handle error messages and display of error messages here
        }
        vm.CsvHandler = function(){
            console.log('file here...');
            console.log(vm.csv.result);
            // place your result data handler here
        }
   */

  // register the service as mmCsvParser
  angular
    .module('app.core')
    .directive('mmCsvParser', mmCsvParser);

  // add mmCsvParser dependencies to inject
  // mmCsvParser.$inject = [''];

  /**
   * mmCsvParser directive
   */
  function mmCsvParser($translate, INPUT_FIELD_SPECS) {

    // directive definition members
    var directive = {
      link: link,
      template: '<div>'+
      '<div ng-show="headerVisible"><div class="label">Header</div><input type="checkbox" ng-model="header"></div>'+
      '<div ng-show="encoding && encodingVisible"><div class="label">Encoding</div><span>{{encoding}}</span></div>'+
      '<div ng-show="separator && separatorVisible">'+
      '<div class="label">Seperator</div>'+
      '<span><input class="separator-input" type="text" ng-change="changeSeparator" ng-model="separator"><span>'+
      '</div>'+
      '<div ng-model="file" ngf-drop="" ngf-select="" class="drag" ngf-drag-over-class="\'dragover\'" accept=".csv">{{\'CSV_PARSER.FILE.UPLOAD\' | translate }}</div>' +
      '</div>',
      restrict: 'E',
      transclude: true,
      replace: true,
      scope:{
        operation: '=',
        content:'=?',
        header: '=?',
        headerVisible: '=?',
        separator: '=?',
        enclosingQuotes: '=?',
        separatorVisible: '=?',
        result: '=?',
        encoding: '=?',
        encodingVisible: '=?',
        accept: '=?',
        acceptSize: '=?',
        acceptTypeCallback: '=?',
        callback: '=?',
        allowedTypes: '=?'
      }
    };


    return directive


    // directives link definition
    function link(scope, element, attrs) {
      scope.separatorVisible = scope.separatorVisible || false;
      scope.headerVisible = scope.headerVisible || false;
      scope.acceptSize = scope.acceptSize;
      var newline = "";
      var configCSV = angular.fromJson(INPUT_FIELD_SPECS);
        switch(scope.operation){
          case 'CASH_IN':
            configCSV = configCSV.CASH_IN;
            break;
          case 'CASH_OUT':
            configCSV = configCSV.CASH_OUT;
            break;
          case 'CARDHOLDER_CREATE':
            configCSV = configCSV.CARDHOLDER_CREATE;
            break;
          case 'CARDHOLDER_CREATE_MOBILEONLY':
            configCSV = configCSV.CARDHOLDER_CREATE_MOBILEONLY;
            break;
        }

      scope.$watch('file', function (onChangeEvent) {
        if (scope.file != null) {
          if (scope.file.size > scope.acceptSize){
            var retObj = {};
            retObj.errorMessage = $translate.instant("CSV_PARSER.ERROR.FILE.SIZE_INVALID");
            if ( typeof scope.acceptTypeCallback === 'function' ) {
              scope.acceptTypeCallback(retObj);
            }
          return;
          }

        if( scope.allowedTypes.indexOf(scope.file.type) < 0) {
            var retObj = {};
            retObj.errorMessage =$translate.instant("CSV_PARSER.ERROR.FILE.TYPE_INVALID");

            if (typeof scope.acceptTypeCallback === 'function'){
              scope.acceptTypeCallback(retObj);
            }
            return;
          }


           // Newline must be valid: \r, \n, or \r\n
        if (newline != '\n' && newline != '\r' && newline != '\r\n'){
          newline = '\n';
        }
        var delim = ",";
        var reader = new FileReader();
        reader.onload = function(onLoadEvent) {
          scope.$apply(function() {
            var content = {
              csv: onLoadEvent.target.result.replace(/\r\n|\r/g,'\n'),
              header: scope.header,
              separator: scope.separator
            };
            scope.content = content.csv;
            scope.rows = scope.content.split(newline);

            scope.result = csvToJSON(content);
            scope.result.validdata = isValidData();

            scope.result.fieldnames = columnHeaders();
            scope.result.filename = scope.file.name;

            scope.$$postDigest(function(){
              if ( typeof scope.callback === 'function' ) {
                scope.callback(onChangeEvent);
              }
            });
          });
        };
        reader.readAsText(scope.file);

        }
      });



      var isValidData = function()
      {
        var validData = true;
        for (var item in scope.result)
        {
          if(scope.result[item].error.length >0)
          {

            validData = false;
            return validData;
          }
        }

        return validData;
      }
      var columnHeaders = function()
      {
        var fieldnames = [];
        for (var item in configCSV)
        {

          fieldnames.push(configCSV[item].field_name);

        }
        return fieldnames;

      }
      var csvToJSON = function(content) {
        if (content.header == true){
          var lines=content.csv.split(new RegExp('\n(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)'));
        }
        if(content.header == false){
          var lines=content.csv.split(new RegExp('[\n]'));
        }

        var result = [];
        var start = 0;
        scope.columnCount = lines[0].split(content.separator).length;
        var headers = [];
        if (content.header) {
          headers=lines[0].split(content.separator);
          start = 1;
        }

        for (var i=start; i<lines.length; i++) {
          var retObj = {};
          retObj.error = [];
          var data = [];
          var err = {};

          if (lines[i] == ""){
            for (var k=0; k<configCSV.length; k++) {
                 data[k] = {"fld_name":configCSV[k].field_name,"value": ""};
                }

            retObj.data = data;
            retObj.error.push( {
                  type: "Empty record",
                  code: "No data found",
                  message: $translate.instant("CSV_PARSER.ERROR.DATA_NOT_FOUND"),
                  row: i,
                  index: start
                });

          }else{
            if(content.header == true){
              var currentline=lines[i].split(new RegExp(content.separator+'(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)'));
            }
            if(content.header == false){
              var currentline=lines[i].split(new RegExp(content.separator));
            }
            if ( currentline.length === scope.columnCount && scope.columnCount == configCSV.length) {
              if (content.header) {
                for (var j=0; j<headers.length; j++) {
                  data[j] = {"fld_name":configCSV[j].field_name, "value":cleanCsvValue(currentline[j])};
                  if(scope.operation === 'CASH_IN' || scope.operation === 'CASH_OUT'){
                    if(j == 0 && cleanCsvValue(currentline[j]) == '' && cleanCsvValue(currentline[j+1]) == '' && cleanCsvValue(currentline[j+2]) == ''){
                      retObj.error.push( {
                        type: "Empty fields",
                        code: "Required field empty",
                        message: $translate.instant("CSV_PARSER.ERROR.TOO_MANY_FIELDS_EMPTY"),
                        row: i,
                        index: start
                      });
                      continue;
                    }else if(j == 0 && cleanCsvValue(currentline[j]) == '' && cleanCsvValue(currentline[j+1]) == ''){
                      var validation = validateCsvValue(currentline[j+2], j+2, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[j+3], j+3, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      continue;
                    }else if(j == 1 && cleanCsvValue(currentline[j-1]) == '' && cleanCsvValue(currentline[j]) == ''){
                      var validation = validateCsvValue(currentline[j+1], j+1, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[j+2], j+2, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      continue;
                    }else if (j == 2 && cleanCsvValue(currentline[j]) == ''){
                      var validation = validateCsvValue(currentline[j-1], j-1, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[j-2], j-2, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[j+1], j+1, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      continue;
                    }else {
                       var validation = validateCsvValue(currentline[j], j, i);
                       if(validation && validation[0].error && validation[0].error.type !== ''){
                          retObj.error.push(validation[0].error);
                        }
                    }
                  }else{
                    var validation = validateCsvValue(currentline[j], j, i);
                     if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                  }
                }
              } else {
                 // no header
                for (var k=0; k<currentline.length; k++) {
                  data[k] = {"fld_name":configCSV[k].field_name,"value":cleanCsvValue(currentline[k])};
                  if (scope.operation === 'CASH_IN' || scope.operation === 'CASH_OUT'){
                    if(k == 0 && cleanCsvValue(currentline[k]) == '' && cleanCsvValue(currentline[k+1]) == '' && cleanCsvValue(currentline[k+2]) == ''){
                      retObj.error.push( {
                        type: "Empty fields",
                        code: "Required field empty",
                        message: $translate.instant("CSV_PARSER.ERROR.TOO_MANY_FIELDS_EMPTY"),
                        row: i,
                        index: start
                      });
                      continue;
                    }else if(k == 0 && cleanCsvValue(currentline[k]) == '' && cleanCsvValue(currentline[k+1]) == ''){
                      var validation = validateCsvValue(currentline[k+2],  k+2, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[k+3],  k+3, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      continue;
                    } else if(k == 1 && cleanCsvValue(currentline[k-1]) == '' && cleanCsvValue(currentline[k]) == ''){
                      var validation = validateCsvValue(currentline[k+1],  k+1, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[k+2],  k+2, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      continue;
                    } else if (k == 2 && cleanCsvValue(currentline[k]) == ''){
                      var validation = validateCsvValue(currentline[k-1],  k-1, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[k-2],  k-2, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      validation = validateCsvValue(currentline[k+1],  k+1, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                      continue;
                    }else {
                      var validation = validateCsvValue(currentline[k], k, i);
                      if(validation && validation[0].error && validation[0].error.type !== ''){
                        retObj.error.push(validation[0].error);
                      }
                    }
                  }else {
                    var validation = validateCsvValue(currentline[k], k, i);
                    if(validation && validation[0].error && validation[0].error.type !== ''){
                      retObj.error.push(validation[0].error);
                    }
                  }
                }
              }
              retObj.data = data;
            }else{
              for (var k=0; k<configCSV.length; k++) {
                  data[k] = {"fld_name":configCSV[k].field_name,"value": cleanCsvValue(currentline[k])};
              }
                retObj.data = data;
                retObj.error.push( {
                    type: "Columns",
                    code: "Mismatch in number of columns",
                    message: $translate.instant("CSV_PARSER.ERROR.COLUMN_MISMATCH"),
                    row: lines.length,
                    index: start
                  });
            }
          }
          start++;
          result.push(retObj);
        }

        return result;
      };

      var cleanCsvValue = function(value) {
        if(typeof value === 'undefined'){
          return "";
        }else {
          return value
          .replace(/^\s*|\s*$/g,"") // remove leading & trailing space
          .replace(/^"|"$/g,"") // remove " on the beginning and end
          .replace(/""/g,'"'); // replace "" with "
        }
      };

      var validateCsvValue = function(value, fieldindex, rowindex){
        var retObj = [];
        var error = {
              type: ""
            };
        if (scope.enclosingQuotes == true){
          var quoteCheck = checkEnclosingQuotes(value, rowindex);
          if (typeof quoteCheck == 'object'){
            retObj.push({error: quoteCheck});
            return retObj
          }
        }
         switch(fieldindex){
            case fieldindex:
            if(configCSV[fieldindex].field_reqd == "yes" || value !== '""'){
                if(configCSV[fieldindex].field_validation !== ""){
                  // TODO:: When enclose quotes is driven by config setting, this next two line can be used in a switch condition
                 //  var pattern = new RegExp('^' + configCSV[fieldindex].field_validation + '$');
                 // if(!pattern.test(value)){

                 var pattern = '^\\"' + configCSV[fieldindex].field_validation + '\\"$';
                  if(!value.match(new RegExp(pattern))){
                    error = {
                        type: "Field",
                        code: "Field " + configCSV[fieldindex].field_name,
                        message: $translate.instant("CSV_PARSER.ERROR.FIELD_INVAILD." + configCSV[fieldindex].field_name),
                        row: rowindex,
                        index: fieldindex
                      }
                  }
                  break;
                }
            }
        }
        retObj.push({error: error});
        return retObj;
      }

      var checkEnclosingQuotes = function (value, rowindex, fieldindex){

        var matches = value.match(/\"/g);
        if(matches != null && matches.length != 2){
          return  {
            type: "Quotes",
            code: "MissingQuotes",
            message: "Quoted field unterminated",
            row: rowindex, // row has yet to be inserted
            index: fieldindex
          };
        }else {
           return true;
        }
      } //End checkEnclosingQuotes
    }
  }
})();
