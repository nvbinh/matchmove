(function () {
  'use strict';

  // register the service as mmUniqueEmail
  angular
    .module('app.core')
    .directive('mmUniqueEmail', mmUniqueEmail);

  // add mmUniqueEmail dependencies to inject
  // mmUniqueEmail.$inject = [''];

  /**
   * mmUniqueEmail directive
   */
  function mmUniqueEmail(MmUsers) {
    // directive definition members
    var directive = {
      require:'ngModel',
      restrict:'A',
      link: function (scope, element, attrs, ngModel) {
            element.bind('blur', function (e) {
                if (!ngModel || !element.val()) return;

                 MmUsers.checkUniqueEmail(attrs.workflow, {email:element.val()})
                    .then(function (response) {
                        //Ensure value that being checked hasn't changed
                        //since the Ajax call was made
                        if (response.data.error == true) {
                            ngModel.$setValidity('uniqueEmail', false);
                        }else {
                          ngModel.$setValidity('uniqueEmail', true);
                        }
                    }, function (error) {
                        //Probably want a more robust way to handle an error
                        //For this demo we'll set unique to true though
                        //email is invalid and hence setting the validity of email key to false
                        ngModel.$setValidity('email',false);
                    });
            });
        }
    };
    return directive;
  }
})();
