(function ()
{
    'use strict';

    angular
        .module('app.core')
        .config(config);

    /** @ngInject */
    function config($ariaProvider, $logProvider, msScrollConfigProvider, $translateProvider, appConfigProvider, msApiProvider, API_BASE, AclServiceProvider)
    {
        // Enable debug logging
        $logProvider.debugEnabled(true);

        // API provider base URl
        msApiProvider.baseUrl = API_BASE;
        // angular-translate configuration
        $translateProvider.useLoader('$translatePartialLoader', {
            urlTemplate: '{part}/i18n/{lang}.json'
        });
        $translateProvider.preferredLanguage('en');
        $translateProvider.useSanitizeValueStrategy('sanitize');

        /*eslint-disable */

        // ng-aria configuration
        $ariaProvider.config({
            tabindex: false
        });

        // App theme configurations
        appConfigProvider.config({
            'disableCustomScrollbars'        : false,
            'disableCustomScrollbarsOnMobile': true,
            'disableMdInkRippleOnMobile'     : true
        });

        // msScroll configuration
        msScrollConfigProvider.config({
            wheelPropagation: true
        });

        /*eslint-enable */

        /* ACL DATA setup */
        var aclConfig = {
            storage: 'localStorage',
            storageKey: 'mpacl'
          };
          AclServiceProvider.config(aclConfig);
    }
})();
