(function() {
    'use strict';

    angular
        .module('app.core')
        .factory('mmErrorFormatter', mmErrorFormatter);

    /** @ngInject */
    function mmErrorFormatter($translate) {
        // Private variables
        return {
            statusMessage: function(statusCode, statusMessage) {
                var statusText = "";
                if (statusCode == 400) {
                    if (statusMessage.toLowerCase().includes("user_not_found")) {
                        statusText = $translate.instant("ERROR_MESSAGE.400.USER_NOT_FOUND");
                    } else if (statusMessage.toLowerCase().includes("resource_card_fund_transfer_maximum_credit_limit_reached")) {
                        statusText = $translate.instant("ERROR_MESSAGE.400.MAXED_CREDIT_LIMIT");
                    } else if (statusMessage.toLowerCase().includes("resource_card_fund_transfer_minimum_credit_limit_reached")) {
                        statusText = $translate.instant("ERROR_MESSAGE.400.MINIMUM_CREDIT_LIMIT");
                    } else if (statusMessage.toLowerCase().includes('resource_user_wallet_fund_receiver_no_match')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.MOBILE_NOT_REGISTERED');
                    } else if (statusMessage.toLowerCase().includes("resource_user_mobilenumber_unique")) {
                        statusText = $translate.instant("ERROR_MESSAGE.400.MOBILE_ALREADY_REGISTERED");
                    } else if (statusMessage.toLowerCase().includes("resource_user_email_unique")) {
                        statusText = $translate.instant("ERROR_MESSAGE.400.EMAIL_IN_USE");
                    } else if (statusMessage.toLowerCase().includes('mobile must be a numeric')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.MOBILE_NUMERIC');
                    } else if (statusMessage.toLowerCase().includes('amount must be a numeric')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.AMOUNT_NUMERIC');
                    } else if (statusMessage.toLowerCase().includes('userauthenticationvalidationfailed')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.INVALID_OTP');
                    } else if (statusMessage.toLowerCase().includes('agent_cancelled_otp_dialog')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.AGENT_CLOSED_OTP_DIALOG');
                    } else if (statusMessage.toLowerCase().includes('debittransfererror')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.MOBILE_NO_MATCH');
                    } else if (statusMessage.toLowerCase().includes('resource_consumer_details_topup_limit_exceeded')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.DEBIT_LIMIT_EXCEEDED');
                    } else if (statusMessage.toLowerCase().includes('userphonealreadyinuse')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.USER_PHONE_ALREADY_IN_USE');
                    } else if (statusMessage.toLowerCase().includes('userauthenticationvalidationtokenexpired')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.OTP_EXPIRED');
                    } else if (statusMessage.toLowerCase().includes('mobile_country_code must be a numeric')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.MOBILE_COUNTRY_CODE_NUMERIC');
                    } else if (statusMessage.toLowerCase().includes('resource_user_firstname_rule')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.FIRST_NAME_INVALID');
                    } else if (statusMessage.toLowerCase().includes('resource_user_prefername_rule')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.PREFERRED_NAME_INVALID');
                    } else if (statusMessage.toLowerCase().includes('user_parameter_validation_failed')) {
                        if (statusMessage.toLowerCase().includes('amount')) {
                            statusText = $translate.instant('ERROR_MESSAGE.400.AMOUNT_INVALID');
                        } else if (statusMessage.toLowerCase().includes('mobile')) {
                            statusText = $translate.instant('ERROR_MESSAGE.400.MOBILE_INVALID');
                        } else if (statusMessage.toLowerCase().includes('email')) {
                            statusText = $translate.instant('ERROR_MESSAGE.400.EMAIL_INVALID');
                        }
                    } else if (statusMessage.toLowerCase().includes('assoc_number_invalid')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.CARD_PROXY_INVALID');
                    } else if (statusMessage.toLowerCase().includes('resource_card_fund_transfer_purse_monthly_count_limit_reached')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.MONTHLY_LIMIT_REACHED');
                    } else if (statusMessage.toLowerCase().includes('parameter_assoc_number_in_use')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.CARD_PROXY_IN_USE');
                    } else if(statusMessage.toLowerCase().includes('400 Invalid Card hash id')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.INVALID_CARD_PROXY');
                    } else if(statusMessage.toLowerCase().includes('400 usercardsnotfound')) {
                        statusText = $translate.instant('ERROR_MESSAGE.400.CARDS_NOT_FOUND');
                    }

                } else if (statusCode == 200) {
                    if (statusMessage.toLowerCase().includes('token') && statusMessage.toLowerCase().includes('success')) {
                        statusText = $translate.instant("MESSAGES.200.TRANSACTION_CANCELLED");
                    }
                } else if (statusCode == 401) {
                    if (statusMessage.toLowerCase().includes("unauthorized")) {
                        statusText = $translate.instant("ERROR_MESSAGE.401.UNAUTHORIZED");
                    }
                } else if(statusCode == 403)
                {
                    if(statusMessage.toLowerCase().includes('user_blocked_risk_threshold_exceeded'))
                    {
                        statusText = $translate.instant("ERROR_MESSAGE.403.USER_BLOCKED")
                    }  else if(statusMessage.toLowerCase().includes('card is currently inactive ')) {
                        statusText = $translate.instant('ERROR_MESSAGE.403.CARDS_IS_INACTIVE');
                    }

                }
                else if (statusCode == 408) {
                    if (statusMessage.toLowerCase().includes("request_timeout")) {
                        statusText = $translate.instant("ERROR_MESSAGE.408.REQUEST_TIMEOUT");
                    }
                } else if (statusCode == 500) {
                    if (statusMessage.toLowerCase().includes("internal server error")) {
                        statusText = $translate.instant("ERROR_MESSAGE.500.SERVER_ERROR");
                    }
                    else if (statusMessage.toLowerCase().includes("fatal service error")) {
                        statusText = $translate.instant("ERROR_MESSAGE.500.SERVER_ERROR");
                    }
                    else if (statusMessage.toLowerCase().includes("email is already in user")) {
                        statusText = $translate.instant("ERROR_MESSAGE.500.EMAIL_IN_USE");
                    }
                } else if (statusCode == 502) {
                    statusText = $translate.instant("ERROR_MESSAGE.502.BAD_GATEWAY");
                } else if (statusCode == 503) {
                    if (statusMessage.toLowerCase().includes("back-end server is at capacity")) {
                        statusText = $translate.instant("ERROR_MESSAGE.503.SERVER_CAPACITY");
                    }
                } else if (statusCode == 504) {
                    if (statusMessage.toLowerCase().includes('gateway_timeout')) {
                        statusText = $translate.instant("ERROR_MESSAGE.504.GATEWAY_TIMEOUT");
                    }
                }
                //if statustext is not set in any of the above, return the statusmessage as is
                return statusText == "" ? statusMessage : statusText;

            }
        };

    }

}());
