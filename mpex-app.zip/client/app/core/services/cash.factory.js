(function ()
{
    'use strict';

    angular
        .module('app.core')
        .service('cashFactory', cashFactory);

    function cashFactory($http, ENDPOINT_BASE){
      return {
        cashOut: function (params) {
                 //return $http.post(ENDPOINT_BASE + 'users/wallets/debit', params);
                   return $http({
                     method: 'POST',
                          url: ENDPOINT_BASE + 'users/wallets/debit',
                          headers: {
                            // 'Authorization': authen,
                            'Content-Type': 'application/x-www-form-urlencoded'
                          },
                          transformRequest: function(obj) {
                                              var str = [];
                                              for(var p in obj) {
                                                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                                              }
                                              return str.join('&');
                                            },
                          data: params
                   });
                 }
      };
    }

})();
