'use strict';

describe('Service: MmUsers', function () {

  // load the service's module
  beforeEach(module('adminApp'));

  // instantiate service
  var service;

  beforeEach(inject(function (_MmUsers_) {
    service = _MmUsers_;
  }));

  it('should be defined', function () {
    Should.exist(service);
  });

  it('should expose a working doSomething function', function () {
    Should.exist(service.doSomething);
    service.doSomething().should.equal('mm-users');
  });

});
