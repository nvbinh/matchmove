(function () {
  'use strict';

  // register the service as MmUsersService
  angular
    .module('app.core')
    .service('MmUsers', MmUsers);

  // add MmUsers dependencies to inject
  // MmUsers.$inject = [''];

  /**
   * MmUsers constructor
   * AngularJS will instantiate a singleton by calling "new" on this function
   * @returns {Object} The service definition for the MmUsers Service
   */
  function MmUsers($http, API_BASE, store) {

    return {
      checkUniqueEmail: checkUniqueEmail
    };

    // define instance methods
    function checkUniqueEmail (workflow, inputEmail) {
       var encodedEmail = inputEmail.email.replace(/@/g, "%40");
       var authen = store.get('globalsTo');

       if(workflow ==='AGENT_CREATE' ){
          return $http.get(API_BASE + 'agents/uniquemail/'+ encodedEmail , {headers: {'Authorization': 'Bearer '+ authen}})
       }
       if (workflow === 'WALLET_USER_CREATE'){
          return $http.get(API_BASE + 'walletusers/uniquemail/'+ encodedEmail , {headers: {'Authorization': 'Bearer '+ authen}})
       }
    }
  }

})();
