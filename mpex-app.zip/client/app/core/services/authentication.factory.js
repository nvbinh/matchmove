(function ()
{
    'use strict';

    angular
        .module('app.core')
        .service('authenticationFactory', authenticationFactory);

    function authenticationFactory(base64Factory,$http, ENDPOINT_BASE){
      return {
        login: function(username, password) {
                 $http.defaults.headers.common['Authorization'] = 'Basic ' + base64Factory.encode(username + ':' + password);// jshint ignore:line
                 $http.defaults.headers.post['Authorization'] = 'Basic ' + base64Factory.encode(username + ':' + password); // jshint ignore:line
                 $http.defaults.headers.put['Authorization'] = 'Basic ' + base64Factory.encode(username + ':' + password); // jshint ignore:line
                 return $http.post(ENDPOINT_BASE + 'auth', { username: username, password: password });
               },
        SetCredentials: function(username, password) {
            var authdata = base64Factory.encode(username + ':' + password);
//            $rootScope.globals = {
//                currentUser: {
//                    username: username,
//                    authdata: authdata
//                }
//            };
//            store.set('globals', $rootScope.globals);

            $http.defaults.headers.common['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
            $http.defaults.headers.post['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
            $http.defaults.headers.put['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
         }
      }

    }

})();
