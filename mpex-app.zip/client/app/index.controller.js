(function ()
{
    'use strict';

    angular
        .module('admin')
        .controller('IndexController', IndexController);

    /** @ngInject */
    function IndexController(appTheming, BRANDING)
    {
        var vm = this;
        vm.branding = BRANDING;
        // Data
        vm.themes = appTheming.themes;

        //////////
    }
})();
