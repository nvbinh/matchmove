(function ()
{
    'use strict';

    angular
        .module('admin')
        .config(config);

    /** @ngInject */
    function config($authProvider, API_BASE )
    {
        // Put your custom configurations here
        $authProvider.httpInterceptor = function() { return true; },
		$authProvider.withCredentials = false;
		$authProvider.tokenRoot = null;
		$authProvider.baseUrl = API_BASE;
		$authProvider.loginUrl = '/login';
		$authProvider.signupUrl = '/auth/signup';
		$authProvider.tokenName = 'token';
		$authProvider.tokenPrefix = 'satellizer';
		$authProvider.tokenHeader = 'Authorization';
		$authProvider.tokenType = 'Bearer';
		$authProvider.storageType = 'localStorage';
    }

})();
