'use strict';
/**
 * @ngdoc filter
 * @name viewMultipleWallet.filter:ccfilter
 * @function
 * @description
 * # ccfilter
 * Filter in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .filter('maskedcardfilter', function () {
    return function (input) {
    	if(!input) {
    		return '';
    	}
        var value = input.toString().trim();
        var leader , middle , middleEnd , ender , cardnumber;

        switch(value.substring(0,1)) {
            default:
                leader = input.slice(0,4);
                middle = input.slice(4,8);
                middleEnd = input.slice(8,12);
                ender = input.slice(12,16);
                cardnumber = leader + '-' + middle + '-' + middleEnd + '-' + ender;
                break;
        }

        return cardnumber;
    };
  });
