'use strict';

describe('Filter: maskedcardfilter', function () {
// load the filter's module

    beforeEach(module('viewMultipleWallet'));
    // initialize a new instance of the filter before each test
    var maskedcardfilterFilter;
    beforeEach(inject(function(_maskedcardfilterFilter_) {
        maskedcardfilterFilter = _maskedcardfilterFilter_;
    }));
    it('"maskedfilter filter:" should process card correctly', function () {
        expect(maskedcardfilterFilter('xxxxxxxxxxxx555')).toBe('xxxx-xxxx-xxxx-555');
    });
});
