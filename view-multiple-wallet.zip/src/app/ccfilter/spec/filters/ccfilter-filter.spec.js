'use strict';

describe('Filter: ccfilter', function () {
// load the filter's module

    beforeEach(module('viewMultipleWallet'));
    // initialize a new instance of the filter before each test
    var ccfilterFilter;
    beforeEach(inject(function(_ccfilterFilter_) {
        ccfilterFilter = _ccfilterFilter_;
    }));
    it('"ccfilter filter:" should process Amex card correctly', function () {
        expect(ccfilterFilter('375546005017503')).toBe('3755 460050 17503');
    });
    it('"ccfilter filter:" should process Master card correctly', function () {
        expect(ccfilterFilter('5412333344445555')).toBe('5412 3333 4444 5555');
    });
    it('"ccfilter filter:" should process Visa card correctly', function () {
        expect(ccfilterFilter('4412333344445555')).toBe('4412 3333 4444 5555');
    });
});
