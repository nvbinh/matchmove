'use strict';
angular.module('viewMultipleWallet')
    .factory('timeUtilFactory',(
        function ($translate) {
            return {
                dhms: function (t) {
                    var days, hours, minutes, seconds;
                    days = Math.floor(t / 86400);
                    if (t > 0) {
                        t -= days * 86400;
                        hours = Math.floor(t / 3600) % 24;
                        t -= hours * 3600;
                        minutes = Math.floor(t / 60) % 60;
                        t -= minutes * 60;
                        seconds = t % 60;
                        return [minutes + " " + $translate.instant('COMPONENT.TIME_UTIL.TIMER_TEXT.MINUTES') , seconds +  " " + $translate.instant('COMPONENT.TIME_UTIL.TIMER_TEXT.SECONDS') ].join(' ');
                    } else {
                        return [0 + " " + $translate.instant('COMPONENT.TIME_UTIL.TIMER_TEXT.MINUTES'), 0 + " " + $translate.instant('COMPONENT.TIME_UTIL.TIMER_TEXT.SECONDS') ].join(' ');
                    }
                }
            };
        }
    ));
