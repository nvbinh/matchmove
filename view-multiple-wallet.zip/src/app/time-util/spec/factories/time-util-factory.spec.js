'use strict';
describe('Factory: timeUtilFactory', function() {
  var timeUtil,
  translate;
  beforeEach(module('viewMultipleWallet'));

  beforeEach(inject(function(_timeUtilFactory_, _$translate_) {
    timeUtil = _timeUtilFactory_;
    translate = _$translate_;
    spyOn(translate, 'instant').and.callFake(function(input){
        switch (input){
            case 'COMPONENT.TIME_UTIL.TIMER_TEXT.MINUTES':
                return 'minutes';
                break;
            case 'COMPONENT.TIME_UTIL.TIMER_TEXT.SECONDS':
                return 'seconds';
                break;
        }
    });
  }));

   it('should display the given unixtimestamp in mins secs', function() {
     var minsecs = timeUtil.dhms(1454988492491);
     expect(minsecs).toBe('8 minutes 11 seconds');
   });
   it('should display the given unixtimestamp in mins secs', function() {
     var minsecs = timeUtil.dhms(0);
     expect(minsecs).toBe('0 minutes 0 seconds');
   });
});
