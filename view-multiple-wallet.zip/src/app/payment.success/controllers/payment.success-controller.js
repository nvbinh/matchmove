'use strict';
/* global angular */
/* global $ */
/* global window */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:paymentSuccessCtrl
 * @description
 * # paymentSuccessCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'paymentSuccessCtrl', function ( $scope, SIGNUP_PARAMS) {
        $scope.signupParams = angular.fromJson( SIGNUP_PARAMS );
    } );
