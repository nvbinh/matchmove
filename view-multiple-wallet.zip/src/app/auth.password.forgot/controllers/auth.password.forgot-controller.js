'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authPasswordForgotCtrl
 * @description
 * # authPasswordForgotCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authPasswordForgotCtrl', function ( $scope, $stateParams, rc4Factory, authPasswordFactory, $timeout, $state, $translate, $analytics ) {
        $scope.token = $stateParams.token;
        $scope.validationError = '';

        function resetFormState() {
            $scope.errorGeneric = false;
            $scope.success = false;
        }

        function postSuccessRedirection() {
            $state.go( 'auth.login' );
        }
        resetFormState();

        $scope.changePassword = function () {
            resetFormState();
            $scope.isLoading = true;
            if ( $scope.password === $scope.rePassword ) {
                $scope.isLoading = true;
                authPasswordFactory.verifyRecoverToken( $scope.token, $scope.password )
                    .then( function () {
                        $scope.success = true;
                        $scope.isLoading = false;
                        $timeout( postSuccessRedirection, 10000 );
                    }, function ( error ) {
                        if ( error.status === 500 ) {
                            $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR500' );
                        } else if ( error.status === 400 ) {
                            if ( error.statusText.indexOf( 'userAuthenticationEmailNotFound' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.EMAIL_NOT_FOUND' );
                                $analytics.eventTrack( 'Wallet Password Forgot Error', {
                                    category: 'Wallet Password Forgot',
                                    label: 'Wallet Password Forgot Error : ' + error.status + ' : ' + error.statusText
                                } );
                            } else if ( error.statusText.indexOf( 'userAuthenticationValidationFailed' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.INVALID_TOKEN' );
                                $analytics.eventTrack( 'Wallet Password Forgot Error', {
                                    category: 'Wallet Password Forgot',
                                    label: 'Wallet Password Forgot Error : ' + error.status + ' : ' + error.statusText
                                } );
                            } else if ( error.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.INVALID_TOKEN' );
                                $analytics.eventTrack( 'Wallet Password Forgot Error', {
                                    category: 'Wallet Password Forgot',
                                    label: 'Wallet Password Forgot Error : ' + error.status + ' : ' + error.statusText
                                } );
                            } else {
                                $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR400' );
                                $analytics.eventTrack( 'Wallet Password Forgot Error', {
                                    category: 'Wallet Password Forgot',
                                    label: 'Wallet Password Forgot Error : ' + error.status + ' : ' + error.statusText
                                } );
                            }

                        } else if ( error.status === 401 ) {
                            if ( error.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR401TOKENEXPIRED' );
                            } else {
                                $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR401' );
                            }
                        } else {
                            $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERRORGENERIC' );
                        }
                        $scope.errorGeneric = true;
                        $scope.isLoading = false;
                    } );
            } else {
                $scope.isLoading = false;
                $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.PASSWORD_NOMATCH' );
                $scope.errorGeneric = true;
            }
        };
    } );
