'use strict';
describe( 'Controller: authPasswordForgotCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authPasswordForgotCtrl,
        scope,
        changePassForm,
        httpBackend,
        authPasswordFactory,
        deferred,
        $q;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.password.temporary/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, _authPasswordFactory_, _$q_ ) {
        scope = $rootScope.$new();
        $q = _$q_;
        authPasswordFactory = _authPasswordFactory_;
        authPasswordForgotCtrl = $controller( 'authPasswordForgotCtrl', {
            $scope: scope
        } );

        var formText = '<form name="changePassForm" ng-submit="changePassword()" autocomplete="off" novalidate>';
        formText += '<input type="password" name="password" ng-model="password" ng-minlength=8 ng-maxlength=32     ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required>';
        formText += '<input type="password" name="password_confirm" ng-model="rePassword" ng-minlength=8 ng-maxlength=32     ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required>';
        formText += '</form>';
        httpBackend.flush();

        $compile( formText )( scope );
        scope.$digest();
        changePassForm = scope.changePassForm;
    } ) );
    it( 'Should have the variables properly defined', function () {
        expect( scope.validationError ).toBeDefined();
        expect( scope.success ).toBeDefined();
    } );
    it( 'Should have variables properly initialized', function () {
        expect( scope.success ).toBe( false );
    } );


    describe( 'authPasswordForgotCtrl changePassword not mached', function () {
        beforeEach( inject( function () {
            scope.password = '1';
            scope.rePassword = '2';
            scope.changePassword();
        } ) );

        it( 'confirm password is not matched', function () {
            expect( scope.validationError ).toBeDefined();
            expect( scope.errorGeneric ).toBeTruthy();
        } );
    } );

    describe( 'authPasswordForgotCtrl changePassword matched', function () {
        beforeEach( inject( function () {
            spyOn( authPasswordFactory, 'verifyRecoverToken' ).and.callFake( function () {
                return {
                    then: function ( callback ) {
                        return callback();
                    }
                };
            } );
            scope.password = '1';
            scope.rePassword = '1';
            scope.changePassword();
        } ) );

        it( 'Verify recover token successful', function () {
            expect( authPasswordFactory.verifyRecoverToken ).toHaveBeenCalled();
        } );
    } );

    describe( 'authPasswordForgotCtrl changePassword matched', function () {
        beforeEach( inject( function () {
            deferred = $q.defer();
            spyOn( authPasswordFactory, 'verifyRecoverToken' ).and.returnValue( deferred.promise );
            deferred.reject( {} );
            scope.password = '1';
            scope.rePassword = '1';
            scope.changePassword();
            scope.$digest();
        } ) );

        it( 'Verify recover token fail', function () {
            expect( authPasswordFactory.verifyRecoverToken ).toHaveBeenCalled();
        } );
    } );

} );

describe( 'Controller: authPasswordForgotCtrl: HTTP call Scenarios', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authPasswordForgotCtrl,
        scope,
        httpBackend,
        authPasswordFactory,
        API_BASE,
        state,
        timeout;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.password.temporary/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, _authPasswordFactory_, _API_BASE_, _$state_, _$timeout_ ) {
        scope = $rootScope.$new();
        API_BASE = _API_BASE_;
        state = _$state_;
        timeout = _$timeout_;
        authPasswordFactory = _authPasswordFactory_;
        authPasswordForgotCtrl = $controller( 'authPasswordForgotCtrl', {
            $scope: scope
        } );
        scope.token = 'abcdefghijkl';
        scope.password = 'onepassword';
        scope.rePassword = 'onepassword';
        spyOn(authPasswordFactory, 'verifyRecoverToken').and.callThrough();
    } ) );
    afterEach(function() {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
      });
    // TODO: fix later
    // it('Fn postSuccessRedirection', function(){
    //     httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(200, '', {}, 'HTTP/1.1 200 reco password success');

    //     spyOn(state, 'go').and.callThrough();
    //     spyOn(timeout, 'flush').and.callThrough();
    //     scope.password = '1';
    //     scope.rePassword = '1';
    //     scope.token = 'abcdeeffdgdf';
    //     scope.changePassword();
    //     timeout.flush(100);
    //     httpBackend.flush();
    //     expect(state.go).toHaveBeenCalled();
    // })

    describe( 'Fn changePassword ', function () {
        it( 'Error 500', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(500, '', {}, 'HTTP/1.1 500 reco password server error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('PAGES.WALLET_PASSWORD_CHANGE.ERROR500');
        } );
        it( 'Error 400 : userAuthenticationEmailNotFound', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(400, '', {}, 'HTTP/1.1 400 userAuthenticationEmailNotFound error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('ERRORS.VALIDATION.PASSWORD_RECOVER.400.EMAIL_NOT_FOUND');
        } );
        it( 'Error 400 : userAuthenticationValidationFailed', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(400, '', {}, 'HTTP/1.1 400 userAuthenticationValidationFailed error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('ERRORS.VALIDATION.PASSWORD_RECOVER.400.INVALID_TOKEN');
        } );
        it( 'Error 400 : userAuthenticationValidationTokenExpired', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(400, '', {}, 'HTTP/1.1 400 userAuthenticationValidationTokenExpired error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('ERRORS.VALIDATION.PASSWORD_RECOVER.400.INVALID_TOKEN');
        } );
        it( 'Error 400 : generic', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(400, '', {}, 'HTTP/1.1 400 generic error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('PAGES.WALLET_PASSWORD_CHANGE.ERROR400');
        } );
        it( 'Error 401 : userAuthenticationValidationTokenExpired', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(401, '', {}, 'HTTP/1.1 401 userAuthenticationValidationTokenExpired error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('PAGES.WALLET_PASSWORD_CHANGE.ERROR401TOKENEXPIRED');
        } );
        it( 'Error 401 : generic', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(401, '', {}, 'HTTP/1.1 401 generic error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('PAGES.WALLET_PASSWORD_CHANGE.ERROR401');
        } );
        it( 'Error 501 : other error', function () {
            httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(501, '', {}, 'HTTP/1.1 501 other error');
            scope.changePassword();
            httpBackend.flush();
            expect( scope.validationError ).toBe('PAGES.WALLET_PASSWORD_CHANGE.ERRORGENERIC');
        } );
    } );
} );
