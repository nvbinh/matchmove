'use strict';
describe('Factory: authPasswordFactory', function() {
  var authPassword,
  	  httpBackend,
  	  API_BASE,
  	  rc4Factory,
  	  scope,
      endpointdata,
      passTokenResp,
      passVerifyResp,
      passRecoVerifyResp;
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize factory
  beforeEach(inject(function(_authPasswordFactory_, _API_BASE_, $rootScope, _rc4Factory_, HTTP_HOST, EMAIL_VERIFICATION_URL) {
    authPassword = _authPasswordFactory_;
    API_BASE = _API_BASE_;
    rc4Factory = _rc4Factory_;
    scope = $rootScope;
    endpointdata = HTTP_HOST + EMAIL_VERIFICATION_URL;

    passTokenResp = angular.toJson({
      "status": "success",
      "token": "27ccba12efb3cfcf00708386a297efef"
    });
    passVerifyResp = angular.toJson({
      "status": "password verify success"
    });
    passRecoVerifyResp = angular.toJson({
      "status": "password recovery success"
    });
    httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(200, passTokenResp);
    httpBackend.whenPUT(API_BASE + 'users/authentications/password').respond(200, passVerifyResp);
    httpBackend.whenPUT(API_BASE + 'users/recover/password').respond(200, passRecoVerifyResp);
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

  	it('should have authPassword service be defined', function () {
    	expect(authPassword).toBeDefined();
  	});
	it(' - change password token is generated correctly', function () {
		authPassword.getToken(endpointdata).then(function (response) {
            expect(response.data).toBeDefined();
			expect(response.data.token).toBe('27ccba12efb3cfcf00708386a297efef');
		});
        httpBackend.flush();
	});
	it(' - verify token is returned 200 when token and new password are correct', function () {
        spyOn(rc4Factory, 'encode').and.callThrough();
		authPassword.verifyToken('27ccba12efb3cfcf00708386a297efef', 'abcd1234').then(function(response){
            expect(response.data).toBeDefined();
            expect(response.data.status).toBe('password verify success');
        });
        httpBackend.flush();
	});
	it(' - verify recover token is returned 200 when token and password are correct', function () {		
		spyOn(rc4Factory, 'encode').and.callThrough();
        authPassword.verifyRecoverToken('27ccba12efb3cfcf00708386a297efef', 'abcd1234').then(function(response){
            expect(response.data).toBeDefined();
            expect(response.data.status).toBe('password recovery success');
        });
        httpBackend.flush();
	});
});
