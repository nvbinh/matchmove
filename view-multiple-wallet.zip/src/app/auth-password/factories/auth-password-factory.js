'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authPassword
 * @description
 * # authPassword
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .factory('authPasswordFactory', function ($http, rc4Factory, API_BASE) {
  // Service logic
  function getToken(endpointdata) {
      return $http({
        method: 'POST',
        url: API_BASE + 'users/authentications/password',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        transformRequest: function(obj) {
            var str = [];
            for(var p in obj) {
                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
            }
            return str.join('&');
        },
        data: endpointdata
      });

    }
  function verifyToken(token, password) {
      return $http({
        method: 'PUT',
        url: API_BASE + 'users/authentications/password',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        transformRequest: function(obj) {
            var str = [];
            for(var p in obj) {
                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
            }
            return str.join('&');
        },
        data: {'key':rc4Factory.encode(token, password), 'token':token}
      });

    }
  function verifyRecoverToken(token, password) {
      return $http({
        method: 'PUT',
        url: API_BASE + 'users/recover/password',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        transformRequest: function(obj) {
            var str = [];
            for(var p in obj) {
                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
            }
            return str.join('&');
        },
        data: {'key':rc4Factory.encode(token, password), 'token':token}
      });
    }
  // Add description
  getToken.description = 'authPasswordFactory:getToken';
  verifyToken.description = 'authPasswordFactory:verifyToken';
  verifyRecoverToken.description = 'authPasswordFactory:verifyRecoverToken';
  // Public API here
  return {
    getToken: getToken,
    verifyToken: verifyToken,
    verifyRecoverToken: verifyRecoverToken
  };
});
