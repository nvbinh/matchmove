'use strict';
/* global angular */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:loginCtrl
 * @description
 * # loginCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authLoginCtrl', function ( $scope, $rootScope, $state, $http, $analytics, authenticationFactory, userFactory, authDocumentFactory, store, MM_BRANDING, loginSvcService ) {
        authenticationFactory.ClearCredentials();
        $scope.credentials = {
            email: '',
            password: ''
        };
        $scope.userInfo = {};
        $scope.showBranding = MM_BRANDING;
        $scope.errorLoginGenric = false;

        $scope.doLogin = function () {
             $scope.errorLoginGenric = false;
            loginSvcService.login( $scope.credentials ).then( function ( response ) {
                $scope.isUserLoggedIn = true;
            }, function ( error ) {
                $scope.isUserLoggedIn = false;
                $scope.errorLoginGenric = true;
            } )
        }

        $scope.login = function () {
            $scope.errorLoginGenric = false;
            $scope.isLoading = true;
            authenticationFactory.Login( $scope.credentials.email, $scope.credentials.password )
                .then( function ( data, status, headers, config ) {
                    authenticationFactory.SetCredentials( data.data.key, data.data.secret );
                    $analytics.eventTrack( 'Login Success', {
                        category: 'Login',
                        label: 'Login Succesfull'
                    } );
                    userFactory.getUser()
                        .then( function ( response ) {
                            userFactory.setCurrentUser( response.data );
                            $analytics.setUsername( response.data.id );
                            $rootScope.$broadcast( 'authorized' );
                            $analytics.setUserProperties( {
                                '$email': response.data.email,
                                '$registration_date': response.data.date.registration,
                                '$mobile': response.data.mobile.country_code + response.data.mobile.number,
                                '$name': response.data.name.first + ' ' + response.data.name.first
                            } ); // jshint ignore:line
                            $state.go( 'wallet.home' );
                            // $scope.isLoading = false;
                        }, function ( response ) {
                            if ( response.status === 500 ) {
                                $scope.errorLoginGenric = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Error 500',
                                    label: 'Error getting User Info after login'
                                } );
                            } else if ( response.status === 403 ) {
                                $scope.errorLoginGenric = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Risk Activity',
                                    label: 'User forbidden to login because of Risk Alert'
                                } );
                            } else {
                                $scope.errorLoginGenric = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Login',
                                    label: 'Login error : ' + response.status + ' : ' + response.statusText
                                } );
                            }
                        } );
                    authDocumentFactory.getStatus(false);
                }, function ( response ) {
                    $scope.errorLoginGenric = true;
                    // $scope.isLoading = false;
                    $scope.errorMessagetext = $rootScope.errorHandler.errors[ 0 ];
                } );
        };
    } );
