'use strict';
describe( 'Service: loginSvcService :: Success Scenarios', function () {
    var loginSvc,
        store,
        rootScope,
        httpBackend,
        API_BASE,
        auth,
        user,
        authDocument,
        userData,
        walletData,
        state;
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.home/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.card.new/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.loyalty.list/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize Service
    beforeEach( inject( function ( $rootScope, _loginSvcService_, _store_, _API_BASE_, _authenticationFactory_, _userFactory_, _authDocumentFactory_, _$state_ ) {
        rootScope = $rootScope.$new();
        rootScope.credentials = {
            email: 'balajiv+24@chimeratechnologies.com',
            password: 'abcd1234'
        };
        loginSvc = _loginSvcService_;
        store = _store_;
        API_BASE = _API_BASE_;
        auth = _authenticationFactory_;
        user = _userFactory_;
        authDocument = _authDocumentFactory_;
        state = _$state_;
        store.set( 'controller', 'loginSvcService' );

        userData = {
            "id": "7e44d2be136976e9fe15377e654dff63",
            "email": "balaji_b_v@yahoo.com",
            "name": {
                "first": "Balaji",
                "last": "V",
                "preferred": "Balaji"
            },
            "mobile": {
                "country_code": "65",
                "number": "12345675"
            },
            "countryofissue": "India",
            "identification": {
                "type": "passport",
                "number": "ABCDEFGH"
            },
            "birthday": "1998-01-05",
            "gender": "male",
            "title": "Mr",
            "status": {
                "is_active": true,
                "text": "active"
            },
            "date": {
                "registration": "2015-12-15T16:26:17+08:00"
            },
            "authentications": {
                "email_verified": true,
                "mobile_verified": false
            },
            "login_info": {
                "logins": 156,
                "last_login": "2016-02-08T17:31:24+08:00"
            }
        };
        walletData = {
            'id': '3967eaf6053fbd652d162691dc110fd2',
            'number': '6501110007662669',
            'holder': {
                'name': 'Shantanu'
            },
            'funds': {
                'available': {
                    'currency': 'SGD',
                    'amount': '5.35'
                },
                'withholding': {
                    'currency': 'SGD',
                    'amount': '0.00'
                }
            },
            'type': {
                'type': 'mmvwallet',
                'name': 'MatchMove Virtual Wallet',
                'description': 'Matchmove Virtual Wallet'
            },
            'date': {
                'expiry': '2023-11',
                'issued': '2015-08-19'
            },
            'image': {
                'small': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png',
                'medium': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png',
                'large': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png'
            },
            'status': {
                'is_active': true,
                'text': 'active'
            },
            'links': [ {
                'rel': 'securities.tokens',
                'href': '',
                'method': 'GET'
            }, {
                'rel': 'cards.transactions',
                'href': '',
                'method': 'GET'
            }, {
                'rel': 'cards.funds.transfers',
                'href': '',
                'method': 'GET'
            } ]
        };

        spyOn( auth, 'Login' ).and.callThrough();
        spyOn( auth, 'SetCredentials' ).and.callThrough();
        spyOn( user, 'getUser' ).and.callThrough();
        spyOn( authDocument, 'getStatus' ).and.callThrough();

        httpBackend.whenGET( API_BASE + 'users' ).respond( 200, userData );
        httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, '' );
        httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
        httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 200, '' );
        httpBackend.whenGET( API_BASE + 'users/addresses/residential' ).respond( 200, {data: null} );
        httpBackend.whenGET( API_BASE + 'users/addresses/billing' ).respond( 200, {data: null} );

        httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '' );
        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    describe( 'Login Service functionality', function () {
        it( 'shuold set the store variable', function () {
            var strController = store.get( 'controller' );
            expect( strController ).toBe( 'loginSvcService' );
        } );
        it( 'should have variables defined', function () {
            expect( rootScope.credentials ).toBeDefined();
        } );
        it( 'Should login a user', function () {
            state.current.name = 'auth.login';
            loginSvc.login( rootScope.credentials );
            httpBackend.flush();
        } );
        it( 'resume a User Session', function () {
            loginSvc.resumeSession( rootScope.credentials );
            httpBackend.flush();
            expect( rootScope.isLoading ).toBeFalsy();
        } );
    } );
} );

describe( 'Service: loginSvcService :: Error Scenarios', function () {
    var loginSvc,
        store,
        rootScope,
        httpBackend,
        API_BASE,
        auth,
        user,
        authDocument,
        userData,
        walletData;
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.home/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.card.new/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize Service
    beforeEach( inject( function ( $rootScope, _loginSvcService_, _store_, _API_BASE_, _authenticationFactory_, _userFactory_, _authDocumentFactory_ ) {
        rootScope = $rootScope.$new();
        rootScope.credentials = {
            email: 'balajiv+24@chimeratechnologies.com',
            password: 'abcd1234'
        };
        loginSvc = _loginSvcService_;
        store = _store_;
        API_BASE = _API_BASE_;
        auth = _authenticationFactory_;
        user = _userFactory_;
        authDocument = _authDocumentFactory_;

        store.set( 'controller', 'loginSvcService' );

        userData = {
            "id": "7e44d2be136976e9fe15377e654dff63",
            "email": "balaji_b_v@yahoo.com",
            "name": {
                "first": "Balaji",
                "last": "V",
                "preferred": "Balaji"
            },
            "mobile": {
                "country_code": "65",
                "number": "12345675"
            },
            "countryofissue": "India",
            "identification": {
                "type": "passport",
                "number": "ABCDEFGH"
            },
            "birthday": "1998-01-05",
            "gender": "male",
            "title": "Mr",
            "status": {
                "is_active": true,
                "text": "active"
            },
            "date": {
                "registration": "2015-12-15T16:26:17+08:00"
            },
            "authentications": {
                "email_verified": true,
                "mobile_verified": false
            },
            "login_info": {
                "logins": 156,
                "last_login": "2016-02-08T17:31:24+08:00"
            }
        };
        walletData = {
            'id': '3967eaf6053fbd652d162691dc110fd2',
            'number': '6501110007662669',
            'holder': {
                'name': 'Shantanu'
            },
            'funds': {
                'available': {
                    'currency': 'SGD',
                    'amount': '5.35'
                },
                'withholding': {
                    'currency': 'SGD',
                    'amount': '0.00'
                }
            },
            'type': {
                'type': 'mmvwallet',
                'name': 'MatchMove Virtual Wallet',
                'description': 'Matchmove Virtual Wallet'
            },
            'date': {
                'expiry': '2023-11',
                'issued': '2015-08-19'
            },
            'image': {
                'small': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png',
                'medium': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png',
                'large': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png'
            },
            'status': {
                'is_active': true,
                'text': 'active'
            },
            'links': [ {
                'rel': 'securities.tokens',
                'href': '',
                'method': 'GET'
            }, {
                'rel': 'cards.transactions',
                'href': '',
                'method': 'GET'
            }, {
                'rel': 'cards.funds.transfers',
                'href': '',
                'method': 'GET'
            } ]
        };

        spyOn( auth, 'Login' ).and.callThrough();
        spyOn( auth, 'SetCredentials' ).and.callThrough();
        spyOn( user, 'getUser' ).and.callThrough();
        spyOn( authDocument, 'getStatus' ).and.callThrough();

        httpBackend.whenGET( API_BASE + 'users/addresses/residential' ).respond( 200, {data: null} );
        httpBackend.whenGET( API_BASE + 'users/addresses/billing' ).respond( 200, {data: null} );
        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    describe( 'Login Success, User data error 500 ', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 500, {}, {}, 'HTTP/1.1 500 Internal server error' );
            httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 500, {}, {}, 'HTTP/1.1 500 Internal server error' );
            httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 500, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 500, '' );
        } ) );

        it( 'Should Error 500 upon user fetch', function () {
            loginSvc.login( rootScope.credentials );
            httpBackend.flush();
            expect( rootScope.errorLoginGenric ).toBeTruthy();
        } );
    } );
    describe( 'Login Success, User data Error 401 ', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 401, {}, {}, 'HTTP/1.1 401 Invalid Password/Username' );
            httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 401, {}, {}, 'HTTP/1.1 401 unauthorized' );
            httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 401, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 401, '' );
        } ) );

        it( 'Should Error 401 upon user fetch', function () {
            loginSvc.login( rootScope.credentials );
            httpBackend.flush();
            expect( rootScope.errorLoginGenric ).toBeTruthy();
        } );
    } );
    describe( 'Login error 401 invalid password', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 401, 'invalid password', {}, 'HTTP/1.1 401 invalid username/password' );
        } ) );
        it( 'Should error 401 upon user login', function () {
            loginSvc.login( rootScope.credentials );
            httpBackend.flush();
            expect( rootScope.errorLoginGenric ).toBeTruthy();
        } );
        it( 'Should error 401 upon user session resume', function () {
            loginSvc.resumeSession( rootScope.credentials );
            httpBackend.flush();
            expect( rootScope.errorLoginGenric ).toBeTruthy();
        } );
    } )
} );
