'use strict';
describe( 'Controller: authLoginCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authLoginCtrl,
        scope,
        httpBackend,
        authenticationFactory,
        authDocumentFactory,
        loginForm,
        userFactory,
        userInfo,
        username,
        password,
        email,
        secret,
        q,
        state,
        API_BASE;

    // mocking the authenticationFactory, userFactory and state services with mock return values
    /*  beforeEach(inject(function($state, _authenticationFactory_, _userFactory_, $q){
      authenticationFactory = _authenticationFactory_;
      userFactory = _userFactory_;
      state = $state;

       authenticationFactory.Login = function(){
        var deferred = $q.defer();
        deferred.resolve({data:{key:'test1@nomail.com', secret: 'dGVzdDFAbm9tYWlsLmNvbTphYmNkMTIzNA=='}});
        return deferred.promise;
    };

        /*authenticationFactory.LoginError = function(){
            var deferred = $q.defer();
            return $q.reject({status: 500});
        };

        userFactory.getUser = function(){
            var deferred = $q.defer();
            deferred.resolve({data:{
                'first_name': 'Shantanu',
                'last_name': 'Gautam',
                'email': 'test1@nomail.com',
                'mobile': '12345678',
                'name': 'Shantanu Gautam',
                date:{'registration': '2015-11-13'},
                'id': '123456'}
                });
            return deferred.promise;
        };

        state.go = function(){
            var deferred = $q.defer();
            deferred.resolve({});
            return deferred.promise;
        };
   })); */
   // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.home/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
        }
    } ) );
    // Initialize the controller and a mock form
    beforeEach( inject( function ( $controller, $rootScope, $compile, $state, _userFactory_, _authenticationFactory_, $q, _authDocumentFactory_, _API_BASE_ ) {
        scope = $rootScope.$new();
        authLoginCtrl = $controller( 'authLoginCtrl', {
            $scope: scope
        } );
        API_BASE = _API_BASE_;
        userFactory = _userFactory_;
        authenticationFactory = _authenticationFactory_;
        authDocumentFactory = _authDocumentFactory_;
        q = $q;
        state = $state;

        userInfo = {
            'first_name': 'Shantanu',
            'last_name': 'Gautam',
            'email': 'test1@nomail.com',
            'mobile': '12345678',
            'name': 'Shantanu Gautam',
            "date": {
                "registration": "2015-12-15T16:26:17+08:00"
            }
        };
        email = 'test1@nomail.com',
            username = 'test1@nomail.com',
            password = 'abcd1234',
            secret = 'dGVzdDFAbm9tYWlsLmNvbTphYmNkMTIzNA==';

        httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, '' );
        httpBackend.flush();
    } ) );

    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    describe( 'Login Success, User data fetch success', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 200, userInfo );
            spyOn( authenticationFactory, 'Login' ).and.callThrough();
            spyOn( userFactory, 'getUser' ).and.callThrough();
            spyOn( userFactory, 'setCurrentUser' ).and.callThrough();
            spyOn( authDocumentFactory, 'getStatus' ).and.callThrough();
            spyOn( state, 'go' ).and.callFake( function () {} );
        } ) );
        it( 'Controller: loginCtrl - Logged in User set properly in store', function () {
            scope.login();
            httpBackend.flush();
            //expect(scope.globals.currentUser.username).toBe(username);
            expect( authenticationFactory.Login ).toHaveBeenCalled();
            expect( state.go ).toHaveBeenCalledWith( 'wallet.home' );
        } );
    } );
    describe( 'Login Success, User Data Fetch errors', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '200 OK' );
            spyOn( authenticationFactory, 'Login' ).and.callThrough();
            spyOn( userFactory, 'getUser' ).and.callThrough();
            spyOn( authDocumentFactory, 'getStatus' ).and.callThrough();
        } ) );
        it( 'User Data Fetch error 500', function () {
            httpBackend.whenGET( API_BASE + 'users' ).respond( 500, 'Error 500 internal server error' );
            scope.login();
            httpBackend.flush();
            expect( scope.errorLoginGenric ).toBeTruthy();
        } );
        it( 'User Data Fetch error 400', function () {
            httpBackend.whenGET( API_BASE + 'users' ).respond( 400, 'Error 400 some error while fetching user data' );
            scope.login();
            httpBackend.flush();
            expect( scope.errorLoginGenric ).toBeTruthy();
        } );
    } );
    describe( 'Login errors', function () {
        beforeEach( inject( function () {
            spyOn( authenticationFactory, 'Login' ).and.callThrough();
        } ) );
        it( 'auth error 500', function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 500, 'Error 500 internal server error' );
            scope.login();
            httpBackend.flush();
            expect( scope.errorLoginGenric ).toBeTruthy();
        } );
        it( 'auth error 400', function () {
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 400, 'Error 400 invalid username/password' );
            scope.login();
            httpBackend.flush();
            expect( scope.errorLoginGenric ).toBeTruthy();
        } );
    } );
} );