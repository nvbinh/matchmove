'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.loginSvc
 * @description
 * # loginSvc
 * Service in the viewMultipleWallet.
 */
angular.module( 'viewMultipleWallet' )
    .service( 'loginSvcService', function ( authenticationFactory, authDocumentFactory, $analytics, userFactory, $rootScope, store, $state, $q, ngDialog, Idle, CacheFactory, userAddressFactory, TRANSLATION_PARAMS, $translate, amMoment, $stateParams ) {
        // AngularJS will instantiate a singleton by calling "new" on this function
        store.set( 'controller', 'loginSvcService' );
        $rootScope.credentials = {
            email: '',
            password: ''
        };

        var config_TRANS_Params = angular.fromJson(TRANSLATION_PARAMS);

        function login( credentials ) {
            var deferred = $q.defer();
            $rootScope.errorLoginGenric = false;
            $rootScope.isLoading = true;
            authenticationFactory.Login( credentials.email, credentials.password )
                .then( function ( data, status, headers, config ) {
                    authenticationFactory.SetCredentials( data.data.key, data.data.secret );
                    $analytics.eventTrack( 'Login Success', {
                        category: 'Login',
                        label: 'Login Succesfull'
                    } );

                    // prime the caches
                    authDocumentFactory.getStatus();
                    userAddressFactory.getAddress('residential', false);
                    userAddressFactory.getAddress('billing', false);

                    userFactory.getUser()
                        .then( function ( response ) {
                            userFactory.setCurrentUser( response.data );
                            $analytics.setUsername( response.data.id );
                            $rootScope.$broadcast( 'authorized' );
                            $analytics.setUserProperties( {
                                '$email': response.data.email,
                                '$registration_date': response.data.date.registration,
                                '$mobile': response.data.mobile.country_code + response.data.mobile.number,
                                '$name': response.data.name.first + ' ' + response.data.name.first
                            } ); // jshint ignore:line
                            Idle.watch();
                            if( $state.current.name === 'auth.login' && $stateParams.referrer === 'transfer')
                            {
                                $state.go('wallet.fund.claim');

                            }
                            else if ( $state.current.name === 'auth.login' ) {
                                $state.go( 'wallet.home' );
                            } else {
                                //ngDialog.closeAll();
                                $state.go( '.', {}, {
                                    reload: true
                                } );
                            }

                            // set the language:
                            //  preference 1) users locale language 2) NG_TRANSLATE_KEY 3) preferred lang from config
                            var lang_locale;
                            if(response.data.language){
                                lang_locale = response.data.language.locale;
                            }
                            if(!lang_locale){
                                lang_locale = store.get('NG_TRANSLATE_LANG_KEY');
                            }
                            if(!lang_locale){
                                lang_locale = config_TRANS_Params.preferredLanguage;
                            }
                            store.set('lang_locale', lang_locale);
                            $translate.use(lang_locale);
                            // set locale for momentJs
                            amMoment.changeLocale(lang_locale);
                            deferred.resolve( response );
                        }, function ( error ) {
                            $rootScope.isLoading = false;
                            if ( error.status === 500 ) {
                                deferred.reject( error );
                                $rootScope.errorLoginGenric = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Error 500',
                                    label: 'Error getting User Info after login'
                                } );
                            } else {
                                deferred.reject( error );
                                $rootScope.errorLoginGenric = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Login',
                                    label: 'Login error : ' + error.status + ' : ' + error.statusText
                                } );
                            }
                        } );

                }, function ( error ) {
                    $rootScope.errorLoginGenric = true;
                    $rootScope.isLoading = false;
                    $rootScope.errorMessagetext = $rootScope.errorHandler.errors[ 0 ];
                    deferred.reject( error );
                } );
            return deferred.promise;
        };

        function resumeSession( credentials ) {
            var deferred = $q.defer();
            $rootScope.errorLoginGenric = false;
            $rootScope.isLoading = true;
            authenticationFactory.Login( credentials.email, credentials.password )
                .then( function ( data, status, headers, config ) {
                    authenticationFactory.SetCredentials( data.data.key, data.data.secret );
                    $rootScope.isLoading = false;
                    deferred.resolve( data );
                }, function ( error ) {
                    $rootScope.errorLoginGenric = true;
                    $rootScope.isLoading = false;
                    $rootScope.errorMessagetext = $rootScope.errorHandler.errors[ 0 ];
                    deferred.reject( error );
                } );
            return deferred.promise;
        };

        // API description
        login.description = 'loginSvcService:login';
        resumeSession.description = 'loginSvcService:resumeSession';

        return {
            login: login,
            resumeSession: resumeSession
        }
    } );
