'use strict';

describe('Factory: authMobileFactory', function() {
  var authMobile,
  	  rc4Factory,
  	  API_BASE,
  	  httpBackend,
  	  scope;
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize factory
  beforeEach(inject(function(_authMobileFactory_, _API_BASE_, $rootScope, _rc4Factory_) {
    authMobile = _authMobileFactory_;
    API_BASE = _API_BASE_;
    rc4Factory = _rc4Factory_;
    scope = $rootScope;
    httpBackend.whenPOST(API_BASE + 'users/authentications/phone').respond(200, {
          "status": "success",
          "token": "bfa7f2121085d50605daab9c0d275e0b"
        });
    httpBackend.whenPUT(API_BASE + 'users/authentications/phone').respond(200, {
          "status": "otp verify success"
        });
    httpBackend.flush();
  }));

  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

  it('should have authMobile service be defined', function () {
    expect(authMobile).toBeDefined();
  });

  describe(' - authentication mobile Function', function() {
  	it(' - Request Verification Otp is generated correctly', function () {			
		authMobile.requestVerificationOtp().then(function (response) {
			expect(response.data.token).toBe('bfa7f2121085d50605daab9c0d275e0b');
		});
        httpBackend.flush();
	});

	it(' - Verify Otp is returned 200 when token and Otp are correct', function () {		
		spyOn(rc4Factory, 'encode').and.callThrough();
        var otp = '662342';
        var token = 'bfa7f2121085d50605daab9c0d275e0b';
        authMobile.verifyOtp(token, otp).then(function(response){
            expect(response.data.status).toBe('otp verify success');
        });
        httpBackend.flush();
	});	
  });

});