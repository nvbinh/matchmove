'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authMobile
 * @description
 * # authMobile
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .service('authMobileFactory', function (rc4Factory, base64Factory, utf8Factory, store, $http, API_BASE) {
// Service logic
    function requestVerificationOtp(){
        return $http({
            method: 'POST',
            url: API_BASE + 'users/authentications/phone'
        });
    };
    function verifyOtp(token,otp){

        var key = rc4Factory.encode(token, otp.toString());
        return $http({
            method: 'PUT',
            url: API_BASE + 'users/authentications/phone',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                    str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
                return str.join('&');
            },
            data: {'key':key, 'token':token}
        });
    };
    // Add descriptions
    requestVerificationOtp.description = 'authMobileFactory:requestVerificationOtp';
    verifyOtp.description = 'authMobileFactory:verifyOtp';
    // Public facing API
    return {
        requestVerificationOtp: requestVerificationOtp,
        verifyOtp: verifyOtp
    };
});
