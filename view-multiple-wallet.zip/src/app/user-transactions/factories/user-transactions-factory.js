'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.userTransactions
 * @description
 * # userTransactions
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .service('userTransactionsFactory', function ($http, API_BASE) {
  // Service logic
  function getWalletTransactions() {
      return $http.get(API_BASE + 'users/wallets/transactions',{cache:false});
  };

  function getCardTransactions(id) {
      return $http.get(API_BASE + 'users/wallets/cards/' + id + '/transactions',{cache:false});
  };

  // Add descriptions
    getWalletTransactions.description = 'userTransactionsFactory:getWalletTransactions';
    getCardTransactions.description = 'userTransactionsFactory:getCardTransactions';

  // Public facing API
  return {
    getWalletTransactions: getWalletTransactions,
    getCardTransactions: getCardTransactions
  };
});
