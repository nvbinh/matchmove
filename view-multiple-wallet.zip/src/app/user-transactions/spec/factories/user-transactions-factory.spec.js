'use strict';

describe('Factory: userTransactionsFactory', function() {
  var userTransactions;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_userTransactionsFactory_) {
    userTransactions = _userTransactionsFactory_;
  }));

  // it('should provide the meaning of life', function() {
  //   expect(userTransactions.someMethod() == 42).toBeTruthy();
  // });

});
