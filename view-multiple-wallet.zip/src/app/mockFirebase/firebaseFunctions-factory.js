'use strict';
/**
 * @ngdoc service
 * @name mockFirebaseFunctions.firebaseFunctions
 * @description
 * # firebaseFunctions
 * Factory in the mockFirebaseFunctions.
 */
angular.module( 'mockFirebaseFunctions', [ 'firebase' ] )
	.factory( 'firebaseFunctionsFactory', function( $timeout, CONTENT_NET ) {
		// Service logic

		function stubAuthRef( URL ) {
            var firebaseApp = new firebase.initializeApp(angular.fromJson(CONTENT_NET));
            return firebaseApp.auth();
            // return new MockFirebase();
		}
        function stubRef( URL ) {
            // return new MockFirebase('Mock://').child( URL );
            var firebaseApp = new firebase.initializeApp(angular.fromJson(CONTENT_NET));
            return firebaseApp.database().ref(URL);
        }
		var flushAll = ( function() {
			return function flushAll() {
				// the order of these flush events is significant
				Array.prototype.slice.call( arguments, 0 ).forEach( function( o ) {
					o.flush();
				} );
				try {
					$timeout.flush();
				} catch ( e ) {}
			}
		} )();

		// Add descriptions here
		flushAll.description = 'firebaseFunctionsFactory.flushAll';
		stubRef.description = 'firebaseFunctionsFactory.stubRef';
        stubAuthRef.description = 'firebaseFunctionsFactory.stubAuthRef';
		// Public API here
		return {
			flushAll: flushAll,
			stubRef: stubRef,
            stubAuthRef:stubAuthRef
		};
	} );
