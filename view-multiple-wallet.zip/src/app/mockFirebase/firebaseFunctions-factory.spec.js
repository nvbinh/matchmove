'use strict';
/**
 * @ngdoc test Spec
 * @name mockFirebaseFunctions.firebaseFunctions
 * @description
 * # firebaseFunctions
 * Factory in the mockFirebaseFunctions.
 */
describe( 'Factory: firebaseFunctionsFactory', function() {
	var firebaseFunctions;
	beforeEach( module( 'mockFirebaseFunctions' ) );
	beforeEach( inject( function( _firebaseFunctionsFactory_ ) {
		firebaseFunctions = _firebaseFunctionsFactory_;
	} ) );

} );