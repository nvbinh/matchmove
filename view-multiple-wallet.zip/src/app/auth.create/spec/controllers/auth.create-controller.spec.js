'use strict';
describe( 'Controller: authCreateCtrl - Error scenarios', function () {
    // Load the controller's module and mock data
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authCreateCtrl,
        scope,
        // data
        userData,
        userRegnResponse,
        // common vars
        httpBackend,
        authFactory,
        userFactory,
        deferred,
        $q,
        API_BASE,
        formText,
        email_pattern;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller and mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, _userFactory_, _$q_, _API_BASE_ ) {
        scope = $rootScope.$new();
        userFactory = _userFactory_;
        $q = _$q_;
        API_BASE = _API_BASE_;
        email_pattern = "/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g";
        formText = '<form name="createForm" class="walletForm">' +
            '<input ng-model="user.first_name" name="first_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.last_name" name="last_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.preferred_name" name="preferred_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.email" name="email" ng-minlength=6 ng-pattern=' + email_pattern + '></input>' +
            '<input ng-model="user.mobile" name="mobile" intl-tel-input intl-tel-input-controller="phoneNumberCtrl" intl-tel-input-options="countryList"></input>' +
            '<input ng-model="user.password" name="password" ng-minlength=8 ng-maxlength=32 ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required></input>'
        '</form>';

        $compile( formText )( scope );
        scope.$digest();
        authCreateCtrl = $controller( 'authCreateCtrl', {
            $scope: scope
        } );
        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    describe( 'Create user 500 error', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 500, 'err', {}, 'HTTP/1.1 500 Create user failed' );
        } ) );
        it( '500 here', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - email length max error', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 Validation:User:Email:Lengthmax error' );
        } ) );
        it( 'User:Email:Lengthmax error here', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - duplicate email', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 resource_user_email_unique error' );
        } ) );
        it( 'user_email_NOT_unique error', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - Invalid domain', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 resource_user_email_domain error' );
        } ) );
        it( 'invaild email domain error', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - Invalid password', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 validationFailed : Password error' );
        } ) );
        it( 'password not valid', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - Only letters in names', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 Validation:FirstName:Rule error' );
        } ) );
        it( 'No letters allowed in name', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - Duplicate mobile number', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 resource_user_mobilenumber_unique error' );
        } ) );
        it( 'duplicate mobile number error', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 400 - Fallback catch all error', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 Other resource error' );
        } ) );
        it( 'catch all error', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
    describe( 'Create user 503 - Server error', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 503, 'err', {}, 'HTTP/1.1 503 Internal server error' );
        } ) );
        it( 'server error', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
        } );
    } );
} );
describe( 'Controller: authCreateCtrl - Success scenarios - Post login config to true', function () {
    // Load the controller's module and mock data
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( 'SIGNUP_PARAMS', {
            "allowNationalityType": false,
            "requireTnc": true,
            "requireLoginPostSignup": true,
            "redirectionUrl": "wallet.home"
        } );
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    beforeEach( module( 'viewMultipleWallet', 'auth.create.JSONData' ) );

    var authCreateCtrl,
        scope,
        // data
        userData,
        userRegnResponse,
        // common vars
        httpBackend,
        authFactory,
        userFactory,
        deferred,
        $q,
        API_BASE,
        formText,
        SIGNUP_PARAMS,
        email_pattern,
        userRegnResponse,
        ngDialog,
        walletData,
        cardTypes,
        base64;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.create/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.home/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.card.new/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.loyalty.list/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.fund/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.fund.claim/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.send/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller and mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, _userFactory_, _$q_, _API_BASE_, _SIGNUP_PARAMS_, authCreateJSON, _authenticationFactory_, _ngDialog_, _base64Factory_ ) {
        scope = $rootScope.$new();
        userFactory = _userFactory_;
        authFactory = _authenticationFactory_;
        $q = _$q_;
        API_BASE = _API_BASE_;
        SIGNUP_PARAMS = _SIGNUP_PARAMS_;
        ngDialog = _ngDialog_;
        base64 = _base64Factory_;
        userData = authCreateJSON.userData;
        userRegnResponse = authCreateJSON.userRegnResponse;
        walletData = authCreateJSON.walletData;
        cardTypes = authCreateJSON.cardTypes;

        spyOn( authFactory, 'SetCredentials' ).and.callThrough();
        spyOn( base64, 'encode' ).and.callThrough();
        spyOn( userFactory, 'getUser' ).and.callThrough();
        spyOn( authFactory, 'Login' ).and.callThrough();

        email_pattern = "/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g";
        formText = '<form name="createForm" class="walletForm">' +
            '<input ng-model="user.first_name" name="first_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.last_name" name="last_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.preferred_name" name="preferred_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.email" name="email" ng-minlength=6 ng-pattern=' + email_pattern + '></input>' +
            '<input ng-model="user.mobile" name="mobile" intl-tel-input intl-tel-input-controller="phoneNumberCtrl" intl-tel-input-options="countryList"></input>' +
            '<input ng-model="user.password" name="password" ng-minlength=8 ng-maxlength=32 ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required></input>'
        '</form>';

        $compile( formText )( scope );
        scope.$digest();
        authCreateCtrl = $controller( 'authCreateCtrl', {
            $scope: scope
        } );
        httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, {data: null});
        httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, {data: null});

        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );

    describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set', function () {
        beforeEach( inject( function (TRANSLATION_PARAMS) {
            scope.signupParams.requireLoginPostSignup = true;
            httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, '' );
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 200, userData );
            httpBackend.whenGET( API_BASE + 'users/addresses/residential' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/addresses/billing' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/25302c8a90917740e0fc6057113bb70f' ).respond( 200, '', {}, 'HTTP/1.1 200 OK' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/types/mcmmgpcard' ).respond( 200, '' );
            //httpBackend.flush();
        } ) );
        it( 'User created successfully, credentials set, getUserInfo invoked', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeFalsy();
        } );
    } );

    describe( 'open ngDialog', function () {
        beforeEach( inject( function () {
            spyOn( ngDialog, 'closeAll' ).and.callFake(function(){});
            spyOn( ngDialog, 'open' ).and.callFake(function(){});
        } ) );
        it( 'open a dialog window', function () {
            scope.showTnc();
            expect( ngDialog.open ).toHaveBeenCalled();
        } )

    } );
} );


describe( 'Controller: authCreateCtrl - Success scenarios - Post login config to false', function () {
    // Load the controller's module and mock data
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( 'SIGNUP_PARAMS', {
            "allowNationalityType": false,
            "requireTnc": true,
            "requireLoginPostSignup": false,
            "redirectionUrl": "wallet.home"
        } );
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    beforeEach( module( 'viewMultipleWallet', 'auth.create.JSONData' ) );
    var authCreateCtrl,
        scope,
        // data
        userData,
        userRegnResponse,
        // common vars
        httpBackend,
        authFactory,
        userFactory,
        deferred,
        $q,
        API_BASE,
        formText,
        SIGNUP_PARAMS,
        email_pattern,
        userRegnResponse,
        ngDialog,
        walletData,
        cardTypes,
        base64;
        // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.home/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.card.new/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.loyalty.list/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.fund/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.fund.claim/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.send/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller and mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, _userFactory_, _$q_, _API_BASE_, _SIGNUP_PARAMS_, authCreateJSON, _authenticationFactory_, _ngDialog_, _base64Factory_ ) {
        scope = $rootScope.$new();
        userFactory = _userFactory_;
        authFactory = _authenticationFactory_;
        $q = _$q_;
        API_BASE = _API_BASE_;
        SIGNUP_PARAMS = _SIGNUP_PARAMS_;
        ngDialog = _ngDialog_;
        base64 = _base64Factory_;

        userData = authCreateJSON.userData;
        userRegnResponse = authCreateJSON.userRegnResponse;
        walletData = authCreateJSON.walletData;
        cardTypes = authCreateJSON.cardTypes;

        spyOn( authFactory, 'SetCredentials' ).and.callThrough();
        spyOn( base64, 'encode' ).and.callThrough();
        spyOn( userFactory, 'getUser' ).and.callThrough();
        spyOn( authFactory, 'Login' ).and.callThrough();

        email_pattern = "/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g";
        formText = '<form name="createForm" class="walletForm">' +
            '<input ng-model="user.first_name" name="first_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.last_name" name="last_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.preferred_name" name="preferred_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
            '<input ng-model="user.email" name="email" ng-minlength=6 ng-pattern=' + email_pattern + '></input>' +
            '<input ng-model="user.mobile" name="mobile" intl-tel-input intl-tel-input-controller="phoneNumberCtrl" intl-tel-input-options="countryList"></input>' +
            '<input ng-model="user.password" name="password" ng-minlength=8 ng-maxlength=32 ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required></input>'
        '</form>';

        $compile( formText )( scope );
        scope.$digest();
        authCreateCtrl = $controller( 'authCreateCtrl', {
            $scope: scope
        } );
        httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, {data: null});
        httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, {data: null});

        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 200, userData );
            httpBackend.whenGET( API_BASE + 'users/addresses/residential' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/addresses/billing' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/' ).respond( 200, '' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/25302c8a90917740e0fc6057113bb70f' ).respond( 200, '', {}, 'HTTP/1.1 200 OK' );
            httpBackend.whenGET( API_BASE + 'users/wallets/cards/types/mcmmgpcard' ).respond( 200, '' );
            //httpBackend.flush();
        } ) );
        it( 'User created successfully, credentials set, getUserInfo invoked', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeFalsy();
        } );
    } );

    describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set, UserInfo error 500', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 500, '' );

        } ) );
        it( 'User created successfully, credentials set, getUserInfo error 500', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.errorLoginGenric ).toBeTruthy();
        } );
    } );
    describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set, UserInfo error 400', function () {
        beforeEach( inject( function () {
            httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
            httpBackend.whenGET( API_BASE + 'users' ).respond( 400, '' );

        } ) );
        it( 'User created successfully, credentials set, getUserInfo error 400', function () {
            scope.createUser();
            httpBackend.flush();
            expect( scope.errorLoginGenric ).toBeTruthy();
        } );
    } );
    describe( 'open ngDialog', function () {
        beforeEach( inject( function () {
            spyOn( ngDialog, 'closeAll' ).and.callThrough();
            spyOn( ngDialog, 'open' ).and.callFake(function(){});
        } ) );
        it( 'open a dialog window', function () {
            scope.showTnc();
            expect( ngDialog.open ).toHaveBeenCalled();
        } )

    } );
} );









// 'use strict';
// describe( 'Controller: authCreateCtrl - Error scenarios', function () {
//     // Load the controller's module and mock data
//     beforeEach( module( 'viewMultipleWallet' ) );
//     var authCreateCtrl,
//         scope,
//         // data
//         userData,
//         userRegnResponse,
//         // common vars
//         httpBackend,
//         authFactory,
//         userFactory,
//         deferred,
//         $q,
//         API_BASE,
//         formText,
//         email_pattern;
//     // Initialize controller and mock scope
//     beforeEach( inject( function ( $controller, $rootScope, $compile, _$httpBackend_, _userFactory_, _$q_, _API_BASE_ ) {
//         scope = $rootScope.$new();
//         userFactory = _userFactory_;
//         $q = _$q_;
//         API_BASE = _API_BASE_;
//
//         httpBackend = _$httpBackend_;
//         httpBackend.flush();
//
//         email_pattern = "/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g";
//         formText = '<form name="createForm" class="walletForm">' +
//             '<input ng-model="user.first_name" name="first_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.last_name" name="last_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.preferred_name" name="preferred_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.email" name="email" ng-minlength=6 ng-pattern=' + email_pattern + '></input>' +
//             '<input ng-model="user.mobile" name="mobile" intl-tel-input intl-tel-input-controller="phoneNumberCtrl" intl-tel-input-options="countryList"></input>' +
//             '<input ng-model="user.password" name="password" ng-minlength=8 ng-maxlength=32 ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required></input>'
//         '</form>';
//
//         $compile( formText )( scope );
//         scope.$digest();
//         authCreateCtrl = $controller( 'authCreateCtrl', {
//             $scope: scope
//         } );
//     } ) );
//     afterEach( function () {
//         httpBackend.verifyNoOutstandingExpectation();
//         httpBackend.verifyNoOutstandingRequest();
//     } );
//     describe( 'Create user 500 error', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 500, 'err', {}, 'HTTP/1.1 500 Create user failed' );
//         } ) );
//         it( '500 here', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - email length max error', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 Validation:User:Email:Lengthmax error' );
//         } ) );
//         it( 'User:Email:Lengthmax error here', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - duplicate email', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 resource_user_email_unique error' );
//         } ) );
//         it( 'user_email_NOT_unique error', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - Invalid domain', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 resource_user_email_domain error' );
//         } ) );
//         it( 'invaild email domain error', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - Invalid password', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 validationFailed : Password error' );
//         } ) );
//         it( 'password not valid', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - Only letters in names', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 Validation:FirstName:Rule error' );
//         } ) );
//         it( 'No letters allowed in name', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - Duplicate mobile number', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 resource_user_mobilenumber_unique error' );
//         } ) );
//         it( 'duplicate mobile number error', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 400 - Fallback catch all error', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 400, 'err', {}, 'HTTP/1.1 400 Other resource error' );
//         } ) );
//         it( 'catch all error', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 503 - Server error', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 503, 'err', {}, 'HTTP/1.1 503 Internal server error' );
//         } ) );
//         it( 'server error', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeTruthy();
//         } );
//     } );
// } );
//
// describe( 'Controller: authCreateCtrl - Success scenarios with postsignauth config set to true', function ( $provide ) {
//     // Load the controller's module and mock data
//     beforeEach( module( 'viewMultipleWallet', 'auth.create.JSONData' ) );
//     beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
//         $provide.constant( 'SIGNUP_PARAMS', {
//             "allowNationalityType": false,
//             "requireTnc": true,
//             "requireLoginPostSignup": true,
//             "redirectionUrl": "wallet.home"
//         } );
//     } ) );
//
//     var authCreateCtrl,
//         scope,
//         // data
//         userData,
//         userRegnResponse,
//         // common vars
//         httpBackend,
//         authFactory,
//         userFactory,
//         deferred,
//         $q,
//         API_BASE,
//         formText,
//         email_pattern,
//         userRegnResponse,
//         SIGNUP_PARAMS,
//         ngDialog,
//         walletData,
//         cardTypes,
//         base64;
//     // Initialize controller and mock scope
//     beforeEach( inject( function ( $controller, $rootScope, $compile, _$httpBackend_, _userFactory_, _$q_, _API_BASE_, authCreateJSON, _authenticationFactory_, _ngDialog_, _base64Factory_ ) {
//         scope = $rootScope.$new();
//         userFactory = _userFactory_;
//         authFactory = _authenticationFactory_;
//         $q = _$q_;
//         API_BASE = _API_BASE_;
//         SIGNUP_PARAMS = _SIGNUP_PARAMS_;
//         ngDialog = _ngDialog_;
//         base64 = _base64Factory_;
//
//         httpBackend = _$httpBackend_;
//         httpBackend.flush();
//
//         userData = authCreateJSON.userData;
//         userRegnResponse = authCreateJSON.userRegnResponse;
//         walletData = authCreateJSON.walletData;
//         cardTypes = authCreateJSON.cardTypes;
//
//         spyOn( authFactory, 'SetCredentials' ).and.callThrough();
//         spyOn( base64, 'encode' ).and.callThrough();
//         spyOn( userFactory, 'getUser' ).and.callThrough();
//         spyOn( authFactory, 'Login' ).and.callThrough();
//
//         email_pattern = "/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g";
//         formText = '<form name="createForm" class="walletForm">' +
//             '<input ng-model="user.first_name" name="first_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.last_name" name="last_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.preferred_name" name="preferred_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.email" name="email" ng-minlength=6 ng-pattern=' + email_pattern + '></input>' +
//             '<input ng-model="user.mobile" name="mobile" intl-tel-input intl-tel-input-controller="phoneNumberCtrl" intl-tel-input-options="countryList"></input>' +
//             '<input ng-model="user.password" name="password" ng-minlength=8 ng-maxlength=32 ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required></input>'
//         '</form>';
//
//         $compile( formText )( scope );
//         scope.$digest();
//         authCreateCtrl = $controller( 'authCreateCtrl', {
//             $scope: scope
//         } );
//     } ) );
//     afterEach( function () {
//         httpBackend.verifyNoOutstandingExpectation();
//         httpBackend.verifyNoOutstandingRequest();
//     } );
//     describe( 'Create user 200 - when signupParams.requireLoginPostSignup is set', function () {
//         beforeEach( inject( function () {
//             scope.signupParams.requireLoginPostSignup = true;
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
//             httpBackend.whenGET( API_BASE + 'users' ).respond( 200, userData );
//             httpBackend.whenPOST( API_BASE + 'auth' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/addresses/residential' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/addresses/billing' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/25302c8a90917740e0fc6057113bb70f' ).respond( 200, '', {}, 'HTTP/1.1 200 OK' );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/types/mcmmgpcard' ).respond( 200, '' );
//             //httpBackend.flush();
//         } ) );
//         it( 'User created successfully, credentials set, getUserInfo invoked', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeFalsy();
//         } );
//     } );
//
//     describe( 'open ngDialog', function () {
//         beforeEach( inject( function () {
//             spyOn( ngDialog, 'closeAll' ).and.callThrough();
//             spyOn( ngDialog, 'open' ).and.callThrough();
//         } ) );
//         it( 'open a dialog window', function () {
//             scope.showTnc();
//             expect( ngDialog.open ).toHaveBeenCalled();
//         } );
//
//     } );
// } );
//
//
//
// describe( 'Controller: authCreateCtrl - Success scenarios with postsignauth config set to false', function () {
//     // Load the controller's module and mock data
//     beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
//         $provide.constant( 'SIGNUP_PARAMS', {
//             "allowNationalityType": false,
//             "requireTnc": true,
//             "requireLoginPostSignup": false,
//             "redirectionUrl": "wallet.home"
//         } );
//     } ) );
//     beforeEach( module( 'viewMultipleWallet', 'auth.create.JSONData' ) );
//     var authCreateCtrl,
//         scope,
//         // data
//         userData,
//         userRegnResponse,
//         // common vars
//         httpBackend,
//         authFactory,
//         userFactory,
//         deferred,
//         $q,
//         API_BASE,
//         formText,
//         email_pattern,
//         userRegnResponse,
//         ngDialog,
//         walletData,
//         cardTypes,
//         SIGNUP_PARAMS,
//         base64;
//     // Initialize controller and mock scope
//     beforeEach( inject( function ( $controller, $rootScope, $compile, _$httpBackend_, _userFactory_, _$q_, _API_BASE_, authCreateJSON, _authenticationFactory_, _ngDialog_, _base64Factory_ ) {
//         scope = $rootScope.$new();
//         userFactory = _userFactory_;
//         authFactory = _authenticationFactory_;
//         $q = _$q_;
//         API_BASE = _API_BASE_;
//         ngDialog = _ngDialog_;
//         base64 = _base64Factory_;
//         SIGNUP_PARAMS = _SIGNUP_PARAMS_;
//
//         httpBackend = _$httpBackend_;
//         httpBackend.flush();
//
//         userData = authCreateJSON.userData;
//         userRegnResponse = authCreateJSON.userRegnResponse;
//         walletData = authCreateJSON.walletData;
//         cardTypes = authCreateJSON.cardTypes;
//
//         spyOn( authFactory, 'SetCredentials' ).and.callThrough();
//         spyOn( base64, 'encode' ).and.callThrough();
//         spyOn( userFactory, 'getUser' ).and.callThrough();
//         spyOn( authFactory, 'Login' ).and.callThrough();
//
//         email_pattern = "/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g";
//         formText = '<form name="createForm" class="walletForm">' +
//             '<input ng-model="user.first_name" name="first_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.last_name" name="last_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.preferred_name" name="preferred_name" ng-minlength=1 ng-maxlength=25  ng-pattern="/^[a-zA-Z\s]*$/"></input>' +
//             '<input ng-model="user.email" name="email" ng-minlength=6 ng-pattern=' + email_pattern + '></input>' +
//             '<input ng-model="user.mobile" name="mobile" intl-tel-input intl-tel-input-controller="phoneNumberCtrl" intl-tel-input-options="countryList"></input>' +
//             '<input ng-model="user.password" name="password" ng-minlength=8 ng-maxlength=32 ng-pattern="/^(?=.*[A-Za-z])(?=.*[0-9])(?!.*[ ]).*$/" required></input>'
//         '</form>';
//
//         $compile( formText )( scope );
//         scope.$digest();
//         authCreateCtrl = $controller( 'authCreateCtrl', {
//             $scope: scope
//         } );
//     } ) );
//     afterEach( function () {
//         httpBackend.verifyNoOutstandingExpectation();
//         httpBackend.verifyNoOutstandingRequest();
//     } );
//     describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
//             httpBackend.whenGET( API_BASE + 'users' ).respond( 200, userData );
//             httpBackend.whenGET( API_BASE + 'users/addresses/residential' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/addresses/billing' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/types' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/' ).respond( 200, '' );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/25302c8a90917740e0fc6057113bb70f' ).respond( 200, '', {}, 'HTTP/1.1 200 OK' );
//             httpBackend.whenGET( API_BASE + 'users/wallets/cards/types/mcmmgpcard' ).respond( 200, '' );
//             //httpBackend.flush();
//         } ) );
//         it( 'User created successfully, credentials set, getUserInfo invoked', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.validationErrorTrue ).toBeFalsy();
//         } );
//     } );
//
//     describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set, UserInfo error 500', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
//             httpBackend.whenGET( API_BASE + 'users' ).respond( 500, '' );
//
//         } ) );
//         it( 'User created successfully, credentials set, getUserInfo error 500', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.errorLoginGenric ).toBeTruthy();
//         } );
//     } );
//     describe( 'Create user 200 - when signupParams.requireLoginPostSignup is NOT set, UserInfo error 400', function () {
//         beforeEach( inject( function () {
//             httpBackend.whenPOST( API_BASE + 'users' ).respond( 200, userRegnResponse );
//             httpBackend.whenGET( API_BASE + 'users' ).respond( 400, '' );
//
//         } ) );
//         it( 'User created successfully, credentials set, getUserInfo error 400', function () {
//             scope.createUser();
//             httpBackend.flush();
//             expect( scope.errorLoginGenric ).toBeTruthy();
//         } );
//     } );
//     describe( 'open ngDialog', function () {
//         beforeEach( inject( function () {
//             spyOn( ngDialog, 'closeAll' ).and.callThrough();
//             spyOn( ngDialog, 'open' ).and.callThrough();
//         } ) );
//         it( 'open a dialog window', function () {
//             scope.showTnc();
//             expect( ngDialog.open ).toHaveBeenCalled();
//         } );
//
//     } );
//
// } );
