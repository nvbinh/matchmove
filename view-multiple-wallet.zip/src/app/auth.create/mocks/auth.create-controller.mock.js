/**
 * auth.create JSON mock data
 */
'use strict'
var API_BASE = angular.module( 'viewMultipleWallet' ).constant( "API_BASE" );
angular.module( 'auth.create.JSONData', [] )
	.value( 'authCreateJSON', {
		userData: {
			"id": "7e44d2be136976e9fe15377e654dff63",
			"email": "balaji_b_v@yahoo.com",
			"name": {
				"first": "Balaji",
				"last": "V",
				"preferred": "Balaji"
			},
			"mobile": {
				"country_code": "65",
				"number": "12345675"
			},
			"countryofissue": "India",
			"identification": {
				"type": "passport",
				"number": "ABCDEFGH"
			},
			"birthday": "1998-01-05",
			"gender": "male",
			"title": "Mr",
			"links": [ {
				"rel": "users.wallets",
				"href": API_BASE + "users/wallets",
				"method": "GET"
			}, {
				"rel": "addresses.residential",
				"href": API_BASE + "users/addresses/residential",
				"method": "GET"
			}, {
				"rel": "addresses.billing",
				"href": API_BASE + "users/addresses/billing",
				"method": "GET"
			} ],
			"status": {
				"is_active": true,
				"text": "active"
			},
			"date": {
				"registration": "2015-12-15T16:26:17+08:00"
			},
			"authentications": {
				"email_verified": true,
				"mobile_verified": false
			},
			"login_info": {
				"logins": 156,
				"last_login": "2016-02-08T17:31:24+08:00"
			}
		},
		userRegnResponse: {
			"id": "a302ba291accb13fb6e6123c718af6ab",
			"email": "balajiv+21@chimeratechnologies.com",
			"name": {
				"first": "Balaji",
				"last": "Two One",
				"preferred": "Balaji"
			},
			"mobile": {
				"country_code": "65",
				"number": "12345674"
			},
			"status": {
				"is_active": true,
				"text": "active"
			},
			"date": {
				"registration": "2016-02-08T19:29:44+08:00"
			},
			"key": "ZGE5MmJiYWMwYTk2ZDIyODJlYWIzN2JmZjA2Njc2NGQ",
			"secret": "MzhmOTI2NjhmMjMzYjY1ODM3YWZkOTQxZWRhYjY3MGZhYzRhOTE5ZDQ0MDRkZWFiZjQzNmYxMTgwNWI5NjJkYw"
		},
		walletData: {
			"funds": {
				"withholding": {
					"currency": "SGD",
					"amount": "0.00"
				},
				"available": {
					"currency": "SGD",
					"amount": "165.00"
				}
			},
			"id": "dfa7916f06e9640daeb0bbe413012659",
			"number": "6377020000009969",
			"holder": {
				"name": "Balaji"
			},
			"date": {
				"expiry": "2024-03",
				"issued": "2015-12-15"
			},
			"image": {
				"small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
				"medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
				"large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
			},
			"status": {
				"is_active": true,
				"text": "active"
			},
			"details": {
				"min_load_limit": 10,
				"fee": 0,
				"topup_limits": {
					"pre_kyc": {
						"frequency": null,
						"allowed": 1
					},
					"post_kyc": {
						"frequency": null
					},
					"current": {
						"lifetime_count": 3
					}
				}
			},
			"cards": []
		},
		cardTypes: {
			"types": [ {
				"code": "mcmmgcard",
				"name": "MatchMove Virtual MasterCard",
				"description": "MatchMove Virtual MasterCard",
				"token": {
					"type": "CVV"
				},
				"image": {
					"small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-small.png"
				},
				"details": {
					"min_load_limit": 10,
					"max_load_limit": 999
				},
				"type": "Virtual Card"
			}, {
				"code": "mcimbacard",
				"name": "MatchMove Imba Card",
				"description": "MatchMove Imba Card",
				"token": {
					"type": "CVV"
				},
				"image": {
					"small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcimbacard/card-small.png"
				},
				"details": {
					"min_load_limit": 10,
					"max_load_limit": 999
				},
				"type": "Virtual Card"
			}, {
				"code": "mcmmgpcard",
				"name": "MatchMove Physical Card",
				"description": "Matchmove Physical Card",
				"token": {
					"type": "CVV"
				},
				"image": {
					"small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png"
				},
				"details": {
					"min_load_limit": 10,
					"max_load_limit": 999
				},
				"type": "Physical Card"
			} ],
			"count": {
				"total": 3
			}
		}
	} );