'use strict';
/* global angular */
/* global $ */
/* global window */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authCreateCtrl
 * @description
 * # authCreateCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authCreateCtrl', function ( SIGNUP_PARAMS, $http, $rootScope, $scope, $state, $stateParams, $translate, $analytics, authenticationFactory, base64Factory, userFactory, store, helperFactory, ngDialog, userAddressFactory ) {
        $scope.signupParams = angular.fromJson( SIGNUP_PARAMS );

        $scope.validationErrorTrue = false;
        $scope.user = {};
        $scope.redirectionUrl = $scope.signupParams.redirectionUrl;
        $scope.requireTnc = $scope.signupParams.requireTnc;
        $scope.user.tnc = false;
        $scope.countryList = helperFactory.getCountryList( $state.current.name );
        $scope.phoneNumberCtrl;

        // If The transfer token exists , update the post user object to include the token propery
        if ( $stateParams.transferToken !== 'null' ) {
            $scope.user.token = $stateParams.transferToken;
        }
        /*Both 'Transfer Token' and user session there*/
        var user = store.get( 'user' );
        if ( $stateParams.transferToken !== null && user ) {
            var cards = store.get( 'cards' );
            authenticationFactory.ClearCredentials();
            helperFactory.clearCacheTransfer( cards );
            $rootScope.$broadcast( 'authorized' );
        } else if ( user ) {
            /*Transfer Token is null and user session there*/
            $state.go( 'wallet.home' );
        }

        $scope.allowNumbersOnly = function(e) {
        	var keyCode=(window.event) ? e.keyCode : e.which;
        	if(keyCode == 0){ //keyCode is 0 on firefox for special keys
        		return true;
        	}
            var charval= String.fromCharCode(keyCode);
            if((isNaN(charval)) && (e.which != 8 ) && (e.which != 9 )){ // Backspace code is 8
                e.preventDefault();
                return false;
            }
            return true;

        };


        function getUserInfo() {
            userFactory.getUser()
                .then( function ( response ) {
                    userFactory.setCurrentUser( response.data );
                    $analytics.setUsername( response.data.id );
                    $analytics.setUserProperties( {
                        '$email': response.data.email,
                        '$registration_date': response.data.date.registration,
                        '$mobile': response.data.mobile.country_code + response.data.mobile.number,
                        '$name': response.data.name.first + ' ' + response.data.name.first
                    } ); // jshint ignore:line
                    $rootScope.$broadcast( 'authorized' );
                    if($stateParams.transferToken !== null)
                    {
                        $state.go("wallet.fund.claim");
                    }
                    else
                    {
                        $state.go( $scope.redirectionUrl );
                    }
                    $scope.isLoading = false;
                }, function ( response ) {
                    if ( response.status === 500 ) {
                        $scope.isLoading = false;
                        $scope.errorLoginGenric = true;
                        $analytics.eventTrack( 'Error getting User Info after Signup', {
                            category: 'Error 500',
                            label: 'Error getting User Info after signup'
                        } );
                    } else {
                        $scope.isLoading = false;
                        $scope.errorLoginGenric = true;
                        $analytics.eventTrack( 'Error getting User Info after Signup', {
                            category: 'Signup',
                            label: 'Signup error' + response.status + ' : ' + response.statusText
                        } );
                    }
                } );
        }
        $scope.createUser = function () {
            $scope.isLoading = true;
            $scope.validationErrorTrue = false;
            // $scope.user.preferred_name = $scope.user.first_name + ' ' + $scope.user.last_name; // jshint ignore:line
            $scope.user.mobile_country_code = $scope.phoneNumberCtrl.getSelectedCountryData().dialCode;
            $scope.user.mobile = $scope.phoneNumberCtrl.getNumber( intlTelInputUtils.numberFormat.NATIONAL ).replace( /[- )(]/g, '' ).replace( /^0/, '' );
            userFactory.createUser( $scope.user )
                .then( function ( response ) {
                    // This is just a temporary hack to fix the issue on IH CTRM-314
                    if ( $scope.signupParams.requireLoginPostSignup ) {
                        authenticationFactory.Login( $scope.user.email, $scope.user.password )
                            .then( function ( resp ) {
                                authenticationFactory.SetCredentials( resp.data.key, resp.data.secret );
                                $http.defaults.headers.common[ 'Authorization' ] = 'Basic ' + base64Factory.encode( resp.data.key + ':' + resp.data.secret ); // jshint ignore:line
                                getUserInfo();
                            }, function () {

                            } );
                    } else {
                        authenticationFactory.SetCredentials( response.data.key, response.data.secret );
                        $http.defaults.headers.common[ 'Authorization' ] = 'Basic ' + base64Factory.encode( response.data.key + ':' + response.data.secret ); // jshint ignore:line
                        getUserInfo();
                    }
                    $scope.loading = false;
                    // prime the address cache
                    userAddressFactory.getAddress('residential', false);
                    userAddressFactory.getAddress('billing', false);
                    $analytics.eventTrack( 'Wallet Creation Succesfull', {
                        category: 'Wallet Create',
                        label: 'Wallet Creation Succesfull'
                    } );

                }, function ( response ) {
                    if ( response.status === 500 ) {
                        $scope.validationErrorTrue = true;
                        $scope.validationError = $translate.instant( 'Validation:CreateWallet:Fallback' );
                        $analytics.eventTrack( 'Error creating user wallet', {
                            category: 'Error 500',
                            label: 'Error creating user wallet'
                        } );
                    } else if ( response.status === 400 ) {
                        // called asynchronously if an error occurs
                        // or server returns response with an error status.
                        // Handle the validation for the user errors
                        if ( response.statusText.indexOf( 'Validation:User:Email:Lengthmax' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.EMAIL.LENGTHMAX' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Email exceeds allowed length'
                            } );
                        } else if ( response.statusText.indexOf( 'resource_user_email_unique' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.EMAIL.EMAILUNIQUE' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Duplicate Email'
                            } );
                        } else if ( response.statusText.indexOf( 'resource_user_email_domain' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.EMAIL.EMAILDOMAINVALID' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Invalid Email Domain'
                            } );
                        } else if ( response.statusText.indexOf( 'resource_user_email_validate' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.EMAIL.EMAILDOMAINVALID' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Invalid Email Domain'
                            } );
                        } else if ( response.statusText.indexOf( 'validationFailed : Password' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.PASSWORD.RULE' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Password not valid'
                            } );
                        } else if ( ( response.statusText.indexOf( 'Validation:FirstName:Rule' ) > -1 ) || ( response.statusText.indexOf( 'Validation:LastName:Rule' ) > -1 ) ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.NAME.RULE' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : First or Last name must only contain letters and spaces'
                            } );
                        } else if ( response.statusText.indexOf( 'resource_user_mobilenumber_unique' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.USER.MOBILENUMBER.UNIQUE' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Duplicate Mobile Number'
                            } );
                        } else {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.CREATEWALLET.FALLBACK' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : Error in payload'
                            } );
                        }
                    } else if ( response.status === 403 ) {
                    	if ( response.statusText.indexOf( 'User have exceeded the risk' ) > -1 ) {
                            $scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_DETAILS.RISK_ERROR' );
                            $analytics.eventTrack( 'Wallet Create Error : ' + response.statusText, {
                                category: 'Wallet Create',
                                label: 'Wallet Create Error : User exceeded the risk and complaince'
                            } );
                        }else{
                        	$scope.validationErrorTrue = true;
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.CREATEWALLET.GENERIC' );
                            $analytics.eventTrack( 'Error Signing up', {
                                category: 'Signup',
                                label: 'Signup error' + response.status + ' : ' + response.statusText
                            } );
                        }
                    } else {
                        $scope.validationErrorTrue = true;
                        $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.CREATEWALLET.GENERIC' );
                        $analytics.eventTrack( 'Error Signing up', {
                            category: 'Signup',
                            label: 'Signup error' + response.status + ' : ' + response.statusText
                        } );
                    }
                    $scope.loading = false;
                    $scope.isLoading = false;
                } );
        };
        $scope.showTnc = function () {
            ngDialog.closeAll();
            ngDialog.open( {
                template: 'app/components/tnc/partials/tnc.html',
                className: 'dialog-tnc',
                controller: 'tncCtrl',
                scope: $scope
            } );
        };
    } );
