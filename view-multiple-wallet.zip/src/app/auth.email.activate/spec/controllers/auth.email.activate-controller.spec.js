'use strict';
describe( 'Controller: authEmailActivateCtrl Logged Out user scenarios', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authEmailActivateCtrl,
        scope,
        helperFactory,
        authEmailFactory,
        authFactory,
        userFactory,
        loggedOutUserForm,
        httpBackend,
        userInfo,
        API_BASE,
        response,
        store,
        authInfo,
        rc4,
        base64,
        q;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.create/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath +'wallet.activate.email/'+angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n+'.json').respond(200, '');
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, _helperFactory_, _authenticationFactory_, _userFactory_, _authEmailFactory_, $q, $compile, $httpBackend, _API_BASE_, _store_, _rc4Factory_, _base64Factory_ ) {
        scope = $rootScope.$new();
        helperFactory = _helperFactory_;
        API_BASE = _API_BASE_;
        store = _store_;
        authFactory = _authenticationFactory_;
        userFactory = _userFactory_;
        rc4 = _rc4Factory_;
        base64 = _base64Factory_;
        authEmailFactory = _authEmailFactory_;
        q = $q;

        scope.loggedOutUser = {
            email: 'balaji_b_v@yahoo.com',
            password: 'abcdefgh7'
        };

        userInfo = {
            "id": "7e44d2be136976e9fe15377e654dff63",
            "email": "balaji_b_v@yahoo.com",
            "name": {
                "first": "Balaji",
                "last": "V",
                "preferred": "Balaji"
            },
            "mobile": {
                "country_code": "65",
                "number": "12345675"
            },
            "countryofissue": "India",
            "identification": {
                "type": "passport",
                "number": "ABCDEFGH"
            },
            "birthday": "1998-01-05",
            "gender": "male",
            "title": "Mr",
            "links": [ {
                "rel": "users.wallets",
                "href": API_BASE + "users/wallets",
                "method": "GET"
            }, {
                "rel": "addresses.residential",
                "href": API_BASE + "users/addresses/residential",
                "method": "GET"
            }, {
                "rel": "addresses.billing",
                "href": API_BASE + "users/addresses/billing",
                "method": "GET"
            } ],
            "status": {
                "is_active": true,
                "text": "active"
            },
            "date": {
                "registration": "2015-12-15T16:26:17+08:00"
            },
            "authentications": {
                "email_verified": true,
                "mobile_verified": true
            },
            "login_info": {
                "logins": 252,
                "last_login": "2016-02-23T11:56:07+08:00"
            }
        };
        store.set( 'user', null );
        response = store.get( 'user' );
        scope.token = '350e20d6377f456fdd38e105569a9bbb';
        authInfo = {
            "key": "NjA5MjJlODY5ZGVmNTI2NTNjMGFjNGNkN2M3ODIzNzA",
            "secret": "NGQ5ZTViZjNmZWI5NzcwY2ViNjgzYmUzYzM0MzFiMDhmY2MyMGYyZTM5YWMyYWI2Y2JjYzhmZjU3YTJhMzNiZQ"
        };
        authEmailActivateCtrl = $controller( 'authEmailActivateCtrl', {
            $scope: scope
        } );
        spyOn( authFactory, 'Login' ).and.callThrough();
        spyOn( authFactory, 'SetCredentials' ).and.callThrough();

        spyOn( userFactory, 'setCurrentUser' ).and.callThrough();
        spyOn( base64, 'encode' ).and.callThrough();

        spyOn( authEmailFactory, 'verifyToken' ).and.callThrough();

        spyOn( helperFactory, 'isNricValid' ).and.callFake( function () {} );
        spyOn( helperFactory, 'resetData' ).and.callFake( function () {} );
        spyOn( helperFactory, 'resetUser' ).and.callFake( function () {} );
        spyOn( helperFactory, 'getWalletData' ).and.callFake( function () {} );
        spyOn( helperFactory, 'clearCacheNotification' ).and.callFake( function () {} );
        spyOn( helperFactory, 'postTransactionInfoUpdate' ).and.callFake( function () {} );
        spyOn( helperFactory, 'postDetailsInfoUpdate' ).and.callFake( function () {} );
        spyOn( helperFactory, 'clearCacheTransfer' ).and.callFake( function () {} );
        spyOn( helperFactory, 'updateMinMaxLengthZipcode' ).and.callFake( function () {} );
        spyOn( helperFactory, 'updatePatternPostalCode' ).and.callFake( function () {} );

        spyOn( rc4, 'encode' ).and.callFake( function () {} );
        httpBackend.whenGET( API_BASE + "users/wallets" ).respond( 200, '' );
        httpBackend.whenGET( API_BASE + "users/addresses/residential" ).respond( 200, '' );
        httpBackend.whenGET( API_BASE + "users/addresses/billing" ).respond( 200, '' );
        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    describe( 'Logged Out User logs-in & getUser is responsive', function () {
        beforeEach( inject( function () {
            spyOn( userFactory, 'getUser' ).and.callFake( function () {
                return {
                    then: function ( callback ) {
                        return callback( {
                            data: userInfo
                        } );
                    }
                };
            } );
        } ) );
        it( 'doemail verify without login : login success, getuser success, verify token success ', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenGET( API_BASE + "users/authentications/documents").respond(200, '');
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 200, 'success' );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
        } );
        it( 'doemail verify without login : login success, getuser success, verify token 500 error', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 500, '500 error', {}, "HTTP/4.1 500 generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
            expect( scope.validataionErrorMessage ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser success, verify error 401 generic', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 401, '401 error', {}, "HTTP/4.1 401 generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
            expect( scope.validataionErrorMessage ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser success, verify error 401 userAuthenticationValidationTokenExpired', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 401, '401 error', {}, "HTTP/4.1 401 userAuthenticationValidationTokenExpired error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
            expect( scope.validataionErrorMessage ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser success, verify error 401 Invalid access token', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 401, '401 error', {}, "HTTP/4.1 401 Invalid access token error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
            expect( scope.validataionErrorMessage ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser success, verify error 400 generic', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 400, '400 error', {}, "HTTP/4.1 400 Generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
            expect( scope.validataionErrorMessage ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser success, verify error 503 generic', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 503, '503 error', {}, "HTTP/4.1 503 internal server error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.userLoggedOut ).toBeFalsy();
            expect( scope.validataionErrorMessage ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser error 500, verify token error 400 generic', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 500, {}, {}, "HTTP/4.1 500 Other login error" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 400, '400 error', {}, "HTTP/4.1 400 Generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
            expect( scope.validationError ).toBeDefined();
        } );
        it( 'doemail verify without login : login success, getuser error 400, verify token error 400 generic', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 400, {}, {}, "HTTP/4.1 400 failed login" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 400, '400 error', {}, "HTTP/4.1 400 Generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
            expect( scope.validationError ).toBeDefined();
        } );
    } );
    describe( 'Error 500 fetching user data after login', function () {
        beforeEach( inject( function () {
            spyOn( userFactory, 'getUser' ).and.callFake( function () {
                var deferred = q.defer();
                deferred.reject( {
                    status: 500,
                    statusText: "HTTP/4.1 500 generic error fetching user data after login"
                } );
                return deferred.promise;
            } );
            scope.$apply();
        } ) );
        it( 'doemail verify without login : login success, getuser error 500, verify token 500 error', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 500, '500 error', {}, "HTTP/4.1 500 generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
            expect( scope.validationError ).toBeDefined();
        } );
    } );
    describe( 'Error 400 fetching user data after login', function () {
        beforeEach( inject( function () {
            spyOn( userFactory, 'getUser' ).and.callFake( function () {
                var deferred = q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: "HTTP/4.1 400 other db error fetching user data after login"
                } );
                return deferred.promise;
            } );
            scope.$apply();
        } ) );
        it( 'doemail verify without login : login success, getuser error 400, verify token 500 error', function () {
            httpBackend.whenPOST( API_BASE + "auth" ).respond( 200, {
                data: authInfo
            }, {}, "HTTP/4.1 200 OK" );
            httpBackend.whenPUT( API_BASE + 'users/authentications/email' ).respond( 500, '500 error', {}, "HTTP/4.1 500 generic error" );
            scope.verifyLoggedOut();
            httpBackend.flush();
            expect( scope.validationErrorTrue ).toBeTruthy();
            expect( scope.validationError ).toBeDefined();
        } );
    } );
} );