'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:walletEmailActivateCtrl
 * @description
 * # walletEmailActivateCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authEmailActivateCtrl', function ( $scope, $stateParams, $state, $timeout, $translate, helperFactory, authEmailFactory, rc4Factory, store, authenticationFactory, $analytics, $rootScope, userFactory, ngDialog ) {
        $scope.loggedOutUser = {
            email: '',
            password: ''
        };
        $scope.token = $stateParams.token;
        $scope.verifyingToken = true;

        var response = store.get( 'user' );

        function handleVerificationError( data ) {
            if ( data.status === 500 ) {
                $scope.validataionErrorMessage = $translate.instant( 'PAGES.WALLET_ACTIVATE_EMAIL.ERROR500' );
            } else if ( data.status === 401 ) {
                if ( data.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                    $scope.validataionErrorMessage = $translate.instant( 'PAGES.WALLET_ACTIVATE_EMAIL.ERROR401TOKENEXPIRED' );
                } else if ( data.statusText.indexOf( 'Invalid access token' ) > -1 ) {
                    $scope.validataionErrorMessage = $translate.instant( 'PAGES.WALLET_ACTIVATE_EMAIL.ERROR401INVALIDTOKEN' );
                } else {
                    $scope.validataionErrorMessage = $translate.instant( 'PAGES.WALLET_ACTIVATE_EMAIL.ERROR401' );
                }
            } else if ( data.status === 400 ) {
                var user = store.get( 'user' );
                if ( $scope.token && user ) {
                    var cards = store.get( 'cards' );
                    authenticationFactory.ClearCredentials();
                    helperFactory.clearCacheTransfer( cards );
                    $rootScope.$broadcast( 'noauthorized' );
                }
                $scope.validataionErrorMessage = $translate.instant( 'PAGES.WALLET_ACTIVATE_EMAIL.ERROR400' );
            } else {
                $scope.validataionErrorMessage = $translate.instant( 'PAGES.WALLET_ACTIVATE_EMAIL.ERRORGENERIC' );
            }
            $scope.validationEmailErrorTrue = true;
        }

        function doEmailVerificationWithUserAuthentication() {
            $scope.validationErrorTrue = false;
            $scope.isLoading = true;
            authenticationFactory.Login( $scope.loggedOutUser.email, $scope.loggedOutUser.password )
                .then( function ( data, status, headers, config ) {
                    authenticationFactory.SetCredentials( data.data.key, data.data.secret );
                    $analytics.eventTrack( 'Login Success', {
                        category: 'Login',
                        label: 'Login Succesfull'
                    } );
                    userFactory.getUser()
                        .then( function ( response ) {
                            userFactory.setCurrentUser( response.data );
                            $analytics.setUsername( response.data.id );
                            $rootScope.$broadcast( 'authorized' );
                            $analytics.setUserProperties( {
                                '$email': response.data.email,
                                '$registration_date': response.data.date.registration,
                                '$mobile': response.data.mobile.country_code + response.data.mobile.number,
                                '$name': response.data.name.first + ' ' + response.data.name.first
                            } ); // jshint ignore:line
                            $scope.isLoading = false;
                        }, function ( response ) {
                            if ( response.status === 500 ) {
                                $scope.isLoading = false;
                                $scope.validationErrorTrue = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Error 500',
                                    label: 'Error getting User Info after login'
                                } );
                            } else {
                                $scope.isLoading = false;
                                $scope.validationErrorTrue = true;
                                $analytics.eventTrack( 'Error getting User Info after login', {
                                    category: 'Login',
                                    label: 'Login error : ' + response.status + ' : ' + response.statusText
                                } );
                            }
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.LOGIN.GENERIC' );
                        } );
                    $scope.userLoggedOut = false;
                    doEmailVerification( $scope.token, $scope.loggedOutUser.email );
                }, function ( response ) {
                    $scope.validationErrorTrue = true;
                    $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.LOGIN.GENERIC' );
                    $scope.isLoading = false;
                    if ( response.status === 500 ) {
                        $analytics.eventTrack( 'Error Logging in', {
                            category: 'Error 500',
                            label: 'Error Logging in'
                        } );
                    } else {
                        $analytics.eventTrack( 'Login error', {
                            category: 'Login',
                            label: 'Login Error : ' + response.status + ' : ' + response.statusText
                        } );
                    }

                } );
        }

        function postSuccessRedirection() {
            $state.transitionTo( 'auth.login', null, {
                'reload': true
            } );
        }

        function doEmailVerification( token, email ) {
            $scope.validationEmailErrorTrue = false;
            $scope.success = false;
            authEmailFactory.verifyToken( token, email )
                .then( function () {
                    store.remove( $scope.token );
                    $scope.success = true;
                    $scope.timeout = $timeout( postSuccessRedirection, 10000 );
                    $scope.isLoading = false;
                }, function ( err ) {
                    handleVerificationError( err );
                    $scope.isLoading = false;
                } );
        }

        if ( typeof ( response ) !== undefined && response !== null ) {
            var user = store.get( 'user' );
            if ( user && user.email ) {
                doEmailVerification( $scope.token, user.email );
            }
        } else {
            $scope.userLoggedOut = true;
            $scope.loggedOutUser = {};
            $scope.verifyLoggedOut = function () {
                $scope.isLoading = true;
                doEmailVerificationWithUserAuthentication();
                helperFactory.resetUser();
            };
        }
        $scope.redirectionLink = function () {
            $timeout.cancel( $scope.timeout );
            postSuccessRedirection();
        }
    } );
