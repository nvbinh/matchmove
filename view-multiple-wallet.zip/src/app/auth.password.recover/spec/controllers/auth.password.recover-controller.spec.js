'use strict';
describe( 'Controller: authPasswordRecoverCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authPasswordRecoverCtrl,
        httpHost,
        recoverPasswordUrl,
        httpBackend,
        scope;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.password.recover/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, HTTP_HOST, RECOVER_PASSWORD_URL, API_BASE ) {
        scope = $rootScope.$new();
        httpHost = HTTP_HOST;
        recoverPasswordUrl = RECOVER_PASSWORD_URL;
        authPasswordRecoverCtrl = $controller( 'authPasswordRecoverCtrl', {
            $scope: scope
        } );
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 200, '' );
    } ) );

    describe( 'recover password', function () {
        it( 'should have verification sent', function () {
            scope.recoverPassword();
            expect( scope.verificationSent ).toBeDefined();
            expect( scope.verificationSent ).toBeFalsy();
        } );
        it( 'should have error recover', function () {
            scope.recoverPassword();
            expect( scope.errorRecoverPassword ).toBeDefined();
            expect( scope.errorRecoverPassword ).toBeFalsy();
        } );
        it( 'should have loading', function () {
            scope.recoverPassword();
            expect( scope.isLoading ).toBeDefined();
            expect( scope.isLoading ).toBeTruthy();
        } );
        it( 'should have endpoint', function () {
            scope.recoverPassword();
            expect( scope.endpoint ).toBeDefined();
            expect( scope.endpoint ).toEqual( httpHost + recoverPasswordUrl );
        } );
        it( 'should have payload', function () {
            scope.recoverPassword();
            expect( scope.payload ).toBeDefined();
        } );
        describe( 'when update password succeeds', function () {
            it( 'should send verification', function () {
                scope.recoverPassword();
                httpBackend.flush();
                expect( scope.verificationSent ).toBeTruthy();
            } );
        } );
    } );

    it( 'should switch send status', function () {
        scope.recoverPassword();
        scope.verificationSent = true;
        scope.switchsendStatus();
        expect( scope.verificationSent ).toBeFalsy();
    } );
} );
describe( 'Controller: authPasswordRecoverCtrl Error Scenarios', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authPasswordRecoverCtrl,
        httpHost,
        recoverPasswordUrl,
        scope,
        httpBackend,
        API_BASE;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'wallet.password.recover/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, HTTP_HOST, RECOVER_PASSWORD_URL, $httpBackend, _API_BASE_ ) {
        scope = $rootScope.$new();
        httpHost = HTTP_HOST;
        recoverPasswordUrl = RECOVER_PASSWORD_URL;
        API_BASE = _API_BASE_;
        authPasswordRecoverCtrl = $controller( 'authPasswordRecoverCtrl', {
            $scope: scope
        } );
       //httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'error 500', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 500, 'Error 500', {}, "HTTP/4.1 500 error generic" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
    it( 'error 501', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 503, 'Error 503', {}, "HTTP/4.1 503 error generic" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
    it( 'error 502', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 502, 'Error 502', {}, "HTTP/4.1 502 error generic" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
    it( 'error 503', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 501, 'Error 501', {}, "HTTP/4.1 501 error generic" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
    it( 'error 400', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 400, 'Error 400', {}, "HTTP/4.1 400 error generic" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
    it( 'error 400 userAuthenticationEmailNotFound', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 400, 'Error 400', {}, "HTTP/4.1 400 userAuthenticationEmailNotFound error" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
    it( 'error 401', function () {
        httpBackend.whenPOST( API_BASE + 'users/recover/password' ).respond( 401, 'Error 401', {}, "HTTP/4.1 401 error generic" );
        scope.recoverPassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
    } );
} );
