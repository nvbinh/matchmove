'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authPasswordRecoverCtrl
 * @description
 * # authPasswordRecoverCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authPasswordRecoverCtrl', function ( $scope, $translate, $analytics, userFactory, store, HTTP_HOST, RECOVER_PASSWORD_URL ) {
        $scope.recoverPassword = function () {
            $scope.verificationSent = false;
            $scope.errorRecoverPassword = false;
            $scope.isLoading = true;
            $scope.endpoint = HTTP_HOST + RECOVER_PASSWORD_URL;
            $scope.payload = {};
            $scope.payload = {
                endpoint: $scope.endpoint,
                email: $scope.email
            };
            userFactory.updatePassword( $scope.payload ).then( function () {
                $scope.verificationSent = true;
                $analytics.eventTrack( 'Wallet Password Recovery email delivery success', {
                    category: 'Wallet Password Recover',
                    label: 'Wallet Password Recovery email delivery'
                } );
                $scope.isLoading = false;
            }, function ( response ) {
                $scope.errorRecoverPassword = true;
                if ( response.status === 401 ) {
                    $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.401' );
                    $analytics.eventTrack( 'Wallet Password Recovery Error', {
                        category: 'Wallet Password Recover',
                        label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                    } );
                } else if ( response.status === 400 ) {
                    if ( response.statusText.indexOf( 'userAuthenticationEmailNotFound' ) > -1 ) {
                        $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.EMAIL_NOT_FOUND' );
                        $analytics.eventTrack( 'Wallet Password Recovery Error', {
                            category: 'Wallet Password Recover',
                            label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.statusText.indexOf( 'userAuthenticationValidationFailed' ) > -1 ) {
                        $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.INVALID_TOKEN' );
                        $analytics.eventTrack( 'Wallet Password Recovery Error', {
                            category: 'Wallet Password Recover',
                            label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                        $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.INVALID_TOKEN' );
                        $analytics.eventTrack( 'Wallet Password Recovery Error', {
                            category: 'Wallet Password Recover',
                            label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                        } );
                    } else {
                        $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.400.FALLBACK' );
                        $analytics.eventTrack( 'Wallet Password Recovery Error', {
                            category: 'Wallet Password Recover',
                            label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                        } );
                    }
                } else if ( response.status === 500 ) {
                    $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.500' );
                    $analytics.eventTrack( 'Error triggering recovery password', {
                        category: 'Error 500',
                        label: 'Error triggering recovery password'
                    } );
                } else if ( response.status === 502 ) {
                    $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.502' );
                    $analytics.eventTrack( 'Wallet Password Recovery Error', {
                        category: 'Wallet Password Recover',
                        label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                    } );
                } else if ( response.status === 501 ) {
                    $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.501' );
                    $analytics.eventTrack( 'Wallet Password Recovery Error', {
                        category: 'Wallet Password Recover',
                        label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                    } );
                } else {
                    $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.PASSWORD_RECOVER.ERRORFALLBACK' );
                    $analytics.eventTrack( 'Wallet Password Recovery Error', {
                        category: 'Wallet Password Recover',
                        label: 'Wallet Password Recovery Error : ' + response.status + ' : ' + response.statusText
                    } );
                }
                $scope.isLoading = false;
            } );
            $scope.switchsendStatus = function () {
                $scope.verificationSent = false;
            };
        };
    } );
