'use strict';
describe( 'Controller: paymentCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    var paymentCtrl,
        scope,
        rootScope,
        x;
    //Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, MM_BRANDING ) {
        scope = $rootScope.$new();
        rootScope = $rootScope;
        authCtrl = $controller( 'paymentCtrl', {
            $scope: scope
        } );
    } ) );
} );
