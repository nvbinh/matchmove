'use strict';
/* global angular */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:paymentCtrl
 * @description
 * # paymentCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'paymentCtrl', function ( MM_BRANDING, $scope ) {
        $scope.showBranding = MM_BRANDING;
    } );
