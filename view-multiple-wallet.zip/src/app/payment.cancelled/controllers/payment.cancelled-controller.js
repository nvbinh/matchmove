'use strict';
/* global angular */
/* global $ */
/* global window */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:paymentCancelledCtrl
 * @description
 * # paymentCancelledCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'paymentCancelledCtrl', function ( $scope, SIGNUP_PARAMS) {
        $scope.signupParams = angular.fromJson( SIGNUP_PARAMS );
    } );
