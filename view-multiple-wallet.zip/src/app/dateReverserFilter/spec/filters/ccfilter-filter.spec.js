'use strict';

describe('Filter: dateReverser', function () {
// load the filter's module

    beforeEach(module('viewMultipleWallet'));
    // initialize a new instance of the filter before each test
    var dateReverserFilter;
    beforeEach(inject(function(_dateReverserFilter_) {
        dateReverserFilter = _dateReverserFilter_;
    }));
    it('"dateReverser filter:" should reformat the date correctly', function () {
        expect(dateReverserFilter('2021-01')).toBe('01 / 21');
    });

    it('"dateReverser filter:" should reformat the date correctly', function () {
        expect(dateReverserFilter('2016-12-18')).toBe('12 / 16');
    });

    it('"dateReverser filter:" should return blank if date passed is blank', function () {
        expect(dateReverserFilter('')).toBe('');
    });
});
