'use strict';
/**
 * @ngdoc filter
 * @name viewMultipleWallet.filter:dateReverser
 * @function
 * @description
 * # dateReverser
 * Filter in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .filter('dateReverser', function () {
    return function (input) {

        if ( input.length ) {
            var arr = input.split( '-' );
            return arr[ 1 ] + ' / ' + arr[ 0 ].substring( 2, arr[ 0 ].length );
        } else {
            return input;
        }
        
    };
  });
