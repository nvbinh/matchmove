'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.apiinterceptor
 * @description
 * # apiinterceptor
 * Service in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .factory('apiinterceptorService', function ($rootScope, $q) {
    // AngularJS will instantiate a singleton by calling "new" on this function

        return {
            request: function (config) {
                return config || $q.when(config);
            },
            requestError: function(request){
                return $q.reject(request);
            },
            response: function (response) {
                return response || $q.when(response);
            },
            responseError: function (response) {
                if (response && response.status === 401) {

                    if(response.statusText.indexOf('userPasswordFailed') > -1){
                        $rootScope.$broadcast('failed');
                    }
                    else if(response.statusText.indexOf('userAuthenticationPhoneSendSMSFailed') > -1){
                        $rootScope.$broadcast('failed');
                    }

                    else if(response.statusText.indexOf('userAuthenticationValidationTokenExpired') > -1){
                      $rootScope.$broadcast('failed');
                    }
                    else if(response.statusText.indexOf('userAuthenticationValidationFailed') > -1) {
                        $rootScope.$broadcast('failed');
                    }
                    else if(response.statusText.indexOf('invalidParameters') > -1) {
                        $rootScope.$broadcast('failed');
                    }
                    else if (response.statusText.indexOf('userPhoneAlreadyInUse') > -1) {
                         $rootScope.$broadcast('failed');
                    }
                    else if (response.statusText.indexOf('userEmailAlreadyInUse') > -1) {
                        $rootScope.$broadcast('failed');
                    }
                    else if (response.statusText.indexOf('userAuthenticationEmailNotFound') > -1){
                        $rootScope.$broadcast('failed');
                    }
                    else {
                        $rootScope.$broadcast('unauthorized');
                    }

                }
                if (response && response.status === 498) {
                    $rootScope.$broadcast('unauthorized');
                }
                return $q.reject(response);
            }
        };
    });
