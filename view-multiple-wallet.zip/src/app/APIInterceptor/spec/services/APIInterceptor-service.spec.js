'use strict';
describe('Service: apiinterceptorService', function() {
  var apiinterceptor,
    responseError,
    responseErrMsg,
    rootScope;

  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_apiinterceptorService_, $rootScope) {
      apiinterceptor = _apiinterceptorService_;
      rootScope = $rootScope;

      spyOn(rootScope, '$broadcast').and.callThrough();
  }));
  it('get request config', function(){
      var cfg = apiinterceptor.request({"name": "Marc"});
        expect(cfg).toEqual({"name": "Marc"});
  });
  it('obtain requestError', function(){
      apiinterceptor.requestError("simple/request").then(
        function(){},
        function(error){
            expect(error).toBeTruthy();
        });
  });
  it('handle response 200', function(){
      var resp = apiinterceptor.response('OK');
      expect(resp).toBe('OK');
  });
  it('handle response error 401 : userPasswordFailed ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userPasswordFailed"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : userAuthenticationPhoneSendSMSFailed ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userAuthenticationPhoneSendSMSFailed"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : userAuthenticationValidationTokenExpired ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userAuthenticationValidationTokenExpired"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : userAuthenticationValidationFailed ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userAuthenticationValidationFailed"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : invalidParameters ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 invalidParameters"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : userPhoneAlreadyInUse ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userPhoneAlreadyInUse"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : userEmailAlreadyInUse ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userEmailAlreadyInUse"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle response error 401 : userAuthenticationEmailNotFound ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 userAuthenticationEmailNotFound"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('failed');
  });
  it('handle unauthorized status : ', function(){
      responseErrMsg = {"status":401, "statusText": "401 HTTP/1.1 401 unauthorized"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('unauthorized');
  });
  it('handle unauthorized status : ', function(){
      responseErrMsg = {"status":498, "statusText": "498 HTTP/1.1 498 unexpected error"};
      apiinterceptor.responseError(responseErrMsg);
      expect(rootScope.$broadcast).toHaveBeenCalledWith('unauthorized');
  });
});
