'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:profileUploadCtrl
 * @description
 * # profileUploadCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('profileUploadCtrl', function ($scope, helperFactory, $timeout, $filter, userFactory, ngDialog, $state, $analytics, flowFactory, PubSub, cordovaFactory, APPLICATION_PARAMS, mobiledetectService) {
    var $translate = $filter('translate');
    $scope.profileUpload = flowFactory.create({
        target: '',
        permanentErrors: [ 500, 501 ],
        maxChunkRetries: 1,
        chunkRetryInterval: 5000,
        simultaneousUploads: 1,
        singleFile: true
    });
    $scope.isMobile = mobiledetectService.mobile();
    $scope.isPlatformApp = angular.fromJson(APPLICATION_PARAMS).platform === 'app';
    $scope.imageStrings = [];
    $scope.processFiles = function (files) {
        var patt = new RegExp('image/');
        if(files.length <= 0){
            $scope.messageText = $translate('ERRORS.VALIDATION.PROFILE_UPLOAD.DOCUMENT_SAME_FILE_ERROR');
            $scope.messageStatus = true;
        }
        angular.forEach(files, function (flowFile) {
            var fileReader = new FileReader(),
                i = files.indexOf(flowFile);
            if (patt.test(flowFile.file.type) === false) {
                files.splice(i, 1);
                $scope.messageText = $translate('ERRORS.VALIDATION.PROFILE_UPLOAD.DOCUMENT_TYPE_ERROR');
                $scope.messageStatus = true;
                return;
            }
            if (flowFile.file.size > 8192000) {
                files.splice(i, 1);
                $scope.messageText = $translate('ERRORS.VALIDATION.PROFILE_UPLOAD.DOCUMENT_SIZE_ERROR');
                $scope.messageStatus = true;
                return;
            }
            fileReader.onload = function (event) {
                var uri = event.target.result;
                $scope.imageStrings.push(uri);
                $scope.checkUploader();
            };
            fileReader.readAsDataURL(flowFile.file);
        });
    };

    $scope.checkUploader = function () {
        if ($scope.imageStrings.length < 1) {
            $scope.hideUploader = false;
        } else {
            $scope.hideUploader = true;
        }
    };

    $scope.updateStrings = function (image, index) {
        var imageStrings = $scope.imageStrings.splice(index, 1);
        $scope.checkUploader();
        return imageStrings;
    };

    // Drag/Drop Classes
    $scope.uDragEnter = function () {
        return $scope.dropClass === 'dropping';
    };
    $scope.uDragLeave = function () {
        return $scope.dropClass === '';
    };

    $scope.updateImages = function ($files) {
        var images = angular.copy($scope.imageStrings);

        $scope.fileCount = 0;
        $scope.failCount = 0;
        $scope.$watch('fileCount', function () {
            uploadFile(images);
        });
    };

    function uploadFile(files) {
        $scope.isLoading = true;
        var value = files.shift(),
            indexToSlice,
            successBlock = function (response) {
                $analytics.eventTrack('Upload Profile Image Success', {  category: 'profileUpload', label: 'Upload Succesfull' });
                $scope.isLoading = false;
                $timeout(function() {
                    ngDialog.closeAll();
                });
                userFactory.clearUserCache();
                PubSub.publish('update-sidebarProfileImage');
                PubSub.publish('update-accountProfileImage');
                $state.go('wallet.details.my', {}, {reload:true});
            },
            errorBlock = function (response) {
                $scope.isLoading = false;
                $analytics.eventTrack('Upload Profile Image Failure', {  category: 'profileUpload', label: 'Upload Fail' });
            };

        if (value === undefined) {
            return;
        }
        indexToSlice = value.indexOf(',') + 1;
        userFactory.updateProfileImage({
            'data': value.slice(indexToSlice)
        }).then(successBlock, errorBlock);
    }

    $scope.takePhoto = function(imgType){
        if(cordovaFactory.onDeviceReady){
            cordovaFactory.takePhoto(imgType);
        }
    }
  });
