'use strict';
describe('Controller: profileUploadCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var profileUploadCtrl,
      scope,
      _userFactory,
      image;
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, userFactory) {
    scope = $rootScope.$new();
    profileUploadCtrl = $controller('profileUploadCtrl', {
      $scope: scope
    });
    _userFactory = userFactory;
    image = ["data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExMVFRUX…3/AMAPIYYJFj9F5r41P/kKii91/kv9kQX+KTwVTVIKii8H1Hkdj8ABU5RRSlM+CgooouNP/9k="];
  }));
  describe('checkUploader', function () {
    it('auto hide uploader box when imageStrings is more than 1 image', function () {
      scope.imageStrings = image;
      scope.checkUploader();
      expect(scope.hideUploader).toBeTruthy();
    });
  });
  it('uploadFile', function () {
    scope.imageStrings = image;
    spyOn( _userFactory, 'updateProfileImage' ).and.callThrough();
    scope.updateImages();
    expect(scope.fileCount).toEqual(0);
    expect(scope.failCount).toEqual(0);
  });
});
