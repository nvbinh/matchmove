'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.user
 * @description
 * # user
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .service('userFactory', function ($http, API_BASE, base64Factory, store, userAddressFactory, $q, $rootScope, CacheFactory, $state, KYC_UPLOAD_SETTINGS) {

        //var service = this,
        var currentUser = null;

        function clearUserCache(){
          var userCache = CacheFactory.get('userCache');
          userCache.remove( 'user' );
        }

        function getUser( cache ) {
            var userCache = CacheFactory.get('userCache');

            var deferred = $q.defer();
            var cacheFlag;
            if ( cache === true ) {
                cacheFlag = userCache;
                var user;
                if (userCache && userCache.get( 'user' )) {
                    user = userCache.get( 'user' );
                    deferred.resolve( user );
                    return deferred.promise;
                }else{
                    cacheFlag = false;
                }
            } else {
                cacheFlag = false;
            }
            $http( {
                method: 'GET',
                url: API_BASE + 'users',
                cache: cacheFlag,
                timeout: 18000
            } ).then( function ( data, status, headers, config ) {
                var user = data;
                userCache.put( 'user', user );
                store.set( 'user', user.data );
                deferred.resolve( user );
            }, function ( errorResponse ) {
                deferred.reject( errorResponse );
            } )
            return deferred.promise;
        };

        function getUserPreOrPostKyc() {
            var userState;
            var status = {};
            status.userPreKyc = true, status.userPostKyc = false;
            if ( store.get( 'kycStatus' ) ) {
                userState = store.get( 'kycStatus' );
                if ( userState === 'approved' ) {
                    status.userPostKyc = true;
                    status.userPreKyc = false;
                }
            }
            return status;
        }

        function setCurrentUser( user ) {
            currentUser = user;
            store.set( 'user', user );
            return currentUser;
        };

        function getCurrentUser() {
            return store.get( 'user' );
        };

        function createUser( user ) {
            var authdata = base64Factory.encode( user.email + ':' + user.password );
            return $http( {
                method: 'POST',
                url: API_BASE + 'users',
                headers: {
                    'Authorization': 'Basic ' + authdata,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function ( obj ) {
                    var str = [];
                    for ( var p in obj ) {
                        str.push( encodeURIComponent( p ) + '=' + encodeURIComponent( obj[ p ] ) );
                    }
                    return str.join( '&' );
                },
                data: user
            } );
        };

        function updateUser( user ) {
            return $http( {
                method: 'PUT',
                url: API_BASE + 'users',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function ( obj ) {
                    var str = [];
                    for ( var p in obj ) {
                        str.push( encodeURIComponent( p ) + '=' + encodeURIComponent( obj[ p ] ) );
                    }
                    return str.join( '&' );
                },
                data: user
            } );
        };

        function closeUser (payload) {
          return $http( {
              method: 'POST',
              url: API_BASE + 'users/closure',
              headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
              },
              transformRequest: function ( obj ) {
                  var str = [];
                  for ( var p in obj ) {
                      str.push( encodeURIComponent( p ) + '=' + encodeURIComponent( obj[ p ] ) );
                  }
                  return str.join( '&' );
              },
              data: payload
          } );
        }

        function updatePassword( payload ) {
            return $http( {
                method: 'POST',
                url: API_BASE + 'users/recover/password',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function ( obj ) {
                    var str = [];
                    for ( var p in obj ) {
                        str.push( encodeURIComponent( p ) + '=' + encodeURIComponent( obj[ p ] ) );
                    }
                    return str.join( '&' );
                },
                data: payload
            } );
        };

        function updateProfileImage(document) {
            var url,
            authen,
            url = API_BASE + 'users/profile/image';
            authen = 'Basic ' + $rootScope.globals.currentUser.authdata;
            return $http({
              method: 'POST',
              url: url,
              headers: {
                'Authorization': authen,
                'Content-Type': 'application/x-www-form-urlencoded'
              },
              transformRequest: function(obj) {
                  var str = [];
                  for(var p in obj) {
                      str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                  }
                  return str.join('&');
              },
              data: document
            });
        };

        // use KYC config param here
        var configKYC = angular.fromJson(KYC_UPLOAD_SETTINGS);
        var KycDataSeekPoints = configKYC.KYCDataSeekPoints;

        function isUserDetailsComplete() {
            var identification = false,
                residential = false,
                billing = false,
                hQ = [],
                deferred = $q.defer();
            if(KycDataSeekPoints.profile.switch === 'ON'){
                hQ.push( getUser()
                .then( function ( response ) {
                    if ( response.data.hasOwnProperty( 'identification' ) ) {
                        identification = true;
                    }
                }, function ( err ) {
                    identification = false;
                } ) );
            }
            if(KycDataSeekPoints.addressInfo.switch === 'ON'){
                hQ.push( userAddressFactory.getAddress( 'residential', false )
                .then( function ( resp ) {
                    if ( resp.status === 200 )
                        residential = true;
                }, function ( err ) {
                    residential = false;
                } ) );
            }
            if(KycDataSeekPoints.addressInfo.switch === 'ON'){
                hQ.push( userAddressFactory.getAddress( 'billing', false )
                .then( function ( resp ) {
                    if ( resp.status === 200 )
                        billing = true;
                }, function ( err ) {
                    billing = false;
                } ) );
            }
            if(KycDataSeekPoints.profile.switch === 'OFF'){
                identification = true;
            }
            if(KycDataSeekPoints.addressInfo.switch === 'OFF'){
                residential = billing = true;
            }

            $q.all( hQ )
                .then( function ( resp ) {
                    deferred.resolve( {
                        status: identification && residential && billing
                    } );
                }, function () {
                    deferred.resolve( {
                        status: false
                    } );
                } );
            return deferred.promise;
        }

        function checkUserVerification() {
            var deferred = $q.defer();
            getUser()
                .then( function ( response ) {
                    deferred.resolve( response.data.authentications );
                }, function ( err ) {} );
            return deferred.promise;
        }

        // Add descriptions
        checkUserVerification.description = 'userFactory:checkUserVerification';
        isUserDetailsComplete.description = 'userFactory:isUserDetailsComplete';
        updatePassword.description = 'userFactory:updatePassword';
        updateProfileImage.description = 'userFactory:updateProfileImage';
        updateUser.description = 'userFactory:updateUser';
        createUser.description = 'userFactory:createUser';
        getCurrentUser.description = 'userFactory:getCurrentUser';
        setCurrentUser.description = 'userFactory:setCurrentUser';
        getUser.description = 'userFactory:getUser';
        getUserPreOrPostKyc.description = 'userFactory:getUserPreOrPostKyc';
        closeUser.description = 'userFactory:closeUser';
        // Public facing API
        return {
            checkUserVerification: checkUserVerification,
            clearUserCache: clearUserCache,
            isUserDetailsComplete: isUserDetailsComplete,
            updatePassword: updatePassword,
            updateProfileImage: updateProfileImage,
            updateUser: updateUser,
            createUser: createUser,
            getCurrentUser: getCurrentUser,
            setCurrentUser: setCurrentUser,
            getUser: getUser,
            getUserPreOrPostKyc: getUserPreOrPostKyc,
            closeUser:closeUser
        }
    } );
