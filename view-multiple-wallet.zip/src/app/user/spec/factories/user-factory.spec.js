'use strict';
describe('Factory: userFactory', function() {
  var scope,
  user,
  httpBackend,
  API_BASE,
  userData,
  userRegnResponse,
  userUpdateResponse,
  recoPassResponse,
  store,
  userAddressFactory,
  userDatainComplete;

  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("KYC_UPLOAD_SETTINGS",{"allowedIdType":[{"nric": "PAGES.WALLET_DETAILS.ID_TYPE_TEXT.NRIC","epfin":"PAGES.WALLET_DETAILS.ID_TYPE_TEXT.EP_FIN","spass":"PAGES.WALLET_DETAILS.ID_TYPE_TEXT.S_PASS","wp":"PAGES.WALLET_DETAILS.ID_TYPE_TEXT.WORK_PERMIT"}], "numberOfFilesAllowed":4,"allowedTitle":[{"Mr": "PAGES.WALLET_DETAILS.MR","Mrs":"PAGES.WALLET_DETAILS.MRS","Miss":"PAGES.WALLET_DETAILS.MISS","Dr":"PAGES.WALLET_DETAILS.DR","Madam":"PAGES.WALLET_DETAILS.MADAM"}], "KYCProcessStates": ["not_submitted", "pending", "rejected", "submitted", "f2f_request", "f2f_approved", "approved"], "KYCDataSeekPoints":{"email": {"langKey": "EMAIL", "switch":"ON"},"mobile": {"langKey": "MOBILE", "switch":"ON"},"profile": {"langKey": "PROFILE", "switch":"ON"},"addressInfo":{"langKey": "ADDRESS_INFORMATION", "switch":"ON"},"KYC": {"langKey": "KYC", "switch":"ON"}}});
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize factory
  beforeEach(inject(function($rootScope, _userFactory_, _API_BASE_, _store_, _userAddressFactory_) {
    scope = $rootScope.$new();
    user = _userFactory_;
    API_BASE = _API_BASE_;
    store = _store_;
    userAddressFactory = _userAddressFactory_;

    userDatainComplete = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          }
       };

    userData = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "birthday": "1998-01-05",
          "gender": "male",
          "title": "Mr",
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            },
            {
              "rel": "addresses.residential",
              "href": API_BASE + "users/addresses/residential",
              "method": "GET"
            },
            {
              "rel": "addresses.billing",
              "href": API_BASE + "users/addresses/billing",
              "method": "GET"
            }
          ],
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2015-12-15T16:26:17+08:00"
          },
          "authentications": {
            "email_verified": true,
            "mobile_verified": false
          },
          "login_info": {
            "logins": 156,
            "last_login": "2016-02-08T17:31:24+08:00"
          }
        };

     userRegnResponse = {
          "id": "a302ba291accb13fb6e6123c718af6ab",
          "email": "balajiv+21@chimeratechnologies.com",
          "name": {
            "first": "Balaji",
            "last": "Two One",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345674"
          },
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2016-02-08T19:29:44+08:00"
          },
          "key": "ZGE5MmJiYWMwYTk2ZDIyODJlYWIzN2JmZjA2Njc2NGQ",
          "secret": "MzhmOTI2NjhmMjMzYjY1ODM3YWZkOTQxZWRhYjY3MGZhYzRhOTE5ZDQ0MDRkZWFiZjQzNmYxMTgwNWI5NjJkYw"
        };
      userUpdateResponse = {
          "id": "a302ba291accb13fb6e6123c718af6ab",
          "email": "balajiv+21@chimeratechnologies.com",
          "name": {
            "first": "Balaji",
            "last": "Two One",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345674"
          },
          "gender": "male",
          "title": "Mr",
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            }
          ],
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2016-02-08T19:29:44+08:00"
          }
        };
      recoPassResponse = {
          "status": "success",
          "token": "350e20d6377f456fdd38e105569a9bbb"
        };
    httpBackend.whenPOST(API_BASE + 'users').respond(200, userRegnResponse);
    httpBackend.whenPUT(API_BASE + 'users').respond(200, userUpdateResponse);
    httpBackend.whenPOST(API_BASE + 'users/recover/password').respond(200, recoPassResponse);
	httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('Get data of logged in user', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
      user.getUser().then(function(response){
          expect(response.status).toBe(200);
          expect(response.data.email).toBe('balaji_b_v@yahoo.com');
      });
      httpBackend.flush();
  });
  it('Set current user in store', function(){
      scope.user = user.setCurrentUser(userData);
      expect(scope.user.email).toBe('balaji_b_v@yahoo.com');
  });
  it('Get user from local storage', function(){
      spyOn(store, 'get').and.returnValue(userData);
      var userFromStore = user.getCurrentUser();
      expect(userFromStore.email).toBe('balaji_b_v@yahoo.com');
  });
  it('should Create a new user', function(){
      user.createUser({email: 'balajiv+21@chimeratechnologies.com'}).then(function(response){
          expect(response.status).toBe(200);
          expect(response.data.email).toBe('balajiv+21@chimeratechnologies.com');
      });
      httpBackend.flush();
  });
  it('should Update the user details', function(){
      user.updateUser({email: 'balajiv+21@chimeratechnologies.com'}).then(function(response){
          expect(response.status).toBe(200);
          expect(response.data.email).toBe('balajiv+21@chimeratechnologies.com');
          expect(response.data.title).toBe('Mr');
          expect(response.data.gender).toBe('male');
      });
      httpBackend.flush();
  });
  it('should send recover password link to user', function(){
      user.updatePassword({email: 'balajiv+21@chimeratechnologies.com', endpoint: 'https://application.example.com/verify/'}).then(function(response){
          expect(response.status).toBe(200);
          expect(response.data.status).toBe('success');
          expect(response.data.token).toBeDefined();
      });
      httpBackend.flush();
  });
  it('should return true when all details are userDetailsComplete', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(200, userData, {}, 'HTTP/1.1 200 OK');
      httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, '', {}, 'HTTP/1.1 200 OK');
      httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, '', {}, 'HTTP/1.1 200 OK');
      spyOn(userAddressFactory, 'getAddress').and.callThrough();
      user.isUserDetailsComplete().then(function(response){
          expect(response.status).toBe(true);
      }, function(error){
          expect(error.status).toBe(false);
      });
      httpBackend.flush();
  });
  it('should return false when information is inComplete: user auth not present', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(401, '401 error', {}, 'HTTP/1.1 401 User data not available');
      httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, '');
      httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, '');
      spyOn(userAddressFactory, 'getAddress').and.callThrough();
      user.isUserDetailsComplete().then(function(response){
          expect(response.status).toBe(false);
      }, function(error){
          expect(error.status).toBe(true);
      });
      httpBackend.flush();
  });
  it('should return false when information is inComplete: residential Address is null', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
      httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(403, '', {}, 'HTTP/1.1 403 No residential address response');
      httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, {data: null});
      spyOn(userAddressFactory, 'getAddress').and.callThrough();
      user.isUserDetailsComplete().then(function(response){
          expect(response.status).toBe(false);
      }, function(error){
          expect(error.status).toBe(true);
      });
      httpBackend.flush();
  });
  it('should return false when information is inComplete: billing address is null', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
      httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, {data: null});
      httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(403, '', {}, 'HTTP/1.1 403 No residential address response');
      spyOn(userAddressFactory, 'getAddress').and.callThrough();
      user.isUserDetailsComplete().then(function(response){
          expect(response.status).toBe(false);
      }, function(error){
          expect(error.status).toBe(true);
      });
      httpBackend.flush();
  });
  it('should check user verification status : when authentication object present', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
      user.checkUserVerification().then(function(response){
          expect(response.email_verified).toBeTruthy();
          expect(response.mobile_verified).toBeFalsy();
      });
      httpBackend.flush();
  });
  it('should check user verification status : when authentication object NOT present', function(){
      httpBackend.whenGET(API_BASE + 'users').respond(401, 'error', {}, "HTTP/1.1 401 User data unavailable");
      user.checkUserVerification().then(function(error){
          expect(error).toBeTruthy();
      });
      httpBackend.flush();
  });
});
