'use strict';
describe( 'Controller: paymentErrorCtrl - HTTP Requests', function () {
    // Load the controller's module and mock data
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    var paymentErrorCtrl,
        scope,
        // data
        // common vars
        deferred,
        $q;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PROVIDER ) {
        httpBackend = $httpBackend;
        httpBackend.whenGET( TRANSLATION_PROVIDER + '?lang=enUS' ).respond( 200, '' );
        httpBackend.flush();
    } ) );
    // Initialize controller and mock scop
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
} );
