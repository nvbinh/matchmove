'use strict';
/* global angular */
/* global $ */
/* global window */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:paymentErrorCtrl
 * @description
 * # paymentErrorCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'paymentErrorCtrl', function ( $scope, SIGNUP_PARAMS) {
        $scope.signupParams = angular.fromJson( SIGNUP_PARAMS );
    } );
