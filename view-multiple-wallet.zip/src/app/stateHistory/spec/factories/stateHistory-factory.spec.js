'use strict';
describe( 'Factory: stateHistoryFactory', function() {
	var stateHistory;
	beforeEach( module( 'viewMultipleWallet' ) );
	beforeEach( inject( function( _stateHistoryFactory_ ) {
		stateHistory = _stateHistoryFactory_;
	} ) );
} );