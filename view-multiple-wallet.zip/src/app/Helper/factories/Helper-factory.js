'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.helper
 * @description
 * # helper
 * Factory in the viewMultipleWallet.
 */
angular.module( 'viewMultipleWallet' )
    .factory( 'helperFactory', function ( API_BASE, $http, store, CacheFactory, $q, $rootScope, COUNTRY_SUPPORT, BASE_CURRENCY, Wallet, authDocumentFactory, userFactory, TRANSLATION_PARAMS ) {
        // Service logic
        // Public API here
        var factory = {};
        factory.isNricValid = function ( theNric ) {
            var multiples = [ 2, 7, 6, 5, 4, 3, 2 ];
            if ( !theNric || theNric === '' ) {
                return false;
            }
            if ( theNric.length !== 9 ) {
                return false;
            }
            var total = 0,
                count = 0,
                numericNric;
            var first = theNric[ 0 ],
                last = theNric[ theNric.length - 1 ];

            if ( first !== 'S' && first !== 'T' ) {
                return false;
            }
            numericNric = theNric.substr( 1, theNric.length - 2 );
            if ( isNaN( numericNric ) ) {
                return false;
            }
            while ( numericNric !== 0 ) {
                total += ( numericNric % 10 ) * multiples[ multiples.length - ( 1 + count++ ) ];

                numericNric /= 10;
                numericNric = Math.floor( numericNric );
            }
            var outputs;
            if ( first === 'S' ) {
                outputs = [ 'J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A' ];
            } else {
                outputs = [ 'G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H' ];
            }
            return last === outputs[ total % 11 ];
        };

        factory.removeUserCache = function(){
            CacheFactory.get('userCache').remove('user');
        }
        factory.storeUpdateAuthStatus = function(){
            var deferred = $q.defer(),
                auth;
            $q.all( [
                    userFactory.getUser()
                    .then(function (userInfo) {
                        auth = userInfo.data.authentications;
                    })
                    //auth = userdata.data.authentications
                ] )
                .then( function ( result ) {
                    authDocumentFactory.getStatus()
                        .then( function ( resp ) {
                            auth.document_status = resp.data.status;
                            deferred.resolve( {
                                authentications: auth
                            } );
                            store.set( 'auth', auth );
                        } );
                } );
        }

        factory.resetData = function () {
            $rootScope.wallet = {};
            var httpCache = CacheFactory.get( 'walletCache' );
            httpCache.remove( API_BASE + 'users/wallets' );
        };

        factory.resetUser = function () {
            $rootScope.wallet = {};
            var httpCache = CacheFactory.get( 'walletCache' );
            httpCache.remove( API_BASE + 'users' );
            httpCache.remove( API_BASE + 'users/addresses/residential' );
            httpCache.remove( API_BASE + 'users/addresses/billing' );
            httpCache.remove( API_BASE + 'users/notifications' );
        };

        factory.getWalletData = function () {
            var deferred = $q.defer();
            var items;
            factory.resetData();
            $http( {
                    method: 'GET',
                    url: API_BASE + 'users/wallets',
                    cache: true,
                    timeout: 70000
                } )
                .then( function ( data ) {
                    var wallet = data.data,
                        i = 0;
                    wallet.walletBalance = 0;
                    wallet.walletBalance = parseFloat( wallet.funds.available.amount );
                    if ( wallet.hasOwnProperty( 'cards' ) ) {
                        items = wallet.cards.length;
                        for ( i = 0; i < items; i++ ) {
                            wallet.usercards = [];
                            wallet.suspendcards = [];
                            $http.get( wallet.cards[ i ].links[ 0 ].href, {
                                    cache: true,
                                    timeout: 70000
                                } )
                                .then( function ( data ) {
                                    var card = data.data;
                                    wallet.usercards.push( card );
                                    if ( card.status.text === 'locked' ) {
                                        wallet.suspendcards.push( card );
                                    }
                                    if ( i === items ) {
                                        if ( card.funds.available.amount.length ) {
                                            wallet.walletBalance += parseFloat( card.funds.available.amount );
                                        }
                                        $rootScope.wallet = wallet;
                                        return deferred.resolve( wallet );
                                    }
                                }, function ( response ) {
                                    return deferred.reject( response );
                                } );
                        }
                    } else {
                        $rootScope.wallet = wallet;
                        return deferred.resolve( wallet );
                    }
                }, function ( response ) {
                    return deferred.reject( response );
                } );
            return deferred.promise;
        };

        factory.getUserTopupLimits = function () {
            var limits = {};
            var auth = store.get( 'auth' );
            var auth_status = {};
            var deferred = $q.defer();
            if(!CacheFactory.get('walletCache')){
              Wallet.getWallet( false );
            }
            var response = CacheFactory.get('walletCache').get('userWallet');
            if ( auth ) {
                if ( auth.document_status ) {
                    auth_status = auth.document_status;
                }
            }

            if ( auth_status === 'approved' ) {
                limits.maximumAmt = response.details.topup_limits.post_kyc.unit_transaction_limit;
            } else {
                limits.maximumAmt = response.details.topup_limits.pre_kyc.unit_transaction_limit;
            }
            limits.minimumAmt = response.details.min_load_limit;

            deferred.resolve( limits );
            // $http( {
            //         method: 'GET',
            //         url: API_BASE + 'users/wallets',
            //         cache: true,
            //         timeout: 18000
            //     } )
            //     .then( function ( response ) {
            //         var auth = store.get( 'auth' );
            //         var auth_status = {};
            //
            //         if ( auth ) {
            //             if ( auth.document_status ) {
            //                 auth_status = auth.document_status;
            //             }
            //         }
            //
            //         if ( auth_status === 'approved' ) {
            //             limits.maximumAmt = response.data.details.post_kyc_topup_limit;
            //         } else {
            //             limits.maximumAmt = response.data.details.pre_kyc_topup_limit;
            //         }
            //         limits.minimumAmt = response.data.details.min_load_limit;
            //
            //     } );
            return deferred.promise;
        };

        factory.clearCacheNotification = function () {
            var httpCache = CacheFactory.get( 'walletCache' );
            // httpCache.remove(API_BASE + 'users/notifications');
        };

        factory.postTransactionInfoUpdate = function () {
            var httpCache = CacheFactory.get( 'walletCache' );
            httpCache.removeAll();
            httpCache.remove( API_BASE + 'users/wallets' );
            httpCache.remove( API_BASE + 'users/wallets/cards' );
            httpCache.remove( API_BASE + 'users/notifications' );
            httpCache.remove( API_BASE + 'users/wallets/transactions' );
            httpCache.remove( API_BASE + 'users/wallets/funds/transfers' );
        };

        factory.postDetailsInfoUpdate = function () {
            var httpCache = CacheFactory.get( 'walletCache' );
            httpCache.remove( API_BASE + 'users/notifications' );
            httpCache.remove( API_BASE + 'users' );
            httpCache.remove( API_BASE + 'users/wallets' );
            httpCache.remove( API_BASE + 'users/addresses/residential' );
            httpCache.remove( API_BASE + 'users/addresses/billing' );
        };

        factory.clearCacheTransfer = function ( cards ) {
            var i = 0,
                item = null,
                len = 0,
                httpCache = CacheFactory.get( 'walletCache' );
            if ( cards ) {
                len = cards.length;
            }
            for ( i = 0; i < len; i++ ) {
                item = cards[ i ];
                if ( item && item.id ) {
                    httpCache.remove( API_BASE + 'users/wallets/cards/' + item.id + '/transactions' );
                }
            }
            httpCache.remove( API_BASE + 'users/wallets/transactions' );
        };

        factory.updateMinMaxLengthZipcode = function ( country ) {
            var zipcode = {};
            switch ( country ) {
            case 'Singapore':
                zipcode.min_length = 6; // jshint ignore:line
                zipcode.max_length = 6; // jshint ignore:line
                break;
            case 'Philippines':
                zipcode.min_length = 4; // jshint ignore:line
                zipcode.max_length = 4; // jshint ignore:line
                break;
            case 'India':
                zipcode.min_length = 6; // jshint ignore:line
                zipcode.max_length = 6; // jshint ignore:line
                break;
            case 'Indonesia':
                zipcode.min_length = 5; // jshint ignore:line
                zipcode.max_length = 5; // jshint ignore:line
                break;
            case 'Vietnam':
                zipcode.min_length = 6;
                zipcode.max_length = 6;
            default:
                zipcode.min_length = 1; // jshint ignore:line
                zipcode.max_length = 20; // jshint ignore:line
                break;
            }
            return zipcode;
        };

        factory.isDefaultCountry = function ( country ) {
            var result = false;
            if ( country === 'Singapore' ) {
                result = true;
            }
            return result;
        };

        factory.updatePatternPostalCode = function ( country ) {
            var regexp = '';
            switch ( country ) {
                case 'Singapore':
                    regexp = /^\d+$/;
                    break;
                case 'Indonesia':
                    regexp = /^\d{5,5}$/;
                    break;
                case 'Vietnam':
                    regexp = /^\d{6,6}$/;
                    break;
                default:
                // allow only numeric digits in postal code TPB-903 fix
                    regexp = /^[0-9]{4,10}$/;
                    break;
            }
            return regexp;
        };
       factory.updatePatternAddressLines=function (country){
    	   var regexp = '';
           switch ( country ) {
           case 'India':
               regexp = /^.*[a-zA-Z]+.*$/;
               break;
           default:
               regexp = '';
               break;
           }
           return regexp;
       }
        // Check User Agent String For Mobile
        factory.mobileCheck = function () {
            var check = false;
            ( function ( a ) {
                if ( /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test( a ) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test( a.substr( 0, 4 ) ) )
                    check = true
            } )( navigator.userAgent || navigator.vendor || window.opera );
            return check;
        };

        // Check User Agent String For Tablet
        factory.tabletCheck = function () {
            var check = false;
            ( function ( a ) {
                if ( /(android|bb\d+|meego).+avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iris|kindle|lge |maemo|midp|mmp.+firefox|netfront|opera\/|android|ipad|playbook|silk/i.test( a ) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test( a.substr( 0, 4 ) ) )
                    check = true
            } )( navigator.userAgent || navigator.vendor || window.opera );
            return check;
        };


        // Check User Agent String For Both Mobile And Tablet
        factory.mobileAndTabletcheck = function () {
            var check = false;
            ( function ( a ) {
                if ( /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test( a ) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test( a.substr( 0, 4 ) ) )
                    check = true
            } )( navigator.userAgent || navigator.vendor || window.opera );
            return check;
        };

        factory.isMobile = function () {
            if ( navigator.userAgent.match( /Android/i ) || navigator.userAgent.match( /webOS/i ) || navigator.userAgent.match( /iPhone/i ) || navigator.userAgent.match( /iPad/i ) || navigator.userAgent.match( /iPod/i ) || navigator.userAgent.match( /BlackBerry/i ) || navigator.userAgent.match( /Windows Phone/i ) ) {
                return true;
            } else {
                return false;
            }
        };

        factory.getCountryList = function ( level ) {
            var list = {},
                configObj = angular.fromJson( COUNTRY_SUPPORT );
            if ( typeof configObj === 'object' && configObj !== null ) {
                switch ( level ) {
                case 'auth.create':
                    list.defaultCountry = configObj.preKYC.signup.defaultCountry;
                    if ( configObj.preKYC.signup.multicountry ) {
                        list.preferredCountries = configObj.preKYC.signup.preferredCountries;
                        if ( configObj.preKYC.signup.excludeCountries ) {
                            list.excludeCountries = configObj.preKYC.signup.excludeCountries;
                        }
                        if (configObj.preKYC.signup.onlyCountries){
                            list.onlyCountries = configObj.preKYC.signup.onlyCountries;
                        }
                    } else {
                        list.onlyCountries = [];
                        list.onlyCountries.push( configObj.preKYC.signup.defaultCountry );
                    }
                    break;
                case 'wallet.send.select':
                    if ( store.get( 'auth' ) !== null ) {
                        if ( store.get( 'auth' ).document_status === 'approved' ) {
                            list.defaultCountry = configObj.postKYC.transfer.defaultCountry;
                            if ( configObj.postKYC.transfer.multicountry ) {
                                list.preferredCountries = configObj.postKYC.transfer.preferredCountries;
                                if ( configObj.postKYC.transfer.excludeCountries ) {
                                    list.excludeCountries = configObj.postKYC.transfer.excludeCountries;
                                }
                                if (configObj.postKYC.transfer.onlyCountries){
                                    list.onlyCountries = configObj.postKYC.transfer.onlyCountries;
                                }
                            } else {
                                list.onlyCountries = [];
                                list.onlyCountries.push( configObj.postKYC.transfer.defaultCountry );
                            }
                        } else {
                            list.defaultCountry = configObj.preKYC.transfer.defaultCountry;
                            if ( configObj.preKYC.transfer.multicountry ) {
                                list.preferredCountries = configObj.preKYC.transfer.preferredCountries;
                                if ( configObj.preKYC.transfer.excludeCountries ) {
                                    list.excludeCountries = configObj.preKYC.transfer.excludeCountries;
                                }
                                if (configObj.preKYC.transfer.onlyCountries){
                                    list.onlyCountries = configObj.preKYC.transfer.onlyCountries;
                                }
                            } else {
                                list.onlyCountries = [];
                                list.onlyCountries.push( configObj.preKYC.transfer.defaultCountry );
                            }
                        }
                    } else {
                        list.defaultCountry = configObj.preKYC.transfer.defaultCountry;
                        if ( configObj.preKYC.transfer.multicountry ) {
                            list.preferredCountries = configObj.preKYC.transfer.preferredCountries;
                            if ( configObj.preKYC.transfer.excludeCountries ) {
                                list.excludeCountries = configObj.preKYC.transfer.excludeCountries;
                            }
                            if (configObj.preKYC.transfer.onlyCountries){
                                list.onlyCountries = configObj.preKYC.transfer.onlyCountries;
                            }
                        } else {
                            list.onlyCountries = [];
                            list.onlyCountries.push( configObj.preKYC.transfer.defaultCountry );
                        }
                    }
                    break;
                case 'wallet.details.my.complete':
                case 'wallet.details.my.list':
                    if ( store.get( 'auth' ) !== null ) {
                        if ( store.get( 'auth' ).document_status === 'approved' ) {
                            list.defaultCountry = configObj.postKYC.details.defaultCountry;
                            if ( configObj.postKYC.details.multicountry ) {
                                list.preferredCountries = configObj.postKYC.details.preferredCountries;
                                if ( configObj.postKYC.details.excludeCountries ) {
                                    list.excludeCountries = configObj.postKYC.details.excludeCountries;
                                }
                                if (configObj.postKYC.details.onlyCountries){
                                    list.onlyCountries = configObj.postKYC.details.onlyCountries;
                                }
                            } else {
                                list.onlyCountries = [];
                                list.onlyCountries.push( configObj.postKYC.transfer.defaultCountry );
                            }
                        } else {
                            list.defaultCountry = configObj.preKYC.details.defaultCountry;
                            if ( configObj.preKYC.details.multicountry ) {
                                list.preferredCountries = configObj.preKYC.details.preferredCountries;
                                if ( configObj.preKYC.details.excludeCountries ) {
                                    list.excludeCountries = configObj.preKYC.details.excludeCountries;
                                }
                                if (configObj.preKYC.details.onlyCountries){
                                    list.onlyCountries = configObj.preKYC.details.onlyCountries;
                                }
                            } else {
                                list.onlyCountries = [];
                                list.onlyCountries.push( configObj.preKYC.details.defaultCountry );
                            }
                        }
                    } else {
                        list.defaultCountry = configObj.preKYC.details.defaultCountry;
                        if ( configObj.preKYC.details.multicountry ) {
                            list.preferredCountries = configObj.preKYC.details.preferredCountries;
                            if ( configObj.preKYC.details.excludeCountries ) {
                                list.exclude = configObj.preKYC.details.excludeCountries;
                            }
                            if (configObj.preKYC.details.onlyCountries){
                                list.onlyCountries = configObj.preKYC.details.onlyCountries;
                            }
                        } else {
                            list.onlyCountries = [];
                            list.onlyCountries.push( configObj.preKYC.details.defaultCountry );
                        }
                    }
                    break;
                }
            }
            return list;
        };

        factory.mapControllerToPageTitle = function ( statename ) {
            var returnKey;
            switch ( statename ) {
                case 'auth':
                    returnKey = 'PAGE_TITLE.FOR.AUTH';
                    break;
                case 'auth.create':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_CREATE';
                    break;
                case 'auth.email':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_EMAIL';
                    break;
                case 'auth.email.activate':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_EMAIL_ACTIVATE';
                    break;
                case 'auth.login':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_LOGIN';
                    break;
                case 'auth.password':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_PASSWORD';
                    break;
                case 'auth.password.change':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_PASSWORD_CHANGE';
                    break;
                case 'auth.password.create':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_PASSWORD_CREATE';
                    break;
                case 'auth.password.forgot':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_PASSWORD_FORGOT';
                    break;
                case 'auth.password.recover':
                    returnKey = 'PAGE_TITLE.FOR.AUTH_PASSWORD_RECOVER';
                    break;
                case 'wallet':
                    returnKey = 'PAGE_TITLE.FOR.WALLET';
                    break;
                case 'wallet.card':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_CARD';
                    break;
                case 'wallet.card.new':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_CARD_NEW';
                    break;
                case 'wallet.details':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_DETAILS';
                    break;
                case 'wallet.details.my.complete':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_DETAILS_COMPLETE';
                    break;
                case 'wallet.details.my.list':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_DETAILS_LIST';
                    break;
                case 'wallet.fund':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_FUND';
                    break;
                case 'wallet.fund.claim':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_FUND_CLAIM';
                    break;
                case 'wallet.home':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_HOME';
                    break;
                case 'wallet.loyalty':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_LOYALTY';
                    break;
                case 'wallet.loyalty.list':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_LOYALTY_LIST';
                    break;
                case 'wallet.notification':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_NOTIFICATION';
                    break;
                case 'wallet.offers':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_OFFERS';
                    break;
                case 'wallet.offers.detail':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_OFFERS_DETAIL';
                    break;
                case 'wallet.offers.list':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_OFFERS_LIST';
                    break;
                case 'wallet.remit':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_REMIT';
                    break;
                case 'wallet.remit.confirm':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_REMIT_CONFIRM';
                    break;
                case 'wallet.remit.enter':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_REMIT_ENTER';
                    break;
                case 'wallet.remit.select':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_REMIT_SELECT';
                    break;
                case 'wallet.remit.summary':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_REMIT_SUMMARY';
                    break;
                case 'wallet.send':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_SEND';
                    break;
                case 'wallet.send.select':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_SEND_SELECT';
                    break;
                case 'wallet.send.success':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_SEND_SUCCESS';
                    break;
                case 'wallet.suspend':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_SUSPEND';
                    break;
                case 'wallet.topup':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_TOPUP';
                    break;
                case 'wallet.topup.enter':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_TOPUP_ENTER';
                    break;
                case 'wallet.topup.select':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_TOPUP_SELECT';
                    break;
                case 'wallet.topup.success':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_TOPUP_SUCCESS';
                    break;
                case 'wallet.transaction':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_TRANSACTION';
                    break;
                case 'wallet.verification':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_VERIFICATION';
                    break;
                case 'wallet.verification.upload':
                    returnKey = 'PAGE_TITLE.FOR.WALLET_VERIFICATION_UPLOAD';
                    break;
                default:
                    returnKey = 'PAGE_TITLE.FOR.HOME'
                    break;
            }
            return returnKey;
        }

        return factory;
    } );
