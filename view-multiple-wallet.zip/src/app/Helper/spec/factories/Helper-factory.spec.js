'use strict';

describe( 'Factory: helperFactory - No support for multi country', function() {
    var helper,
        API_BASE,
        httpBackend,
        $scope,
        $cacheFactory,
        $rootScope,
        country,
        pattern,
        walletInfo,
        COUNTRY_SUPPORT,
        cardInfo,
        store,
        wallet;
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( "COUNTRY_SUPPORT", {
            "preKYC": {
                "signup": {
                    "multicountry": false,
                    "defaultCountry": "sg"
                },
                "transfer": {
                    "multicountry": false,
                    "defaultCountry": "sg"
                },
                "details": {
                    "multicountry": false,
                    "defaultCountry": "sg"
                }
            },
            "postKYC": {
                "transfer": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                },
                "details": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                }
            }
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    //  Initialize the factory and a mock rootScope
    beforeEach( inject( function( _helperFactory_, _API_BASE_, _$rootScope_, _CacheFactory_, _COUNTRY_SUPPORT_, _store_, _Wallet_ ) {
        helper = _helperFactory_;
        API_BASE = _API_BASE_;
        COUNTRY_SUPPORT = _COUNTRY_SUPPORT_;
        store = _store_;
        $rootScope = _$rootScope_;
        $rootScope.wallet = {};
        $cacheFactory = _CacheFactory_;
        wallet = _Wallet_;
        $rootScope.globals = {};
        $rootScope.globals.currentUser = {};
        $rootScope.globals.currentUser.authdata = '';
        walletInfo = angular.toJson( {
            "funds": {
                "withholding": {
                    "currency": "SGD",
                    "amount": "20.00"
                },
                "available": {
                    "currency": "SGD",
                    "amount": "165.00"
                }
            },
            "id": "dfa7916f06e9640daeb0bbe413012659",
            "number": "6377020000009969",
            "holder": {
                "name": "Balaji"
            },
            "date": {
                "expiry": "2024-03",
                "issued": "2015-12-15"
            },
            "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
            },
            "status": {
                "is_active": true,
                "text": "active"
            },
            "kyc_status": "approved",
            "details": {
              "min_load_limit": 1,
              "max_load_limit": 999,
              "network_type": "mastercard",
              "fee": 0,
              "topup_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 23,
                  "lifetime_transactional": 2370,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 0,
                  "weekly_transactional": 0,
                  "monthly_count": 6,
                  "monthly_transactional": 60
                }
              },
              "deduct_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 0,
                  "lifetime_transactional": 0,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 0,
                  "weekly_transactional": 0,
                  "monthly_count": 0,
                  "monthly_transactional": 0
                }
              },
              "transfer_in_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 15,
                  "lifetime_transactional": 167,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 0,
                  "weekly_transactional": 0,
                  "monthly_count": 0,
                  "monthly_transactional": 0
                }
              },
              "transfer_out_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 116,
                  "lifetime_transactional": 1752.19,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 32,
                  "weekly_transactional": 32,
                  "monthly_count": 32,
                  "monthly_transactional": 32
                }
              },
              "load_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 84,
                  "lifetime_transactional": 637.42,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 0,
                  "weekly_transactional": 0,
                  "monthly_count": 2,
                  "monthly_transactional": 20
                }
              },
              "unload_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 43,
                  "lifetime_transactional": 308.2,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 0,
                  "weekly_transactional": 0,
                  "monthly_count": 2,
                  "monthly_transactional": 20
                }
              },
              "remittance_limits": {
                "pre_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 500
                },
                "post_kyc": {
                  "allowed": 1,
                  "lifetime_count_limit": null,
                  "lifetime_transactional_limit": 999999999999,
                  "daily_count_limit": null,
                  "daily_transactional_limit": null,
                  "weekly_count_limit": null,
                  "weekly_transactional_limit": null,
                  "monthly_count_limit": null,
                  "monthly_transactional_limit": null,
                  "unit_transaction_limit": 999
                },
                "current": {
                  "lifetime_count": 54,
                  "lifetime_transactional": 1593.99,
                  "daily_count": 0,
                  "daily_transactional": 0,
                  "weekly_count": 0,
                  "weekly_transactional": 0,
                  "monthly_count": 0,
                  "monthly_transactional": 0
                }
              }
            },
            "cards": [ {
                "id": "25302c8a90917740e0fc6057113bb70f",
                "type": [ {
                    "rel": "self",
                    "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                    "method": "GET"
                } ],
                "links": [ {
                    "rel": "self",
                    "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f",
                    "method": "GET"
                } ]
            } ]
        } );
        cardInfo = angular.toJson( {
            "id": "25302c8a90917740e0fc6057113bb70f",
            "number": "5363950000213401",
            "holder": {
                "name": "Balaji"
            },
            "funds": {
                "available": {
                    "currency": "SGD",
                    "amount": "0.00"
                }
            },
            "type": {
                "type": "mcmmgpcard",
                "name": "MatchMove Physical Card",
                "description": "Matchmove Physical Card",
                "code_type": "Physical Card"
            },
            "date": {
                "expiry": "2020-12",
                "issued": "2016-01-05"
            },
            "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
            },
            "status": {
                "is_active": false,
                "text": "locked"
            },
            "links": [ {
                "rel": "securities.tokens",
                "href": "",
                "method": "GET"
            } ],
            "activation_code": "967209"
        } );
        httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletInfo );
        httpBackend.whenGET( API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f" ).respond( 200, cardInfo );
        httpBackend.whenGET( API_BASE + "users/wallets/cards/types/mcmmgpcard" ).respond( 200, '' );
        httpBackend.flush();
    } ) );
    afterEach( function() {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'should have helper be defined', function() {
        expect( helper ).toBeDefined();
    } );

    describe( 'check NRIC', function() {
        var nric;
        it( 'should return false if nric input is blank or null', function() {
            nric = '';
            expect( nric ).toEqual( '' );
            expect( helper.isNricValid( nric ) ).toBeFalsy();
        } );
        it( 'should return false if nric input is less than 9 characters', function() {
            nric = 'abcd1234';
            expect( nric.length ).toBeLessThan( 9 );
            expect( helper.isNricValid( nric ) ).toBeFalsy();
        } );
        it( 'should return false if first character in nric input is not "S" and "T"', function() {
            nric = 'abcd12345';
            var first = nric[ 0 ].toUpperCase();
            expect( first ).not.toEqual( 'S' );
            expect( first ).not.toEqual( 'T' );
        } );
        it( 'should return false if string input from character 2 to 8 is not a number', function() {
            nric = 'abcd12345';
            var str = nric.substr( 1, nric.length - 2 );
            expect( str ).not.toEqual( jasmine.any( Number ) );
        } );
        it( 'should return true if nric input is correct validation', function() {
            nric = 'S6247285E';
            expect( helper.isNricValid( nric ) ).toBeTruthy();
        } );
        it( 'should return false for first letter not S/T', function() {
            nric = 'Z6247285E';
            var validity = helper.isNricValid( nric );
            expect( validity ).toBeFalsy();
        } );
        it( 'should return false for NAN numeric', function() {
            nric = 'WZABCDEFE';
            var validity = helper.isNricValid( nric );
            expect( validity ).toBeFalsy();
        } );
    } );

    describe( 'clear cached data of user wallet', function() {
        it( 'cache of user wallet should be removed', function() {
            var key = API_BASE + 'users/wallets';
            helper.resetData();
            expect( $cacheFactory.get( key ) ).toBeUndefined();
        } );
    } );

    describe( 'reset user', function() {
        it( 'cache of user wallet should be removed', function() {
            helper.resetUser();
            expect( $cacheFactory.get( API_BASE + 'users/addresses/residential' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/addresses/billing' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/notifications' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users' ) ).toBeUndefined();
        } );
    } );

    describe( 'get data wallet', function() {
        it( 'should have a response status after get wallet info', function() {
            helper.getWalletData().then( function( response ) {
                expect( response.funds ).toBeDefined();
            } );
            httpBackend.flush();
        } );
        it( 'should have available amount in wallet', function() {
            helper.getWalletData().then( function( response ) {
                expect( response.funds.available.amount ).toBe( '165.00' );
                expect( response.status.text ).toBe( 'active' );
            } );
            httpBackend.flush();
        } );
    } );
    describe( 'clear Cache Notification', function() {
        it( 'cache of notifications should be removed', function() {
            helper.clearCacheNotification();
            expect( $cacheFactory.get( API_BASE + 'users/notifications' ) ).toBeUndefined();
        } );
    } );

    describe( 'post Transaction Info Update', function() {
        it( 'cache of notification, wallet and wallet transaction should be removed', function() {
            helper.postTransactionInfoUpdate();
            expect( $cacheFactory.get( API_BASE + 'users/wallets' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/wallets/cards' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/notifications' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/wallets/transactions' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/wallets/funds/transfers' ) ).toBeUndefined();
        } );
    } );

    describe( 'post Details Info Update', function() {
        it( 'cache of notification, wallet and addresses transaction should be removed', function() {
            helper.postDetailsInfoUpdate();
            expect( $cacheFactory.get( API_BASE + 'users/notifications' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/wallets' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/addresses/residential' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/addresses/billing' ) ).toBeUndefined();
        } );
    } );

    describe( 'Clear Cache After Transfer', function() {
        it( 'cache of transfer and claim, transaction history should be removed', function() {
            helper.clearCacheTransfer( [ {
                id: '1'
            }, {
                id: '2'
            } ] );
            expect( $cacheFactory.get( API_BASE + 'users/wallets/transactions' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/wallets/cards/1/transactions' ) ).toBeUndefined();
            expect( $cacheFactory.get( API_BASE + 'users/wallets/cards/2/transactions' ) ).toBeUndefined();
        } );
    } );

    describe( 'update min length and max length of zipcode', function() {
        var country;
        it( 'min_length = 0 and max_length = 100 if country is not Singapore', function() {
            country = '';
            expect( helper.updateMinMaxLengthZipcode( country ) ).toEqual( {
                'min_length': 1,
                'max_length': 20
            } );
            country = 'Vietnam';
            expect( helper.updateMinMaxLengthZipcode( country ) ).toEqual( {
                'min_length': 1,
                'max_length': 20
            } );
        } );

        it( 'min_length = 6 and max_length = 6 if country is Singapore', function() {
            country = 'Singapore';
            expect( helper.updateMinMaxLengthZipcode( country ) ).toEqual( {
                'min_length': 6,
                'max_length': 6
            } );
        } );
    } );
    describe( 'Postal code pattern', function() {
        beforeEach( inject( function() {
            spyOn( helper, 'updatePatternPostalCode' ).and.callThrough();
        } ) );

        it( 'Pattern for SG should allow only numbers', function() {
            country = 'Singapore';
            pattern = helper.updatePatternPostalCode( country );
            expect( pattern ).toEqual( /^\d+$/ );
        } );
        it( 'Other countries to allow alpha-numeric values', function() {
            country = 'India';
            pattern = helper.updatePatternPostalCode( country );
            expect( pattern ).toEqual( /^[0-9]{4,10}$/ );
        } );
    } );
    describe( 'Get country list from config json', function() {
        describe( 'multicountry NOT supported', function() {
            it( 'level: auth.create', function() {
                var level = 'auth.create';
                var list = helper.getCountryList( level );
                expect( list.onlyCountries ).toBeDefined();
            } );
            describe( 'Pre KYC', function() {
                beforeEach( inject( function( store ) {
                    store.set( 'auth', {
                        document_status: 'not_submitted'
                    } );
                } ) );
                afterEach( function() {
                    store.remove( 'auth' );
                } );
                it( 'level: wallet.send.select', function() {
                    var level = 'wallet.send.select';
                    var list = helper.getCountryList( level );
                    expect( list.onlyCountries ).toBeDefined();
                } );
                it( 'level: wallet.details.my.list', function() {
                    var level = 'wallet.details.my.list';
                    var list = helper.getCountryList( level );
                    expect( list.onlyCountries ).toBeDefined();
                } );
            } );
            describe( 'KYC approved', function() {
                beforeEach( inject( function( store ) {
                    store.set( 'auth', {
                        document_status: 'approved'
                    } );
                } ) );
                afterEach( function() {
                    store.remove( 'auth' );
                } );
                it( 'level: wallet.send.select', function() {
                    var level = 'wallet.send.select';
                    var list = helper.getCountryList( level );
                    expect( list.preferredCountries ).toBeDefined();
                } );
                it( 'level: wallet.details.my.list', function() {
                    var level = 'wallet.details.my.list';
                    var list = helper.getCountryList( level );
                    expect( list.preferredCountries ).toBeDefined();
                } );
            } );
        } );
    } );
    describe( 'getUserTopupLimits', function() {
      beforeEach( inject( function( store ) {
          store.set( 'auth', {
              document_status: 'approved'
          } );
          spyOn(wallet, 'getWallet');
          spyOn($cacheFactory, 'get').and.callFake(function(){
            return {
              get: function(callback){
                return angular.fromJson(walletInfo);
              }
            };
          });
      } ) );
      afterEach( function() {
          store.remove( 'auth' );
      } );
        it( 'return an object with maximumAmt and minimumAmt', function() {
            helper.getUserTopupLimits().then( function( response ) {
                expect( response ).toBeDefined();
                expect( response.maximumAmt ).toBeDefined();
                expect( response.minimumAmt ).toBeDefined();
                expect( response.minimumAmt ).toBe( 1 );
                expect( response.maximumAmt ).toBe( 999 );
            } );
        } );
    } );
    describe( 'Check User Agent String For Mobile', function() {
        it( 'return an object with maximumAmt and minimumAmt', function() {

        } );
    } );
    describe( 'Fn mapControllerToPageTitle', function() {
        it( 'statename : auth', function() {
            var statename = 'auth';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH' );
        } );
        it( 'statename : auth.create', function() {
            var statename = 'auth.create';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_CREATE' );
        } );
        it( 'statename : auth.email', function() {
            var statename = 'auth.email';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_EMAIL' );
        } );
        it( 'statename : auth.email.activate', function() {
            var statename = 'auth.email.activate';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_EMAIL_ACTIVATE' );
        } );
        it( 'statename : auth.login', function() {
            var statename = 'auth.login';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_LOGIN' );
        } );
        it( 'statename : auth.password', function() {
            var statename = 'auth.password';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_PASSWORD' );
        } );
        it( 'statename : auth.password.change', function() {
            var statename = 'auth.password.change';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_PASSWORD_CHANGE' );
        } );
        it( 'statename : auth.password.create', function() {
            var statename = 'auth.password.create';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_PASSWORD_CREATE' );
        } );
        it( 'statename : auth.password.forgot', function() {
            var statename = 'auth.password.forgot';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_PASSWORD_FORGOT' );
        } );
        it( 'statename : auth.password.recover', function() {
            var statename = 'auth.password.recover';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.AUTH_PASSWORD_RECOVER' );
        } );
        it( 'statename : wallet', function() {
            var statename = 'wallet';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET' );
        } );
        it( 'statename : wallet.card', function() {
            var statename = 'wallet.card';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_CARD' );
        } );
        it( 'statename : wallet.card.new', function() {
            var statename = 'wallet.card.new';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_CARD_NEW' );
        } );
        it( 'statename : wallet.details', function() {
            var statename = 'wallet.details';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_DETAILS' );
        } );
        it( 'statename : wallet.details.my.complete', function() {
            var statename = 'wallet.details.my.complete';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_DETAILS_COMPLETE' );
        } );
        it( 'statename : wallet.details.my.list', function() {
            var statename = 'wallet.details.my.list';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_DETAILS_LIST' );
        } );
        it( 'statename : wallet.fund', function() {
            var statename = 'wallet.fund';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_FUND' );
        } );
        it( 'statename : wallet.fund.claim', function() {
            var statename = 'wallet.fund.claim';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_FUND_CLAIM' );
        } );
        it( 'statename : wallet.home', function() {
            var statename = 'wallet.home';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_HOME' );
        } );
        it( 'statename : wallet.loyalty', function() {
            var statename = 'wallet.loyalty';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_LOYALTY' );
        } );
        it( 'statename : wallet.loyalty.list', function() {
            var statename = 'wallet.loyalty.list';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_LOYALTY_LIST' );
        } );
        it( 'statename : wallet.notification', function() {
            var statename = 'wallet.notification';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_NOTIFICATION' );
        } );
        it( 'statename : wallet.offers', function() {
            var statename = 'wallet.offers';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_OFFERS' );
        } );
        it( 'statename : wallet.offers.detail', function() {
            var statename = 'wallet.offers.detail';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_OFFERS_DETAIL' );
        } );
        it( 'statename : wallet.offers.list', function() {
            var statename = 'wallet.offers.list';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_OFFERS_LIST' );
        } );
        it( 'statename : wallet.remit', function() {
            var statename = 'wallet.remit';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_REMIT' );
        } );
        it( 'statename : wallet.remit.confirm', function() {
            var statename = 'wallet.remit.confirm';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_REMIT_CONFIRM' );
        } );
        it( 'statename : wallet.remit.enter', function() {
            var statename = 'wallet.remit.enter';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_REMIT_ENTER' );
        } );
        it( 'statename : wallet.remit.select', function() {
            var statename = 'wallet.remit.select';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_REMIT_SELECT' );
        } );
        it( 'statename : wallet.remit.summary', function() {
            var statename = 'wallet.remit.summary';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_REMIT_SUMMARY' );
        } );
        it( 'statename : wallet.send', function() {
            var statename = 'wallet.send';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_SEND' );
        } );
        it( 'statename : wallet.send.select', function() {
            var statename = 'wallet.send.select';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_SEND_SELECT' );
        } );
        it( 'statename : wallet.send.success', function() {
            var statename = 'wallet.send.success';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_SEND_SUCCESS' );
        } );
        it( 'statename : wallet.suspend', function() {
            var statename = 'wallet.suspend';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_SUSPEND' );
        } );
        it( 'statename : wallet.topup', function() {
            var statename = 'wallet.topup';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_TOPUP' );
        } );
        it( 'statename : wallet.topup.enter', function() {
            var statename = 'wallet.topup.enter';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_TOPUP_ENTER' );
        } );
        it( 'statename : wallet.topup.select', function() {
            var statename = 'wallet.topup.select';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_TOPUP_SELECT' );
        } );
        it( 'statename : wallet.topup.success', function() {
            var statename = 'wallet.topup.success';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_TOPUP_SUCCESS' );
        } );
        it( 'statename : wallet.transaction', function() {
            var statename = 'wallet.transaction';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_TRANSACTION' );
        } );
        it( 'statename : wallet.verification', function() {
            var statename = 'wallet.verification';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_VERIFICATION' );
        } );
        it( 'statename : wallet.verification.upload', function() {
            var statename = 'wallet.verification.upload';
            var ret = helper.mapControllerToPageTitle( statename );
            expect( ret ).toBe( 'PAGE_TITLE.FOR.WALLET_VERIFICATION_UPLOAD' );
        } );
        it( 'statename : default', function() {
            var ret = helper.mapControllerToPageTitle();
            expect( ret ).toBe( 'PAGE_TITLE.FOR.HOME' );
        } );
    } );
} );

describe('Factory Helper: With Multicountry support', function(){
    var helper,
        API_BASE,
        httpBackend,
        COUNTRY_SUPPORT,
        store;
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( "COUNTRY_SUPPORT", {
            "preKYC": {
                "signup": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                },
                "transfer": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                },
                "details": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                }
            },
            "postKYC": {
                "transfer": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                },
                "details": {
                    "multicountry": true,
                    "defaultCountry": "sg",
                    "preferredCountries": [ "sg", "ph", "vn", "th" ],
                    "excludeCountries": [ "AF", "KP", "IR", "IQ" ]
                }
            }
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    //  Initialize the factory and a mock rootScope
    beforeEach( inject( function( _helperFactory_, _API_BASE_, _$rootScope_, _CacheFactory_, _COUNTRY_SUPPORT_, _store_ ) {
        helper = _helperFactory_;
        API_BASE = _API_BASE_;
        COUNTRY_SUPPORT = _COUNTRY_SUPPORT_;
        store = _store_;
    }));
    describe( 'auth is not set', function() {
        beforeEach( inject( function( store ) {
            store.set( 'auth', null );
        } ) );
        afterEach( function() {
            store.remove( 'auth' );
        } );
        it( 'level: wallet.send.select', function() {
            var level = 'wallet.send.select';
            var list = helper.getCountryList( level );
            expect( list.excludeCountries ).toBeDefined();
        } );
        it( 'level: wallet.details.my.list', function() {
            var level = 'wallet.details.my.list';
            var list = helper.getCountryList( level );
            expect( list.exclude ).toBeDefined();
        } );
    } );
    it( 'level: auth.create', function() {
        var level = 'auth.create';
        var list = helper.getCountryList( level );
        expect( list.excludeCountries ).toBeDefined();
    } );
    describe( 'Pre KYC', function() {
        beforeEach( inject( function( store ) {
            store.set( 'auth', {
                document_status: 'not_submitted'
            } );
        } ) );
        afterEach( function() {
            store.remove( 'auth' );
        } );
        it( 'level: wallet.send.select', function() {
            var level = 'wallet.send.select';
            var list = helper.getCountryList( level );
            expect( list.excludeCountries ).toBeDefined();
        } );
        it( 'level: wallet.details.my.list', function() {
            var level = 'wallet.details.my.list';
            var list = helper.getCountryList( level );
            expect( list.excludeCountries ).toBeDefined();
        } );
    } );
});
