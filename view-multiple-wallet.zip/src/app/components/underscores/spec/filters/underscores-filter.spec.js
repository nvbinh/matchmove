'use strict';

describe('Filter: underscores', function () {
// load the filter's module
  beforeEach(module('viewMultipleWallet'));
// initialize a new instance of the filter before each test
  var underscores;
  beforeEach(inject(function ($filter) {
    underscores = $filter('underscores');
  }));
  it('underscores filter  should replace space in between', function () {
    var text = 'Text in Middle';
    expect(underscores(text)).toBe('Text_in_Middle');
  });
  it('underscores filter  should replace space in start', function () {
    var text = ' Text in Middle';
    expect(underscores(text)).toBe('_Text_in_Middle');
  });
  it('underscores filter  should replace space at end', function () {
    var text = 'Text in Middle ';
    expect(underscores(text)).toBe('Text_in_Middle_');
  });
  it('underscores filter  should replace double space in middle', function () {
    var text = 'Text  in Middle';
    expect(underscores(text)).toBe('Text__in_Middle');
  });
  it('underscores filter  should replace double space in start', function () {
    var text = '  Text in Middle';
    expect(underscores(text)).toBe('__Text_in_Middle');
  });
  it('underscores filter  should replace double space at end', function () {
    var text = 'Text in Middle  ';
    expect(underscores(text)).toBe('Text_in_Middle__');
  });
});
