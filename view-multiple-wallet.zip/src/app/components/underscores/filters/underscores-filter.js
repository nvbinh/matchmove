'use strict';
/**
 * @ngdoc filter
 * @name viewMultipleWallet.filter:underscores
 * @function
 * @description
 * # underscores
 * Filter in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .filter('underscores', function () {
    return function (input) {
      if(!input) {
    		return '';
    	}
      return input.replace(/ /g, '_');
    };
  });
