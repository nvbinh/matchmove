'use strict';

describe('Controller: passwordChangeCtrl Auth with New password Success Scenarios', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));

  var passwordChangeCtrl,
      scope,
      authPasswordFactory,
      HTTP_HOST,
      EMAIL_VERIFICATION_URL,
      timeout,
      httpBackend,
      store,
      email,
      changePassForm,
      authenticationFactory,
      userFactory;

  // mocking the authenticationFactory, userFactory and state services with mock return values
  beforeEach(inject(function(_authPasswordFactory_, $q, _authenticationFactory_, _userFactory_){
    authPasswordFactory = _authPasswordFactory_;
    authenticationFactory = _authenticationFactory_;
    userFactory = _userFactory_;
    
    authPasswordFactory.getToken = function(){
      var deferred = $q.defer();
      deferred.resolve({data:{status:'success', token: '84cc4badd7ab59f4f7ba3e9eb7cdcaeb'}});
      return deferred.promise;
    };
  
    authPasswordFactory.getTokenError = function(){
      var deferred = $q.defer();
      return $q.reject({status: 500});
    };
    
    authPasswordFactory.verifyToken = function(){
      var deferred = $q.defer();
      deferred.resolve({data:{status: 'success'}});
      return deferred.promise;
    };
    
   })); 

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, _authPasswordFactory_, $rootScope, $httpBackend, _HTTP_HOST_, _EMAIL_VERIFICATION_URL_, _$timeout_, store, $q) {
    scope = $rootScope.$new();
    store = {
      get: function(value) {
        return email;
      }
    };
    passwordChangeCtrl = $controller('passwordChangeCtrl', {
      $scope: scope,
      store: store
    });
    httpBackend = $httpBackend;
    HTTP_HOST = _HTTP_HOST_;
    EMAIL_VERIFICATION_URL = _EMAIL_VERIFICATION_URL_;
    timeout = _$timeout_;

    authPasswordFactory = _authPasswordFactory_;
  }));

  afterEach(function() {
    //httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

  describe('changePassword', function(){
    beforeEach(inject(function() {
      email = 'khoi@matchmove.com';
    }));

    it ('- initialize message box should be undefined', function () {
      expect(scope.messageText).not.toBeDefined();
      expect(scope.messageIcon).not.toBeDefined();
      expect(scope.messageType).not.toBeDefined();
      expect(scope.turnonFlag).not.toBeDefined();
    });

    it ('- password field should be blank when popup form open', function() {
      expect(scope.password).toEqual('');
    });

    it ('- authPasswordFactory was called correctly', function () {
      scope.changePassword();
      spyOn(authPasswordFactory, 'getToken').and.callThrough();
      spyOn(authPasswordFactory, 'verifyToken').and.callThrough();
    });

    it('- getToken erorr handled correctly', function () {
      authPasswordFactory.getToken().then(function(){
       
      }, function(error){
        expect(error).toEqual({status: 500});
        expect(scope.messageIcon).toEqual('mcw-common-alert');
        expect(scope.messageType).toEqual('error');
        expect(scope.turnonFlag).toBeTruthy();
      });    
    });

    it('- verifyToken erorr handled correctly', function () {
      authPasswordFactory.verifyToken().then(function(){
       
      }, function(error){
        expect(error).toEqual({status: 500});
        expect(scope.messageIcon).toEqual('mcw-common-alert');
        expect(scope.messageType).toEqual('error');
        expect(scope.turnonFlag).toBeTruthy();
      });    
    });

    it('- show success message when verify token correctly', function () {
      authPasswordFactory.getToken().then(function (data, status, headers, config) {  
        authPasswordFactory.verifyToken().then(function (data, status, headers, config) {
          expect(scope.messageIcon).toEqual('mcw-common-congratulations');
          expect(scope.messageType).toEqual('success');
          expect(scope.turnonFlag).toBeTruthy();
        });
      });
    });
  });
  describe('Controller: passwordChangeCtrl call the method authWithNewPassword', function() {
    beforeEach(inject(function($q) {
      var data = {};
      data.data = {};
      data.data.key = '';
      data.data.secret = '';
      var response = {};
      response.data = {};
      response.data.id = '';
      response.data.date = {};
      response.data.date.registration = {};
      response.data.mobile = {};
      response.data.mobile.country_code = '';
      response.data.mobile.number = '';
      response.data.name = {};
      response.data.name.first = '';
      
      spyOn(authenticationFactory, 'Login').and.callFake(function() {
        return {
          then: function(callback) { return callback(data); }
        };
      });
      spyOn(authenticationFactory, 'SetCredentials').and.callFake(function() { return true; });
      spyOn(userFactory, 'getUser').and.callFake(function() {
        return {
          then: function(callback) { return callback(response); }
        };
      });
      spyOn(userFactory, 'setCurrentUser').and.callFake(function() { return true; });

      scope.authWithNewPassword('');
    }));

    it('Do authentication with new password', function () {
      expect(authenticationFactory.Login).toHaveBeenCalled();
      expect(authenticationFactory.SetCredentials).toHaveBeenCalled();
      expect(userFactory.getUser).toHaveBeenCalled();
      expect(userFactory.setCurrentUser).toHaveBeenCalled();
    });
  });
});

describe('Controller: passwordChangeCtrl Auth with New password Error Scenarios', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var passwordChangeCtrl,
      scope,
      authPasswordFactory,
      HTTP_HOST,
      EMAIL_VERIFICATION_URL,
      httpBackend,
      store,
      email,
      userFactory,
      rootScope,
      authFactory,
      API_BASE,
      userInfo,
      authInfo,
      q;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, _authPasswordFactory_, $rootScope, _HTTP_HOST_, _EMAIL_VERIFICATION_URL_, $q, _authenticationFactory_, _userFactory_, _API_BASE_, _store_) {
    scope = $rootScope.$new();
    store = _store_;
    HTTP_HOST = _HTTP_HOST_;
    EMAIL_VERIFICATION_URL = _EMAIL_VERIFICATION_URL_;
    authPasswordFactory = _authPasswordFactory_;
    authFactory = _authenticationFactory_;
    userFactory = _userFactory_;
    q = $q;
    API_BASE = _API_BASE_;

    passwordChangeCtrl = $controller('passwordChangeCtrl', {
      $scope: scope
    });

    userInfo = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "birthday": "1998-01-05",
          "gender": "male",
          "title": "Mr",
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            },
            {
              "rel": "addresses.residential",
              "href": API_BASE + "users/addresses/residential",
              "method": "GET"
            },
            {
              "rel": "addresses.billing",
              "href": API_BASE + "users/addresses/billing",
              "method": "GET"
            }
          ],
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2015-12-15T16:26:17+08:00"
          },
          "authentications": {
            "email_verified": true,
            "mobile_verified": true
          },
          "login_info": {
            "logins": 252,
            "last_login": "2016-02-23T11:56:07+08:00"
          }
        };
    store.set('user', userInfo);

    authInfo = {
      "key": "NjA5MjJlODY5ZGVmNTI2NTNjMGFjNGNkN2M3ODIzNzA",
      "secret": "NGQ5ZTViZjNmZWI5NzcwY2ViNjgzYmUzYzM0MzFiMDhmY2MyMGYyZTM5YWMyYWI2Y2JjYzhmZjU3YTJhMzNiZQ"
    };
    spyOn(authFactory, 'Login').and.callThrough();
    spyOn(authFactory, 'SetCredentials').and.callThrough();
    spyOn(userFactory, 'setCurrentUser').and.callThrough();    
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  describe('NewPassword login success ', function(){
      it(' User data fetch error 500', function(){
          httpBackend.whenPOST(API_BASE + "auth").respond(200, {data: authInfo}, {}, "HTTP/4.1 200 OK");
          spyOn(userFactory, 'getUser').and.callFake(function(){
              var deferred = q.defer();
              deferred.reject({status:500, statusText:"HTTP/4.1 500 User data fetch error"});
              return deferred.promise;
            });
          scope.authWithNewPassword('abcdefgh7');
          httpBackend.flush();
          expect(scope.errorLoginGenric).toBeTruthy();
      });
      it(' User data fetch error 401', function(){
          httpBackend.whenPOST(API_BASE + "auth").respond(200, {data: authInfo}, {}, "HTTP/4.1 200 OK");
          spyOn(userFactory, 'getUser').and.callFake(function(){
              var deferred = q.defer();
              deferred.reject({status:401, statusText:"HTTP/4.1 401 User data fetch error"});
              return deferred.promise;
            });
          scope.authWithNewPassword('abcdefgh7');
          httpBackend.flush();
          expect(scope.errorLoginGenric).toBeTruthy();
      });
  });
  describe('New Password Login error', function(){
      it(' error 500', function(){
          httpBackend.whenPOST(API_BASE + "auth").respond(500, '500 fetch error', {}, "HTTP/4.1 500 Internal server error");
          scope.authWithNewPassword('abcdefgh7');
          httpBackend.flush();
          expect(scope.errorLoginGenric).toBeTruthy();
      });
      it(' error 400', function(){
          httpBackend.whenPOST(API_BASE + "auth").respond(400, '400 fetch error', {}, "HTTP/4.1 400 Internal server error");
          scope.authWithNewPassword('abcdefgh7');
          httpBackend.flush();
          expect(scope.errorLoginGenric).toBeTruthy();
      });
  });
});
describe('Controller: passwordChangeCtrl Change password Function', function () {
    // load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var passwordChangeCtrl,
      scope,
      authPassFactory,
      authFactory,
      userFactory,
      httpBackend,
      userInfo,
      API_BASE,
      response,
      store,
      authInfo,
      rc4,
      base64,
      q,
      passTokenInfo;
      // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    beforeEach(inject(function($controller, $rootScope, authPasswordFactory, $q, $compile, _API_BASE_, _store_, _rc4Factory_, _base64Factory_, HTTP_HOST, EMAIL_VERIFICATION_URL){
        scope = $rootScope.$new();
        API_BASE = _API_BASE_;
        store = _store_;
        rc4 = _rc4Factory_;
        base64 = _base64Factory_;
        authPassFactory = authPasswordFactory;
        q = $q;
        passwordChangeCtrl = $controller('passwordChangeCtrl', {
          $scope: scope
        });

        userInfo = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "birthday": "1998-01-05",
          "gender": "male",
          "title": "Mr",
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            },
            {
              "rel": "addresses.residential",
              "href": API_BASE + "users/addresses/residential",
              "method": "GET"
            },
            {
              "rel": "addresses.billing",
              "href": API_BASE + "users/addresses/billing",
              "method": "GET"
            }
          ],
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2015-12-15T16:26:17+08:00"
          },
          "authentications": {
            "email_verified": true,
            "mobile_verified": true
          },
          "login_info": {
            "logins": 252,
            "last_login": "2016-02-23T11:56:07+08:00"
          }
        };
        passTokenInfo = {
          "status": "success",
          "token": "b62ccb43feb25ebedd9936dd64186dce"
        };
        store.set('user', userInfo);
        scope.endpoint = HTTP_HOST + EMAIL_VERIFICATION_URL;
        scope.payload = {};
        scope.payload.email = store.get('user').email;
        scope.payload.endpoint = scope.endpoint;
        spyOn(base64, 'encode').and.callThrough();
        spyOn(rc4, 'encode').and.callFake(function(){});

        spyOn(authPassFactory, 'verifyToken').and.callThrough();
        spyOn(authPassFactory, 'getToken').and.callThrough();
        spyOn(scope, 'authWithNewPassword').and.callFake(function(){});
        httpBackend.flush();
    }));
    afterEach(function(){
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    });
    it('Get Token success, verify token success', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(200, {data: passTokenInfo});
        httpBackend.whenPUT(API_BASE + 'users/authentications/password').respond(200, 'success');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('success');
    });
    it('Get Token success, verify token Error 500', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(200, {data: passTokenInfo});
        httpBackend.whenPUT(API_BASE + 'users/authentications/password').respond(500, '500 error', {}, 'HTTP/4.1 500 Token Verify error 500');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
    it('Get Token success, verify token Error 400', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(200, {data: passTokenInfo});
        httpBackend.whenPUT(API_BASE + 'users/authentications/password').respond(400, '400 error', {}, 'HTTP/4.1 400 Token Verify error 400');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
    it('Get Token success, verify token Error 401', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(200, {data: passTokenInfo});
        httpBackend.whenPUT(API_BASE + 'users/authentications/password').respond(401, '401 error', {}, 'HTTP/4.1 401 Token Verify error 401');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
    it('Get Token success, verify token Error generic', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(200, {data: passTokenInfo});
        httpBackend.whenPUT(API_BASE + 'users/authentications/password').respond(503, '503 error', {}, 'HTTP/4.1 503 Internal Server Error');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
    it('Get Token Error 500', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(500, '500 error', {}, 'HTTP/4.1 500 gett token Failed');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
    it('Get Token Error 400', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(400, '400 error', {}, 'HTTP/4.1 400 Token failed');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
    it('Get Token Error 503', function(){
        httpBackend.whenPOST(API_BASE + 'users/authentications/password').respond(503, '503 error', {}, 'HTTP/4.1 503 Internal Server error');
        scope.changePassword();
        httpBackend.flush();
        expect(scope.messageType).toBe('error');
    });
});