'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:passwordChangeCtrl
 * @description
 * # passwordChangeCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('passwordChangeCtrl', function ($scope, HTTP_HOST, EMAIL_VERIFICATION_URL, $filter, store, ngDialog, authPasswordFactory, authEmailFactory, $timeout, authenticationFactory, $analytics, $rootScope, userFactory) {
        var $translate = $filter('translate');
        $scope.password = '';

        $scope.authWithNewPassword = function (newPassword) {
            $scope.errorLoginGenric = false;
            $scope.isLoading = true;
            authenticationFactory.Login(store.get('user')
                .email, newPassword)
                .then(function (data, status, headers, config) {
                    authenticationFactory.SetCredentials(data.data.key, data.data.secret);
                    $analytics.eventTrack('Login Success', {
                        category: 'Login',
                        label: 'Login Succesfull'
                    });
                    userFactory.getUser()
                        .then(function (response) {
                            userFactory.setCurrentUser(response.data);
                            $analytics.setUsername(response.data.id);
                            $rootScope.$broadcast('authorized');
                            $analytics.setUserProperties({
                                '$email': response.data.email,
                                '$registration_date': response.data.date.registration,
                                '$mobile': response.data.mobile.country_code + response.data.mobile.number, // jshint ignore:line
                                '$name': response.data.name.first + ' ' + response.data.name.first
                            }); // jshint ignore:line
                            $scope.isLoading = false;
                        }, function (response) {
                            if (response.status === 500) {
                                $scope.isLoading = false;
                                $scope.errorLoginGenric = true;
                                $analytics.eventTrack('Error getting User Info after login', {
                                    category: 'Error 500',
                                    label: 'Error getting User Info after login'
                                });
                            } else {
                                $scope.isLoading = false;
                                $scope.errorLoginGenric = true;
                                $analytics.eventTrack('Error getting User Info after login', {
                                    category: 'Login',
                                    label: 'Login error : ' + response.status + ' : ' + response.statusText
                                });
                            }
                        });
                    $scope.userLoggedOut = false;
                }, function (response) {
                    $scope.errorLoginGenric = true;
                    $scope.isLoading = false;
                    if (response.status === 500) {
                        $analytics.eventTrack('Error Logging in', {
                            category: 'Error 500',
                            label: 'Error Logging in'
                        });
                    } else {
                        $analytics.eventTrack('Login error', {
                            category: 'Login',
                            label: 'Login Error : ' + response.status + ' : ' + response.statusText
                        });
                    }

                });
        };

        $scope.changePassword = function () {
            $scope.isLoading = true;
            $scope.endpoint = HTTP_HOST + EMAIL_VERIFICATION_URL;
            $scope.payload = {};
            $scope.payload.email = store.get('user')
                .email;
            $scope.payload.endpoint = $scope.endpoint;

            $scope.messageText = '';
            $scope.messageIcon = '';
            $scope.messageType = '';
            $scope.turnonFlag = false;

            authPasswordFactory.getToken($scope.payload)
                .then(function (response) {
                    authPasswordFactory.verifyToken(response.data.token, $scope.password)
                        .then(function (response) {
                            $scope.turnonFlag = true;
                            $scope.messageIcon = 'mcw-common-congratulations';
                            $scope.messageType = 'success';
                            if (response.status === 200) {
                                $scope.messageText = $translate('SUCCESS.VALIDATION.USER.PASS_CHANGE');
                            }
                            $scope.isLoading = false;

                            $scope.authWithNewPassword($scope.password);

                            $timeout(function () {
                                ngDialog.closeAll();
                            }, 4000);
                        }, function (response) {
                            $scope.turnonFlag = true;
                            $scope.messageIcon = 'mcw-common-alert';
                            $scope.messageType = 'error';
                            if (response.status === 401) {
                                $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.401');
                            } else if (response.status === 400) {
                                if (response.statusText.indexOf('change_password_using_current_password') > -1 || response.statusText.indexOf('New password must not be the same with the current password') > -1) {
                                   $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.400ALREADYUSED');
                                   $analytics.eventTrack('Error changing password', {  category: 'Error 400', label: 'Password has already been used previously'});
                                } else {
                                    $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.400');
                                }
                            } else if (response.status === 500) {
                                $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.500');
                            } else {
                                $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.GENERIC');
                            }
                            $scope.isLoading = false;
                        });

                }, function (response) {
                    $scope.turnonFlag = true;
                    $scope.messageIcon = 'mcw-common-alert';
                    $scope.messageType = 'error';
                    if (response.status === 500) {
                        $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.500');
                    } else if (response.status === 400) {
                        $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.400');
                    } else {
                        $scope.messageText = $translate('ERRORS.VALIDATION.USER.PASS_CHANGE.GENERIC');
                    }
                });
        };
    });
