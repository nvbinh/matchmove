'use strict';
describe('Directive: messageBox', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var compile, scope, elm, $timeout, httpBackend;
  
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
  // Initialize directive scope
  beforeEach(inject(function ($rootScope, $compile, _$timeout_) {
    elm = angular.element('<message-box messageText="ERROR MESSAGE" messageIcon="mcw-common-alert" messageType="error" turnOn="true" timeout="5000"></message-box>');

    scope = $rootScope.$new();
    compile = $compile;
    $timeout = _$timeout_;
  }));

  describe( "show message box", function() {
    it( "initialize", function () {
      var compiledElement = compile(elm)(scope);
      scope.$digest();
      expect(compiledElement.find('aside').length).toEqual(2);
      expect(compiledElement.find('div').length).toEqual(2);
      expect(compiledElement.find('svg').length).toEqual(1);
      expect(compiledElement.find('p').length).toEqual(1);
    });

    it('message box will be hidden after 5 seconds', function() {
      var compiledElement = compile(elm)(scope);
      scope.$digest();
      $timeout.flush();
      expect(compiledElement.find('aside').length).toEqual(0);
      expect(compiledElement.find('div').length).toEqual(0);
      expect(compiledElement.find('svg').length).toEqual(0);
      expect(compiledElement.find('p').length).toEqual(0);
    });
  });
});
