'use strict';
describe('Controller: loyaltyHelpModalCtrl', function () {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
// load the controller's module
  beforeEach(module('viewMultipleWallet', 'mockFirebaseFunctions' ));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var loyaltyHelpModalCtrl,
      scope,
      $timeout,
      httpBackend,
      loyaltyTermsData,
      firebase,
      fbFnFactory,
      store;
      // language based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );

    }
  } ) );
// Initialize the controller and a mock scope
  describe(' loyaltyHelp data test specs', function(){
        beforeEach(inject(function($controller, $rootScope,  _$timeout_, _firebaseFunctionsFactory_, _store_, CONTENT_NET){
            scope = $rootScope.$new();
            firebase = window.firebase;
            store = _store_;
            fbFnFactory = _firebaseFunctionsFactory_;
            firebase.apps = [];
            loyaltyHelpModalCtrl = $controller('loyaltyHelpModalCtrl', {
              $scope: scope
            });
            store.set('selectedLang', 'en_us');
            loyaltyTermsData = {
                  "en_us": {
                    "-K0-gvWrQge4SbR3eVlx": {
                      "data": "english loyalty tnc here"
                    }
                  },
                  "vi_vn": {
                    "-K0-gvWrQge4SbR3eBNx": {
                      "data": "VN loyalty tnc here"
                    }
                  }
                };
        $timeout = _$timeout_;
        }));
      afterEach( function() {
        httpBackend.flush();
          httpBackend.verifyNoOutstandingExpectation();
          httpBackend.verifyNoOutstandingRequest();
        } );
     describe(' loadLoyaltyTermsData data test specs', function(){
        it(' :: should return loyaltyTerms data as a promise', function() {
            scope.loyaltyRef = fbFnFactory.stubRef('guides/loyalty/' + scope.lang);

            scope.loyaltyRef.on('value', function(snapshot){
                 $timeout(function(){
                        scope.loyaltyArray = [];
                        scope.loyaltyRef.on('value', function(snapshot) {
                            scope.loyaltyTerms = snapshot.val();
                            angular.forEach(scope.loyaltyTerms, function(value, key){
                                scope.loyaltyArray.push(value);
                            });
                        });
                        expect(scope.loyaltyArray).toBeDefined();
                        expect(scope.loyaltyArray).toEqual(loyaltyTermsData);
                    }, 10);
                });
                $timeout.flush(10);
            scope.loyaltyRef.fakeEvent('value', null, loyaltyTermsData);
            scope.loadLoyaltyTermsData();
            // fbFnFactory.flushAll(scope.loyaltyRef);
        });
    });
    });
});
