'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:loyaltyHelpModalCtrl
 * @description
 * # loyaltyHelpModalCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'loyaltyHelpModalCtrl', function ($rootScope, $scope, $firebaseArray, CONTENT_NET, BASE_CURRENCY, PubSub, store, $timeout, $translateLocalStorage){

        $scope.loadLoyaltyTermsData = function () {
            $scope.isLoading = true;
            $scope.lang = $translateLocalStorage.get('NG_TRANSLATE_LANG_KEY');

            if (firebase.apps.length === 0) {
               $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.loyaltyTermsRef = $rootScope.firebaseApp.database().ref( 'guides/loyalty/'+ $scope.lang );
            $timeout(function(){
                $scope.loyaltyTermsRef.on('value', function(snapshot) {
                    $scope.loyaltyTerms = snapshot.val();
                    $scope.recKey = Object.keys($scope.loyaltyTerms);
                    $timeout(function(){
                        $scope.loyaltyTermsItem = ($scope.loyaltyTerms[$scope.recKey[0]].data);
                        $scope.isLoading = false;
                    }, 0);
                });
            }, 5);
        };
        $scope.loadLoyaltyTermsData();
        PubSub.subscribe('language-changed', $scope.loadLoyaltyTermsData);

       $scope.baseCurrency = BASE_CURRENCY;
    });
