'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:messageBox
 * @description
 * # messageBox
 */
angular.module('viewMultipleWallet')
.directive('loyaltyHelpModal', function () {
    return {
        restrict: 'EA',
        scope: {
        },
        templateUrl: 'app/components/loyaltyHelpModal/partials/loyaltyHelpModal.html',
        transclude: true
    };
});
