'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:paymentModalCtrl
 * @description
 * # paymentModalCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('paymentModalCtrl', function ($scope) {
    
  });
