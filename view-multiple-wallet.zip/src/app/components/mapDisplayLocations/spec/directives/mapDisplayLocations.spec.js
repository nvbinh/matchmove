'use strict';
/**
 * Receive place name from controller
 * Handling callback to server for check that place name
 * Display current position of end user and place reference on google map
 */
describe('Directive: mapDisplayLocations', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  var element,
    scope;

  beforeEach(inject(function ($rootScope, $compile) {
    scope = $rootScope.$new();
  }));

  describe('initialisation', function() {
    element = '';

    window.onload = function (){
        it('should not produce a google map', function() {
            expect(element.find('map').length).toEqual(0);

        });
    }
  });

  it('should load google map', function() {
    element = '<map center="{{myLocation.lat}}, {{myLocation.long}}" zoom="15"><marker position="{{myLocation.lat}}, {{myLocation.long}}"><marker ng-repeat="mapItem in placelocations" position="{{mapItem.latitude}}, {{mapItem.longitude}}" on-click="showInfoWindow(event, mapItem)" icon="{{mapItem.iconcss}}"></map>';
    window.onload = function (){
        expect(element.find('map').length).toEqual(1);

    }
  });

});
