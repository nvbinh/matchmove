'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:mapDisplayLocations
 * @description
 * # mapLocations
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'mapDisplayLocations', function ( $log, $timeout, $filter ) {
        return {
            restrict: 'E',
            scope: {
                model: '='
            },
            controller: [ '$scope', function ( $scope ) {

                $scope.$on( 'mapInitialized', function ( event, map ) {
                   $timeout( function () {
                         var locations = $scope.model;
                        var marker;

                         for (var i=0;i< locations.length;i++)
                         {
                            var position = new google.maps.LatLng(locations[i].LATITUDE,locations[i].LONGITUDE);
                            marker = new google.maps.Marker({map:map,icon: $scope.iconcss, position:position, key: 'AIzaSyCdfVT99PtKmZrJBJ6eVy5o-HvTbPIhrbs'});

                            var infoWindow = new google.maps.InfoWindow();

                            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                            return function() {
                                var content = "<div class='mapInfo-content'> "+ locations[i].ADDRESS_1 + ", <br>" + locations[i].CITY + ", " + (locations[i].STATE ? locations[i].STATE + " - " : '' ) + locations[i].POSTAL_CODE + "</div>";
                                infoWindow.setContent(content);
                                infoWindow.open(map, marker);
                                }
                            })(marker, i));

                         }

                   }, 4000 );
                } );


            } ],

            templateUrl: 'app/components/mapDisplayLocations/partials/mapDisplayLocations.html',
            link: function ( scope, element, attrs ) {
                scope.lat = 0;
                scope.lng = 0;
                scope.iconcss = '';
                var $translate = $filter( 'translate' );
                scope.mapError = false;
                scope.mapSupport = true;
                getLocation();

                 function getLocation() {
                    scope.mapError = false;
                    if ( navigator.geolocation ) {
                        navigator.geolocation.getCurrentPosition( showPosition, handle_errors );
                    } else {
                        scope.mapSupport = false;
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.NOT_SUPPORTED' ); // geolocation API is not supported
                    }
                }

                  function showPosition( position ) {
                    scope.lat = position.coords.latitude;
                    scope.lng = position.coords.longitude;

                    var currentPos = {
                        'name': 'currentPos',
                        'lat': scope.lat,
                        'long': scope.lng
                    }
                    scope.myLocation = currentPos;
                }


                function handle_errors( error ) {
                    scope.mapError = false;
                    switch ( error.code ) {
                    case error.PERMISSION_DENIED:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.PERMISSION_DENIED' ); // permission denied
                        break;

                    case error.POSITION_UNAVAILABLE:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.POSITION_UNAVAILABLE' ); // cannot detect current position
                        break;

                    case error.TIMEOUT:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.TIMEOUT' ); // timeout
                        break;

                    default:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.FALLBACK' ); // unknown error
                        break;
                    }
                }

            },
        };
    } );
