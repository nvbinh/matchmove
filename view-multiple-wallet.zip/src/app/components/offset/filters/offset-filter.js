'use strict';
/**
 * @ngdoc filter
 * @name viewMultipleWallet.filter:offset
 * @function
 * @description
 * # offset
 * Filter in the viewMultipleWallet.offset
 */
angular.module('viewMultipleWallet')
.filter('offset', function() {
    return function(input, start) {
        if(input !== undefined){
            start = parseInt(start, 10);
            return input.slice(start);
        }
    };
});
