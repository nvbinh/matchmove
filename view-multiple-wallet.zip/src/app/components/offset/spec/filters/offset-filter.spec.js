'use strict';

describe('Filter: offset', function () {
// load the filter's module

    beforeEach(module('viewMultipleWallet'));
    // initialize a new instance of the filter before each test
    var offsetFilter;
    beforeEach(inject(function(_offsetFilter_) {
        offsetFilter = _offsetFilter_;
    }));
    it('should return an offset', function(){
        expect(offsetFilter([1,2,3,4,5], 2)).toEqual([3, 4, 5]);
    });
});
