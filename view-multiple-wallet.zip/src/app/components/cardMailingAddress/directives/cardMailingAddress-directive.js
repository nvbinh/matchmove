'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:cardMailingAddress
 * @description
 * # cardMailingAddress
 */
angular.module( 'viewMultipleWallet' )
	.directive( 'cardMailingAddress', function () {
		return {
			template: 'app/components/cardMailingAddress/partials/cardMailingAddress.html',
			scope: {
				forms: '='
			},
			restrict: 'E'
		};
	} );