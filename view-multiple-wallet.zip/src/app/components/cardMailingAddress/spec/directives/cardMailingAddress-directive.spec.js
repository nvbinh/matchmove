'use strict';
describe('Directive: cardMailingAddress', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  var element,
    scope;
  beforeEach(inject(function ($rootScope) {
    scope = $rootScope.$new();
  }));
});
