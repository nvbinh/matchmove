'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:mmButton
 * @description
 * # mmButton
 */
angular.module('viewMultipleWallet')
    .directive('mgButton', function () {

        return {
            restrict: 'A',
            link: function (scope, element) {
                var rippler = element;
                element.on('click',function (event) {

                    if(rippler.find('.ripple').length === 0) {
                        rippler.append('<span class=\'ripple\'></span>');
                    }

                    var ripple = rippler.find('.ripple');

                    // prevent quick double clicks
                    ripple.removeClass('animate');

                    if(!ripple.height() && !ripple.width()) {
                        var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
                        ripple.css({height: d, width: d});
                    }

                    var x = event.pageX - rippler.offset().left - ripple.width()/2;
                    var y = event.pageY - rippler.offset().top - ripple.height()/2;

                    ripple.css({
                      top: y+'px',
                      left:x+'px'
                    }).addClass('animate');
                });
            }
        };
  });