'use strict';
describe('Directive: receiptOrder', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var element,
    scope,
    httpBackend,
    document,
    BASE_CURRENCY;
    // language based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  beforeEach(inject(function ($rootScope, _BASE_CURRENCY_, $compile, _$document_) {
    scope = $rootScope.$new();
    document = _$document_;
    BASE_CURRENCY = _BASE_CURRENCY_;

    element = angular.element('<receipt-order card-name="EasyPay2" fees="3"></receipt-order>');
    scope.baseCurrency = BASE_CURRENCY;
    $compile(element)(scope);
    scope.$digest();
  }));
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  /* TODO fix test case
  it('should have scope variables defined', inject(function ($compile) {
    expect(scope).toBeDefined();
    expect(scope.baseCurrency).toBe('SGD');
  }));*/
  it('should have the div element with class "total" defined', function(){
      var divtotal = angular.element(document).find('div.total');
      expect(divtotal).toBeDefined();
  });
  
});