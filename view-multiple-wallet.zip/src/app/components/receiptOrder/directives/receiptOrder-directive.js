'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:receiptOrder
 * @description
 * # receiptOrder
 */
angular.module('viewMultipleWallet')
  .directive('receiptOrder', function (BASE_CURRENCY) {
    return {
            templateUrl: 'app/components/receiptOrder/partials/receiptOrder.html',
            restrict: 'E',
            scope: {
                cardName: '=cardName',
                fees: '=fees',
                total: '=total',
                refId: '=refId',
                date: '=date'
            },
            link: function(scope) {
                scope.baseCurrency = BASE_CURRENCY;
            }
        };
  });