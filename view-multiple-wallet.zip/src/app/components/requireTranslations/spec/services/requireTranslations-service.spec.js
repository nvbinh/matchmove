describe('Service: requireTranslationsService', function() {
  var requireTranslations;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_requireTranslationsService_) {
  requireTranslations = _requireTranslationsService_;
  }));


});
