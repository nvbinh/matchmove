'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.requireTranslations
 * @description
 * # requireTranslations
 * Service in the viewMultipleWallet.
 */
angular.module( 'viewMultipleWallet' )
	.service( 'requireTranslationsService', function( $translatePartialLoader, $translate ) {
		return function() {
			angular.forEach( arguments, function( translationKey ) {
				$translatePartialLoader.addPart( translationKey );
			} );
			return $translate.refresh();
		};
	} );
