'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:notifyAddressVerifyCtrl
 * @description
 * # notifyAddressVerifyCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('notifyAddressVerifyCtrl', function($scope, $state) {
        $scope.goToAddress = function() {
            $state.go('wallet.details.my.complete', { activeTab: 'addressForm' }, {});
        }
    });
