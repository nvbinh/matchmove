'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:displayErrors
 * @description
 * # displayErrors
 */
angular.module('viewMultipleWallet')
  .directive('displayErrors', ['$timeout','$interval', function ($timeout, $interval) {
    return {
      restrict: 'E',
      templateUrl: 'app/components/displayErrors/partials/displayErrors.html',
      scope: {
        messageType: '@messagetype',
        messageIcon: '@messageicon',
      },
      controller: ['$scope', function($scope) {

      }],
      link: function(scope, element, attrs) {
        var timeout,
            flag;
  	    scope.messageText = '';
        scope.flag = (attrs.turnon === 'true');

        var displayError = attrs.$observe('turnon', function(val){
          if (val === 'true') {
            $timeout(function() {
              scope.messageText = attrs.messagetext;
            }, parseInt(250));
            scope.flag = true;
            $timeout(function() {
              scope.flag = false;
            }, parseInt(attrs.timeout));
          }
        });
      }
    };
  }]);
