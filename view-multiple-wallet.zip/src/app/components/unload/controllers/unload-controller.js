'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:unloadCtrl
 * @description
 * # unloadCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'unloadCtrl', function ( $scope, $analytics, $http, $log, $filter, $timeout, ngDialog, Cards, Wallet, userswalletscardsfundsFactory, helperFactory, $rootScope, UNLOAD_PARAMETERS, store, PubSub, CacheFactory, $state ) {
        store.set( 'controller', 'unloadCtrl' );
        $scope.cardTounLoad = $scope.$parent.cardTounLoad;
        $scope.balance = 0;
        $scope.unload = {};
        $scope.unload.amount = 10;
        $scope.isLoading = true;

        var $translate = $filter( 'translate' );
        $scope.wallet = $scope.$parent.wallet;

        Cards.getCardNoCache( $scope.cardTounLoad )
            .then( function ( response ) {
                $scope.card = response.data;
                if ( $scope.unload.amount && $scope.unload.amount <= $scope.card.funds.available.amount ) {
                    $scope.balance = ( $scope.card.funds.available.amount - $scope.unload.amount )
                        .toFixed( 2 );
                    $scope.cardBalance = ( parseFloat( $scope.wallet.funds.available.amount ) + $scope.unload.amount )
                        .toFixed( 2 );
                }
                $scope.configObj = angular.fromJson( UNLOAD_PARAMETERS );
                $scope.min = $scope.configObj.min;
                $scope.max = Math.min( $scope.configObj.max, $scope.card.funds.available.amount );
                $scope.isLoading = false;
            }, function () {
                $scope.isLoading = false;
            } );

        $scope.parseFloat = function ( amount ) {
            return parseFloat( amount );
        };
        $scope.updateBalance = function ( value ) {
            if ( value && value <= $scope.card.funds.available.amount ) {
                $scope.balance = ( $scope.card.funds.available.amount - value )
                    .toFixed( 2 );
                $scope.cardBalance = ( parseFloat( $scope.wallet.funds.available.amount ) + value )
                    .toFixed( 2 );
            } else {
                $scope.balance = $scope.card.funds.available.amount;
                $scope.cardBalance = parseFloat( $scope.wallet.funds.available.amount )
                    .toFixed( 2 );
            }
            //$scope.isLoading = false;
        };
        $scope.updateBalanceOnDashboard = function ( amount ) {
            var balanceEl = $scope.$parent.balanceEl,
                current = 0,
                finalResult = 0;
            if ( balanceEl.length > 0 ) {
                current = parseFloat( $scope.cardAmount );
                if ( current >= amount ) {
                    finalResult = current - amount;
                    finalResult = $filter('mmCurrency')(finalResult, 'skipSymbolFalse');
                    balanceEl.html( finalResult );
                    if ( finalResult <= 0 ) {
                        $rootScope.$broadcast( 'hideunloadbutton' );
                        $scope.updatePopupBalance( amount );
                    }
                }
                if ( finalResult > 0 ) {
                    $scope.updatePopupBalance( amount );
                    balanceEl.html( finalResult );
                }
                //$scope.isLoading = false;
            } else {
                //$scope.isLoading = false;
            }
        };

        $scope.updatePopupBalance = function ( amount ) {
            $scope.isLoading = true;
            /*Wallet.getWallet()
                .then(function (response) {

                    $scope.wallet = response;
                    if ( $scope.card && $scope.card.id ) {
                        Cards.getCardNoCache( $scope.card.id )
                            .then( function ( response ) {
                                $scope.card = response.data;
                                $scope.updateBalance( amount );
                                $scope.isLoading = false;
                            }, function () {
                                $scope.isLoading = false;
                            } );
                    }
                }, function () {
                    $scope.isLoading = false;

                });*/
            $scope.updateBalance(amount);
            $scope.isLoading = false;
        };


        $scope.unloadCard = function () {
            $scope.unloadSuccess = false;
            // Pre-Unload check on amount limits from Wallet detail data
            $scope.isLoading = true;
            $scope.unloadError = false;

            if ( $scope.unload.amount < $scope.wallet.details.min_load_limit ) {
                $scope.unloadError = true;
                $scope.isLoading = false;
                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.LESSER_THAN_MIN_WALLET_LIMIT' );
                return;
            } else if ( $scope.unload.amount > $scope.wallet.details.max_load_limit ) {
                $scope.unloadError = true;
                $scope.isLoading = false;
                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.GREATER_THAN_MAX_WALLET_LIMIT' );
                return;
            } else {
                // all limit checks are safe for current unload request
                // allow user to Proceed
                //$scope.isLoading = true;
                //$scope.unloadError = false;
                $scope.unloadingTextMsg = $translate( 'MODAL.UNLOAD.LOADING.PROCESSING_UNLOAD' );
                userswalletscardsfundsFactory.unloadCard( $scope.$parent.cardTounLoad, $scope.unload.amount )
                    .then( function ( response ) {
                        $scope.unloadResponse = response.data;
                        $analytics.eventTrack( 'Unload Card Successfull', {
                            category: 'Unload Card',
                            label: 'Unload Card Successfull - Amount :' + $scope.unload.amount
                        } );
                        helperFactory.postTransactionInfoUpdate();

                        $scope.unloadingTextMsg = $translate( 'MODAL.UNLOAD.LOADING.UPDATING_BALANCE' );

                        // manually remove the cache - userWallet
                        CacheFactory.get('walletCache').remove('userWallet');
                        // notify PubSub
                        PubSub.publish( 'unload-success' );
                        $scope.unloadSuccess = true;
                        $scope.updateBalanceOnDashboard( $scope.unload.amount );
                        //$rootScope.$broadcast('updateBalanceBar');
                        //$scope.unload.amount = '';
                        $scope.unloadForm.$setPristine();
                        $timeout( function () {
                            ngDialog.closeAll();
                            $state.go( '.', {}, {
                                reload: true
                            } );
                        }, 3500 );
                        $scope.isLoading = false;
                    }, function ( response ) {
                        // error handling is in generic errorHandler.js file
                        $scope.unloadError = true;
                        $scope.isLoading = false;
                        if ( response.status === 500 ) {
                            $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.500_SERVICE_ERROR' );
                            $analytics.eventTrack( 'Error unloading card in Dashboard', {
                                category: 'Error 500',
                                label: 'Error unloading card in Dashboard'
                            } );
                        } else if ( response.status === 403 ) {
                            // TODO: Pending from OP NEEDS TO CHANGE ERROR CODE TO 400
                            // Doing 403 for the quick patch
                            // Related ticket TPB-911, TPB-915
                            console.log(response)
                            if ( response.statusText.indexOf( 'User currently has a pending transaction' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.EXISTING_PROCESS_ON_GOING' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            }
                            // END TODO
                        } else if ( response.status === 400 ) {
                            if (response.statusText.indexOf('Lifetime count limit reached') > -1) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.LIFETIME_COUNT_LIMIT' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'PreKYC User Repeated UnLoad Card attempt : ' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'greater_than_limit' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.GREATER_THAN_LIMIT' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_daily_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_DAILY_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_weekly_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_WEEKLY_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_monthly_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_MONTHLY_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_lifetime_transactional_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_LIFETIME_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_lifetime_count_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_LIFETIME_COUNT_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_minimum_credit_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_MIN_CREDIT_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'resource_card_fund_category_transfer_maximum_credit_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_MAX_CREDIT_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_maximum_credit_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_MAX_CREDIT_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_purse_daily_transactional_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_DAILY_TRANSACTIONAL_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_purse_weekly_transactional_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_WEEKLY_TRANSACTIONAL_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_purse_monthly_transactional_limit_reached' ) > -1 ) {
                                $scope.unloadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_MONTHLY_TRANSACTIONAL_LIMIT_REACHED' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'existingProcessOngoing' ) > -1 ) {
                                $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.EXISTING_PROCESS_ON_GOING' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else if ( response.statusText.indexOf( 'User currently has a pending transaction' ) > -1 ) {
                                $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.UNLOAD.400.EXISTING_PROCESS_ON_GOING' );
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );
                            } else {
                                $scope.unloadErrorMsg = response.statusText;
                                $analytics.eventTrack( 'Invalid Request UnLoad Card', {
                                    category: 'UnLoad Card',
                                    label: 'Invalid Request UnLoad Card :' + response.statusText
                                } );

                            }
                        } else {
                            $scope.unloadErrorMsg = response.statusText;
                            $analytics.eventTrack( 'Uncaught Error UnLoad Card', {
                                category: 'UnLoad Card',
                                label: 'Uncaght Error UnLoad Card :' + response.status + ' : ' + response.statusText
                            } );
                        }
                    } );
            }
        };
    } );
