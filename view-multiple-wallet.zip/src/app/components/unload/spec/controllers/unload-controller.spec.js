/* global inject */
/* global expect */
/* global it */
/* global beforeEach */
/* global describe */

'use strict';
angular.module('mockWallet', [])
    .factory('mockCardSvc', function($q, $http, API_BASE){
        var cardSvc = {};
        cardSvc.getCardNoCache = function(cardId){
            var mock = {};
            mock.card = angular.toJson({
              "id": "464d9a323e583498f76860aef89a32b3",
              "number": "5363950000255600",
              "holder": {
                "name": "Balaji"
              },
              "funds": {
                "available": {
                  "currency": "SGD",
                  "amount": "60.00"
                }
              },
              "type": {
                "type": "mcmmgpcard",
                "name": "MatchMove Physical Card",
                "description": "Matchmove Physical Card",
                "code_type": "Physical Card"
              },
              "date": {
                "expiry": "2020-12",
                "issued": "2016-02-10"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "links": [
                {
                  "rel": "securities.tokens",
                  "href": "",
                  "method": "GET"
                }
              ]
            });
            return $q.when(mock);
        };
        return cardSvc;
})
.factory('mockNoCardSvc', function($q, $http, API_BASE){
        var cardSvc = {};
        cardSvc.getCardNoCache = function(cardId){
           return $q.reject({error: 'NoCardAvailable'});
        };
        return cardSvc;
})
.factory('mockWalletSvc', function($q, $http, API_BASE) {
        var walletSvc = {};

        // example stub method that returns a promise, e.g. if original method returned $http.get(...)
        walletSvc.getWallet = function() {
            var mock = {};
            mock.wallet = angular.toJson({
              "funds": {
                "withholding": {
                  "currency": "SGD",
                  "amount": "27.00"
                },
                "available": {
                  "currency": "SGD",
                  "amount": "162.00"
                }
              },
              "id": "dfa7916f06e9640daeb0bbe413012659",
              "number": "6377020000009969",
              "holder": {
                "name": "Balaji"
              },
              "date": {
                "expiry": "2024-03",
                "issued": "2015-12-15"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "details": {
                "min_load_limit": 10,
                "max_load_limit": 999,
                "network_type": "mastercard",
                "fee": 0,
                "topup_limits": {
                  "pre_kyc": {
                    "frequency": null,
                    "allowed": null,
                    "monthly_transactional_limit": 9999999999
                  },
                  "post_kyc": {
                    "frequency": null,
                    "monthly_transactional_limit": 5000
                  },
                  "current": {
                    "lifetime_count": 4,
                    "lifetime_transactional": 175,
                    "monthly_transactional": 10
                  }
                }
              },
              "cards": [
                {
                  "id": "464d9a323e583498f76860aef89a32b3",
                  "type": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                      "method": "GET"
                    }
                  ],
                  "links": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3",
                      "method": "GET"
                    }
                  ]
                }
              ]
            });
            mock.userCards = angular.toJson({
              "id": "464d9a323e583498f76860aef89a32b3",
              "number": "5363950000255600",
              "holder": {
                "name": "Balaji"
              },
              "funds": {
                "available": {
                  "currency": "SGD",
                  "amount": "60.00"
                }
              },
              "type": {
                "type": "mcmmgpcard",
                "name": "MatchMove Physical Card",
                "description": "Matchmove Physical Card",
                "code_type": "Physical Card"
              },
              "date": {
                "expiry": "2020-12",
                "issued": "2016-02-10"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "links": [
                {
                  "rel": "securities.tokens",
                  "href": "",
                  "method": "GET"
                }
              ]
            });
            return $q.when(mock);
        };
        // other stubbed methods
        return walletSvc;
    })
.factory('mockWalletErrorSvc', function($q, $http, API_BASE) {
    var walletSvc = {};

    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
    walletSvc.getWallet = function() {
        var mock = {};
        mock.wallet = angular.toJson({});
        mock.userCards = angular.toJson({});
        return $q.reject({'error': 'Error retrieving Wallet Information'});
    };
    // other stubbed methods
    return walletSvc;
});
describe('Controller: unloadCtrl', function () {
    // load mockWallet Service
    beforeEach(module('mockWallet'));
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var unloadCtrl,
      backend,
      scope,
      Wallet,
      userswalletscardsfundsFactory,
      helperFactory,
      Cards,
      API_BASE,
      httpBackend,
      walletInfo,
      cardInfo;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _API_BASE_, _mockWalletSvc_, _userswalletscardsfundsFactory_, _helperFactory_, _mockCardSvc_) {

    Wallet = _mockWalletSvc_;
    Cards = _mockCardSvc_;
    API_BASE = _API_BASE_;
    userswalletscardsfundsFactory = _userswalletscardsfundsFactory_;
    helperFactory = _helperFactory_;

    walletInfo = {
              "funds": {
                "withholding": {
                  "currency": "SGD",
                  "amount": "27.00"
                },
                "available": {
                  "currency": "SGD",
                  "amount": "162.00"
                }
              },
              "id": "dfa7916f06e9640daeb0bbe413012659",
              "number": "6377020000009969",
              "holder": {
                "name": "Balaji"
              },
              "date": {
                "expiry": "2024-03",
                "issued": "2015-12-15"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "details": {
                "min_load_limit": 10,
                "max_load_limit": 999,
                "network_type": "mastercard",
                "fee": 0,
                "topup_limits": {
                  "pre_kyc": {
                    "frequency": null,
                    "allowed": null,
                    "monthly_transactional_limit": 9999999999
                  },
                  "post_kyc": {
                    "frequency": null,
                    "monthly_transactional_limit": 5000
                  },
                  "current": {
                    "lifetime_count": 4,
                    "lifetime_transactional": 175,
                    "monthly_transactional": 10
                  }
                }
              },
              "cards": [
                {
                  "id": "464d9a323e583498f76860aef89a32b3",
                  "type": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                      "method": "GET"
                    }
                  ],
                  "links": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3",
                      "method": "GET"
                    }
                  ]
                }
              ]
            };

    cardInfo = {
          "id": "464d9a323e583498f76860aef89a32b3",
          "number": "5363950000255600",
          "holder": {
            "name": "Balaji"
          },
          "funds": {
            "available": {
              "currency": "SGD",
              "amount": "60.00"
            }
          },
          "type": {
            "type": "mcmmgpcard",
            "name": "MatchMove Physical Card",
            "description": "Matchmove Physical Card",
            "code_type": "Physical Card"
          },
          "date": {
            "expiry": "2020-12",
            "issued": "2016-02-10"
          },
          "image": {
            "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
            "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
            "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
          },
          "status": {
            "is_active": true,
            "text": "active"
          },
          "links": [
            {
              "rel": "securities.tokens",
              "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/securities/tokens",
              "method": "GET"
            }
          ]
        };
    scope = $rootScope.$new();
    scope.$parent.wallet = walletInfo;
    scope.card = cardInfo;
    scope.$parent.cardTounLoad = '464d9a323e583498f76860aef89a32b3';
    unloadCtrl = $controller('unloadCtrl', {
      $scope: scope
    });

    scope.$parent.balanceEl = angular.element('<span class="balance-number">30.00</span>');

    scope.form = {$valid: true, $dirty: true, $setPristine: function () {scope.unloadForm.$dirty = false, scope.unloadForm.$pristine = true;}};
    scope.unloadForm = scope.form;
    httpBackend.whenGET(API_BASE + 'users/wallets').respond(200, walletInfo);
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(200, cardInfo);
    httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/undefined/funds').respond(200, cardInfo);
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/undefined').respond(200, cardInfo);

    Wallet.getWallet().then(function(response){
        scope.wallet = (response);
    });
   Cards.getCardNoCache(scope.card).then(function(){
       scope.wallet = angular.fromJson(walletInfo);
       scope.card = angular.fromJson(cardInfo);
       scope.cardBalance = 10.00;
       scope.balance = 200.00;
   });
   httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('initialization for scope amount', function () {
    expect(scope.balance).toEqual('50.00');
  });

  it('update balance amount', function() {
    scope.wallet = {};
    scope.wallet.funds = {};
    scope.wallet.funds.available = {};
    scope.wallet.funds.available.amount = 200.00;
    scope.card = {};
    scope.card.funds = {};
    scope.card.funds.available = {};
    scope.card.funds.available.amount = 200.00;
    scope.updateBalance(5);
    expect(parseInt(scope.balance)).toEqual(195);
    expect(parseInt(scope.cardBalance)).toEqual(205);
    //httpBackend.flush();
  });

  describe('unload card', function(){
      describe('when http request is called', function(){
          it('should succeed', function(){
              scope.unload.amount = 5;
              scope.wallet.details.min_load_limit = 1;
              scope.wallet.details.max_load_limit = 999;
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(200, cardInfo);
              spyOn(userswalletscardsfundsFactory, 'unloadCard').and.callThrough();
              spyOn(helperFactory, 'postTransactionInfoUpdate').and.callThrough();
              spyOn(scope, 'updateBalanceOnDashboard').and.callThrough();
              spyOn(Wallet, 'getWallet').and.callThrough();
              spyOn(scope, 'updateBalance').and.callThrough();
              spyOn(Cards, 'getCardNoCache').and.callThrough();
              scope.unloadCard();
              httpBackend.flush();
              //expect(scope.isLoading).toBeFalsy();
              expect(scope.unloadSuccess).toBeTruthy();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(helperFactory.postTransactionInfoUpdate).toHaveBeenCalled();
          });
      });
  });
  describe('unload card ', function(){
      beforeEach(inject(function(){
          spyOn(userswalletscardsfundsFactory, 'unloadCard').and.callThrough();
          spyOn(scope, 'updateBalance').and.callThrough();
          spyOn(helperFactory, 'postTransactionInfoUpdate').and.callFake(function() { return true; });
      }));
      describe('Errors', function(){
          it('should Fail with Error 400', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(400, 'error 400', {}, '(HTTP/1.1 400 greater_than_limit)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 greater_than_limit)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
          it('should Fail with Error 400', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_daily_limit_reached)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_daily_limit_reached)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
          it('should Fail with Error 400', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_weekly_limit_reached)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_weekly_limit_reached)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
          it('should Fail with Error 400', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_monthly_limit_reached)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_monthly_limit_reached)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
          it('should Fail with Error 400 generic', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(400, 'error 400', {}, '(HTTP/1.1 400 generic error)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 generic error)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
          it('should Fail with Error 500', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(500, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(500, 'error 500', {}, '(HTTP/1.1 Internal Server Error)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(500, 'error 500', {}, '(HTTP/1.1 500 Internal Server Error)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
          it('should Fail with Error 503', function(){
              httpBackend.whenGET(API_BASE + 'users/wallets').respond(503, '');
              httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(503, 'error 503', {}, '(HTTP/1.1 503 Uncaught Error)');
              httpBackend.whenDELETE(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(503, 'error 503', {}, '(HTTP/1.1 503 Uncaught Error)');
              scope.unloadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.unloadCard).toHaveBeenCalled();
              expect(scope.unloadErrorMsg).toBeDefined();
          });
      });
  });
});
