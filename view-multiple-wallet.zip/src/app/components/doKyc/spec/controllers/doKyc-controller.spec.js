'use strict';
describe('Controller: doKycCtrl', function () {
// Load custom config constant
 beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var doKycCtrl,
      scope,
      httpBackend,
      walletData,
      createCardInfo,
      store,
      ngdialog;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _store_, _ngDialog_ ) {
    scope = $rootScope.$new();
    store = _store_;
    ngdialog = _ngDialog_;
    doKycCtrl = $controller('doKycCtrl', {
      $scope: scope
    });
    store.set( 'kycStatus', 'approved' );
    spyOn( ngdialog, 'closeAll' ).and.callThrough();

  }));
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  describe('closeDialog Functionality', function(){
  	it('call ngDialog', function(){
        scope.closeDialog();
  		expect(ngdialog.closeAll).toHaveBeenCalled();
  	});

  });
});
