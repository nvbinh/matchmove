'use strict';

angular.module( 'viewMultipleWallet' )
	.controller( 'doKycCtrl', function ( store, $scope, ngDialog ) {
		$scope.currentStatus = store.get( 'kycStatus' );

		$scope.closeDialog = function () {
			ngDialog.closeAll();
		}
	} );