'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:doKyc
 * @description
 * # doKyc
 */
angular.module('viewMultipleWallet')
  .directive('doKyc', function () {
    return {
      templateUrl: 'app/components/doKyc/partials/doKyc.html',
      restrict: 'A',
      controller: 'doKycCtrl',
      transclude: true,
      replace: true,
      link: function(scope, element, attrs) {
        
      }
    };
  });
