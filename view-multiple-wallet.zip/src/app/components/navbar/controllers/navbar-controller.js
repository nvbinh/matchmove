'use strict';
/* global angular */

angular.module( 'viewMultipleWallet' )
    .controller( 'NavbarCtrl', function( CONTENT_NET, TRANSLATION_PARAMS, APPLICATION_PARAMS, $rootScope, $scope, $filter, $log, $state, $window, userFactory, userNotificationsFactory, authenticationFactory, helperFactory, store, mobiledetectService, $translate, $stateHistory, $timeout, PubSub ) {
        $scope.isMobile = mobiledetectService.mobile();
        $scope.isTablet = mobiledetectService.tablet();
        $scope.isPhone = mobiledetectService.phone();
        $scope.noNewsNotification = true;
        $scope.countOfLanguages = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        if(angular.fromJson(APPLICATION_PARAMS).platform === 'app') {
          $scope.isApp = true;
        }
        $scope.prevState = function() {
            $stateHistory.back();
        };

        $rootScope.$on( '$stateChangeSuccess', function() {
            if ( $state.current.history.button === 'back' ) {
                $scope.showBackButton = true;
            } else if ( $state.current.history.button === 'menu' ) {
                $scope.showBackButton = false;
            } else {
                $scope.showBackButton = false;
            }
        } )

        if ( $scope.countOfLanguages > 1 ) {
            $scope.multipleLanguages = true;
        }

        if ( !$rootScope.globals.currentUser ) {
            $scope.showLogin = true;
            $scope.logoUrl = '/';
        } else {
            $scope.showLogin = false;
            $scope.logoUrl = '/wallet/home';
            $scope.currentUser = userFactory.getCurrentUser();
            $scope.user = $scope.currentUser.name.first;
            helperFactory.clearCacheNotification();
            userNotificationsFactory.getList( {
                    filter_field: 'is_read',
                    filter_condition: '=',
                    filter_value: '0',
                    sort_field: 'date_added',
                    sort_direction: 'DESC',
                    limit: '5'
                } ) // jshint ignore:line
                .then( function( response ) {
                    $scope.notifications = response.data.notifications;

                    $scope.notificationsCount = response.data.pagination.total_unread; // jshint ignore:line
                    if ( $scope.notificationsCount === 0 ) {
                        $scope.noUnreadItems = true;
                    }
                    $scope.isRead = function( notification ) {
                        if ( notification.is_read === "0" ) { // jshint ignore:line
                            return 'notification-unread';
                        } else {
                            return '';
                        }
                    };
                }, function() {

                } );
        }

        $rootScope.$on( 'authorized', function() {
            $scope.showLogin = false;
        } );

        $rootScope.$on( 'noauthorized', function() {
            $scope.showLogin = true;
        } );

        $scope.getNewsContent = function(){
            if (firebase.apps.length === 0) {
              $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.lang = store.get('selectedLang');
            $scope.newsRef = $rootScope.firebaseApp.database().ref( 'news/' + $scope.lang );
            //
            $scope.newsRef.on('value', function(snapshot) {
                $scope.newsArray = [];
                $scope.news = snapshot.val();
                angular.forEach($scope.news, function(value, key){
                    $scope.newsArray.push(value);
                    $scope.noNewsNotification = false;
                  });
            });
        }
        $scope.getNewsContent();
        PubSub.subscribe('language-changed', $scope.getNewsContent);

        $scope.notificationTabs = {
            active: 0
        };

        function scrollTo( element, to, duration ) {
            if ( duration <= 0 ) return;
            var difference = to - element.scrollTop;
            var perTick = difference / duration * 10;

            setTimeout( function() {
                element.scrollTop = element.scrollTop + perTick;
                if ( element.scrollTop == to ) return;
                scrollTo( element, to, duration - 10 );
            }, 10 );
        }

        $scope.goToNotification = function() {
            $scope.isLoading = true;
            $rootScope.$emit( 'ngDropover.close', 'notificationDropDown' );
            $state.go( 'wallet.notification' );
            $scope.isLoading = false;
        };
        $scope.showsSidebar = function() {
            scrollTo( document.getElementsByClassName( 'content-main' ), 0, 600 );
            $rootScope.sideBarActive = $rootScope.sideBarActive === true ? false : true;
        };

        $scope.logout = function() {
            var cards = store.get( 'cards' );
            authenticationFactory.ClearCredentials();
            helperFactory.clearCacheTransfer( cards );
            $state.go( 'auth.login' );
        };

        $scope.$on( 'unreadEvent', function( event, data ) {
            updateUnreadNotification();
        } );

        function updateUnreadNotification() {
            userNotificationsFactory.getList( {
                    filter_field: 'is_read',
                    filter_condition: '=',
                    filter_value: '0',
                    sort_field: 'date_added',
                    sort_direction: 'DESC',
                    limit: '1'
                } ) // jshint ignore:line
                .then( function( response ) {
                    $scope.notificationsCount = response.data.pagination.total_unread; // jshint ignore:line
                } );
        }

        $scope.readAllNotification = function() {
            userNotificationsFactory.getList( {
                    filter_field: 'is_read',
                    filter_condition: '=',
                    filter_value: '0',
                    sort_field: 'date_added',
                    sort_direction: 'DESC',
                    limit: '5'
                } ) // jshint ignore:line
                .then( function( response ) {
                    var dataList = response.data.notifications;
                    angular.forEach( dataList, function( item ) {
                        if ( item.is_read !== '1' ) {
                            var endpointdata = {};
                            endpointdata.id = item.id;
                            endpointdata.is_read = 1;
                            userNotificationsFactory.setRead( endpointdata );
                        }
                    } );

                    helperFactory.clearCacheNotification();
                    updateUnreadNotification();

                } );
        };

        $rootScope.$on( '$translateChangeSuccess', function( event, data ) {
            var varKey = helperFactory.mapControllerToPageTitle( $rootScope.curStateName );
            $rootScope.pagetitle = $translate.instant( 'PAGE_TITLE_TEXT', {
                pagename: $translate.instant( varKey )
            } );
        } );
    } );
