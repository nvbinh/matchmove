'use strict';
describe( 'Controller: NavbarCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
  // load the controller's module
  beforeEach( module( 'viewMultipleWallet', 'mockFirebaseFunctions' ) );
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var NavbarCtrl,
    scope,
    httpBackend,
    API_BASE,
    mobDetectSvc,
    newsData,
    fbFnFactory;
  // langugage based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  // Initialize the controller and a mock scope
  beforeEach( inject( function( $controller, $rootScope, API_BASE, _mobiledetectService_, _firebaseFunctionsFactory_ ) {
    scope = $rootScope.$new();
    API_BASE = API_BASE;
    mobDetectSvc = _mobiledetectService_;
    fbFnFactory = _firebaseFunctionsFactory_;
    NavbarCtrl = $controller( 'NavbarCtrl', {
      $scope: scope
    } );
    newsData = {
              "en_us": {
                "-K0-gvWrQge4SbR3eVlx": {
                  "title": "MatchmovePay",
                  "image": "https://vcard-assets.s3.amazonaws.com/vn/products/vnhdbmc/card-medium.png",
                  "time": "2016-12-28 12:33:34",
                  "description": "Matchmove Pay news 1 content here."
                }
              },
              "vi_vn": {
                "-K0-gvXrQge4SbR3eVlf": {
                  "title": "Vn MatchmovePay",
                  "image": "https://vcard-assets.s3.amazonaws.com/vn/products/vnhdbpcard/card-medium.png",
                  "time": "2016-12-20 12:33:34",
                  "description": "VN - Matchmove Pay news 1 content here."
                }
              }
            };
  } ) );

  it( 'should Have initial Scope variables defined', function() {
    expect( scope.isMobile ).toBeDefined();
    expect( scope.isTablet ).toBeDefined();
    expect( scope.isPhone ).toBeDefined();
  } );
  describe(' getNewsContent data test specs', function(){
        beforeEach(inject(function($controller, $rootScope, _$timeout_, $q){
            scope = $rootScope.$new();
            NavbarCtrl = $controller('NavbarCtrl', {
              $scope: scope
            });
        }));

        it(' :: should return news data as a promise', function() {
            scope.newsRef = fbFnFactory.stubRef('news/' + scope.lang);

            scope.newsRef.on('value', function(snapshot){
                    scope.newsArray = [];
                scope.news = snapshot.val();
                spyOn(angular, 'forEach').and.callThrough();
                // {
                //     scope.newsArray.push(value);
                //     scope.noNewsNotification = false;
                //   });
                    expect(scope.newsArray).toBeDefined();
                    expect(scope.newsArray).toEqual(newsData);
            });
            scope.newsRef.fakeEvent('value', null, newsData);
            scope.getNewsContent();
            scope.newsRef.flush();
        });
    });
} );
