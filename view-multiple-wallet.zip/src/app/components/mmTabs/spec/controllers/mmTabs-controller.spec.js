'use strict';
describe( 'Controller: mmTabsCtrl', function() {
	// load the controller's module
	beforeEach( module( 'viewMultipleWallet' ) );
	var mmTabsCtrl,
		scope;
	// Initialize the controller and a mock scope
	beforeEach( inject( function( $controller, $rootScope ) {
		scope = $rootScope.$new();
		mmTabsCtrl = $controller( 'mmTabsCtrl', {
			$scope: scope
		} );
	} ) );

} );