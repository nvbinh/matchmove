'use strict';
(function(){
	var enableAnimations;

  afterEach(function() {
    enableAnimations && enableAnimations();
    enableAnimations = null;
  });

  beforeEach(function() {

    /**
     * Before each test, require that the 'mmMaterial-mock' module is ready for injection
     * NOTE: assumes that angular-material-mocks.js has been loaded.
     */

    module('viewMultipleWallet');

    module(function() {
      return function($mmUtil, $rootElement, $document, $animate) {
        var DISABLE_ANIMATIONS = 'disable_animations';

        // Create special animation 'stop' function used
        // to set 0ms durations for all animations and transitions

        window.disableAnimations = function disableAnimations() {
          var body = angular.element($document[0].body);
          var head = angular.element($document[0].getElementsByTagName('head')[0]);
          var styleSheet = angular.element( buildStopTransitions() );

          $animate.enabled(false);

          head.prepend(styleSheet);
          body.addClass(DISABLE_ANIMATIONS);

          // Prepare auto-restore
          enableAnimations = function() {
            body.removeClass(DISABLE_ANIMATIONS);
            styleSheet.remove();
          };
        };

        /**
         * Build stylesheet to set all transition and animation
         * durations' to zero.
         */
        function buildStopTransitions() {
          var style = "<style> .{0} * { {1} }</style>";

          return $mmUtil.supplant(style,[ DISABLE_ANIMATIONS,
            "transition -webkit-transition animation -webkit-animation"
                .split(" ")
                .map(function(key){
                  return $mmUtil.supplant("{0}: 0s none !important",[key]);
                })
                .join("; ")
          ]);

        }

      };
    });

    /**
     * Mocks angular.element#focus ONLY for the duration of a particular test.
     *
     * @example
     *
     * it('some focus test', inject(function($document)
     * {
     *   jasmine.mockElementFocus(this); // 'this' is the test instance
     *
     *   doSomething();
     *   expect($document.activeElement).toBe(someElement[0]);
     *
     * }));
     *
     */
    jasmine.mockElementFocus = function(test) {
      var focus = angular.element.prototype.focus;
      inject(function($document) {
        angular.element.prototype.focus = function() {
          $document.activeElement = this[0];
        };
      });
      // Un-mock focus after the test is done
      afterEach(function() {
        angular.element.prototype.focus = focus;
      });
    };



    /**
     * Add special matchers used in the Angular-Material spec.
     */
    jasmine.addMatchers({

      /**
       * Asserts that an element has a given class name.
       * Accepts any of:
       *   {string} - A CSS selector.
       *   {angular.JQLite} - The result of a jQuery query.
       *   {Element} - A DOM element.
       */
      toHaveClass: function() {
        return {
          compare: function(actual, expected) {
            var results = {pass: true};
            var classes = expected.trim().split(/\s+/);

            for (var i = 0; i < classes.length; ++i) {
              if (!getElement(actual).hasClass(classes[i])) {
                results.pass = false;
              }
            }

            var negation = !results.pass ? "" : " not ";

            results.message = "";
            results.message += "Expected '";
            results.message += angular.mock.dump(actual);
            results.message += "'" + negation + "to have class '" + expected + "'.";

            return results;
          }
        };
      },

      /**
       * A helper to match the type of a given value
       * @example expect(1).toBeOfType('number')
       */
      toBeOfType: function(type) {
        return {
          compare: function(actual, expected) {
            var results = {
              pass: typeof actual == expected
            };

            var negation = !results.pass ? "" : " not ";

            results.message = "";
            results.message += "Expected ";
            results.message += angular.mock.dump(actual) + " of type ";
            results.message += (typeof actual);
            results.message += negation + "to have type '" + type + "'.";

            return results;
          }
        };
      },

      toHaveFields: function() {
        return {
          compare: function(actual, expected) {
            var results = {pass: true};

            for (var key in expected) {
              if (!(actual || {}).hasOwnProperty(key) || !angular.equals(actual[key], expected[key])) {
                results.pass = false;
              }
            }

            var negation = !results.pass ? "" : " not ";

            results.message = "";
            results.message += "Expected ";
            results.message += angular.mock.dump(actual) + " of type ";
            results.message += (typeof actual);
            results.message += negation + "to have fields matching '" + angular.mock.dump(expected);

            return results;
          }
        };
      },

      /**
       * Asserts that an element has keyboard focus in the DOM.
       * Accepts any of:
       *   {string} - A CSS selector.
       *   {angular.JQLite} - The result of a jQuery query.
       *   {Element} - A DOM element.
       */
      toBeFocused: function() {
        return {
          'compare': function(actual) {
            var pass =  getElement(actual)[0] === document.activeElement;
            var not = pass ? 'not ' : '';
            return {
              'pass': pass,
              'message': 'Expected element ' + not + 'to have focus.'
            };
          }
        };
      },

      /**
       * Asserts that a given selector matches one or more items.
       * Accepts any of:
       *   {string} - A CSS selector.
       *   {angular.JQLite} - The result of a jQuery query.
       *   {Element} - A DOM element.
       */
      toExist: function() {
        return {
          compare: function(actual) {
            var el = getElement(actual);
            var pass = el.length > 0;
            var not = pass ? 'not ' : '';

            return {
              pass: pass,
              message: 'Expected "' + actual +
              '" ' + not + 'to match element(s), ' +
              'but found ' + el.length +
              ' items in the DOM'
            };
          }
        };
      },

      /**
       * Asserts that a given element contains a given substring in
       * its innerHTML property.
       * Accepts any of:
       *   {string} - A CSS selector.
       *   {angular.JQLite} - The result of a jQuery query.
       *   {Element} - A DOM element.
       */
      toContainHtml: function() {
        return {
          compare: function(actual, expected) {
            var el = getElement(actual);
            var html = el.html();
            var pass = html.indexOf(expected) !== -1;
            var not = pass ? 'not ' : '';

            return {
              pass: pass,
              message: 'Expected element ' + not + 'to contain the html ' +
              '[' + expected + '] in [' + html + ']'
            };
          }
        };
      }
    });

    /**
     * Returns the angular element associated with a css selector or element.
     * @param el {string|!angular.JQLite|!Element}
     * @returns {!angular.JQLite}
     */
    function getElement(el) {
      var queryResult = angular.isString(el) ?
          document.querySelector(el) : el;
      return angular.element(queryResult);
    }

  });
})();

describe('Directive : <mm-tabs>', function () {

  beforeEach(module('viewMultipleWallet'));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var httpBackend;
	// langugage based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  beforeEach(function () {
    jasmine.mockElementFocus(this);

    jasmine.addMatchers({
      toBeActiveTab: function () {
        return {
          compare: function (actual, expected) {
            var fails = [];

            if (!actual.length) {
              fails.push('element not found');
            } else {
              if (!actual.hasClass('mm-active')) {
                fails.push('does not have active class');
              }
              if (actual.attr('aria-selected') != 'true') {
                fails.push('aria-selected is not true');
              }
            }

            var results  = { pass: fails.length === 0 };
            var negation = !results.pass ? "" : " not ";

            results.message = "";
            results.message += "Expected '";
            results.message += angular.mock.dump(actual);
            results.message += negation + "' to be the active tab. Failures: " + fails.join(', ');

            return results;
          }
        };
      }
    });
  });

  function setup (template, scope) {
    var el;
    inject(function ($compile, $rootScope) {
      var newScope = $rootScope.$new();
      for (var key in scope || {}) newScope[key] = scope[key];
      el = $compile(template)(newScope);
      newScope.$apply();
    });
    return el;
  }

  function triggerKeydown (el, keyCode) {
    return el.triggerHandler({
      type:           'keydown',
      keyCode:        keyCode,
      preventDefault: angular.noop
    });
  }

  describe('activating tabs', function () {

    it('should have `._mm` class indicator', inject(function() {
      var tabs = setup(
        '<mm-tabs> ' +
        '   <mm-tab label="a">a</mm-tab>' +
        '   <mm-tab label="b">b</mm-tab>' +
        '</mm-tabs>'
      );

      expect(tabs.find('mm-tabs-content-wrapper').hasClass('_mm')).toBe(true);
    }));

    it('should select first tab by default', function () {
      var tabs = setup(
              '<mm-tabs> ' +
              '   <mm-tab label="a">a</mm-tab>' +
              '   <mm-tab label="b">b</mm-tab>' +
              '</mm-tabs>'
          );
      expect(tabs.find('mm-tab-item').eq(0)).toBeActiveTab();
    });

    it('should select & focus tab on click', inject(function ($document, $rootScope) {
      var tabs     = setup('<mm-tabs>' +
                           '<mm-tab></mm-tab>' +
                           '<mm-tab></mm-tab>' +
                           '<mm-tab ng-disabled="true"></mm-tab>' +
                           '</mm-tabs>');
      var tabItems = tabs.find('mm-tab-item');

      tabs.find('mm-tab-item').eq(1).triggerHandler('click');
      $rootScope.$apply();
      expect(tabItems.eq(1)).toBeActiveTab();

      tabs.find('mm-tab-item').eq(0).triggerHandler('click');
      expect(tabItems.eq(0)).toBeActiveTab();
    }));

    it('should focus tab on arrow if tab is enabled', inject(function ($document, $timeout) {
      var tabs     = setup('<mm-tabs>' +
                           '<mm-tab></mm-tab>' +
                           '<mm-tab ng-disabled="true"></mm-tab>' +
                           '<mm-tab></mm-tab>' +
                           '</mm-tabs>');
      var tabItems = tabs.find('mm-tab-item');

      expect(tabItems.eq(0)).toBeActiveTab();

      // Boundary case, do nothing
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 37);
      expect(tabItems.eq(0)).toBeActiveTab();

      // Tab 0 should still be active, but tab 2 focused (skip tab 1 it's disabled)
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 39); // key:: right arrow
      expect(tabItems.eq(0)).toBeActiveTab();

      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 13); // key:: enter
      expect(tabItems.eq(2)).toBeActiveTab();

      // Boundary case, do nothing
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 39); // key:: right arrow
      expect(tabItems.eq(2)).toBeActiveTab();

      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 13); // key:: enter
      expect(tabItems.eq(2)).toBeActiveTab();

      // Skip tab 1 again, it's disabled
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 37); // key:: left arrow
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 13); // key:: enter
      expect(tabItems.eq(0)).toBeActiveTab();

    }));

    it('should select tab on space or enter', inject(function () {
      var tabs     = setup('<mm-tabs>' +
                           '<mm-tab></mm-tab>' +
                           '<mm-tab></mm-tab>' +
                           '</mm-tabs>');
      var tabItems = tabs.find('mm-tab-item');
      tabs.find('mm-tab-item').eq(0).triggerHandler('click');

      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 39); // key:: right arrow
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 13);// key:: enter
      expect(tabItems.eq(1)).toBeActiveTab();

      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 37); // key:: left arrow
      triggerKeydown(tabs.find('mm-tabs-canvas').eq(0), 32); // key:: space
      expect(tabItems.eq(0)).toBeActiveTab();
    }));

    it('should bind to selected', function () {
      var tabs      = setup('<mm-tabs mm-selected="current">' +
                            '<mm-tab></mm-tab>' +
                            '<mm-tab></mm-tab>' +
                            '<mm-tab></mm-tab>' +
                            '</mm-tabs>');
      var tabItems  = tabs.find('mm-tab-item');
      var dummyTabs = tabs.find('mm-dummy-tab');

      expect(tabItems.eq(0)).toBeActiveTab();
      expect(tabs.scope().current).toBe(0);
      expect(dummyTabs.eq(0).attr('aria-selected')).toBe('true');

      tabs.scope().$apply('current = 1');
      expect(tabItems.eq(1)).toBeActiveTab();

      expect(tabItems.eq(0).attr('aria-selected')).toBe('false');
      expect(dummyTabs.eq(0).attr('aria-selected')).toBe('false');
      expect(dummyTabs.eq(1).attr('aria-selected')).toBe('true');

      tabItems.eq(2).triggerHandler('click');
      expect(tabs.scope().current).toBe(2);
    });

    it('disabling active tab', function () {
      var tabs      = setup('<mm-tabs>' +
                            '<mm-tab ng-disabled="disabled0"></mm-tab>' +
                            '<mm-tab ng-disabled="disabled1"></mm-tab>' +
                            '</mm-tabs>');
      var tabItems  = tabs.find('mm-tab-item');
      var dummyTabs = tabs.find('mm-dummy-tab');

      expect(tabItems.eq(0)).toBeActiveTab();
      expect(dummyTabs.eq(0).attr('aria-selected')).toBe('true');

      tabs.scope().$apply('disabled0 = true');
      expect(tabItems.eq(1)).toBeActiveTab();

      expect(tabItems.eq(0).attr('aria-disabled')).toBe('true');
      expect(dummyTabs.eq(0).attr('aria-disabled')).toBe('true');
      expect(tabItems.eq(1).attr('aria-disabled')).toBe('false');
      expect(dummyTabs.eq(1).attr('aria-disabled')).toBe('false');

      tabs.scope().$apply('disabled0 = false; disabled1 = true');
      expect(tabItems.eq(0)).toBeActiveTab();

      expect(tabItems.eq(0).attr('aria-disabled')).toBe('false');
      expect(dummyTabs.eq(0).attr('aria-disabled')).toBe('false');
      expect(tabItems.eq(1).attr('aria-disabled')).toBe('true');
      expect(dummyTabs.eq(1).attr('aria-disabled')).toBe('true');
    });

  });

  describe('tab label & content DOM', function () {

    it('should support both label types', function () {
      var tabs1 = setup('<mm-tabs>' +
                        '<mm-tab label="super label"></mm-tab>' +
                        '</mm-tabs>');
      expect(tabs1.find('mm-tab-item').text()).toBe('super label');

      var tabs2 = setup('<mm-tabs>' +
                        '<mm-tab><mm-tab-label><b>super</b> label</mm-tab-label></mm-tab>' +
                        '</mm-tabs>');
      expect(tabs2.find('mm-tab-item').text()).toBe('super label');

    });

    it('should support content inside with each kind of label', function () {
      var tabs1 = setup('<mm-tabs>' +
                        '<mm-tab label="label that!"><b>content</b> that!</mm-tab>' +
                        '</mm-tabs>');
      expect(tabs1.find('mm-tab-item').text()).toBe('label that!');
      expect(tabs1[ 0 ].querySelector('mm-tab-content').textContent.trim()).toBe('content that!');

      var tabs2 = setup('<mm-tabs>\
        <mm-tab>\
          <mm-tab-label>label that!</mm-tab-label>\
          <mm-tab-body><b>content</b> that!</mm-tab-body>\
        </mm-tab>\
      </mm-tabs>');
      expect(tabs1.find('mm-tab-item').text()).toBe('label that!');
      expect(tabs1[ 0 ].querySelector('mm-tab-content').textContent.trim()).toBe('content that!');
    });

    /* support for toHaveBeenCalledTimes removed in jasmine 2.0
    it('updates pagination and ink styles when string labels change', function(done) {
      inject(function($rootScope, $timeout) {
        // Setup our initial label
        $rootScope.$apply('label = "Some Label"');

        // Init our variables
        var template = '<mm-tabs><mm-tab label="{{label}}"></mm-tab></mm-tabs>';
        var tabs = setup(template);
        var ctrl = tabs.controller('mmTabs');

        // Flush the tabs controller timeout for initialization.
        $timeout.flush();

        // After the first timeout the mutation observer should have been fired once, because
        // the initialization of the dummy tabs, already causes some mutations.
        // Use setTimeout to add our expectations to the end of the call stack, after the
        // MutationObservers have already fired
        setTimeout(function() {
          // Setup spies
          spyOn(ctrl, 'updatePagination');
          spyOn(ctrl, 'updateInkBarStyles');

          // Update the label to trigger a new update of the pagination and InkBar styles.
          $rootScope.$apply('label = "Another Label"');

          // Use setTimeout to add our expectations to the end of the call stack, after the
          // MutationObservers have already fired
          setTimeout(function() {
            expect(ctrl.updatePagination).toHaveBeenCalledTimes(1);
            expect(ctrl.updateInkBarStyles).toHaveBeenCalledTimes(1);

            done();
          });
        });
      })
    });

    it('updates pagination and ink styles when content label changes', function(done) {
      inject(function($rootScope, $timeout) {
        // Setup our initial label
        $rootScope.$apply('label = "Default Label"');

        // Init our variables
        var template = '' +
          '<mm-tabs>' +
            '<mm-tab>' +
              '<mm-tab-label>{{ label }}</mm-tab-label>' +
            '</mm-tab>' +
          '</mm-tabs>';

        var tabs = setup(template);
        var ctrl = tabs.controller('mmTabs');

        // Flush the tabs controller timeout for initialization.
        $timeout.flush();

        // After the first timeout the mutation observer should have been fired once, because
        // the initialization of the dummy tabs, already causes some mutations.
        // Use setTimeout to add our expectations to the end of the call stack, after the
        // MutationObservers have already fired
        setTimeout(function() {
          // Setup spies
          spyOn(ctrl, 'updatePagination');
          spyOn(ctrl, 'updateInkBarStyles');

          // Update the label to trigger a new update of the pagination and InkBar styles.
          $rootScope.$apply('label = "New Label"');

          // Use setTimeout to add our expectations to the end of the call stack, after the
          // MutationObservers have already fired
          setTimeout(function() {
            expect(ctrl.updatePagination).toHaveBeenCalledTimes(1);
            expect(ctrl.updateInkBarStyles).toHaveBeenCalledTimes(1);

            done();
          });
        });
      })
    });
*/
   /* it('updates pagination and ink styles when HTML labels change', function(done) {
      inject(function($rootScope) {
        // Setup our initial label
        $rootScope.$apply('label = "Some Label"');

        // Init our variables
        var template = '<mm-tabs><mm-tab><mm-tab-label>{{label}}</mm-tab-label></mm-tab></mm-tabs>';
        var tabs = setup(template);
        var ctrl = tabs.controller('mmTabs');

        // Setup spies
        spyOn(ctrl, 'updatePagination');
        spyOn(ctrl, 'updateInkBarStyles');

        // Change the label
        $rootScope.$apply('label="Another Label"');

        // Use window.setTimeout to add our expectations to the end of the call stack, after the
        // MutationObservers have already fired
        window.setTimeout(function() {
          // Fire expectations
          expect(ctrl.updatePagination.calls.count()).toBe(1);
          expect(ctrl.updateInkBarStyles.calls.count()).toBe(1);

          done();
        });
      })
    });*/
  });

  describe('aria', function () {

    it('should link tab content to tabItem with auto-generated ids', function () {
      var tabs       = setup('<mm-tabs>' +
                             '<mm-tab label="label!">content!</mm-tab>' +
                             '</mm-tabs>');
      var tabItem    = tabs.find('mm-dummy-tab');
      var tabContent = angular.element(tabs[ 0 ].querySelector('mm-tab-content'));

      expect(tabs.find('mm-tabs-canvas').attr('role')).toBe('tablist');

      expect(tabItem.attr('id')).toBeTruthy();
      expect(tabItem.attr('role')).toBe('tab');
      expect(tabItem.attr('aria-controls')).toBe(tabContent.attr('id'));

      expect(tabContent.attr('id')).toBeTruthy();
      expect(tabContent.attr('role')).toBe('tabpanel');
      expect(tabContent.attr('aria-labelledby')).toBe(tabItem.attr('id'));

      //Unique ids check
      expect(tabContent.attr('id')).not.toEqual(tabItem.attr('id'));
    });
  });

  describe('<mm-tab>', function () {
    it('should use its contents as the label if there is no label attribute or label/body tags', function () {
      var tab = setup('<mm-tab>test</mm-tab>');
      expect(tab[ 0 ].tagName).toBe('MM-TAB');
      expect(tab.find('mm-tab-label').length).toBe(1);
      expect(tab.find('mm-tab-label').text()).toBe('test');
      expect(tab.find('mm-tab-body').length).toBe(0);
    });
    it('should use its contents as the body if there is a label attribute', function () {
      var tab = setup('<mm-tab label="test">content</mm-tab>');
      expect(tab[ 0 ].tagName).toBe('MM-TAB');
      expect(tab.find('mm-tab-label').length).toBe(1);
      expect(tab.find('mm-tab-body').length).toBe(1);
      expect(tab.find('mm-tab-label').html()).toBe('test');
      expect(tab.find('mm-tab-body').html()).toBe('content');
    });
    it('should convert a label attribute to a label tag', function () {
      var tab = setup('<mm-tab label="test"><mm-tab-body>content</mm-tab-body></mm-tab>');
      expect(tab[ 0 ].tagName).toBe('MM-TAB');
      expect(tab.find('mm-tab-label').length).toBe(1);
      expect(tab.find('mm-tab-body').length).toBe(1);
      expect(tab.find('mm-tab-label').html()).toBe('test');
      expect(tab.find('mm-tab-body').html()).toBe('content');
    });
    it('should not insert a body if there is no content', function () {
      var tab = setup('<mm-tab>' +
                      '<mm-tab-label>test</mm-tab-label>' +
                      '</mm-tab>');
      expect(tab[ 0 ].tagName).toBe('MM-TAB');
      expect(tab.find('mm-tab-label').length).toBe(1);
      expect(tab.find('mm-tab-label').text()).toBe('test');
      expect(tab.find('mm-tab-body').length).toBe(0);
    });
  });

  describe('internal scope', function () {
    it('should have the same internal scope as external', function () {
      var template = '\
        <mm-tabs mm-selected="selectedTab">\
          <mm-tab label="a">\
            <mm-button ng-click="data = false">Set data to false</mm-button>\
          </mm-tab>\
        </mm-tabs>\
      ';
      var element  = setup(template);
      var button   = element.find('mm-button');

      expect(button[ 0 ].tagName).toBe('MM-BUTTON');

      button.triggerHandler('click');

      expect(element.scope().data).toBe(false);
    });
  });

  describe('no tab selected', function () {
    it('should allow cases where no tabs are selected', inject(function () {
      var template = '\
        <mm-tabs mm-selected="selectedIndex">\
          <mm-tab label="a">tab content</mm-tab>\
          <mm-tab label="b">tab content</mm-tab>\
        </mm-tabs>\
      ';
      var element  = setup(template, { selectedIndex: -1 });
      var scope = element.scope();

      expect(scope.selectedIndex).toBe(-1);
      expect(element.find('mm-tab-item').eq(0).hasClass('mm-active')).toBe(false);
      expect(element.find('mm-tab-item').eq(1).hasClass('mm-active')).toBe(false);
      expect(element.find('mm-tabs-content-wrapper').hasClass('ng-hide')).toBe(true);

      element.find('mm-tab-item').eq(0).triggerHandler('click');

      expect(element.find('mm-tab-item').eq(0).hasClass('mm-active')).toBe(true);
      expect(element.find('mm-tab-item').eq(1).hasClass('mm-active')).toBe(false);
      expect(scope.selectedIndex).toBe(0);

      element.find('mm-tab-item').eq(1).triggerHandler('click');

      expect(element.find('mm-tab-item').eq(0).hasClass('mm-active')).toBe(false);
      expect(element.find('mm-tab-item').eq(1).hasClass('mm-active')).toBe(true);
      expect(scope.selectedIndex).toBe(1);

      scope.$apply('selectedIndex = -1');

      expect(scope.selectedIndex).toBe(-1);
      expect(element.find('mm-tab-item').eq(0).hasClass('mm-active')).toBe(false);
      expect(element.find('mm-tab-item').eq(1).hasClass('mm-active')).toBe(false);
      expect(element.find('mm-tabs-content-wrapper').hasClass('ng-hide')).toBe(true);
    }));
  });

  describe('nested tabs', function () {
    it('should properly nest tabs', inject(function () {
      var template = '' +
          '<mm-tabs>' +
          ' <mm-tab label="one">' +
          '   <mm-tabs>' +
          '     <mm-tab><mm-tab-label>a</mm-tab-label></mm-tab>' +
          '     <mm-tab><mm-tab-label>b</mm-tab-label></mm-tab>' +
          '     <mm-tab><mm-tab-label>c</mm-tab-label></mm-tab>' +
          '   </mm-tabs>' +
          ' </mm-tab>' +
          ' <mm-tab label="two">two</mm-tab>' +
          '</mm-tabs>';
      var element = setup(template);
      // first item should be 'one'
      expect(element.find('mm-tab-item').eq(0).text()).toBe('one');
      // first item in nested tabs should be 'a'
      expect(element.find('mm-tabs').find('mm-tab-item').eq(0).text()).toBe('a');
    }));
  });

  describe('mm-pagination-wrapper', function () {
    var template =  '<mm-tabs mm-stretch-tabs="{{stretch}}">' +
                    '  <mm-tab label="label!">content!</mm-tab>' +
                    '</mm-tabs>';

    it('should have inline width if mm-stretch-tabs="never"',
      inject(function ($timeout, $document) {
      var scope = { 'stretch': 'never' };
      var element = setup(template, scope);
      // Appending to body is required for style checks
      angular.element($document.body).append(element);
      // $timeout.flush required to run nextTick inside init();
      $timeout.flush();
      expect(element.find('mm-pagination-wrapper').attr('style').indexOf('width')).toBeGreaterThan(-1);
      element.remove();
    }));

    it('should not have inline width if mm-stretch-tabs="always"',
      inject(function ($timeout, $document) {
      var scope = { 'stretch': 'always' };
      var element = setup(template, scope);
      // Appending to body is required for style checks
      angular.element($document.body).append(element);
      // $timeout.flush required to run nextTick inside init();
      $timeout.flush();
      expect(element.find('mm-pagination-wrapper').attr('style').indexOf('width')).toBe(-1);
      element.remove();
    }));
  });
});
