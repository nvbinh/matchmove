'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:mmTabs
 * @description
 * # mmTabs
 */


/**
 * @ngdoc directive 
 * @restrict E
 *
 * @description
 * The `<mm-tabs>` directive serves as the container for 1..n `<mm-tab>` child directives to produces a Tabs components.
 * In turn, the nested `<mm-tab>` directive is used to specify a tab label for the **header button** and a [optional] tab view
 * content that will be associated with each tab button.
 *
 * Below is the markup for its simplest usage:
 *
 *  <hljs lang="html">
 *  <mm-tabs>
 *    <mm-tab label="Tab #1"></mm-tab>
 *    <mm-tab label="Tab #2"></mm-tab>
 *    <mm-tab label="Tab #3"></mm-tab>
 *  </mm-tabs>
 *  </hljs>
 *
 * Tabs supports three (3) usage scenarios:
 *
 *  1. Tabs (buttons only)
 *  2. Tabs with internal view content
 *  3. Tabs with external view content
 *
 * **Tab-only** support is useful when tab buttons are used for custom navigation regardless of any other components, content, or views.
 * **Tabs with internal views** are the traditional usages where each tab has associated view content and the view switching is managed internally by the Tabs component.
 * **Tabs with external view content** is often useful when content associated with each tab is independently managed and data-binding notifications announce tab selection changes.
 *
 * Additional features also include:
 *
 * *  Content can include any markup.
 * *  If a tab is disabled while active/selected, then the next tab will be auto-selected.
 *
 * ### Explanation of tab stretching
 *
 * Initially, tabs will have an inherent size.  This size will either be defined by how much space is needed to accommodate their text or set by the user through CSS.  Calculations will be based on this size.
 *
 * On mobile devices, tabs will be expanded to fill the available horizontal space.  When this happens, all tabs will become the same size.
 *
 * On desktops, by default, stretching will never occur.
 *
 * This default behavior can be overridden through the `mm-stretch-tabs` attribute.  Here is a table showing when stretching will occur:
 *
 * `mm-stretch-tabs` | mobile    | desktop
 * ------------------|-----------|--------
 * `auto`            | stretched | ---
 * `always`          | stretched | stretched
 * `never`           | ---       | ---
 *
 * @param {integer=} mm-selected Index of the active/selected tab 
 * @param {boolean=} mm-no-ink-bar If present, disables the selection ink bar.
 * @param {string=}  mm-align-tabs Attribute to indicate position of tab buttons: `bottom` or `top`; default is `top`
 * @param {string=} mm-stretch-tabs Attribute to indicate whether or not to stretch tabs: `auto`, `always`, or `never`; default is `auto`
 * @param {boolean=} mm-dynamic-height When enabled, the tab wrapper will resize based on the contents of the selected tab
 * @param {boolean=} mm-border-bottom If present, shows a solid `1px` border between the tabs and their content
 * @param {boolean=} mm-center-tabs When enabled, tabs will be centered provided there is no need for pagination
 * @param {boolean=} mm-no-pagination When enabled, pagination will remain off
 * @param {boolean=} mm-swipe-content When enabled, swipe gestures will be enabled for the content area to jump between tabs
 * @param {boolean=} mm-enable-disconnect When enabled, scopes will be disconnected for tabs that are not being displayed.  This provides a performance boost, but may also cause unexpected issues and is not recommended for most users.
 * @param {boolean=} mm-autoselect When present, any tabs added after the initial load will be automatically selected
 * @param {boolean=} mm-no-select-click When enabled, click events will not be fired when selecting tabs
 *
 * @usage
 * <hljs lang="html">
 * <mm-tabs mm-selected="selectedIndex" >
 *   <img ng-src="img/angular.png" class="centered">
 *   <mm-tab
 *       ng-repeat="tab in tabs | orderBy:predicate:reversed"
 *       mm-on-select="onTabSelected(tab)"
 *       mm-on-deselect="announceDeselected(tab)"
 *       ng-disabled="tab.disabled">
 *     <mm-tab-label>
 *       {{tab.title}}
 *       <img src="img/removeTab.png" ng-click="removeTab(tab)" class="delete">
 *     </mm-tab-label>
 *     <mm-tab-body>
 *       {{tab.content}}
 *     </mm-tab-body>
 *   </mm-tab>
 * </mm-tabs>
 * </hljs>
 *
 */

angular.module( 'viewMultipleWallet' )
  .directive( 'mmTabs', MmTabs );


function MmTabs(  ) {
  return {
    scope: {
      selectedIndex: '=?mmSelected'
    },
    template: function( element, attr ) {
      attr[ "$mmTabsTemplate" ] = element.html();
      return '' +
        '<mm-tabs-wrapper> ' +
        '<mm-tab-data></mm-tab-data> ' +
        '<mm-prev-button ' +
        'tabindex="-1" ' +
        'role="button" ' +
        'aria-label="Previous Page" ' +
        'aria-disabled="{{!$mmTabsCtrl.canPageBack()}}" ' +
        'ng-class="{ \'mm-disabled\': !$mmTabsCtrl.canPageBack() }" ' +
        'ng-if="$mmTabsCtrl.shouldPaginate" ' +
        'ng-click="$mmTabsCtrl.previousPage()"> ' +
        '<div><svg><use xlink:href="#mcw-transferhistory-claim"></svg></div> ' +
        '</mm-prev-button> ' +
        '<mm-next-button ' +
        'tabindex="-1" ' +
        'role="button" ' +
        'aria-label="Next Page" ' +
        'aria-disabled="{{!$mmTabsCtrl.canPageForward()}}" ' +
        'ng-class="{ \'mm-disabled\': !$mmTabsCtrl.canPageForward() }" ' +
        'ng-if="$mmTabsCtrl.shouldPaginate" ' +
        'ng-click="$mmTabsCtrl.nextPage()"> ' +
        '<div><svg><use xlink:href="#mcw-transferhistory-send"></svg></div> ' +              
        '</mm-next-button> ' +
        '<mm-tabs-canvas ' +
        'tabindex="{{ $mmTabsCtrl.hasFocus ? -1 : 0 }}" ' +
        'aria-activedescendant="tab-item-{{$mmTabsCtrl.tabs[$mmTabsCtrl.focusIndex].id}}" ' +
        'ng-focus="$mmTabsCtrl.redirectFocus()" ' +
        'ng-class="{ ' +
        '\'mm-paginated\': $mmTabsCtrl.shouldPaginate, ' +
        '\'mm-center-tabs\': $mmTabsCtrl.shouldCenterTabs ' +
        '}" ' +
        'ng-keydown="$mmTabsCtrl.keydown($event)" ' +
        'role="tablist"> ' +
        '<mm-pagination-wrapper ' +
        'ng-class="{ \'mm-center-tabs\': $mmTabsCtrl.shouldCenterTabs }" ' +
        'mm-tab-scroll="$mmTabsCtrl.scroll($event)"> ' +
        '<mm-tab-item ' +
        'tabindex="-1" ' +
        'class="mm-tab" ' +
        'ng-repeat="tab in $mmTabsCtrl.tabs" ' +
        'role="tab" ' +
        'aria-controls="tab-content-{{::tab.id}}" ' +
        'aria-selected="{{tab.isActive()}}" ' +
        'aria-disabled="{{tab.scope.disabled || \'false\'}}" ' +
        'ng-click="$mmTabsCtrl.select(tab.getIndex());" ' +
        'ng-class="{ ' +
        '\'mm-active\':    tab.isActive(), ' +
        '\'mm-focused\':   tab.hasFocus(), ' +
        '\'mm-disabled\':  tab.scope.disabled ' +
        '}" ' +
        'ng-disabled="tab.scope.disabled" ' +
        'mm-swipe-left="$mmTabsCtrl.nextPage()" ' +
        'mm-swipe-right="$mmTabsCtrl.previousPage()" ' +
        'mm-tabs-template="::tab.label" ' +
        'mm-tabs-template="::tab.label-icon" ' +
        'mm-scope="::tab.parent"></mm-tab-item> ' +
        '<mm-ink-bar></mm-ink-bar> ' +
        '</mm-pagination-wrapper> ' +
        '<mm-tabs-dummy-wrapper class="mm-visually-hidden mm-dummy-wrapper"> ' +
        '<mm-dummy-tab ' +
        'class="mm-tab" ' +
        'tabindex="-1" ' +
        'id="tab-item-{{::tab.id}}" ' +
        'role="tab" ' +
        'aria-controls="tab-content-{{::tab.id}}" ' +
        'aria-selected="{{tab.isActive()}}" ' +
        'aria-disabled="{{tab.scope.disabled || \'false\'}}" ' +
        'ng-focus="$mmTabsCtrl.hasFocus = true" ' +
        'ng-blur="$mmTabsCtrl.hasFocus = false" ' +
        'ng-repeat="tab in $mmTabsCtrl.tabs" ' +
        'mm-tabs-template="::tab.label" ' +
        'mm-tabs-template="::tab.label-icon" ' +
        'mm-scope="::tab.parent"></mm-dummy-tab> ' +
        '</mm-tabs-dummy-wrapper> ' +
        '</mm-tabs-canvas> ' +
        '</mm-tabs-wrapper> ' +
        '<mm-tabs-content-wrapper ng-show="$mmTabsCtrl.hasContent && $mmTabsCtrl.selectedIndex >= 0" class="_mm"> ' +
        '<mm-tab-content ' +
        'id="tab-content-{{::tab.id}}" ' +
        'class="_mm" ' +
        'role="tabpanel" ' +
        'aria-labelledby="tab-item-{{::tab.id}}" ' +
        'mm-swipe-left="$mmTabsCtrl.swipeContent && $mmTabsCtrl.incrementIndex(1)" ' +
        'mm-swipe-right="$mmTabsCtrl.swipeContent && $mmTabsCtrl.incrementIndex(-1)" ' +
        'ng-if="$mmTabsCtrl.hasContent" ' +
        'ng-repeat="(index, tab) in $mmTabsCtrl.tabs" ' +
        'ng-class="{ ' +
        '\'mm-no-transition\': $mmTabsCtrl.lastSelectedIndex == null, ' +
        '\'mm-active\':        tab.isActive(), ' +
        '\'mm-left\':          tab.isLeft(), ' +
        '\'mm-right\':         tab.isRight(), ' +
        '\'mm-no-scroll\':     $mmTabsCtrl.dynamicHeight ' +
        '}"> ' +
        '<div ' +
        'mm-tabs-template="::tab.template" ' +
        'mm-connected-if="tab.isActive()" ' +
        'mm-scope="::tab.parent" ' +
        'ng-if="$mmTabsCtrl.enableDisconnect || tab.shouldRender()"></div> ' +
        '</mm-tab-content> ' +
        '</mm-tabs-content-wrapper>';
    },
    controller: 'mmTabsCtrl',
    controllerAs: '$mmTabsCtrl',
    bindToController: true
  };
}

angular
  .module( 'viewMultipleWallet' )
  .directive( 'mmTabsTemplate', MmTabsTemplate );

function MmTabsTemplate( $compile, $mmUtil ) {
  return {
    restrict: 'A',
    link: link,
    scope: {
      template: '=mmTabsTemplate',
      connected: '=?mmConnectedIf',
      compileScope: '=mmScope'
    },
    require: '^?mmTabs'
  };

  function link( scope, element, attr, ctrl ) {
    if ( !ctrl ) return;

    var compileScope = ctrl.enableDisconnect ? scope.compileScope.$new() : scope.compileScope;

    element.html( scope.template );
    $compile( element.contents() )( compileScope );

    return $mmUtil.nextTick( handleScope );

    function handleScope() {
      scope.$watch( 'connected', function( value ) {
        value === false ? disconnect() : reconnect();
      } );
      scope.$on( '$destroy', reconnect );
    }

    function disconnect() {
      if ( ctrl.enableDisconnect ) $mmUtil.disconnectScope( compileScope );
    }

    function reconnect() {
      if ( ctrl.enableDisconnect ) $mmUtil.reconnectScope( compileScope );
    }
  }
}


angular
  .module( 'viewMultipleWallet' )
  .directive( 'mmTabsDummyWrapper', MmTabsDummyWrapper );

/**
 * @private
 *
 * @param $mmUtil
 * @returns {{require: string, link: link}}
 * @constructor
 * 
 * @ngInject
 */
function MmTabsDummyWrapper( $mmUtil ) {
  return {
    require: '^?mmTabs',
    link: function link( scope, element, attr, ctrl ) {
      if ( !ctrl ) return;

      var observer = new MutationObserver( function( mutations ) {
        ctrl.updatePagination();
        ctrl.updateInkBarStyles();
      } );

      var config = {
        childList: true,
        subtree: true,
        // Per https://bugzilla.mozilla.org/show_bug.cgi?id=1138368, browsers will not fire
        // the childList mutation, once a <span> element's innerText changes.
        // The characterData of the <span> element will change.
        characterData: true
      };

      observer.observe( element[ 0 ], config );

      // Disconnect the observer
      scope.$on( '$destroy', function() {
        if ( observer ) {
          observer.disconnect();
        }
      } );
    }
  };
}


angular
  .module( 'viewMultipleWallet' )
  .directive( 'mmTabLabel', MmTabLabel );

function MmTabLabel() {
  return {
    terminal: true
  };
}

angular
  .module( 'viewMultipleWallet' )
  .directive( 'mmTabItem', MmTabItem );

function MmTabItem() {
  return {
    require: '^?mmTabs',
    link: function link( scope, element, attr, ctrl ) {
      if ( !ctrl ) return;
      // ripple funtionality is not needed for present use case
      //ctrl.attachRipple(scope, element);
    }
  };
}

angular.module( 'viewMultipleWallet' )
  .directive( 'mmTabScroll', MmTabScroll );

function MmTabScroll( $parse ) {
  return {
    restrict: 'A',
    compile: function( $element, attr ) {
      var fn = $parse( attr.mmTabScroll, null, true );
      return function ngEventHandler( scope, element ) {
        element.on( 'mousewheel', function( event ) {
          scope.$apply( function() {
            fn( scope, {
              $event: event
            } );
          } );
        } );
      };
    }
  }
}

angular.module( 'viewMultipleWallet' )
  .directive( 'mmSwipeLeft', getDirective( 'SwipeLeft' ) )
  .directive( 'mmSwipeRight', getDirective( 'SwipeRight' ) )
  .directive( 'mmSwipeUp', getDirective( 'SwipeUp' ) )
  .directive( 'mmSwipeDown', getDirective( 'SwipeDown' ) );

function getDirective( name ) {
  var directiveName = 'mm' + name;
  var eventName = '$mm.' + name.toLowerCase();

  DirectiveFactory.$inject = [ "$parse" ];
  return DirectiveFactory;

  /* @ngInject */
  function DirectiveFactory( $parse ) {
    return {
      restrict: 'A',
      link: postLink
    };

    function postLink( scope, element, attr ) {
      var fn = $parse( attr[ directiveName ] );
      element.on( eventName, function( ev ) {
        scope.$applyAsync( function() {
          fn( scope, {
            $event: ev
          } );
        } );
      } );
    }
  }
}

