'use strict';
describe( 'Controller: topupDbsCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
	// load the controller's module
	beforeEach( module( 'viewMultipleWallet', 'mockFirebaseFunctions' ) );
	// mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
	var topupDbsCtrl,
		scope,
		httpBackend,
		dbsData,
		$timeout,
        fbFnFactory,
        store;
	// langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller
	beforeEach( inject( function( $controller, $rootScope, _$timeout_, _firebaseFunctionsFactory_, _store_ ) {
		scope = $rootScope.$new();
		store = _store_;
        fbFnFactory = _firebaseFunctionsFactory_;
        firebase.apps = [];
		$timeout = _$timeout_;
		topupDbsCtrl = $controller( 'topupDbsCtrl', {
			$scope: scope
		} );
        store.set('selectedLang', 'en_us');
        scope.provider = 'DBS';
        dbsData = {
          "dbs": {
            "en_us": {
              "app": {
                "y8hK": {
                  "description": "<h1>1</h1><p>Login to your iBanking account using POSB/DBS mBanking app<br/></p>",
                  "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/app/step-01.png",
                  "order": "0"
                }
              },
              "atm": {
                "ihrm": {
                  "description": "<h1>1</h1><p>Enter more services</p>",
                  "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                  "order": "1"
                }
              },
              "ibanking": {
                "wMo6": {
                  "description": "<h1>1</h1><p>Visit POSB/DBS iBanking site, and login using your internet banking account<br/></p>",
                  "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                  "order": "0"
                }
              }
            },
            "vi_vn": {
              "app": {
                "R8hK": {
                  "description": "<h1>1</h1><p>VN Login to your iBanking account using POSB/DBS mBanking app<br/></p>",
                  "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/app/step-01.png",
                  "order": "0"
                }
              },
              "atm": {
                "ihrn": {
                  "description": "<h1>1</h1><p>VN Enter more services</p>",
                  "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                  "order": "1"
                }
              },
              "ibanking": {
                "nMo6": {
                  "description": "<h1>1</h1><p>VN Visit POSB/DBS iBanking site, and login using your internet banking account<br/></p>",
                  "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                  "order": "0"
                }
              }
            }
          }
        };
	} ) );

    describe(' get atm data tests', function(){
        it(' :: should return atm data as a promise', function() {
            scope.atmRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang +'/app');
            scope.atmRef.on('value', function(snapshot){
                scope.atmdata = [];
                scope.atmHasData = true;
                scope.atmObj = snapshot.val();
                angular.forEach(scope.atmObj, function(value, key){
                    scope.atmdata.push(value);
                    expect(scope.atmdata).toBeDefined();
                    expect(scope.atmdata).toEqual(dbsData.dbs.en_us.atm.ihrm);
                });

            });
            scope.atmRef.fakeEvent('value', null, dbsData.dbs.en_us.atm);
            scope.loadAtmData();
            // scope.atmRef.flush();
            fbFnFactory.flushAll(scope.atmRef);
        });
    });
    describe(' get ibanking data tests', function(){
        it(' :: should return banking data as a promise', function() {
            scope.ibankingRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang +'/ibanking');
            scope.ibankingRef.on('value', function(snapshot){
                scope.ibankingdata = [];
                scope.ibankingHasData = true;
                scope.ibankingObj = snapshot.val();
                angular.forEach(scope.ibankingObj, function(value, key){
                    scope.ibankingdata.push(value);
                    expect(scope.ibankingdata).toBeDefined();
                    expect(scope.ibankingdata).toEqual(dbsData.dbs.en_us.ibanking.wMo6);
                });

            });
            scope.ibankingRef.fakeEvent('value', null, dbsData.dbs.en_us.ibanking);
            scope.loadIBankingData();
            // scope.ibankingRef.flush();
            fbFnFactory.flushAll(scope.ibankingRef);
        });
    });
    describe(' get app data tests', function(){
        it(' :: should return app data as a promise', function() {
            scope.appRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang +'/atm');
            scope.appRef.on('value', function(snapshot){
                scope.appdata = [];
                scope.appHasData = true;
                scope.appObj = snapshot.val();
                angular.forEach(scope.appObj, function(value, key){
                    scope.appdata.push(value);
                    expect(scope.appdata).toBeDefined();
                    expect(scope.appdata).toEqual(dbsData.dbs.en_us.app.y8hK);
                });

            });
            scope.appRef.fakeEvent('value', null, dbsData.dbs.en_us.app);
            scope.loadAppData();
            // scope.appRef.flush();
            fbFnFactory.flushAll(scope.appRef);
        });
    });
} );
