'use strict';

angular.module( 'viewMultipleWallet' )
    .controller( 'topupDbsCtrl', function ( $rootScope, CONTENT_NET, store, $scope, $q, $timeout, PubSub ) {
        $scope.provider = 'DBS';
        $scope.placeName = 'DBS';
        $scope.types = 'atm';
        $scope.walletTopupDBS = {
            active: 0
        };
        $scope.orderField = 'order';

        $scope.loadAtmData = function () {
            if (firebase.apps.length === 0) {
              $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.lang = store.get('selectedLang');
            $scope.atmRef = $rootScope.firebaseApp.database().ref( 'guides/payments/'+angular.lowercase($scope.provider)+ '/' + $scope.lang +'/atm' );

            $scope.atmRef.on('value', function(snapshot){
                $scope.atmdata = [];
                $scope.atmHasData = true;
                $scope.atmObj = snapshot.val();
                angular.forEach($scope.atmObj, function(value, key){
                    $scope.atmdata.push(value);
                });
            });
        };
        $scope.loadAtmData();
        PubSub.subscribe('language-changed', $scope.loadAtmData);

        $scope.loadAppData = function () {
            if (firebase.apps.length === 0) {
              $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.lang = store.get('selectedLang');
            $scope.appRef = $rootScope.firebaseApp.database().ref( 'guides/payments/'+angular.lowercase($scope.provider)+ '/' + $scope.lang +'/app' );

            $scope.appRef.on('value', function(snapshot){
                $scope.appdata = [];
                $scope.appHasData = true
                $scope.appObj = snapshot.val();
                angular.forEach($scope.appObj, function(value, key){
                    $scope.appdata.push(value);
                  });
            });

        };
        $scope.loadAppData();
        PubSub.subscribe('language-changed', $scope.loadAppData);

        $scope.loadIBankingData = function () {
            if (firebase.apps.length === 0) {
              $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.lang = store.get('selectedLang');
            $scope.ibankingRef = $rootScope.firebaseApp.database().ref( 'guides/payments/'+angular.lowercase($scope.provider)+ '/' + $scope.lang +'/ibanking' );

            $scope.ibankingRef.on('value', function(snapshot){
                $scope.ibankingdata = [];
                $scope.ibankingHasData = true
                $scope.ibankingObj = snapshot.val();
                angular.forEach($scope.ibankingObj, function(value, key){
                    $scope.ibankingdata.push(value);
                  });
            });
        };
        $scope.loadIBankingData();
        PubSub.subscribe('language-changed', $scope.loadIBankingData);
    } );
