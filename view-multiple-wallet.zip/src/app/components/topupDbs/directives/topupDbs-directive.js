'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:doKyc
 * @description
 * # doKyc
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'topupDbs', function () {
        return {
            templateUrl: 'app/components/topupDbs/partials/topupDbs.html',
            restrict: 'A',
            controller: 'topupDbsCtrl',
            transclude: true,
            replace: true,
            link: function ( scope, element, attrs ) {

            }
        };
    } );
