/* global inject */
/* global expect */
/* global it */
/* global beforeEach */
/* global describe */

'use strict';
describe('Directive: receipt', function () {
// load the directive's module
beforeEach(module('viewMultipleWallet'));
// mock constants
	beforeEach( module( 'viewMultipleWallet', function( $provide ) {
		$provide.constant( "TRANSLATION_PARAMS", {
			"partFilesPath": "../assets/locales/",
			"preferredLanguage": "vi_vn",
			"client": "hdb",
			"source": "http://localhost:3000/assets/hdb/locales\/",
			"supportedLanguages": [ {
				"i18n": "en_us",
				"name": "English"
			}, {
				"i18n": "vi_vn",
				"name": "Vietnamese"
			} ]
		} );
	} ) );
var rootScope,
    scope,
    httpBackend,
    document,
    element,
    compile;
   // language based mock calls
	beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
		httpBackend = $httpBackend;
		var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
		for ( var i = 0; i < lngth; i++ ) {
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
		}
	} ) );
beforeEach(inject(function ($rootScope, $compile, _$document_ ) {
	rootScope = $rootScope;
    scope = $rootScope.$new();
	document = _$document_;
    rootScope.transfer = {};
    rootScope.transfer.paymentRefId = 'ABCDEFH-IJ-564';
    rootScope.transfer.transactionDate = '2016-02-10';
	element = angular.element('<receipt-remittance></receipt-remittance>');
	compile = $compile;
	compile(element)(scope);
	scope.$digest();
}));
afterEach( function() {
		httpBackend.flush();
		httpBackend.verifyNoOutstandingExpectation();
		httpBackend.verifyNoOutstandingRequest();
	} );
it('initialize', inject(function () {
	expect(element.find('aside').length).toEqual(1);
}));
});
