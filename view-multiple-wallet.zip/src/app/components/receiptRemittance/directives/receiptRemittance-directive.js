'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:receipt
 * @description
 * # receipt
 */
angular.module('viewMultipleWallet')
    .directive('receiptRemittance', function (BASE_CURRENCY, $rootScope) {
        return {
            templateUrl: 'app/components/receiptRemittance/partials/receiptRemittance.html',
            restrict: 'E',
            scope: {
                receivableAmountDestinationCurrency: '=?receivableAmount',
                provider: '=?provider',
                fees: '=?providerFee',
                state:'=?retrivalState',
                finalTransaction:'=?finalTransaction',
                baseCurrency:'=?baseCurrency',
                errorMsg:'=?errorMsg',
                baseCurrencyunit:'=?baseCurrencyunit',
                destinationCurrencyunit:'=?destinationCurrencyunit',
                recipientCurrency:'=?destinationCurrency',
                total: '=?totalAmount',
                amountChargedLocalCurrency:'=?totalAmountlocal',
                refId: '=?refId',
                paymentRefId: '=?transferRefid',
                date: '=?transactionDate',
                remitStep: "=?remitStep"
            },
            link: function(scope) {
                if (typeof $rootScope.transfer !== 'undefined') {
                    scope.paymentRefId = $rootScope.transfer.paymentRefId;
                    scope.date = $rootScope.transfer.transactionDate;
                }
            }
        };
    });
