'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:notifyEmailVerifyCtrl
 * @description
 * # notifyEmailVerifyCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('notifyEmailVerifyCtrl', function (EMAIL_VERIFICATION_URL , HTTP_HOST, $rootScope, $scope, $log, store, authEmailFactory, $cookieStore) {
      $scope.verificationSent = false;
      $scope.endpoint = HTTP_HOST + EMAIL_VERIFICATION_URL;
      $scope.payload = {};
      $scope.payload.endpoint = $scope.endpoint;
      $scope.requestEmailVerification = function() {
          $scope.emailResendError = false;
          $scope.isLoading = true;
          authEmailFactory.getToken($scope.payload)
            .then(function(data, status){
                $rootScope.userInfo = $cookieStore.get('userInfo');
                store.set(data.data.token, { user: $rootScope.globals.currentUser.email });
                $scope.isLoading = false;
                $scope.verificationSent = true;
            },function(response){
                $scope.isLoading = false;
                $scope.emailResendError = true;
                $scope.validationError = response.statusText;
            });
      };
      $scope.reRequestEmailVerification = function() {
          $scope.emailResend = false;
          $scope.isLoadingResend = true;
          authEmailFactory.getToken($scope.payload)
            .then(function(data, status){
                $rootScope.userInfo = $cookieStore.get('userInfo');
                store.set(data.data.token, { user: $rootScope.globals.currentUser.email });
                $scope.isLoadingResend = false;
                $scope.emailResend = true;
            },function(response){
                $scope.isLoadingResend = false;
                $scope.emailResendError = true;
                $scope.validationError = response.statusText;
            });
      };
  });
