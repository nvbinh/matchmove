'use strict';
describe('Controller: notifyEmailVerifyCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var notifyEmailVerifyCtrl,
      authEmail,
      scope,
      httpBackend,
      API_BASE,
      tokenInfo,
      $rootScope;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _authEmailFactory_, HTTP_HOST, EMAIL_VERIFICATION_URL, _API_BASE_) {
    $rootScope = $rootScope;
    scope = $rootScope.$new();
    authEmail = _authEmailFactory_;
    API_BASE = _API_BASE_;

    notifyEmailVerifyCtrl = $controller('notifyEmailVerifyCtrl', {
      $scope: scope
    });
    $rootScope.globals = {};
    $rootScope.globals.currentUser = {};
    $rootScope.globals.currentUser.email = 'balajiv@chimeratechnologies.com';
    scope.verificationSent = false;
    scope.endpoint = HTTP_HOST + EMAIL_VERIFICATION_URL;
    scope.payload = {};
    scope.payload.endpoint = scope.endpoint;

    tokenInfo = {
      "status": "success",
      "token": "25e2805a24c19b4e0e530f9d249801b2"
    };
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('requestEmailVerification function get token Success', function(){
     httpBackend.whenPOST(API_BASE + 'users/authentications/email').respond(200, {data: tokenInfo}, {}, "HTTP/4.1 200 OK");
     scope.requestEmailVerification();
     httpBackend.flush();
     expect(scope.verificationSent).toBeTruthy();
  });
  it('requestEmailVerification function Error response', function(){
     httpBackend.whenPOST(API_BASE + 'users/authentications/email').respond(400, 'error 400 getting', {}, "HTTP/4.1 400 authtokenerror: could not get token");
     scope.requestEmailVerification();
     httpBackend.flush();
     expect(scope.validationError).toBe('HTTP/4.1 400 authtokenerror: could not get token');
     expect(scope.emailResendError).toBeTruthy();
  });
  it('re-requestEmailVerification function get token Success', function(){
     httpBackend.whenPOST(API_BASE + 'users/authentications/email').respond(200, {data: tokenInfo}, {}, "HTTP/4.1 200 OK");
     scope.reRequestEmailVerification();
     httpBackend.flush();
     expect(scope.emailResend).toBeTruthy();
  });
  it('re-requestEmailVerification function Error response', function(){
     httpBackend.whenPOST(API_BASE + 'users/authentications/email').respond(400, 'error 400 getting', {}, "HTTP/4.1 400 authtokenerror: could not get token");
     scope.reRequestEmailVerification();
     httpBackend.flush();
     expect(scope.validationError).toBe('HTTP/4.1 400 authtokenerror: could not get token');
     expect(scope.emailResendError).toBeTruthy();
  });
});
