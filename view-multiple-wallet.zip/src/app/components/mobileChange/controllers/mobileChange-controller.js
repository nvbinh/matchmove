/* global intlTelInputUtils */
'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:mobileChangeCtrl
 * @description
 * # mobileChangeCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'mobileChangeCtrl', function ( $scope, $log, $filter, $analytics, userFactory, authMobileFactory, ngDialog, $timeout, $rootScope, $state, helperFactory, OTP_VERIFY_WORKFLOW, CacheFactory ) {

        /*jshint camelcase: false */
        var $translate = $filter( 'translate' );

        $scope.loading = false;
        $scope.success = false;
        $scope.user = {};
        $scope.user.mobile = '';
        $scope.user.otpValue = '';
        $scope.countryList = helperFactory.getCountryList( $state.current.name );
        $scope.otpVerifyWorkflow = angular.fromJson(OTP_VERIFY_WORKFLOW);
        $scope.otpVerifySwitch = $scope.otpVerifyWorkflow.switch == 'ON' ? true : false;
        $scope.user.phoneNumberCtrl;

        $scope.submitChangeMobileForm = function () {
            $scope.user.mobile_country_code = $scope.user.phoneNumberCtrl.getSelectedCountryData().dialCode;
            $scope.user.mobile = $scope.user.phoneNumberCtrl.getNumber( intlTelInputUtils.numberFormat.NATIONAL ).replace( /[- )(]/g, '' ).replace( /^0/, '' );
            $scope.isLoading = true;
            $scope.changeMobileerror = false;
            $scope.modalOtpMessageTranslate = {};
            $scope.modalOtpMessageTranslate.userMobile = $scope.user.mobile_country_code + ' ' + $scope.user.mobile;

            userFactory.updateUser( $scope.user )
                .then( function ( response ) {
                    $scope.loading = false;
                    $scope.isLoading = false;
                    $scope.verificationSent = true;
                    $scope.token = response.data.token;
                    $analytics.eventTrack( 'Account Details : Mobile Change - Request OTP : Success', {
                        category: 'Account Details',
                        label: 'Account Details : Mobile Change - Request OTP : Success'
                    } );
                }, function ( response ) {
                    if ( response.status === 401 ) {
                        $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.401' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - Request OTP : Error', {
                            category: 'Error 401',
                            label: 'Account Details : Mobile Change - Request OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.status === 400 ) {
                        if ( response.statusText.indexOf( 'userPhoneAlreadyInUse' ) > -1 ) {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400.MOBILEINUSE' );
                        } else if ( response.statusText.indexOf( 'userAuthenticationValidationFailed' ) > -1 ) {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400.TOKENINVALID' );
                        } else if ( response.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400.TOKENEXPIRED' );
                        } else {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400' );
                        }
                        $analytics.eventTrack( 'Account Details : Mobile Change - Request OTP : Error', {
                            category: 'Account Details',
                            label: 'Account Details : Mobile Change - Request OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.status === 500 ) {
                        $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.500' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - Request OTP : Error', {
                            category: 'Error 500',
                            label: 'Account Details : Mobile Change - Request OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else {
                        $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.GENERIC' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - Request OTP : Error', {
                            category: 'Account Details',
                            label: 'Account Details : Mobile Change - Request OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    }
                    $scope.changeMobileerror = true;
                    $scope.isLoading = false;
                } );
        };

        $scope.submitChangeMobileFormWithoutOTP = function(){
            $scope.user.mobile_country_code = $scope.user.phoneNumberCtrl.getSelectedCountryData().dialCode;
            $scope.user.mobile = $scope.user.phoneNumberCtrl.getNumber( intlTelInputUtils.numberFormat.NATIONAL ).replace( /[- )(]/g, '' ).replace( /^0/, '' );
            $scope.isLoading = true;
            $scope.changeMobileerror = false;

            $scope.userCache = CacheFactory.get('userCache');
            $scope.userData = $scope.userCache.get('user');

            userFactory.updateUser( $scope.user )
                .then( function ( response ) {
                    $scope.loading = false;
                    $scope.isLoading = false;
                    $scope.changeMobileSuccess = true;
                    $scope.changeMobileSuccessMsg = $translate('COMPONENT.MOBILE_CHANGE.SUCCESS');

                    $analytics.eventTrack( 'Account Details : Mobile Change - without OTP : Success', {
                        category: 'Account Details',
                        label: 'Account Details : Mobile Change - without OTP : Success'
                    } );

                    $timeout(function(){
                        ngDialog.closeAll();
                        helperFactory.removeUserCache();
                        userFactory.getUser(false);
                    }, 2900);
                    $timeout(function(){
                        $state.go('.', {}, {reload: true});
                    }, 4000);
                }, function ( response ) {
                    if ( response.status === 401 ) {
                        $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.401' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - without OTP : Error', {
                            category: 'Error 401',
                            label: 'Account Details : Mobile Change - without OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.status === 400 ) {
                        if ( response.statusText.indexOf( 'userPhoneAlreadyInUse' ) > -1 ) {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400.MOBILEINUSE' );
                        } else if ( response.statusText.indexOf( 'userAuthenticationValidationFailed' ) > -1 ) {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400.TOKENINVALID' );
                        } else if ( response.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400.TOKENEXPIRED' );
                        } else {
                            $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.400' );
                        }
                        $analytics.eventTrack( 'Account Details : Mobile Change - without OTP : Error', {
                            category: 'Account Details',
                            label: 'Account Details : Mobile Change - without OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.status === 500 ) {
                        $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.500' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - without OTP : Error', {
                            category: 'Error 500',
                            label: 'Account Details : Mobile Change - without OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else {
                        $scope.changeMobilevalidationError = $translate( 'ERRORS.VALIDATION.USER.MOBILE_CHANGE.GENERIC' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - without OTP : Error', {
                            category: 'Account Details',
                            label: 'Account Details : Mobile Change - without OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    }
                    $scope.changeMobileerror = true;
                    $scope.isLoading = false;
                } );
        }


        $scope.resendToken = function () {
            $scope.flagOtp = false;
            userFactory.updateUser( $scope.user )
                .then( function ( response ) {
                    $scope.token = response.data.token;
                    $scope.newTokenSent = true;
                    $analytics.eventTrack( 'Re-Request New OTP : Success', {
                        category: 'OTP',
                        label: 'Request New OTP : Success'
                    } );

                    $scope.flagOtp = true;
                    $scope.messageTextOtp = $translate( 'MODAL.OTP.TOKEN_RESEND_SUCCESS' );
                    $scope.messageIcon = 'mcw-common-congratulations';
                    $scope.messageType = 'success';
                }, function ( response ) {
                    if ( response.status === 500 ) {
                        $scope.messageTextOtp = $translate( 'ERRORS.OTP.TOKEN_RESEND_FAILED.500' );
                        $analytics.eventTrack( 'Re-Request New OTP : Error', {
                            category: 'Error 500',
                            label: 'Request/Re-Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                        } );
                    } else {
                        $scope.messageTextOtp = $translate( 'ERRORS.OTP.TOKEN_RESEND_FAILED.GENERIC' );
                        $analytics.eventTrack( 'Re-Request New OTP : Error', {
                            category: 'OTP',
                            label: 'Request/Re-Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                        } );
                    }

                    $scope.flagOtp = true;
                    $scope.messageIcon = 'mcw-common-alert';
                    $scope.messageType = 'error';
                } );
        };

        $scope.submitVerifyMobileForm = function () {
            $scope.flagOtp = false;
            $scope.isLoading = true;
            authMobileFactory.verifyOtp( $scope.token, $scope.user.otpValue.toString() )
                .then( function () {
                    $scope.isLoading = false;
                    $scope.loading = false;

                    $scope.flagOtp = true;
                    $scope.messageTextOtp = $translate( 'MODAL.MOBILE_CHANGE.VERIFICATION_SUCCESS' );
                    $scope.messageIcon = 'mcw-common-congratulations';
                    $scope.messageType = 'success';

                    $rootScope.$broadcast( 'updateOTPStatus' );
                    $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Success', {
                        category: 'Account Details',
                        label: 'Account Details : Mobile Change - Request OTP : Success'
                    } );
                    $timeout( function () {
                        ngDialog.closeAll();
                    }, parseInt( 4500 ) );
                }, function ( response ) {
                    if ( response.status === 500 ) {
                        $scope.messageTextOtp = $translate( 'ERRORS.VALIDATION.OTP.500' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Error', {
                            category: 'Error 500',
                            label: 'Account Details : Mobile Change - Verify OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.status === 401 ) {
                        $scope.messageTextOtp = $translate( 'ERRORS.VALIDATION.OTP.401' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Error', {
                            category: 'Account Details',
                            label: 'Account Details : Mobile Change - Verify OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    } else if ( response.status === 400 ) {
                        if ( response.statusText.indexOf( 'userAuthenticationValidationFailed' ) > -1 ) {
                            $scope.messageTextOtp = $translate( 'ERRORS.VALIDATION.OTP.400.INVALID_OTP' );
                            $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Error', {
                                category: 'Account Details',
                                label: 'Account Details : Mobile Change - Verify OTP : Error: ' + response.status + ' : ' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                            $scope.messageTextOtp = $translate( 'ERRORS.VALIDATION.OTP.400.EXPIRED' );
                            $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Error', {
                                category: 'Account Details',
                                label: 'Account Details : Mobile Change - Verify OTP : Error: ' + response.status + ' : ' + response.statusText
                            } );
                        } else {
                            $scope.messageTextOtp = $translate( 'ERRORS.VALIDATION.OTP.400.FALLBACK' );
                            $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Error', {
                                category: 'Account Details',
                                label: 'Account Details : Mobile Change - Verify OTP : Error: ' + response.status + ' : ' + response.statusText
                            } );
                        }
                    } else {
                        $scope.messageTextOtp = $translate( 'ERRORS.VALIDATION.OTP.GENERIC' );
                        $analytics.eventTrack( 'Account Details : Mobile Change - Verify OTP : Error', {
                            category: 'Account Details',
                            label: 'Account Details : Mobile Change - Verify OTP : Error: ' + response.status + ' : ' + response.statusText
                        } );
                    }

                    $scope.flagOtp = true;
                    $scope.messageIcon = 'mcw-common-alert';
                    $scope.messageType = 'error';

                    $scope.isLoading = false;

                } );
        };
    } );
