'use strict';
describe( 'Controller: mobileChangeCtrl - with OTP workflow', function() {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( "OTP_VERIFY_WORKFLOW",  {"switch":"ON"});
    } ) );
    var mobileChangeCtrl,
        phoneNumberCtrl,
        httpBackend,
        authMobileFactory,
        userFactory,
        scope,
        verifyReturn,
        $q,
        deferred,
        cacheFactory,
        helperFactory,
        element,
        ngDialog;
    // language based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function( $controller, $rootScope, API_BASE, _authMobileFactory_, _userFactory_, _$q_, $compile, OTP_VERIFY_WORKFLOW, _CacheFactory_, _helperFactory_, _ngDialog_ ) {
        scope = $rootScope.$new();
        $q = _$q_;
        httpBackend.whenPUT( API_BASE + 'users' ).respond( 200, {
            token: ''
        } );
        authMobileFactory = _authMobileFactory_;
        userFactory = _userFactory_;
        cacheFactory = _CacheFactory_;
        helperFactory = _helperFactory_;
        ngDialog = _ngDialog_;
        mobileChangeCtrl = $controller( 'mobileChangeCtrl', {
            $scope: scope
        } );
        scope.user = {};
        scope.user.mobile = '';
        scope.user.phoneNumberCtrl;
        scope.user.otpValue = 132433;

        spyOn(helperFactory, 'getCountryList').and.callThrough();
        spyOn(ngDialog, 'closeAll').and.callThrough();
        element = angular.element('<input type="tel" ng-model="user.mobile" tabindex="1" name="mobile" intl-tel-input intl-tel-input-controller="user.phoneNumberCtrl" intl-tel-input-options="countryList" required>')
        $compile(element)(scope);
        scope.$digest();
    } ) );
    afterEach( function() {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'should have scope to be defined', function() {
        expect( scope ).toBeDefined();
    } );
    it( 'should have scope loading set as false on load', function() {
        expect( scope.loading ).toBe( false );
    } );
    it( 'should have scope success set as false on load', function() {
        expect( scope.success ).toBe( false );
    } );
    it( 'should have user', function() {
        expect( scope.user ).toBeDefined();
    } );
    it( 'should have mobile', function() {
        expect( scope.user.mobile ).toBeDefined();
        expect( scope.user.mobile ).toEqual( '' );
    } );
    it( 'should have otp value', function() {
        expect( scope.user.otpValue ).toBeDefined();
        expect( scope.user.otpValue ).toEqual( 132433 );
    } );
    it( 'countryList should be defined', function() {
        expect( scope.countryList ).toBeDefined();
    } );
    describe( 'submit change mobile form success', function () {
        beforeEach( inject( function () {

            var response = {};
            response.data = {};
            response.data.token = '345353453245hjbfjhf';
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.resolve(response);
                return deferred.promise;
            } );

            scope.submitChangeMobileForm();
        } ) );

        it( 'should have loading', function () {
            expect( scope.loading ).toBeDefined();
            expect( scope.isLoading ).toBeDefined();
            expect( userFactory.updateUser ).toHaveBeenCalled();
        } );
    } );
    describe( 'submit change mobile form errors', function() {

        it( 'error 500', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 500,
                    statusText: 'HTTP/4.01 500 OTP error here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 userPhoneAlreadyInUse', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 userPhoneAlreadyInUse here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 userAuthenticationValidationFailed', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 userAuthenticationValidationFailed here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 userAuthenticationValidationTokenExpired', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 userAuthenticationValidationTokenExpired here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 generic error', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 generic error'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 401 ', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 401,
                    statusText: 'HTTP/4.01 401 error here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 503 ', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 503,
                    statusText: 'HTTP/4.01 503 internal server error here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileForm();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
    } );

    describe( 'submit resend otp success', function() {
        beforeEach( inject( function() {
            scope.user = {};
            scope.user.mobile_country_code = '65';
            scope.user.mobile = '91626388';
            scope.user.otpValue = '';
            var response = {};
            response.data = {};
            spyOn( userFactory, 'updateUser' ).and.callFake( function() {
                return {
                    then: function( callback ) {
                        return callback( response );
                    }
                };
            } );
            scope.resendToken();
        } ) );
        it( 'should have success message box when resend otp successful', function() {
            userFactory.updateUser( scope.user ).then( function( data, status, headers, config ) {
                expect( scope.newTokenSent ).toBeTruthy();
                expect( scope.flagOtp ).toBeTruthy();
                expect( scope.messageIcon ).toEqual( 'mcw-common-congratulations' );
                expect( scope.messageType ).toEqual( 'success' );
            } );
        } );
    } );

    describe( 'submit resend otp fail', function() {
        beforeEach( inject( function() {
            scope.user = {};
            scope.user.mobile_country_code = '65';
            scope.user.mobile = '91626388';
            scope.user.otpValue = '';
            deferred = $q.defer();
        } ) );
        it( 'error 500', function() {
            deferred.reject( {
                status: 500,
                statusText: 'HTTP/4.01 500 server error here'
            } );
            spyOn( userFactory, 'updateUser' ).and.returnValue( deferred.promise );
            scope.resendToken();
            scope.$digest();
            expect( scope.messageType ).toBe( 'error' );
            expect( userFactory.updateUser ).toHaveBeenCalled();
        } );
        it( 'error 400', function() {
            deferred.reject( {
                status: 400,
                statusText: 'HTTP/4.01 400 validation error here'
            } );
            spyOn( userFactory, 'updateUser' ).and.returnValue( deferred.promise );
            scope.resendToken();
            scope.$digest();
            expect( scope.messageType ).toBe( 'error' );
            expect( userFactory.updateUser ).toHaveBeenCalled();
        } );
    } );

    describe( 'submit verify mobile form success', function() {
        beforeEach( inject( function() {
            scope.token = '';
            spyOn( authMobileFactory, 'verifyOtp' ).and.callFake( function() {
                return {
                    then: function( callback ) {
                        return callback();
                    }
                };
            } );
            scope.submitVerifyMobileForm();
        } ) );
        it( 'message box is hidden when initialize', function() {
            expect( scope.flagOtp ).toBeTruthy();
            expect( authMobileFactory.verifyOtp ).toHaveBeenCalled();
        } );
    } );
    describe( 'submit verify mobile form fail errors', function() {
        beforeEach( inject( function() {
            scope.token = '';
            deferred = $q.defer();
        } ) );
        it( 'message box is hidden when initialize', function() {
            deferred.reject( {
                status: 400,
                statusText: 'HTTP/4.01 400 userAuthenticationValidationFailed error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.flagOtp ).toBeTruthy();
            expect( scope.messageType ).toBe( 'error' );
            expect( authMobileFactory.verifyOtp ).toHaveBeenCalled();
        } );
        it( 'error 400 userAuthenticationValidationFailed', function() {
            deferred.reject( {
                status: 400,
                statusText: 'HTTP/4.01 400 userAuthenticationValidationFailed error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.messageTextOtp ).toBeDefined();
            expect( scope.messageType ).toBe( 'error' );
        } );
        it( 'error 400 userAuthenticationValidationTokenExpired', function() {
            deferred.reject( {
                status: 400,
                statusText: 'HTTP/4.01 400 userAuthenticationValidationTokenExpired error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.messageTextOtp ).toBeDefined();
            expect( scope.messageType ).toBe( 'error' );
        } );
        it( 'error 400 fallback', function() {
            deferred.reject( {
                status: 400,
                statusText: 'HTTP/4.01 400 fallback error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.messageTextOtp ).toBeDefined();
            expect( scope.messageType ).toBe( 'error' );
        } );
        it( 'error 503 OTP generic', function() {
            deferred.reject( {
                status: 503,
                statusText: 'HTTP/4.01 503 OTP generic error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.messageTextOtp ).toBeDefined();
            expect( scope.messageType ).toBe( 'error' );
        } );
        it( 'error 401 OTP generic', function() {
            deferred.reject( {
                status: 401,
                statusText: 'HTTP/4.01 401 OTP error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.messageTextOtp ).toBeDefined();
            expect( scope.messageType ).toBe( 'error' );
        } );
        it( 'error 500 OTP', function() {
            deferred.reject( {
                status: 500,
                statusText: 'HTTP/4.01 500 OTP error here'
            } );
            spyOn( authMobileFactory, 'verifyOtp' ).and.returnValue( deferred.promise );
            scope.submitVerifyMobileForm();
            scope.$digest();
            expect( scope.messageTextOtp ).toBeDefined();
            expect( scope.messageType ).toBe( 'error' );
        } );
    } );
} );

describe( 'Controller: mobileChangeCtrl - WITHOUT OTP workflow', function() {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( "OTP_VERIFY_WORKFLOW",  {"switch":"OFF"});
    } ) );
    var mobileChangeCtrl,
        phoneNumberCtrl,
        httpBackend,
        authMobileFactory,
        userFactory,
        scope,
        verifyReturn,
        $q,
        deferred,
        cacheFactory,
        helperFactory,
        element,
        timeout,
        state,
        ngDialog;
    // language based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function( $controller, $rootScope, API_BASE, _authMobileFactory_, _userFactory_, _$q_, OTP_VERIFY_WORKFLOW, _CacheFactory_, _helperFactory_, $compile, _$timeout_, _$state_, _ngDialog_ ) {
        scope = $rootScope.$new();
        $q = _$q_;
        //
        authMobileFactory = _authMobileFactory_;
        userFactory = _userFactory_;
        cacheFactory = _CacheFactory_;
        helperFactory = _helperFactory_;
        timeout = _$timeout_;
        state = _$state_;
        ngDialog = _ngDialog_;
        mobileChangeCtrl = $controller( 'mobileChangeCtrl', {
            $scope: scope
        } );
        scope.user = {};
        scope.user.mobile = '';
        scope.user.phoneNumberCtrl;

        spyOn(helperFactory, 'getCountryList').and.callThrough();
        spyOn(timeout, 'flush').and.callThrough();
        spyOn(state, 'go').and.callThrough();
        spyOn(ngDialog, 'closeAll').and.callThrough();
        element = angular.element('<input type="tel" ng-model="user.mobile" tabindex="1" name="mobile" intl-tel-input intl-tel-input-controller="user.phoneNumberCtrl" intl-tel-input-options="countryList" required>')
        $compile(element)(scope);
        scope.$digest();
    } ) );
    afterEach( function() {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'should have scope to be defined', function() {
        spyOn( userFactory, 'updateUser' ).and.callThrough();
        expect( scope ).toBeDefined();
    } );
    it( 'should have scope loading set as false on load', function() {
        spyOn( userFactory, 'updateUser' ).and.callThrough();
        expect( scope.loading ).toBe( false );
    } );
    it( 'should have scope success set as false on load', function() {
        spyOn( userFactory, 'updateUser' ).and.callThrough();
        expect( scope.success ).toBe( false );
    } );
    it( 'should have user', function() {
        spyOn( userFactory, 'updateUser' ).and.callThrough();
        expect( scope.user ).toBeDefined();
    } );
    it( 'should have mobile', function() {
        spyOn( userFactory, 'updateUser' ).and.callThrough();
        expect( scope.user.mobile ).toBeDefined();
        expect( scope.user.mobile ).toEqual( '' );
    } );

    it( 'countryList should be defined', function() {
        expect( scope.countryList ).toBeDefined();
    } );
    describe( 'submit change mobile form success', function () {

        it( 'should have loading', function () {
            httpBackend.whenPUT( API_BASE + 'users' ).respond( 200, 'OK' );
            spyOn( userFactory, 'updateUser' ).and.callFake(function(){
                deferred = $q.defer();
                deferred.resolve({
                    status: 200,
                    statusText: 'HTTP/1.1 200 OK'
                });
                return deferred.promise;
            });
            timeout.flush(4000);
            scope.submitChangeMobileFormWithoutOTP();
            expect( scope.loading ).toBeDefined();
            expect( scope.isLoading ).toBeDefined();
            expect( userFactory.updateUser ).toHaveBeenCalled();
        } );

    } );
    describe( 'submit change mobile form errors', function() {
        it( 'error 500', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 500,
                    statusText: 'HTTP/4.01 500 OTP error here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 userPhoneAlreadyInUse', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 userPhoneAlreadyInUse here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 userAuthenticationValidationFailed', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 userAuthenticationValidationFailed here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 userAuthenticationValidationTokenExpired', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 userAuthenticationValidationTokenExpired here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 400 generic error', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 400,
                    statusText: 'HTTP/4.01 400 generic error'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 401 ', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 401,
                    statusText: 'HTTP/4.01 401 error here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
        it( 'error 503 ', function () {
            spyOn( userFactory, 'updateUser' ).and.callFake( function () {
                deferred = $q.defer();
                deferred.reject( {
                    status: 503,
                    statusText: 'HTTP/4.01 503 internal server error here'
                } );
                return deferred.promise;
            } );
            scope.submitChangeMobileFormWithoutOTP();
            scope.$digest();
            expect( scope.changeMobileerror ).toBeTruthy();
            expect( scope.changeMobilevalidationError ).toBeDefined();
        } );
    } );
} );
