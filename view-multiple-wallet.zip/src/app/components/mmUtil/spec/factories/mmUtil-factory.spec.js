'use strict';
describe( 'util', function() {


  describe( 'with no overrides', function() {
    beforeEach( module( 'viewMultipleWallet' ) );
    
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function( $provide ) {
      $provide.constant( "TRANSLATION_PARAMS", {
        "partFilesPath": "../assets/locales/",
        "preferredLanguage": "vi_vn",
        "client": "hdb",
        "source": "http://localhost:3000/assets/hdb/locales\/",
        "supportedLanguages": [ {
          "i18n": "en_us",
          "name": "English"
        }, {
          "i18n": "vi_vn",
          "name": "Vietnamese"
        } ]
      } );
    } ) );

    var $rootScope, $timeout, $mmUtil, $animate;
    var httpBackend;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
      httpBackend = $httpBackend;
      var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
      for ( var i = 0; i < lngth; i++ ) {
        httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      }
    } ) );
    afterEach( function() {
      httpBackend.flush();
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    beforeEach( inject( function( _$animate_, _$rootScope_, _$timeout_, _$mmUtil_ ) {
      $animate = _$animate_;
      $rootScope = _$rootScope_;
      $timeout = _$timeout_;
      $mmUtil = _$mmUtil_;
    } ) );

    describe( 'now', function() {

      it( 'returns proper time values', inject( function( $mmUtil, $timeout ) {
        var t1 = $mmUtil.now();
        expect( t1 ).toBeGreaterThan( 0 );
      } ) );

    } );

    describe( 'disconnect', function() {
      var disconnectScope, reconnectScope;
      beforeEach( inject( function( $mmUtil ) {
        disconnectScope = $mmUtil.disconnectScope;
        reconnectScope = $mmUtil.reconnectScope;
      } ) );

      it( 'disconnectScope events', inject( function( $rootScope ) {
        var scope1 = $rootScope.$new();

        var spy = jasmine.createSpy( 'eventSpy' );
        scope1.$on( 'event', spy );

        disconnectScope( scope1 );

        $rootScope.$broadcast( 'event' );
        expect( spy ).not.toHaveBeenCalled();

        reconnectScope( scope1 );

        $rootScope.$broadcast( 'event' );
        expect( spy ).toHaveBeenCalled();
      } ) );

    } );

    describe( 'supplant', function() {

      it( 'should replace with HTML arguments', inject( function( $mmUtil ) {
        var param1 = "",
          param2 = '' +
          '<mm-content>' +
          '   <mm-option ng-repeat="value in values" value="{{value}}">' +
          '      {{value}}  ' +
          '   </mm-option>  ' +
          '</mm-content>    ';
        var template = '<div class="mm-select-menu-container"><mm-select-menu {0}>{1}</mm-select-menu></div>';
        var results = $mmUtil.supplant( template, [ param1, param2 ] );
        var segment = '<mm-select-menu >'; // After supplant() part of the result should be...

        expect( results.indexOf( segment ) > -1 ).toBe( true );

      } ) );

    } );

    /*describe('findFocusTarget', function() {
      it('should not find valid focus target', inject(function($rootScope, $compile, $mmUtil) {
        var widget = $compile('<div class="autoFocus"><button><img></button></div>')($rootScope);
            $rootScope.$apply();
        var target = $mmUtil.findFocusTarget(widget);

        expect(target).toBeFalsy();
      }));

      it('should find valid a valid focusTarget with "mm-autofocus"', inject(function($rootScope, $compile, $mmUtil) {
        var widget = $compile('<div class="autoFocus"><button mm-autofocus><img></button></div>')($rootScope);
            $rootScope.$apply();
        var target = $mmUtil.findFocusTarget(widget);

        expect(target[0].nodeName).toBe("BUTTON");
      }));

      it('should find valid a valid focusTarget with "mm-auto-focus"', inject(function($rootScope, $compile, $mmUtil) {
        var widget = $compile('<div class="autoFocus"><button mm-auto-focus><img></button></div>')($rootScope);
            $rootScope.$apply();
        var target = $mmUtil.findFocusTarget(widget);

        expect(target[0].nodeName).toBe("BUTTON");
      }));

      it('should find valid a valid focusTarget with "mm-auto-focus" argument', inject(function($rootScope, $compile, $mmUtil) {
        var widget = $compile('<div class="autoFocus"><button mm-autofocus><img></button></div>')($rootScope);
            $rootScope.$apply();
        var target = $mmUtil.findFocusTarget(widget,'[mm-auto-focus]');

        expect(target[0].nodeName).toBe("BUTTON");
      }));

      it('should find valid a valid focusTarget with a deep "mm-autofocus" argument', inject(function($rootScope, $compile, $mmUtil) {
        var widget = $compile('<div class="autoFocus"><mm-sidenav><button mm-autofocus><img></button></mm-sidenav></div>')($rootScope);
            $rootScope.$apply();
        var target = $mmUtil.findFocusTarget(widget);

        expect(target[0].nodeName).toBe("BUTTON");
      }));

      it('should find valid a valid focusTarget with a deep "mm-sidenav-focus" argument', inject(function($rootScope, $compile, $mmUtil) {
        var template = '' +
          '<div class="autoFocus">' +
          '  <mm-sidenav>' +
          '    <button mm-sidenav-focus>' +
          '      <img>' +
          '    </button>' +
          '  </mm-sidenav>' +
          '</div>';
        var widget = $compile(template)($rootScope);
            $rootScope.$apply();
        var target = $mmUtil.findFocusTarget(widget,'[mm-sidenav-focus]');

        expect(target[0].nodeName).toBe("BUTTON");
      }));
    });*/

    describe( 'extractElementByname', function() {

      it( 'should not find valid element', inject( function( $rootScope, $compile, $mmUtil ) {
        var widget = $compile( '<div><mm-button1><img></mm-button1></div>' )( $rootScope );
        $rootScope.$apply();
        var target = $mmUtil.extractElementByName( widget, 'mm-button' );

        // Returns same element
        expect( target[ 0 ] === widget[ 0 ] ).toBe( true );
      } ) );

      it( 'should not find valid element for shallow scan', inject( function( $rootScope, $compile, $mmUtil ) {
        var widget = $compile( '<div><mm-button><img></mm-button></div>' )( $rootScope );
        $rootScope.$apply();
        var target = $mmUtil.extractElementByName( widget, 'mm-button' );

        expect( target[ 0 ] !== widget[ 0 ] ).toBe( false );
      } ) );

      it( 'should find valid element for deep scan', inject( function( $rootScope, $compile, $mmUtil ) {
        var widget = $compile( '<div><mm-button><img></mm-button></div>' )( $rootScope );
        $rootScope.$apply();
        var target = $mmUtil.extractElementByName( widget, 'mm-button', true );

        expect( target !== widget ).toBe( true );
      } ) );
    } );

    describe( 'throttle', function() {
      var delay = 500;
      var nowMockValue;
      var originalFn;
      var throttledFn;

      beforeEach( inject( function( $mmUtil ) {
        $mmUtil.now = function() {
          return nowMockValue;
        };
        originalFn = jasmine.createSpy( 'originalFn' );
        throttledFn = $mmUtil.throttle( originalFn, delay );
        nowMockValue = 1; // Not 0, to prevent `!recent` inside `throttle()` to
        // evaluate to true even after `recent` has been set
      } ) );

      it( 'should immediately invoke the function on first call', function() {
        expect( originalFn ).not.toHaveBeenCalled();
        throttledFn();
        expect( originalFn ).toHaveBeenCalled();
      } );

      it( 'should not invoke the function again before (delay + 1) milliseconds', function() {
        throttledFn();
        expect( originalFn.calls.count() ).toBe( 1 );

        throttledFn();
        expect( originalFn.calls.count() ).toBe( 1 );

        nowMockValue += delay;
        throttledFn();
        expect( originalFn.calls.count() ).toBe( 1 );

        nowMockValue += 1;
        throttledFn();
        expect( originalFn.calls.count() ).toBe( 2 );
      } );

      it( 'should pass the context to the original function', inject( function( $mmUtil ) {
        var obj = {
          called: false,
          fn: function() {
            this.called = true;
          }
        };
        var throttled = $mmUtil.throttle( obj.fn, delay );

        expect( obj.called ).toBeFalsy();
        throttled.call( obj );
        expect( obj.called ).toBeTruthy();
      } ) );

      it( 'should pass the arguments to the original function', function() {
        throttledFn( 1, 2, 3, 'test' );
        expect( originalFn ).toHaveBeenCalledWith( 1, 2, 3, 'test' );
      } );
    } );

    describe( 'disableScrollAround', function() {
      it( 'should prevent scrolling of the passed element', inject( function( $mmUtil ) {
        var element = angular.element( '<div style="height: 2000px">' );
        document.body.appendChild( element[ 0 ] );

        var enableScrolling = $mmUtil.disableScrollAround( element );

        window.scrollTo( 0, 1000 );

        expect( window.pageYOffset ).toBe( 0 );

        // Restore the scrolling.
        enableScrolling();
        window.scrollTo( 0, 0 );
        document.body.removeChild( element[ 0 ] );
      } ) );
    } );

    describe( 'nextTick', function() {
      it( 'should combine multiple calls into a single digest', inject( function( $mmUtil, $rootScope, $timeout ) {
        var digestWatchFn = jasmine.createSpy( 'watchFn' );
        var callback = jasmine.createSpy( 'callback' );
        var timeout;
        $rootScope.$watch( digestWatchFn );
        expect( digestWatchFn ).not.toHaveBeenCalled();
        expect( callback ).not.toHaveBeenCalled();
        //-- Add a bunch of calls to prove that they are batched
        for ( var i = 0; i < 10; i++ ) {
          timeout = $mmUtil.nextTick( callback );
          expect( timeout.$$timeoutId ).toBeOfType( 'number' );
        }
        $timeout.flush();
        expect( digestWatchFn ).toHaveBeenCalled();
        //-- $digest seems to be called one extra time here
        expect( digestWatchFn.calls.count() ).toBe( 4 );
        //-- but callback is still called more
        expect( callback.calls.count() ).toBe( 10 );
      } ) );

      it( 'should return a timeout', inject( function( $mmUtil ) {
        var timeout = $mmUtil.nextTick( angular.noop );
        expect( timeout.$$timeoutId ).toBeOfType( 'number' );
      } ) );

      it( 'should return the same timeout for multiple calls', inject( function( $mmUtil ) {
        var a = $mmUtil.nextTick( angular.noop ),
          b = $mmUtil.nextTick( angular.noop );
        expect( a ).toBe( b );
      } ) );

      it( 'should use scope argument and `scope.$$destroyed` to skip the callback', inject( function( $mmUtil ) {
        var callback = jasmine.createSpy( 'callback' );
        var scope = $rootScope.$new( true );

        $mmUtil.nextTick( callback, false, scope );
        scope.$destroy();

        flush( function() {
          expect( callback ).not.toHaveBeenCalled();
        } );
      } ) );

      it( 'should only skip callbacks of scopes which were destroyed', inject( function( $mmUtil ) {
        var callback1 = jasmine.createSpy( 'callback1' );
        var callback2 = jasmine.createSpy( 'callback2' );
        var scope1 = $rootScope.$new( true );
        var scope2 = $rootScope.$new( true );

        $mmUtil.nextTick( callback1, false, scope1 );
        $mmUtil.nextTick( callback2, false, scope2 );
        scope1.$destroy();

        flush( function() {
          expect( callback1 ).not.toHaveBeenCalled();
          expect( callback2 ).toHaveBeenCalled();
        } );
      } ) );

      it( 'should skip callback for destroyed scopes even if first scope registered is undefined', inject( function( $mmUtil ) {
        var callback1 = jasmine.createSpy( 'callback1' );
        var callback2 = jasmine.createSpy( 'callback2' );
        var scope = $rootScope.$new( true );

        $mmUtil.nextTick( callback1, false ); // no scope
        $mmUtil.nextTick( callback2, false, scope );
        scope.$destroy();

        flush( function() {
          expect( callback1 ).toHaveBeenCalled();
          expect( callback2 ).not.toHaveBeenCalled();
        } );
      } ) );

      it( 'should use scope argument and `!scope.$$destroyed` to invoke the callback', inject( function( $mmUtil ) {
        var callback = jasmine.createSpy( 'callback' );
        var scope = $rootScope.$new( true );

        $mmUtil.nextTick( callback, false, scope );
        flush( function() {
          expect( callback ).toHaveBeenCalled();
        } );
      } ) );

      function flush( expectation ) {
        $rootScope.$digest();
        $timeout.flush();
        expectation && expectation();
      }
    } );

    describe( 'hasComputedStyle', function() {
      describe( 'with expected value', function() {
        it( 'should return true for existing and matching value', inject( function( $window, $mmUtil ) {
          spyOn( $window, 'getComputedStyle' ).and.callFake( function() {
            return {
              'color': 'red'
            };
          } );

          var elem = angular.element( '<span style="color: red"></span>' );

          expect( $mmUtil.hasComputedStyle( elem, 'color', 'red' ) ).toBe( true );
        } ) );

        it( 'should return false for existing and not matching value', inject( function( $window, $mmUtil ) {
          spyOn( $window, 'getComputedStyle' ).and.callFake( function() {
            return {
              'color': 'red'
            };
          } );

          var elem = angular.element( '<span style="color: red"></span>' );

          expect( $mmUtil.hasComputedStyle( elem, 'color', 'blue' ) ).toBe( false );
        } ) );
      } );

      describe( 'without expected value', function() {
        it( 'should return true for existing key', inject( function( $window, $mmUtil ) {
          spyOn( $window, 'getComputedStyle' ).and.callFake( function() {
            return {
              'color': 'red'
            };
          } );

          var elem = angular.element( '<span style="color: red"></span>' );

          expect( $mmUtil.hasComputedStyle( elem, 'color' ) ).toBe( true );
        } ) );

        it( 'should return false for not existing key', inject( function( $window, $mmUtil ) {
          spyOn( $window, 'getComputedStyle' ).and.callFake( function() {
            return {
              'color': 'red'
            };
          } );

          var elem = angular.element( '<span style="color: red"></span>' );

          expect( $mmUtil.hasComputedStyle( elem, 'height' ) ).toBe( false );
        } ) );
      } );
    } );

    describe( 'parseAttributeBoolean', function() {

      it( 'should validate `1` string to be true', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( '1' ) ).toBe( true );
      } ) );

      it( 'should validate an empty value to be true', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( '' ) ).toBe( true );
      } ) );

      it( 'should validate `false` text to be false', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( 'false' ) ).toBe( false );
      } ) );

      it( 'should validate `true` text to be true', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( 'true' ) ).toBe( true );
      } ) );

      it( 'should validate a random text to be true', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( 'random-string' ) ).toBe( true );
      } ) );

      it( 'should validate `0` text to be false', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( '0' ) ).toBe( false );
      } ) );

      it( 'should validate true boolean to be true', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( true ) ).toBe( true );
      } ) );

      it( 'should validate false boolean to be false', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( false ) ).toBe( false );
      } ) );

      it( 'should validate `false` text to be true when ignoring negative values', inject( function( $mmUtil ) {
        expect( $mmUtil.parseAttributeBoolean( 'false', false ) ).toBe( true );
      } ) );
    } );

    describe( 'getParentWithPointerEvents', function() {
      describe( 'with wrapper with pointer events style element', function() {
        it( 'should find the parent element and return it', inject( function( $window, $mmUtil ) {
          spyOn( $window, 'getComputedStyle' ).and.callFake( function( target ) {
            return target === wrapper[ 0 ] ? {
              'pointer-events': 'none'
            } : {};
          } );

          var elem = angular.element( '<span></span>' );
          var wrapper = angular.element( '<div style="pointer-events:none;"></div>' );
          var parent = angular.element( '<div></div>' );

          wrapper.append( elem );
          parent.append( wrapper );

          // Scan up the DOM tree to find nearest parent with point-events !== none
          // This means we should skip the wrapper node.

          expect( $mmUtil.getParentWithPointerEvents( elem )[ 0 ] ).toBe( parent[ 0 ] );
        } ) );
      } );

      describe( 'with wrapper without pointer events style element', function() {
        it( 'should find the wrapper element and return it', inject( function( $window, $mmUtil ) {
          spyOn( $window, 'getComputedStyle' ).and.callFake( function( elem ) {
            return {};
          } );

          var elem = angular.element( '<span></span>' );
          var wrapper = angular.element( '<div id="wrapper"></div>' );
          var parent = angular.element( '<div></div>' );

          wrapper.append( elem );
          parent.append( wrapper );

          expect( $mmUtil.getParentWithPointerEvents( elem )[ 0 ] ).toBe( wrapper[ 0 ] );
        } ) );
      } );
    } );

    describe( 'getNearestContentElement', function() {
      describe( 'with rootElement as parent', function() {
        it( 'should find stop at the rootElement and return it', inject( function( $rootElement, $mmUtil ) {
          var elem = angular.element( '<span></span>' );
          var wrapper = angular.element( '<div></div>' );

          wrapper.append( elem );
          $rootElement.append( wrapper );

          expect( $mmUtil.getNearestContentElement( elem ) ).toBe( $rootElement[ 0 ] );
        } ) );
      } );

      describe( 'with document body as parent', function() {
        it( 'should find stop at the document body and return it', inject( function( $mmUtil ) {
          var elem = angular.element( '<span></span>' );
          var wrapper = angular.element( '<div></div>' );
          var body = angular.element( document.body );

          wrapper.append( elem );
          body.append( wrapper );

          expect( $mmUtil.getNearestContentElement( elem ) ).toBe( body[ 0 ] );
        } ) );
      } );

      describe( 'with mm-content as parent', function() {
        it( 'should find stop at mm-content element and return it', inject( function( $mmUtil ) {
          var elem = angular.element( '<span></span>' );
          var wrapper = angular.element( '<div></div>' );
          var content = angular.element( '<mm-content></mm-content>' );

          wrapper.append( elem );
          content.append( wrapper );

          expect( $mmUtil.getNearestContentElement( elem ) ).toBe( content[ 0 ] );
        } ) );
      } );

      describe( 'with no rootElement, body or mm-content as parent', function() {
        it( 'should return null', inject( function( $mmUtil ) {
          var elem = angular.element( '<span></span>' );
          var wrapper = angular.element( '<div></div>' );

          wrapper.append( elem );

          expect( $mmUtil.getNearestContentElement( elem ) ).toBe( null );
        } ) );
      } );
    } );
  } );

  describe( 'processTemplate', function() {
    var $mmUtil;
    beforeEach( module( 'viewMultipleWallet' ) );
    beforeEach( inject( function( _$mmUtil_ ) {
      $mmUtil = _$mmUtil_;
    } ) );
    it( 'should return exact template when using the default start/end symbols', function() {
      var output = $mmUtil.processTemplate( '<some-tag>{{some-var}}</some-tag>' );

      expect( output ).toEqual( '<some-tag>{{some-var}}</some-tag>' );
    } );

  } );

  describe( 'isParentFormSubmitted', function() {
    var $mmUtil;
    beforeEach( module( 'viewMultipleWallet' ) );
    beforeEach( inject( function( _$mmUtil_ ) {
      $mmUtil = _$mmUtil_;
    } ) );
    var formTemplate =
      '<form>' +
      '  <input type="text" name="test" ng-model="test" />' +
      '  <input type="submit" />' +
      '<form>';

    it( 'returns false if you pass no element', function() {
      expect( $mmUtil.isParentFormSubmitted() ).toBe( false );
    } );

    it( 'returns false if there is no form', function() {
      var element = angular.element( '<input />' );
      expect( $mmUtil.isParentFormSubmitted( element ) ).toBe( false );
    } );

    it( 'returns false if the parent form is NOT submitted', inject( function( $compile, $rootScope, $mmUtil ) {
      var scope = $rootScope.$new();
      var form = $compile( formTemplate )( scope );

      expect( $mmUtil.isParentFormSubmitted( form.find( 'input' ) ) ).toBe( false );
    } ) );

    it( 'returns true if the parent form is submitted', inject( function( $compile, $rootScope, $mmUtil ) {
      var scope = $rootScope.$new();
      var form = $compile( formTemplate )( scope );

      var formController = form.controller( 'form' );

      formController.$setSubmitted();

      expect( formController.$submitted ).toBe( true );
      expect( $mmUtil.isParentFormSubmitted( form.find( 'input' ) ) ).toBe( true );
    } ) );
  } );

  describe( 'with $interpolate.start/endSymbol override', function() {

    describe( 'processTemplate', function() {
      beforeEach( function() {
        module( function( $interpolateProvider ) {
          $interpolateProvider.startSymbol( '[[' );
          $interpolateProvider.endSymbol( ']]' );
        } );
        module( 'viewMultipleWallet' );
      } );

      it( 'should replace the start/end symbols', inject( function( $mmUtil ) {
        var output = $mmUtil.processTemplate( '<some-tag>{{some-var}}</some-tag>' );

        expect( output ).toEqual( '<some-tag>[[some-var]]</some-tag>' );
      } ) );
    } );
  } );

  describe( 'getClosest', function() {
    var $mmUtil;
    beforeEach( module( 'viewMultipleWallet' ) );
    beforeEach( inject( function( _$mmUtil_ ) {
      $mmUtil = _$mmUtil_;
    } ) );

    it( 'should be able to get the closest parent of a particular node type', function() {
      var grandparent = angular.element( '<h1>' );
      var parent = angular.element( '<h2>' );
      var element = angular.element( '<h3>' );

      parent.append( element );
      grandparent.append( parent );

      var result = $mmUtil.getClosest( element, 'h1' );

      expect( result ).toBeTruthy();
      expect( result.nodeName.toLowerCase() ).toBe( 'h1' );

      grandparent.remove();
    } );

    it( 'should be able to start from the parent of the specified node', function() {
      var grandparent = angular.element( '<div>' );
      var parent = angular.element( '<span>' );
      var element = angular.element( '<div>' );

      parent.append( element );
      grandparent.append( parent );

      var result = $mmUtil.getClosest( element, 'div', true );

      expect( result ).toBeTruthy();
      expect( result ).not.toBe( element[ 0 ] );

      grandparent.remove();
    } );

    it( 'should be able to take in a predicate function', function() {
      var grandparent = angular.element( '<div random-attr>' );
      var parent = angular.element( '<div>' );
      var element = angular.element( '<span>' );

      parent.append( element );
      grandparent.append( parent );

      var result = $mmUtil.getClosest( element, function( el ) {
        return el.hasAttribute( 'random-attr' );
      } );

      expect( result ).toBeTruthy();
      expect( result ).toBe( grandparent[ 0 ] );

      grandparent.remove();
    } );
  } );
} );