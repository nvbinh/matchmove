'use strict';
angular.module('mockWallet', [])
    .factory('mockCardSvc', function($q, $http, API_BASE){
        var cardSvc = {};
        cardSvc.getCardNoCache = function(cardId){
            var mock = {};
            mock.card = angular.toJson({
              "id": "464d9a323e583498f76860aef89a32b3",
              "number": "5363950000255600",
              "holder": {
                "name": "Balaji"
              },
              "funds": {
                "available": {
                  "currency": "SGD",
                  "amount": "6.00"
                }
              },
              "type": {
                "type": "mcmmgpcard",
                "name": "MatchMove Physical Card",
                "description": "Matchmove Physical Card",
                "code_type": "Physical Card"
              },
              "date": {
                "expiry": "2020-12",
                "issued": "2016-02-10"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "links": [
                {
                  "rel": "securities.tokens",
                  "href": "",
                  "method": "GET"
                }
              ]
            });
            return $q.when(mock);
        };
        return cardSvc;
})
.factory('mockNoCardSvc', function($q, $http, API_BASE){
        var cardSvc = {};
        cardSvc.getCardNoCache = function(cardId){
           return $q.reject({error: 'NoCardAvailable'});
        };
        return cardSvc;
})
.factory('mockWalletSvc', function($q, $http, API_BASE) {
        var walletSvc = {};

        // example stub method that returns a promise, e.g. if original method returned $http.get(...)
        walletSvc.getWallet = function() {
            var mock = {};
            mock.wallet = angular.fromJson({
              "funds": {
                "withholding": {
                  "currency": "SGD",
                  "amount": "27.00"
                },
                "available": {
                  "currency": "SGD",
                  "amount": "162.00"
                }
              },
              "id": "dfa7916f06e9640daeb0bbe413012659",
              "number": "6377020000009969",
              "holder": {
                "name": "Balaji"
              },
              "date": {
                "expiry": "2024-03",
                "issued": "2015-12-15"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "details": {
                "min_load_limit": 10,
                "max_load_limit": 999,
                "network_type": "mastercard",
                "fee": 0,
                "topup_limits": {
                  "pre_kyc": {
                    "frequency": null,
                    "allowed": null,
                    "monthly_transactional_limit": 9999999999
                  },
                  "post_kyc": {
                    "frequency": null,
                    "monthly_transactional_limit": 5000
                  },
                  "current": {
                    "lifetime_count": 4,
                    "lifetime_transactional": 175,
                    "monthly_transactional": 10
                  }
                }
              },
              "cards": [
                {
                  "id": "464d9a323e583498f76860aef89a32b3",
                  "type": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                      "method": "GET"
                    }
                  ],
                  "links": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3",
                      "method": "GET"
                    }
                  ]
                }
              ]
            });
            mock.userCards = angular.toJson({
              "id": "464d9a323e583498f76860aef89a32b3",
              "number": "5363950000255600",
              "holder": {
                "name": "Balaji"
              },
              "funds": {
                "available": {
                  "currency": "SGD",
                  "amount": "6.00"
                }
              },
              "type": {
                "type": "mcmmgpcard",
                "name": "MatchMove Physical Card",
                "description": "Matchmove Physical Card",
                "code_type": "Physical Card"
              },
              "date": {
                "expiry": "2020-12",
                "issued": "2016-02-10"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "links": [
                {
                  "rel": "securities.tokens",
                  "href": "",
                  "method": "GET"
                }
              ]
            });
            return $q.when(mock);
        };
        // other stubbed methods
        return walletSvc;
    })
.factory('mockWalletErrorSvc', function($q, $http, API_BASE) {
    var walletSvc = {};

    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
    walletSvc.getWallet = function() {
        var mock = {};
        mock.wallet = angular.toJson({});
        mock.userCards = angular.toJson({});
        return $q.reject({'error': 'Error retrieving Wallet Information'});
    };
    // other stubbed methods
    return walletSvc;
});
describe('Controller: loadCtrl', function () {
  // load mockWallet Service
    beforeEach(module('mockWallet'));
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var loadCtrl,
      httpBackend,
      scope,
      Wallet,
      userswalletscardsfundsFactory,
      helperFactory,
      Cards,
      API_BASE,
      walletInfo,
      cardInfo,
      q,
      defered;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ( $rootScope, $controller, _API_BASE_, _mockWalletSvc_, _userswalletscardsfundsFactory_, _helperFactory_, _mockCardSvc_, _$q_) {
    Wallet = _mockWalletSvc_;
    Cards = _mockCardSvc_;
    API_BASE = _API_BASE_;
    userswalletscardsfundsFactory = _userswalletscardsfundsFactory_;
    helperFactory = _helperFactory_;
    q = _$q_;

    walletInfo = {
              "funds": {
                "withholding": {
                  "currency": "SGD",
                  "amount": "27.00"
                },
                "available": {
                  "currency": "SGD",
                  "amount": "162.00"
                }
              },
              "id": "dfa7916f06e9640daeb0bbe413012659",
              "number": "6377020000009969",
              "holder": {
                "name": "Balaji"
              },
              "date": {
                "expiry": "2024-03",
                "issued": "2015-12-15"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "details": {
                "min_load_limit": 10,
                "max_load_limit": 999,
                "network_type": "mastercard",
                "fee": 0,
                "topup_limits": {
                  "pre_kyc": {
                    "frequency": null,
                    "allowed": null,
                    "monthly_transactional_limit": 9999999999
                  },
                  "post_kyc": {
                    "frequency": null,
                    "monthly_transactional_limit": 5000
                  },
                  "current": {
                    "lifetime_count": 4,
                    "lifetime_transactional": 175,
                    "monthly_transactional": 10
                  }
                }
              },
              "cards": [
                {
                  "id": "464d9a323e583498f76860aef89a32b3",
                  "type": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                      "method": "GET"
                    }
                  ],
                  "links": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3",
                      "method": "GET"
                    }
                  ]
                }
              ]
            };

    cardInfo = {
          "id": "464d9a323e583498f76860aef89a32b3",
          "number": "5363950000255600",
          "holder": {
            "name": "Balaji"
          },
          "funds": {
            "available": {
              "currency": "SGD",
              "amount": "6.00"
            }
          },
          "type": {
            "type": "mcmmgpcard",
            "name": "MatchMove Physical Card",
            "description": "Matchmove Physical Card",
            "code_type": "Physical Card"
          },
          "date": {
            "expiry": "2020-12",
            "issued": "2016-02-10"
          },
          "image": {
            "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
            "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
            "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
          },
          "status": {
            "is_active": true,
            "text": "active"
          },
          "links": [
            {
              "rel": "securities.tokens",
              "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/securities/tokens",
              "method": "GET"
            }
          ]
        };
    scope = $rootScope.$new();
    scope.$parent.wallet = walletInfo;
    scope.$parent.cardToLoad = '464d9a323e583498f76860aef89a32b3';
    loadCtrl = $controller('loadCtrl', {
      $scope: scope
    });
    scope.form = {$valid: true, $dirty: true, $setPristine: function () {scope.loadForm.$dirty = false, scope.loadForm.$pristine = true;}};
    scope.loadForm = scope.form;
    scope.card = scope.$parent.cardToLoad = '464d9a323e583498f76860aef89a32b3';
    scope.$parent.balanceEl = angular.element('<span class="balance-number">33.00</span>');    
    httpBackend.whenGET(API_BASE + 'users/wallets').respond(200, walletInfo);
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(200, cardInfo);
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/undefined').respond(200, cardInfo);
    httpBackend.whenPOST(API_BASE + 'users/wallets/cards/undefined/funds').respond(200, cardInfo);
   
    Wallet.getWallet().then(function(response){
        scope.wallet = (response);
    });
    
   Cards.getCardNoCache(scope.card).then(function(){
       scope.wallet = walletInfo;
       scope.cardBalance = 10.00;
       scope.balance = 200.00;
   });
  
   httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('initialization for scope amount', function () {
    expect(scope.balance).toEqual('152.00');
  });
  it('should have default load amount', function(){
      expect(scope.load).toBeDefined();
      expect(scope.load.amount).toBeDefined();
      expect(scope.load.amount).toEqual(10);
  });
  it('update balance amount', function() {
    scope.wallet = {};
    scope.wallet.funds = {};
    scope.wallet.funds.available = {};
    scope.wallet.funds.available.amount = 200.00;
    scope.card = {};
    scope.card.funds = {};
    scope.card.funds.available = {};
    scope.card.funds.available.amount = 2;
    scope.updateBalance(5);
    expect(scope.balance).toEqual('195.00');
  });
  describe('load card', function(){
      it('should succeed', function(){
          scope.load.amount = 10;
          httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(200, cardInfo);

          spyOn(userswalletscardsfundsFactory, 'loadCard').and.callThrough();
          spyOn(helperFactory, 'postTransactionInfoUpdate').and.callThrough();
          spyOn(scope, 'updateBalanceOnDashboard').and.callThrough();
          spyOn(scope, 'updateBalance').and.callThrough();
          scope.loadCard();
          httpBackend.flush();
          expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
          expect(helperFactory.postTransactionInfoUpdate).toHaveBeenCalled();
          expect(scope.loadSuccess).toBeTruthy();
      });
   });
      describe('load card Errors', function(){
          beforeEach(inject(function(){
              spyOn(userswalletscardsfundsFactory, 'loadCard').and.callThrough();
              spyOn(scope, 'updateBalance').and.callThrough();
              spyOn(helperFactory, 'postTransactionInfoUpdate').and.callFake(function() { return true; });
          }));

          describe('when http request is called', function(){
              it('Error 400 - greater_than_limit', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 greater_than_limit)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('should Fail with Error 400 - card_fund_transfer_purse_daily_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_daily_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('should Fail with Error 400 - card_fund_transfer_purse_weekly_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_weekly_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('should Fail with Error 400 - card_fund_transfer_purse_monthly_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_monthly_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('should Fail with Error 400 generic', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 generic error)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - Lifetime count limit reached', function(){
                  scope.isUserPreKYC = true;
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 Lifetime count limit reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - card_fund_transfer_purse_lifetime_transactional_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_lifetime_transactional_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - resource_card_fund_transfer_minimum_credit_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 resource_card_fund_transfer_minimum_credit_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - resource_card_fund_transfer_maximum_credit_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 resource_card_fund_transfer_maximum_credit_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - resource_card_fund_transfer_purse_daily_transactional_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 resource_card_fund_transfer_purse_daily_transactional_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - resource_card_fund_transfer_purse_weekly_transactional_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 resource_card_fund_transfer_purse_weekly_transactional_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - resource_card_fund_transfer_purse_monthly_transactional_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 resource_card_fund_transfer_purse_monthly_transactional_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('Error 400 - card_fund_transfer_purse_lifetime_count_limit_reached', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(400, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(400, 'error 400', {}, '(HTTP/1.1 400 card_fund_transfer_purse_lifetime_count_limit_reached)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('should Fail with Error 500', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(500, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(500, 'error 500', {}, '(HTTP/1.1 500 Internal Server Error)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
              it('should Fail with Error 503', function(){
                  httpBackend.whenGET(API_BASE + 'users/wallets').respond(503, '');
                  httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(503, 'error 503', {}, '(HTTP/1.1 503 Uncaught Error)');
                  scope.loadCard();
                  httpBackend.flush();
                  expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
                  expect(scope.loadErrorMsg).toBeDefined();
              });
          });
      });
  });
/*
describe('Controller: loadCtrl Error Scenarios', function () {
  // load mockWallet Service
    beforeEach(module('mockWallet'));
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var loadCtrl,
      httpBackend,
      scope,
      Wallet,
      userswalletscardsfundsFactory,
      helperFactory,
      Cards,
      API_BASE,
      walletInfo,
      cardInfo,
      q,
      defered;
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, $httpBackend, _API_BASE_, _mockWalletErrorSvc_, _userswalletscardsfundsFactory_, _helperFactory_, _mockCardSvc_, _$q_) {
    httpBackend = $httpBackend;
    Wallet = _mockWalletErrorSvc_;
    Cards = _mockCardSvc_;
    API_BASE = _API_BASE_;
    userswalletscardsfundsFactory = _userswalletscardsfundsFactory_;
    helperFactory = _helperFactory_;
    q = _$q_;
    scope = $rootScope.$new();
    scope.$parent = {};
    scope.$parent.wallet = '';
    scope.$parent.cardToLoad = '464d9a323e583498f76860aef89a32b3';
    loadCtrl = $controller('loadCtrl', {
      $scope: scope
    });
    
    scope.form = {$valid: true, $dirty: true, $setPristine: function () {scope.loadForm.$dirty = false, scope.loadForm.$pristine = true;}};
    scope.loadForm = scope.form;
    scope.card = scope.$parent.cardToLoad = '464d9a323e583498f76860aef89a32b3';
    scope.$parent.balanceEl = angular.element('<span class="balance-number">33.00</span>');
    scope.load = {};
    scope.load.amount = 10;    
    
    httpBackend.whenGET(API_BASE + 'users/wallets').respond(401, 'error 401', {}, 'HTTP/1.1 401 Wallet fetch Error');
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(401, 'error 401', {}, 'HTTP/1.1 401 Wallet fetch Error');
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/undefined').respond(401, 'error 401', {}, 'HTTP/1.1 401 Wallet fetch Error');
    httpBackend.whenPOST(API_BASE + 'users/wallets/cards/undefined/funds').respond(401, 'error 401', {}, 'HTTP/1.1 401 Wallet fetch Error');
    httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(401, 'error 401', {}, 'HTTP/1.1 401 Wallet fetch Error');

    Wallet.getWallet().then(function(){}, function(error){});

   Cards.getCardNoCache(scope.card).then(function(){});

   httpBackend.flush();
   scope.forms = {};
 
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

  describe('Wallet fetch Error', function(){
      beforeEach(inject(function(){
          spyOn(userswalletscardsfundsFactory, 'loadCard').and.callThrough();
          spyOn(helperFactory, 'postTransactionInfoUpdate').and.callFake(function() { return true; });
      }));

      describe('when http request is called', function(){
         it('should fail with wallet fetch error', function(){
              spyOn(scope, 'updateBalanceOnDashboard').and.callThrough();
              spyOn(scope, 'updateBalance').and.callThrough();
              scope.loadCard();
              httpBackend.flush();
              expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
              expect(scope.wallet).not.toBeDefined();
          });
      });
  });
});
*/
describe('Controller: loadCtrl No Load amount available Scenarios', function () {
  // load mockWallet Service
    beforeEach(module('mockWallet'));
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var loadCtrl,
      httpBackend,
      scope,
      Wallet,
      userswalletscardsfundsFactory,
      helperFactory,
      Cards,
      API_BASE,
      walletInfo,
      cardInfo,
      q,
      defered;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _API_BASE_, _mockWalletSvc_, _userswalletscardsfundsFactory_, _helperFactory_, _mockCardSvc_, _$q_) {
    Wallet = _mockWalletSvc_;
    Cards = _mockCardSvc_;
    API_BASE = _API_BASE_;
    userswalletscardsfundsFactory = _userswalletscardsfundsFactory_;
    helperFactory = _helperFactory_;
    q = _$q_;
    walletInfo = {
              "funds": {
                "withholding": {
                  "currency": "SGD",
                  "amount": "0.00"
                },
                "available": {
                  "currency": "SGD",
                  "amount": "0.00"
                }
              },
              "id": "dfa7916f06e9640daeb0bbe413012659",
              "number": "6377020000009969",
              "holder": {
                "name": "Balaji"
              },
              "date": {
                "expiry": "2024-03",
                "issued": "2015-12-15"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "cards": [
                {
                  "id": "464d9a323e583498f76860aef89a32b3",
                  "type": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                      "method": "GET"
                    }
                  ],
                  "links": [
                    {
                      "rel": "self",
                      "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3",
                      "method": "GET"
                    }
                  ]
                }
              ]
            };

    cardInfo = {
          "id": "464d9a323e583498f76860aef89a32b3",
          "number": "5363950000255600",
          "holder": {
            "name": "Balaji"
          },
          "funds": {
            "available": {
              "currency": "SGD",
              "amount": "6.00"
            }
          },
          "type": {
            "type": "mcmmgpcard",
            "name": "MatchMove Physical Card",
            "description": "Matchmove Physical Card",
            "code_type": "Physical Card"
          },
          "date": {
            "expiry": "2020-12",
            "issued": "2016-02-10"
          },
          "status": {
            "is_active": true,
            "text": "active"
          }
        };
    scope = $rootScope.$new();
    scope.$parent.wallet = walletInfo;
    scope.$parent.cardToLoad = '464d9a323e583498f76860aef89a32b3';
    loadCtrl = $controller('loadCtrl', {
      $scope: scope
    });
    scope.form = {$valid: true, $dirty: true, $setPristine: function () {scope.loadForm.$dirty = false, scope.loadForm.$pristine = true;}};
    scope.loadForm = scope.form;
    scope.card = scope.$parent.cardToLoad = '464d9a323e583498f76860aef89a32b3';
    scope.$parent.balanceEl = angular.element('<span class="balance-number">33.00</span>');
    httpBackend.whenGET(API_BASE + 'users/wallets').respond(200, walletInfo);
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3').respond(200, cardInfo);
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/undefined').respond(200, cardInfo);
    httpBackend.whenPOST(API_BASE + 'users/wallets/cards/undefined/funds').respond(200, cardInfo);

    Wallet.getWallet().then(function(response){
        scope.wallet = (response);
    });
   Cards.getCardNoCache(scope.card).then(function(){
       scope.wallet = walletInfo;
       scope.cardBalance = 0.00;
       scope.balance = 0.00;
   });
   httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  describe('load card', function(){
      it('should succeed', function(){
          httpBackend.whenPOST(API_BASE + 'users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds').respond(200, cardInfo);

          spyOn(userswalletscardsfundsFactory, 'loadCard').and.callThrough();
          spyOn(helperFactory, 'postTransactionInfoUpdate').and.callThrough();
          spyOn(scope, 'updateBalanceOnDashboard').and.callThrough();
          spyOn(scope, 'updateBalance').and.callThrough();
          scope.loadCard();
          httpBackend.flush();
          expect(userswalletscardsfundsFactory.loadCard).toHaveBeenCalled();
          expect(helperFactory.postTransactionInfoUpdate).toHaveBeenCalled();
          expect(scope.loadSuccess).toBeTruthy();
      });
   });
});
