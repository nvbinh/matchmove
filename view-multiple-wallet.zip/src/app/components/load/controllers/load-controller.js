'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:loadCtrl
 * @description
 * # loadCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'loadCtrl', function ( $scope, $http, $log, $analytics, $filter, Cards, ngDialog, Wallet, userswalletscardsfundsFactory, helperFactory, $rootScope, LOAD_PARAMETERS, store, PubSub, CacheFactory, $timeout, userFactory, $state ) {
        store.set( 'controller', 'loadCtrl' );
        $scope.cardToLoad = $scope.$parent.cardToLoad;
        $scope.load = {};
        $scope.load.amount = 10;
        $scope.balance = 0;
        var $translate = $filter( 'translate' );
        $scope.isLoading = true;
        $scope.isUserPreKYC = userFactory.getUserPreOrPostKyc();
        $scope.isUserPreKYC = $scope.isUserPreKYC.userPreKyc;

        $scope.wallet = $scope.$parent.wallet;
        $scope.configObj = angular.fromJson( LOAD_PARAMETERS );
        $scope.min = $scope.configObj.min;
        $scope.max = Math.min( $scope.configObj.max, $scope.wallet.funds.available.amount );

        Cards.getCardNoCache( $scope.cardToLoad )
            .then( function ( response ) {
                $scope.card = response.data;
                if ( $scope.load.amount && $scope.load.amount <= $scope.wallet.funds.available.amount ) {
                    $scope.balance = ( $scope.wallet.funds.available.amount - $scope.load.amount ).toFixed( 2 );
                    $scope.cardBalance = ( parseFloat( $scope.card.funds.available.amount ) + $scope.load.amount ).toFixed( 2 );
                }
                $scope.isLoading = false;
            }, function () {
                $scope.isLoading = false;
                $scope.loadError = true;
            } );

        $scope.updateBalance = function ( value ) {
            //$scope.loadingTextMsg = $translate( 'MODAL.LOAD.LOADING.UPDATINGBALANCE' );
            if ( value && value <= $scope.wallet.funds.available.amount ) {
                $scope.balance = ( $scope.wallet.funds.available.amount - value ).toFixed( 2 );
                $scope.cardBalance = ( parseFloat( $scope.card.funds.available.amount ) + value ).toFixed( 2 );
            } else {
                if ( parseFloat( $scope.wallet.funds.available.amount ) <= 0 ) {
                    $scope.balance = $scope.wallet.funds.available.amount;
                } else {
                    $scope.balance = $scope.card.funds.available.amount;
                }
                if ( !value ) {
                    $scope.balance = $scope.wallet.funds.available.amount;
                }
                $scope.cardBalance = parseFloat( $scope.card.funds.available.amount ).toFixed( 2 );
            }
            $scope.max = $scope.wallet.funds.available.amount;
            $scope.isLoading = false;
        };

        $scope.updateBalanceOnDashboard = function ( amount ) {
            var balanceEl = $scope.$parent.balanceEl,
                current = 0,
                finalResult = 0;
            if ( balanceEl.length > 0 ) {
                current = parseFloat( $scope.cardAmount );
                finalResult = current + amount;
                finalResult = $filter('mmCurrency')(finalResult, 'skipSymbolFalse');
                if (finalResult > 0) {
                    $scope.updateBalance(amount);
                    $scope.isLoading = false;
                    $rootScope.$broadcast('showunloadbutton');
                    balanceEl.html(finalResult);
                } else {
                    $scope.isLoading = false;
                    balanceEl.html(finalResult);
                }
            } else {
                $scope.isLoading = false;
            }
        };

        $scope.loadCard = function () {
            $scope.loadSuccess = false;
            $scope.isLoading = true;
            $scope.loadError = false;
            $scope.loadingTextMsg = $translate( 'MODAL.LOAD.LOADING.PROCESSING_LOAD' );
            userswalletscardsfundsFactory.loadCard( $scope.$parent.cardToLoad, $scope.load.amount )
                .then( function ( response ) {
                    $scope.loadResponse = response.data;
                    $analytics.eventTrack( 'Load Card Successfull', {
                        category: 'Load Card',
                        label: 'Load Card Successfull - Amount :' + $scope.load.amount
                    } );
                    helperFactory.postTransactionInfoUpdate();
                    $timeout(function(){
                        $scope.loadingTextMsg = $translate( 'MODAL.LOAD.LOADING.UPDATING_BALANCE' );
                    }, 2500);
                    $scope.updateBalanceOnDashboard( $scope.load.amount );

                    //$rootScope.$broadcast('updateBalanceBar');
                    // manually remove the cache - userWallet
                    CacheFactory.get('walletCache').remove('userWallet');
                    PubSub.publish( 'load-success' );
                    $scope.loadSuccess = true;
                    //$scope.load.amount = '';
                    $scope.loadForm.$setPristine();
                    $timeout( function () {
                        ngDialog.closeAll();
                        $state.go( '.', {}, {
                            reload: true
                        } );
                    }, 3500 );
                }, function ( response ) {
                    if ( response.status === 500 ) {
                        $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.500_SERVICE_ERROR' );
                        $analytics.eventTrack( 'Error loading card in Dashboard', {
                            category: 'Error 500',
                            label: 'Error loading card in Dashboard'
                        } );
                    } else if ( response.status === 403 ) {
                        // TODO: Pending from OP NEEDS TO CHANGE ERROR CODE TO 400
                        // Doing 403 for the quick patch
                        // Related ticket TPB-911, TPB-915
                        if ( response.statusText.indexOf( 'User currently has a pending transaction' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.EXISTING_PROCESS_ON_GOING' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        }
                        // END TODO
                    } else if ( response.status === 400 ) {

                        if ($scope.isUserPreKYC === true && response.statusText.indexOf('Lifetime count limit reached') > -1) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.LIFETIME_COUNT_LIMIT' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'PreKYC User Repeated Load Card attempt : ' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'greater_than_limit' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.GREATER_THAN_LIMIT' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_daily_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_DAILY_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_weekly_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_WEEKLY_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_monthly_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_MONTHLY_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_lifetime_transactional_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_LIFETIME_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'card_fund_transfer_purse_lifetime_count_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_LIFETIME_COUNT_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_minimum_credit_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_MIN_CREDIT_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'resource_card_fund_category_transfer_maximum_credit_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_MAX_CREDIT_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_maximum_credit_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_MAX_CREDIT_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_purse_daily_transactional_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_DAILY_TRANSACTIONAL_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_purse_weekly_transactional_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_WEEKLY_TRANSACTIONAL_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'resource_card_fund_transfer_purse_monthly_transactional_limit_reached' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_MONTHLY_TRANSACTIONAL_LIMIT_REACHED' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'existingProcessOngoing' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.EXISTING_PROCESS_ON_GOING' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else if ( response.statusText.indexOf( 'User currently has a pending transaction' ) > -1 ) {
                            $scope.loadErrorMsg = $translate( 'ERRORS.VALIDATION.LOAD.400.EXISTING_PROCESS_ON_GOING' );
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );
                        } else {
                            $scope.loadErrorMsg = response.statusText;
                            $analytics.eventTrack( 'Invalid Request Load Card', {
                                category: 'Load Card',
                                label: 'Invalid Request Load Card :' + response.statusText
                            } );

                        }
                    } else {
                        $scope.loadErrorMsg = response.statusText;
                        $analytics.eventTrack( 'Uncaught Error Load Card', {
                            category: 'Load Card',
                            label: 'Uncaght Error Load Card :' + response.status + ' : ' + response.statusText
                        } );
                    }
                    $scope.isLoading = false;
                    $scope.loadError = true;
                    // $scope.loadErrorMsg = $rootScope.errorHandler.errors[0];
                } );
        };
    } );
