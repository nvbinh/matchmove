'use strict';
describe('Directive: getFirstCard', function() {
    // load the directive's module
    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach(module('viewMultipleWallet', function($provide) {
        $provide.constant("TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [{
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            }]
        });

        $provide.constant("GET_FIRST_CARD", {
            "FirstCardDataSeekPoints": {
                "email": {
                    "langKey": "EMAIL",
                    "switch": "ON"
                },
                "mobile": {
                    "langKey": "MOBILE",
                    "switch": "ON"
                },
                "profile": {
                    "langKey": "PROFILE",
                    "switch": "ON"
                },
                "addressInfo": {
                    "langKey": "ADDRESS_INFORMATION",
                    "switch": "ON"
                },
                "KYC": {
                    "langKey": "KYC",
                    "switch": "ON"
                }
            }
        });
    }));
    // langugage based mock calls
    beforeEach(inject(function($httpBackend, TRANSLATION_PARAMS) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson(TRANSLATION_PARAMS).supportedLanguages.length;
        for (var i = 0; i < lngth; i++) {
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'common/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'login/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'modal/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
        }
    }));
    var element,
        scope,
        ngDialog,
        Cards,
        spyDialog,
        httpBackend;
    beforeEach(inject(function($rootScope, $compile, _ngDialog_, _Cards_) {
        scope = $rootScope.$new();
        ngDialog = _ngDialog_;
        Cards = _Cards_;
        element = angular.element('<button mg-button class="button-primary--medium"  ng-click="getFirstCard();" get-first-card>');

        $compile(element)(scope);
        scope.$digest();
        spyDialog = spyOn(ngDialog, 'open').and.callThrough();
    }));
    it('email NOT verified', inject(function($compile) {
        spyOn(Cards, 'getFirstCardFactory').and.callFake(function() {
            return { "email": false, "mobile": true, "profile": true, "addressInfo": true, "kycStatus": true }
        })
        element.triggerHandler('click');
        expect(spyDialog).toHaveBeenCalled();
    }));
    it('mobile NOT verified', inject(function($compile) {
        spyOn(Cards, 'getFirstCardFactory').and.callFake(function() {
            return { "email": true, "mobile": false, "profile": true, "addressInfo": true, "kycStatus": true }
        })
        element.triggerHandler('click');
        expect(spyDialog).toHaveBeenCalled();
    }));
    it('profile NOT verified', inject(function($compile) {
        spyOn(Cards, 'getFirstCardFactory').and.callFake(function() {
            return { "email": true, "mobile": true, "profile": false, "addressInfo": true, "kycStatus": true }
        })
        element.triggerHandler('click');
        expect(spyDialog).toHaveBeenCalled();
    }));
    it('address NOT verified', inject(function($compile) {
        spyOn(Cards, 'getFirstCardFactory').and.callFake(function() {
            return { "email": true, "mobile": true, "profile": true, "addressInfo": false, "kycStatus": true }
        })
        element.triggerHandler('click');
        expect(spyDialog).toHaveBeenCalled();
    }));
    it('KYC NOT verified', inject(function($compile) {
        spyOn(Cards, 'getFirstCardFactory').and.callFake(function() {
            return { "email": true, "mobile": true, "profile": true, "addressInfo": true, "kycStatus": false }
        })
        element.triggerHandler('click');
        expect(spyDialog).toHaveBeenCalled();
    }));
    it('All requirements verified', inject(function($compile) {
        spyOn(Cards, 'getFirstCardFactory').and.callFake(function() {
            return { "email": true, "mobile": true, "profile": true, "addressInfo": true, "kycStatus": true }
        })
        element.triggerHandler('click');
        expect(spyDialog).not.toHaveBeenCalled();
    }));
});
