'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:getFirstCard
 * @description
 * # getFirstCard
 */
angular.module('viewMultipleWallet')
    .directive('getFirstCard', function(Cards, ngDialog, GET_FIRST_CARD) {
        return {
            restrict: 'A',
            priority: -1,
            link: function(scope, element, attrs) {
                element.bind('click', function(e) {
                    // console.log('directive execution here:::');
                    var configGetFirstCard = angular.fromJson(GET_FIRST_CARD);

                    var allowFirstCard = Cards.getFirstCardFactory();
                    if (allowFirstCard.email === true && allowFirstCard.mobile === true && allowFirstCard.profile === true && allowFirstCard.addressInfo === true && allowFirstCard.kycStatus === true) {
                        //  allow the User to proceed with card acquiring
                        // console.log('allowFirstCard ::' + allowFirstCard)
                    } else {

                        if (configGetFirstCard.FirstCardDataSeekPoints.email.switch == 'ON' && allowFirstCard.email === false) {
                            verify('Email', e);
                        } else if (configGetFirstCard.FirstCardDataSeekPoints.mobile.switch == 'ON' && allowFirstCard.mobile === false) {
                            verify('Mobile', e);
                        } else if (configGetFirstCard.FirstCardDataSeekPoints.profile.switch === 'ON' && allowFirstCard.profile === false) {
                            verify('Profile', e);
                        } else if (configGetFirstCard.FirstCardDataSeekPoints.addressInfo.switch === 'ON' && allowFirstCard.addressInfo === false) {
                            verify('Address', e);
                        } else if (configGetFirstCard.FirstCardDataSeekPoints.KYC.switch === 'ON' && allowFirstCard.kycStatus === false) {
                            verify('KYC', e);
                        } else {
                            // allow normal execution of ng-click
                        }
                    }
                });
            }
        };

        function verify(type, event) {
            var template, controller;
            switch (type) {
                case 'Email':
                    template = 'app/components/notifyEmailVerify/partials/notifyEmailVerify.html';
                    controller = 'notifyEmailVerifyCtrl';
                    break;
                case 'Mobile':
                    template = 'app/components/notifyMobileVerify/partials/notifyMobileVerify.html';
                    controller = 'notifyMobileVerifyCtrl';
                    break;
                case 'Profile':
                    template = 'app/components/notifyProfileVerify/partials/notifyProfileVerify.html';
                    controller = 'notifyProfileVerifyCtrl';
                    break;
                case 'Address':
                    template = 'app/components/notifyAddressVerify/partials/notifyAddressVerify.html';
                    controller = 'notifyAddressVerifyCtrl';
                    break;
                case 'KYC':
                    template = 'app/components/notifyDocumentVerify/partials/notifyDocumentVerify.html';
                    controller = 'notifyDocumentVerifyCtrl';
                    break
            }
            event.stopImmediatePropagation();
            event.preventDefault();
            notificationDialog(template, controller);
        };

        function notificationDialog(template, controller) {
            ngDialog.open({
                template: template,
                className: 'dialog-notification',
                controller: controller,
                scope: true,
                showClose: false,
                data: { trigger: 'get-first-card' }
            });
        }
    });
