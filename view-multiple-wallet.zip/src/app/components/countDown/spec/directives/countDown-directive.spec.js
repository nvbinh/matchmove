'use strict';
describe('Directive: countDown', function () {
    // load the directive's module
    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var scopeElement,
        scope,
        isolatedScope,
        rootScope,
        $timeout,
        $interval,
        httpBackend;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Intialize directive scope
    beforeEach(inject(function ($rootScope, $compile, _$timeout_, _$interval_) {
      rootScope = $rootScope;
      scope = $rootScope.$new();
      $timeout = _$timeout_;
      $interval = _$interval_;
      scope.id = "464d9a323e583498f76860aef89a32b3";
      scopeElement = angular.element('<div id="464d9a323e583498f76860aef89a32b3" count-down></div><span class="cvv ng-binding" id="cvv-464d9a323e583498f76860aef89a32b3" ng-show="::card.cvv" style="display: inline;">571</span>');
      $compile(scopeElement)(scope);
      spyOn($interval, 'flush').and.callThrough();
    }));
    it('should initially display the card ID', function(){
        var spanElem = scopeElement.find('span');
        expect(scopeElement[1]).toHaveText(571);
        expect(scopeElement[1]).not.toHaveClass('ng-hide');
    });
    it('should hide ccvId after timeout flush ',function(){
        spyOn(rootScope, '$broadcast').and.callThrough()
        expect(scopeElement[1]).not.toHaveClass('ng-hide');
        rootScope.$broadcast(scope.id);
        // tick the timer for starting the countdown
        $interval.flush(2000);
        scope.$apply();
        // expect(scopeElement[0]).toHaveText('9 minutes 59 seconds');
        expect(scopeElement[1]).toHaveClass('ng-hide');
    });
});
