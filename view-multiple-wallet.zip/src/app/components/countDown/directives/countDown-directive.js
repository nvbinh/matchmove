'use strict';
angular.module('viewMultipleWallet')
    .directive('countDown', ['timeUtilFactory', '$interval', '$analytics',
        function (timeUtilFactory, $interval, $analytics) {
            return {
                restrict: 'A',
                scope: {
                    date: '@',
                    id: '@'
                },
                link: function (scope, element) {
                    var future;
                    var cvvId = '#cvv-' + scope.id;
                    var interval = $interval;
                    scope.intervals = {};

                    scope.$on(scope.id, function () {
                        future = new Date();
                        future = future.setMinutes(future.getMinutes() + 10);
                        interval.cancel(scope.intervals[scope.id]);
                        scope.intervals[scope.id] = $interval(function () {
                            var diff;
                            diff = Math.floor((future - new Date()
                                .getTime()) / 1000);
                            if (diff <= 0) {
                                interval.cancel(scope.intervals[scope.id]);
                                angular.element(cvvId)
                                    .hide();
                            }

                            return element.text(timeUtilFactory.dhms(diff));
                        }, 1000);
                        $analytics.eventTrack('Security Token Fetched From Server', {
                            category: 'Security Token',
                            label: 'Security Token Fetched From Server'
                        });
                    });
                }
            };
        }
    ]);