'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:callCs
 * @description
 * # callCs
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'languageChange', function () {
        return {
            templateUrl: 'app/components/languageChange/partials/languageChange.partial.html',
            scope: {
                mainMessage: '=',
                subMessage: '='
            },
            restrict: 'E',
            replace: true,
            controller: 'languageChangeCtrl',
            link: function () {

            }
        };
    } );
