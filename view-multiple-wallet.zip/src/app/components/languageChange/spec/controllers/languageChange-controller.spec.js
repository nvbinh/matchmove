'use strict';
describe( 'Controller: languageChangeCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    var languageChangeCtrl,
        scope,
        callCsCtrl;
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope ) {
        scope = $rootScope.$new();
        scope.TRANSLATION_PARAMS= {
                'partFilesPath': '/assets/locales',
                'preferredLanguage': 'en_us',
                'source': 'https://vcard1.s3.amazonaws.com/hdbank/multi/',
                'supportedLanguages': [
                    {
                        "i18n": "en_us",
                        "name": "English"
                    },
                    {
                        "i18n": "vi_vn",
                        "name": "Vietnamese"
                    }
                ]
            };
        callCsCtrl = $controller( 'languageChangeCtrl', {
            $scope: scope
        } );
    } ) );
    it( 'should TRANSLATION_PARAMS settings', function () {
        var supported = [
            {
                "i18n": "en_us",
                "name": "English"
            },
            {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            }
        ];
        expect( scope.TRANSLATION_PARAMS.partFilesPath ).toEqual( '/assets/locales' );
        expect( scope.TRANSLATION_PARAMS.preferredLanguage ).toEqual( 'en_us' );
        expect( scope.TRANSLATION_PARAMS.source ).toEqual( 'https://vcard1.s3.amazonaws.com/hdbank/multi/' );
        expect( scope.TRANSLATION_PARAMS.supportedLanguages ).toEqual( supported );
    } );
} );
