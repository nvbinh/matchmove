'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:callCsCtrl
 * @description
 * # callCsCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'languageChangeCtrl', function( TRANSLATION_PARAMS, $rootScope, $scope, $translate, $filter, $state, $window, store, $timeout, helperFactory, amMoment, PubSub ) {
        $scope.translationConfig = angular.fromJson( TRANSLATION_PARAMS );
        $scope.activeProvider = $filter( 'filter' )( $scope.translationConfig.supportedLanguages, {
            i18n: $translate.use()
        } )[ 0 ];

        $scope.setProvider = function( lang ) {
            $timeout( $translate.use( lang ), 100 );
            $timeout( amMoment.changeLocale(lang));
            var varKey = helperFactory.mapControllerToPageTitle( $state.current.name );

            $rootScope.$on( '$translateChangeSuccess', function( event, data ) {
                $window.document.title = $translate.instant( 'PAGE_TITLE_TEXT', {
                    pagename: $translate.instant( varKey )
                } );
            } );
            $rootScope.$emit( 'ngDropover.close', 'languageChangeDropDown' );
            $scope.activeProvider = $filter( 'filter' )( $scope.translationConfig.supportedLanguages, {
                i18n: lang
            } )[ 0 ];
            store.set('selectedLang', lang);
            PubSub.publish('language-changed');
            if ($state.current.name === 'wallet.notification' || $state.current.name === 'wallet.fund.claim') {
                $state.go( '.', {}, {reload: true} );
            }
        };
        $scope.avilableLanguages = $scope.translationConfig.supportedLanguages;
    } );
