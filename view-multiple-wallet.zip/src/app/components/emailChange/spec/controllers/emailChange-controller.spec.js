'use strict';
describe('Controller: emailChangeCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var emailChangeCtrl,
      _HTTP_HOST,
      _EMAIL_VERIFICATION_URL,
      scope,
      API_BASE,
      httpBackend,
      user,
      userUpdateResponse;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, HTTP_HOST, EMAIL_VERIFICATION_URL, _userFactory_, _API_BASE_) {
    scope = $rootScope.$new();
    _HTTP_HOST = HTTP_HOST;
    _EMAIL_VERIFICATION_URL = EMAIL_VERIFICATION_URL;
    API_BASE = _API_BASE_;
    user = _userFactory_;
    emailChangeCtrl = $controller('emailChangeCtrl', {
      $scope: scope
    });
    userUpdateResponse = {
          "id": "a302ba291accb13fb6e6123c718af6ab",
          "email": "balajiv+21@chimeratechnologies.com",
          "name": {
            "first": "Balaji",
            "last": "Two One",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345674"
          },
          "gender": "male",
          "title": "Mr",
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            }
          ],
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2016-02-08T19:29:44+08:00"
          }
        };

    spyOn(user, 'updateUser').and.callThrough();
  }));

  it('should have email', function(){
      expect(scope.email).toBeDefined();
  });
  it('should have verification sent', function(){
      expect(scope.verificationSent).toBeDefined();
  });
  describe('changeEmail Function', function(){
      var response;
      it('should define parameters', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(200, userUpdateResponse);
          scope.changeEmail();
          httpBackend.flush();
          expect(scope.endpoint).toEqual(_HTTP_HOST + _EMAIL_VERIFICATION_URL);
          expect(scope.endpoint).toBeDefined();
      });
      it('should invoke an HTTP REQUEST and return a promise containing http status response', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(200, userUpdateResponse);
          response = scope.changeEmail();
          httpBackend.flush();
          expect(response.$$state).toBeDefined();
          expect(response.$$state.status).toBeDefined();
          expect(response.$$state.status).toEqual(1);
      });
      it('Error 401 email already in use', function(){
          // http://stackoverflow.com/questions/23937505/angular-httpbackend-expectget-respond-with-409-status-custom-statustext/23937819
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [401, 'error body', {}, '(HTTP/1.1 401 userEmailAlreadyInUse)'];
            });
          scope.changeEmail();
          httpBackend.flush();
          expect(scope.changeEmailvalidationError).toBeDefined();
          expect(scope.changeEmailError).toBeTruthy();
      });
      it('Error 401 email fallback error', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [401, 'error body', {}, '(HTTP/1.1 401 userEmail401Fallback)'];
            });
          scope.changeEmail();
          httpBackend.flush();
          expect(scope.changeEmailvalidationError).toBeDefined();
          expect(scope.changeEmailError).toBeTruthy();
      });
      it('Error 400 email error', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [400, 'error body', {}, '(HTTP/1.1 400 userEmail400Error)'];
            });
          scope.changeEmail();
          httpBackend.flush();
          expect(scope.changeEmailvalidationError).toBeDefined();
          expect(scope.changeEmailError).toBeTruthy();
      });
      it('Error 500 email error', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [500, 'error body', {}, '(HTTP/1.1 500 userEmail500Error)'];
            });
          scope.changeEmail();
          httpBackend.flush();
          expect(scope.changeEmailvalidationError).toBeDefined();
          expect(scope.changeEmailError).toBeTruthy();
      });
      it('Error 503 email generic error', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [503, 'error body', {}, '(HTTP/1.1 503 userEmail503Generic)'];
            });
          scope.changeEmail();
          httpBackend.flush();
          expect(scope.changeEmailvalidationError).toBeDefined();
          expect(scope.changeEmailError).toBeTruthy();
      });
  });

  describe('close verification Modal', function(){
      it('should have scope variables defined', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(200, userUpdateResponse);
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.messageText).toBeDefined();
          expect(scope.messageIcon).toBeDefined();
          expect(scope.messageType).toBe('success');
          expect(scope.turnOnFlag).toBeDefined();
          expect(scope.endpoint).toBeDefined();
          expect(scope.isLoading).toBeDefined();
      });
      it('send verification token success:  get 200 response for a valid user data', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(200, userUpdateResponse);
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.verificationSent).toBeTruthy();
      });
      it('Error 401 email already taken', function(){
         httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [401, 'error body', {}, '(HTTP/1.1 401 userEmailAlreadyInUse)'];
            });
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.messageIcon).toBe('mcw-common-alert');
          expect(scope.messageText).toBeDefined();
          expect(scope.messageType).toBe('error');
      });
      it('Error 401 other error', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [401, 'error body', {}, '(HTTP/1.1 401 userEmail401Fallback)'];
            });
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.messageIcon).toBe('mcw-common-alert');
          expect(scope.messageText).toBeDefined();
          expect(scope.messageType).toBe('error');
      });
      it('Error 400 generic', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [400, 'error body', {}, '(HTTP/1.1 400 userEmail400Error)'];
            });
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.messageIcon).toBe('mcw-common-alert');
          expect(scope.messageText).toBeDefined();
          expect(scope.messageType).toBe('error');
      });
      it('Error 500 ', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [500, 'error body', {}, '(HTTP/1.1 500 userEmail500Error)'];
            });
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.messageIcon).toBe('mcw-common-alert');
          expect(scope.messageText).toBeDefined();
          expect(scope.messageType).toBe('error');
      });
      it('Error 503 generic', function(){
          httpBackend.whenPUT(API_BASE + 'users').respond(function (method, url, data, headers) {
                return [503, 'error body', {}, '(HTTP/1.1 503 userEmail503Generic)'];
            });
          scope.closeVerificationModal();
          httpBackend.flush();
          expect(scope.messageIcon).toBe('mcw-common-alert');
          expect(scope.messageText).toBeDefined();
          expect(scope.messageType).toBe('error');
      });
  });
});
