'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:emailChangeCtrl
 * @description
 * # emailChangeCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('emailChangeCtrl', function ($scope, $filter, HTTP_HOST, EMAIL_VERIFICATION_URL, $http, API_BASE, store, ngDialog, userFactory, $timeout) {
        $scope.verificationSent = false;
        $scope.email = '';

        var $translate = $filter('translate');

        $scope.changeEmail = function(){
            $scope.changeEmailError = false;
            $scope.endpoint = HTTP_HOST + EMAIL_VERIFICATION_URL;
            $scope.isLoading = true;
            var getData = userFactory.updateUser({'email': $scope.email, 'endpoint': $scope.endpoint})
            .then(function(response){
                if(response.status === 200){
                    $scope.verificationSent = true;
                    store.set(response.data.token, { user: $scope.email });
                }
                $scope.isLoading = false;
            },function(response) {
                if(response.status === 400) {
                  if (response.statusText.indexOf('userEmailAlreadyInUse') > -1) {
                      $scope.changeEmailvalidationError = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.400.DUPLICATE_USER');
                  }
                  else {
                    $scope.changeEmailvalidationError = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.400.FALLBACK');
                  }
                }
                else if(response.status === 401) {
                  $scope.changeEmailvalidationError = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.401');
                }
                else if(response.status === 500) {
                  $scope.changeEmailvalidationError = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.500');
                }
                else {
                  $scope.changeEmailvalidationError = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.GENERIC');
                }
                $scope.changeEmailError = true;
                $scope.isLoading = false;
            });
            return getData;
        };

        $scope.closeVerificationModal = function(){
            $scope.messageText = ''; // response.statusText OR MODAL.NOTIFICATION_EMAIL_MODAL.RESENT_MESSAGE
            $scope.messageIcon = ''; // mcw-common-alert OR mcw-accountdetails-savechanges
            $scope.messageType = ''; // error OR success
            $scope.turnOnFlag = false;

            $scope.endpoint = HTTP_HOST + EMAIL_VERIFICATION_URL;
            $scope.isLoading = true;
            var getData = userFactory.updateUser({'email': $scope.email, 'endpoint': $scope.endpoint})
            .then(function(response){
                $scope.turnOnFlag = true;
                $scope.messageText = $translate('MODAL.NOTIFICATION_EMAIL_MODAL.RESENT_MESSAGE');
                $scope.messageIcon = 'mcw-accountdetails-savechanges';
                $scope.messageType = 'success';
                if(response.status === 200){
                    $scope.verificationSent = true;
                    store.set(response.data.token, { user: $scope.email });
                }
                $scope.isLoading = false;
            },function(response) {
                $scope.turnOnFlag = true;
                $scope.messageIcon = 'mcw-common-alert';
                $scope.messageType = 'error';
                if(response.status === 401) {
                  if (response.statusText.indexOf('userEmailAlreadyInUse') > -1) {
                      $scope.messageText = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.401.DUPLICATE_USER');
                  }
                  else {
                    $scope.messageText = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.401.FALLBACK');
                  }
                }
                else if(response.status === 400) {
                  $scope.messageText = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.400');
                }
                else if(response.status === 500) {
                  $scope.messageText = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.500');
                }
                else {
                  $scope.messageText = $translate('ERRORS.VALIDATION.USER.EMAIL_CHANGE.GENERIC');
                }
                $scope.isLoading = false;
            });
            $timeout(function() {
                ngDialog.closeAll();
            }, parseInt(5000));
            return getData;
        };
    });
