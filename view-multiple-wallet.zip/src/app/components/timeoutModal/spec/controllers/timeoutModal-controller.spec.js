'use strict';
describe('Controller: timeoutModalCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var timeoutModalCtrl,
      rootScope,
      _store,
      _ngDialog, 
      scope;
// Initialize the controller and a mock scope
//beforeEach(inject(function($controller, $rootScope, ngDialog, $rootScope, store) {
    beforeEach(inject(function($rootScope, authenticationFactory, ngDialog, store, $controller){
        scope = $rootScope.$new(),
        _store = store,
        rootScope = $rootScope,
        _ngDialog = ngDialog,
        _store = store;
        timeoutModalCtrl = $controller('timeoutModalCtrl', {
            $scope: scope
        });
    }));
  describe('end session', function(){
      it('should set loaded to true', function(){
          scope.endSession();
          expect(rootScope.loaded).toBeTruthy();
      });
      it('should clear user session', function(){
          scope.endSession();
          var user = _store.get('user');
          expect(user).toEqual(null);
      });
  });

  describe('resume session', function(){
      it('should close ngDialog', function(){
          spyOn(_ngDialog, 'closeAll');
          scope.resumeSession();
          expect(_ngDialog.closeAll).toHaveBeenCalled();
      });
  });
});

