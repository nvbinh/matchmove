'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:timeoutModalCtrl
 * @description
 * # timeoutModalCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'timeoutModalCtrl', function ( $scope, $rootScope, authenticationFactory, ngDialog, Idle, $state, store, loginSvcService ) {

        $scope.endSession = function () {
            $rootScope.loaded = true;
            authenticationFactory.ClearCredentials();
            Idle.unwatch();
            ngDialog.closeAll();
            $state.go( 'auth.login' );
        };


        $scope.resumeSession = function () {
            Idle.watch();
            ngDialog.closeAll();
        };

        $scope.credentials = {};
        if ( store.get( 'user' ) ) {
            $scope.user = store.get( 'user' );
        } else {
            $scope.user = {};
        }

        $scope.credentials.email = $scope.user.email ? $scope.user.email : '';

        $scope.resumeLogin = function() {
            loginSvcService.resumeSession( $scope.credentials ).then( function( response ) {
                $scope.isUserLoggedIn = true;
                //console.log(response);
                Idle.watch();
            }, function( error ) {
                $scope.isUserLoggedIn = false;
                //console.log(error);
            } );
        };
    } );
