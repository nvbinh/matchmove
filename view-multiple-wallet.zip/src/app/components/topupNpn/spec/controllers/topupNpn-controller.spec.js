'use strict';
describe( 'Controller: topupNpnCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet', 'mockFirebaseFunctions' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var topupNpnCtrl,
        scope,
        httpBackend,
        npnData,
        $timeout,
        fbFnFactory,
        store;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller
    beforeEach( inject( function( $controller, $rootScope, _$timeout_, _firebaseFunctionsFactory_, _store_ ) {
        scope = $rootScope.$new();
        store = _store_;
        fbFnFactory = _firebaseFunctionsFactory_;
        firebase.apps = [];
        $timeout = _$timeout_;
        topupNpnCtrl = $controller( 'topupNpnCtrl', {
            $scope: scope
        } );
        store.set('selectedLang', 'en_us');
        scope.provider = 'NPN';
        npnData = {
          "npn": {
                "en_us": {
                  "-KKEoQd_zZpA0F6U67zB": {
                    "description": "<h1>1</h1><p>Select “More Services”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                    "order": "0"
                  },
                  "-KKEojQWx5U5Jxnvopcp": {
                    "description": "<h1>2</h1><p>Select “Bill Payments”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/ibanking/step-02.png",
                    "order": "1"
                  }
                },
                "vi_vn": {
                  "-KKEoQd_zZpA0F6U67zC": {
                    "description": "<h1>1</h1><p>VN- Select “More Services”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                    "order": "0"
                  },
                  "-KKEojQWx5U5Jxnvopcq": {
                    "description": "<h1>2</h1><p>VN - Select “Bill Payments”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/ibanking/step-02.png",
                    "order": "1"
                  }
                }
            }
        };
    } ) );

    describe(' get NPN data ', function(){
        it(' :: should return npn data as a promise', function() {
            scope.npnRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang );
            scope.npnRef.on('value', function(snapshot){
                scope.npnData = [];
                $timeout(function(){
                    scope.npnHasData = true;
                    scope.npnObj = snapshot.val();
                    angular.forEach(scope.npnObj, function(value, key){
                        scope.npnData.push(value);
                        expect(scope.npnData).toBeDefined();
                        expect(scope.npnData).toEqual(npnData.npn.en_us);
                    });
                }, 10);
            });
            scope.npnRef.fakeEvent('value', null, npnData.npn.en_us);
            scope.loadNPNData();
            // scope.atmRef.flush();
            fbFnFactory.flushAll(scope.npnRef);
        });
    });
} );
