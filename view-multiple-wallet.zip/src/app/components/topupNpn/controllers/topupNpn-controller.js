'use strict';

angular.module( 'viewMultipleWallet' )
    .controller( 'topupNpnCtrl', function ( $rootScope, CONTENT_NET, store, $scope, $timeout, PubSub ) {

        $scope.provider = 'NPN';
        $scope.placeName = 'NPN';
        $scope.types = 'atm';

        $scope.npmHasData = false;

        $scope.loadNPNData = function () {
            if (firebase.apps.length === 0) {
              $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.lang = store.get('selectedLang');
            $scope.npnRef = $rootScope.firebaseApp.database().ref( 'guides/payments/'+angular.lowercase($scope.provider)+ '/' + $scope.lang );

            $scope.npnRef.on('value', function(snapshot){
                $scope.npnData = [];
                $timeout(function(){
                    $scope.npnHasData = true
                    $scope.npnObj = snapshot.val();
                    angular.forEach($scope.npnObj, function(value, key){
                        $scope.npnData.push(value);
                      });
                }, 10)
            });
        };
        $scope.loadNPNData();
        PubSub.subscribe('language-changed', $scope.loadNPNData);
    } );
