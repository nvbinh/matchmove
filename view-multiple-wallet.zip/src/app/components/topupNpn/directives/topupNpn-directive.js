'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:doKyc
 * @description
 * # doKyc
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'topupNpn', function () {
        return {
            templateUrl: 'app/components/topupNpn/partials/topupNpn.html',
            restrict: 'A',
            controller: 'topupNpnCtrl',
            transclude: true,
            replace: true,
            link: function ( scope, element, attrs ) {

            }
        };
    } );
