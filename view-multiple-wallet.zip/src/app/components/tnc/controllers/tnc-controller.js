'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:tncCtrl
 * @description
 * # tncCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('tncCtrl', function ($rootScope, $scope, store, CONTENT_NET, PubSub, $timeout) {

        $scope.loadTncData = function () {
            $scope.isLoading = true;
            $scope.lang = store.get('selectedLang');

            if (firebase.apps.length === 0) {
               $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.tncRef = $rootScope.firebaseApp.database().ref( 'tnc/'+ $scope.lang );

            $scope.tncArray = [];
            $scope.tncRef.on('value', function(snapshot) {
                $timeout(function(){
                    $scope.tnc = snapshot.val();
                    angular.forEach($scope.tnc, function(value, key){
                        $scope.tncArray.push(value);
                    });
                    $scope.isLoading = false;
                }, 0);

            });
        };
        $scope.loadTncData();
        PubSub.subscribe('language-changed', $scope.loadTncData);
  });
