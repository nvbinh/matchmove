'use strict';
describe('Controller: tncCtrl', function () {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
// load the controller's module
  beforeEach(module('viewMultipleWallet', 'mockFirebaseFunctions' ));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var tncCtrl,
      scope,
      arr,
      $timeout,
      httpBackend,
      q,
      tncRef,
      deferred,
      firebase,
      rootScope,
      fbFnFactory,
      store,
      tncData;
      // language based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
// Initialize the controller and a mock scope
  describe(' TNC data test specs', function(){
        beforeEach(inject(function($controller, $rootScope,  _$timeout_, $q, _firebaseFunctionsFactory_, _store_, CONTENT_NET){
            scope = $rootScope.$new();
            firebase = window.firebase;
            store = _store_;
            fbFnFactory = _firebaseFunctionsFactory_;
            firebase.apps = [];
            tncCtrl = $controller('tncCtrl', {
              $scope: scope
            });
            q = $q;
            store.set('selectedLang', 'en_us');
            tncData = {
                  "en_us": {
                    "-K0-gvWrQge4SbR3eVlx": {
                      "data": "english tnc here"
                    }
                  },
                  "vi_vn": {
                    "-K0-gvWrQge4SbR3eVlx": {
                      "data": "VN tnc here"
                    }
                  }
                };
        $timeout = _$timeout_;
        }));
      afterEach( function() {
          httpBackend.flush();
          httpBackend.verifyNoOutstandingExpectation();
          httpBackend.verifyNoOutstandingRequest();
        } );
     describe(' getTncContent data test specs', function(){
        it(' :: should return tnc data as a promise', function() {
            scope.tncRef = fbFnFactory.stubRef('tnc/' + scope.lang);

            scope.tncRef.on('value', function(snapshot){
                    scope.tncArray = [];
                scope.tnc = snapshot.val();
                spyOn(angular, 'forEach').and.callThrough();

                    expect(scope.tncArray).toBeDefined();
                    expect(scope.tncArray).toEqual(tncData);
            });
            scope.tncRef.fakeEvent('value', null, tncData);
            scope.loadTncData();
            fbFnFactory.flushAll(scope.tncRef);
        });
    });
    });
});
