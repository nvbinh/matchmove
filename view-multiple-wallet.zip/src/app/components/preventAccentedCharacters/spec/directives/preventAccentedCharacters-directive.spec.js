'use strict';
describe( 'Directive: preventAccentedCharacters', function() {
	// load the directive's module
	beforeEach( module( 'viewMultipleWallet' ) );
	// mock constants
	beforeEach( module( 'viewMultipleWallet', function( $provide ) {
	    $provide.constant( "TRANSLATION_PARAMS", {
	      "partFilesPath": "../assets/locales/",
	      "preferredLanguage": "vi_vn",
	      "client": "hdb",
	      "source": "http://localhost:3000/assets/hdb/locales\/",
	      "supportedLanguages": [ {
	        "i18n": "en_us",
	        "name": "English"
	      }, {
	        "i18n": "vi_vn",
	        "name": "Vietnamese"
	      } ]
	    } );
	  } ) );
	  var element,
	    compile,
	    $scope,
	    httpBackend,
	    $q,
	    API_BASE,
	    form;
	    // language based mock calls
	  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
	    httpBackend = $httpBackend;
	    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
	    for ( var i = 0; i < lngth; i++ ) {
	      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
	      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
	      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
	    }
	} ) );

	beforeEach(inject(function($compile, $rootScope){
	    $scope = $rootScope;
	    element = angular.element(
	      '<form name="form"><input name="address_1" ng-minlength="1" ng-maxlength="35" prevent-accented-characters type="text" ng-model="address1" autocomplete="off" required></form>'
	    );
	    $scope.model = { address1: null};
	    $compile(element)($scope);
        $scope.$digest();
        form = $scope.form;
    }));
    
	it('should be invalid when user enters special characters like <>', function(){
        form.address_1.$setViewValue('<>abc');
        expect(form.address_1.$valid).toBe(false);
    });

    it('should validate the input with the pattern allowing all alpha with space', function(){
        form.address_1.$setViewValue('abcdeijkl pqrstuvwxyz');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing all numeric', function(){
        form.address_1.$setViewValue('0123456789');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing ~', function(){
        form.address_1.$setViewValue('~');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing !', function(){
        form.address_1.$setViewValue('!');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing @', function(){
        form.address_1.$setViewValue('@');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing #', function(){
        form.address_1.$setViewValue('#');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing %', function(){
        form.address_1.$setViewValue('%');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing ^', function(){
        form.address_1.$setViewValue('^');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing *', function(){
        form.address_1.$setViewValue('*');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing (', function(){
        form.address_1.$setViewValue('(');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing )', function(){
        form.address_1.$setViewValue(')');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing _', function(){
        form.address_1.$setViewValue('_');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing +', function(){
        form.address_1.$setViewValue('+');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing -', function(){
        form.address_1.$setViewValue('-');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing =', function(){
        form.address_1.$setViewValue('=');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing [', function(){
        form.address_1.$setViewValue('[');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing ]', function(){
        form.address_1.$setViewValue(']');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing {', function(){
        form.address_1.$setViewValue('{');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing }', function(){
        form.address_1.$setViewValue('}');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing :', function(){
        form.address_1.$setViewValue(':');
        expect(form.address_1.$valid).toBe(true);
    });

    it("should validate the input with the pattern allowing '", function(){
        form.address_1.$setViewValue("'");
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing ;', function(){
        form.address_1.$setViewValue(';');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing "', function(){
        form.address_1.$setViewValue('"');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing /', function(){
        form.address_1.$setViewValue('/');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing |', function(){
        form.address_1.$setViewValue('|');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing ,', function(){
        form.address_1.$setViewValue(',');
        expect(form.address_1.$valid).toBe(true);
    });

    it('should validate the input with the pattern allowing .', function(){
        form.address_1.$setViewValue('.');
        expect(form.address_1.$valid).toBe(true);
    });

} );