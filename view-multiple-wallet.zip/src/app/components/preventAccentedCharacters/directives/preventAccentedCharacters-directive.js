'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:preventAccentedCharacters
 * @description
 * # preventAccentedCharacters
 */
angular.module( 'viewMultipleWallet' )
	.directive( 'preventAccentedCharacters', function() {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function( scope, element, attrs, controller ) {
				function noAccentedChars( ngModelValue ) {
					if ( ngModelValue.match( /[^a-zA-Z0-9 ~!@#$%^*()_+\-=\[\]{};`':"\\|,.\/?]+/ ) ) {
						controller.$setValidity( 'accentedCharacter', false );
					} else {
						controller.$setValidity( 'accentedCharacter', true );
					}
					return ngModelValue;
				}
				controller.$parsers.push( noAccentedChars );
			}
		};
	} );
