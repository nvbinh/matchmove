'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:itemhide
 * @description
 * # itemhide
 */
angular.module('viewMultipleWallet')
    .directive('itemHide', function ($timeout) {
        return {
            restrict: 'A',
            scope: {
                ngModel: '='
            },
            link: function(scope, element) {
                $timeout(function(){
                    element.hide();
                }, 5000);
            }
        };
    });
