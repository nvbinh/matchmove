'use strict';
describe( 'Directive: itemhide', function() {
  // load the directive's module
  beforeEach( module( 'viewMultipleWallet' ) );
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var element,
    scope,
    httpBackend,
    API_BASE,
    scopeElem,
    timeout;
  // langugage based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  beforeEach( inject( function( $rootScope, $compile, _API_BASE_, $timeout ) {
    scope = $rootScope.$new();
    API_BASE = _API_BASE_;
    timeout = $timeout;
    scopeElem = angular.element( '<aside class="msg-banner" item-hide>' +
      '<aside class="error-banner">' +
      '<span class="mcw-common-alert"></span>' +
      '<p>Card Creation Failed</p>' +
      '</aside>' +
      '</aside>' );
    $compile( scopeElem )( scope );
    scope.$digest();
  } ) );
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  it( 'should display element initially', function() {
    expect( scopeElem.find( 'p' ) ).toHaveText( 'Card Creation Failed' );
    expect( scopeElem ).not.toHaveAttr( 'style' );
  } );
  /* //TODO:: timeout flush in CI is not firing correctly. re-visit this test spec later
  it('should hide element initially', function(){
      expect(scopeElem).not.toHaveAttr('style', 'display: none;');
      timeout.flush(10000);
      scope.$digest();
      //timeout.verifyNoPendingTasks();
      expect(scopeElem).toHaveAttr('style', 'display: none;');
  });*/
} );