'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:personalInfo
 * @description
 * # personalInfo
 */
angular.module( 'viewMultipleWallet' )
	.directive( 'personalInfo', function( $compile ) {
		return {
			scope: true,
			restrict: 'E',
			templateUrl: 'app/components/personalInfo/partials/personalInfo.html',
			link: function( ) {

			}
		};
	} );
