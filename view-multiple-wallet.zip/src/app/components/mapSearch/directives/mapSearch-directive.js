'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:mapSearch
 * @description
 * # mapSearch
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'mapSearch', function ( $log, $timeout, $filter ) {
        return {
            restrict: 'E',
            scope: {
                placeName: '@placeName',
                types: '@types',
                // myLocation: '=myLocation',
                // placelocations: '=placeReference',
            },
            controller: [ '$scope', function ( $scope ) {

                $scope.$on( 'mapInitialized', function ( event, map ) {
                    $timeout( function () {
                        $scope.objMapa = map;
                        $scope.placelocations = [];
                        var service = new google.maps.places.PlacesService( map );
                        $scope.lat === 0 ? $scope.lat = 1.290270 : $scope.lat = $scope.lat;
                        $scope.lng === 0 ? $scope.lng = 103.851959 : $scope.lng = $scope.lng;
                        service.nearbySearch( {
                            location: new google.maps.LatLng( $scope.lat, $scope.lng ),
                            radius: 500,
                            types: [ $scope.types ],
                            name: [ 'DBS', 'POSB' ],
                            key: 'AIzaSyCdfVT99PtKmZrJBJ6eVy5o-HvTbPIhrbs'
                        }, callback );
                    }, 4000 );
                } );

                function callback( results, status ) {
                    var placelocations = [],
                        item = {},
                        i = 0;
                    if ( status === google.maps.places.PlacesServiceStatus.OK ) {
                        for ( i = 0; i < results.length; i++ ) {
                            item = {};
                            createMarker( results[ i ] );
                            item.name = results[ i ].name;
                            item.address = results[ i ].vicinity;
                            item.postal_code = '';
                            placelocations.push( item );
                        }
                    }
                    if ( $scope.mapError === false ) {
                        $scope.placelocations = placelocations;
                    }
                }

                function createMarker( place ) {
                    var placeLoc = place.geometry.location,
                        content = '',
                        infowindow = new google.maps.InfoWindow(),
                        marker;

                    try {
                        marker = new google.maps.Marker( {
                            map: $scope.objMapa,
                            icon: $scope.iconcss,
                            position: place.geometry.location
                        } );

                        content += '<h3>' + place.name + '</h3><br>';
                        content += '<div class="mapInfo-content">' + place.vicinity + '<br>';
                        content += '</div>';

                        google.maps.event.addListener( marker, 'click', function () {
                            infowindow.setContent( '<h3>' + content + '</h3>' );
                            infowindow.open( $scope.objMapa, this );
                        } );

                    } catch ( e ) {

                    }
                }

            } ],

            templateUrl: 'app/components/mapSearch/partials/mapSearch.html',
            link: function ( scope, element, attrs ) {
                scope.lat = 0;
                scope.lng = 0;
                scope.iconcss = '';
                scope.mapError = false;
                var $translate = $filter( 'translate' );
                switch ( attrs.placeName ) {
                case 'DBS':
                    scope.iconcss = 'https://assets.mmvpay.com/payments/dbs_small.png';
                    scope.types = attrs.types;
                    getLocation();
                    break;
                default:
                    break;
                }

                function showPosition( position ) {
                    scope.lat = position.coords.latitude;
                    scope.lng = position.coords.longitude;

                    var currentPos = {
                        'name': 'currentPos',
                        'lat': scope.lat,
                        'long': scope.lng
                    }
                    scope.myLocation = currentPos;
                }

                function getLocation( icon ) {
                    scope.mapError = false;
                    if ( navigator.geolocation ) {
                        navigator.geolocation.getCurrentPosition( showPosition, handle_errors );
                    } else {
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.NOT_SUPPORTED' ); // geolocation API is not supported
                    }
                }

                function handle_errors( error ) {
                    scope.mapError = false;
                    switch ( error.code ) {
                    case error.PERMISSION_DENIED:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.PERMISSION_DENIED' ); // permission denied
                        break;

                    case error.POSITION_UNAVAILABLE:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.POSITION_UNAVAILABLE' ); // cannot detect current position
                        break;

                    case error.TIMEOUT:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.TIMEOUT' ); // timeout
                        break;

                    default:
                        scope.mapError = true;
                        scope.errorMsg = $translate( 'ERRORS.MAP_SEARCH.GEOLOCATION.FALLBACK' ); // unknown error
                        break;
                    }
                }

            },
        };
    } );
