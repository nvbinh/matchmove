'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:otpCtrl
 * @description
 * # otpCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('otpCtrl', function ($scope, $analytics, $filter, store, authMobileFactory, helperFactory, $rootScope, PubSub, userFactory, $state, $timeout, ngDialog) {
        $scope.verification = {};
        $scope.verification.otp = '';

        $scope.modalOtpMessageTranslate = {};
        if (store.get('user')) {
            $scope.userdetails = store.get('user');
            $scope.modalOtpMessageTranslate.userMobile = $scope.userdetails.mobile.country_code + ' ' + $scope.userdetails.mobile.number; // jshint ignore:line
        }

        $scope.otpVerify = false;
        $scope.changeMobile = false;
        $scope.otpSent = true;

        var $translate = $filter('translate');
        $scope.newTokenSendFailed = false;
        authMobileFactory.requestVerificationOtp()
            .then(function (response) {
                $scope.token = response.data.token;
                $analytics.eventTrack('Request New OTP : Success', {
                    category: 'OTP',
                    label: 'Request New OTP : Success'
                });
            }, function (response) {
                if (response.status === 500) {
                    $scope.otpDeliveryError = $translate('ERRORS.OTP.TOKEN_REQUEST_FAILED.500');
                    $analytics.eventTrack('Request New OTP : Error', {
                        category: 'Error 500',
                        label: 'Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                    });
                } else {
                    $scope.otpDeliveryError = $translate('ERRORS.OTP.TOKEN_REQUEST_FAILED.GENERIC');
                    $analytics.eventTrack('Request New OTP : Error', {
                        category: 'OTP',
                        label: 'Request/Re-Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                    });
                }
                $scope.newTokenSendFailed = true;
            });

        $scope.resendToken = function () {
            $scope.newTokenSendFailed = false;
            $scope.newTokenSent = false;
            authMobileFactory.requestVerificationOtp()
                .then(function (response) {
                    $scope.token = response.data.token;
                    $scope.newTokenSent = true;
                    $analytics.eventTrack('Re-Request New OTP : Success', {
                        category: 'OTP',
                        label: 'Request New OTP : Success'
                    });
                }, function (response) {
                    if (response.status === 500) {
                        $scope.otpDeliveryError = $translate('ERRORS.OTP.TOKEN_RESEND_FAILED.500');
                        $analytics.eventTrack('Re-Request New OTP : Error', {
                            category: 'Error 500',
                            label: 'Request/Re-Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                        });
                    } else {
                        $scope.otpDeliveryError = $translate('ERRORS.OTP.TOKEN_RESEND_FAILED.GENERIC');
                        $analytics.eventTrack('Re-Request New OTP : Error', {
                            category: 'OTP',
                            label: 'Request/Re-Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                        });
                    }
                    $scope.newTokenSendFailed = true;
                });
        };

        $scope.reLoad = function(){
            $timeout(ngDialog.closeAll(), 1000);
            $timeout( $state.go( '.', {}, { reload: true } ), 1000);
        }

        $scope.verifyOtp = function () {
            $scope.verifyingOtp = true;
            $scope.otpVerifyError = false;
            authMobileFactory.verifyOtp($scope.token, $scope.verification.otp.toString())
                .then(function () {
                    $scope.otpVerify = true;
                    $scope.verifyingOtp = false;
                    helperFactory.removeUserCache();
                    //$rootScope.$broadcast('updateOTPStatus');
                    //$rootScope.$broadcast('updateKYCPage');
                    helperFactory.storeUpdateAuthStatus();
                    userFactory.getUser(false);
                    PubSub.publish('mobile-verified');
                    $analytics.eventTrack('Verification OTP : Success', {
                        category: 'OTP',
                        label: 'Verification OTP : Success'
                    });
                    $timeout($scope.reLoad, 1000);
                }, function (response) {
                    if (response.status === 500) {
                        $scope.otpVerificationErrorMsg = $translate('ERRORS.OTP.TOKEN_VERIFICATION.500');
                        $analytics.eventTrack('Verification OTP : Error', {
                            category: 'Error 500',
                            label: 'Verification OTP : Error : ' + response.status + ' : ' + response.statusText
                        });
                    } else if (response.status === 400) {
                        if (response.statusText.indexOf('userAuthenticationValidationFailed') > -1) {
                            $scope.otpVerificationErrorMsg = $translate('ERRORS.OTP.TOKEN_VERIFICATION.400.OTP_INVALID');
                            $analytics.eventTrack('Request New OTP : Error', {
                                category: 'Error 400',
                                label: 'Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                            });
                        } else if (response.statusText.indexOf('userAuthenticationValidationTokenExpired') > -1) {
                            $scope.otpVerificationErrorMsg = $translate('ERRORS.OTP.TOKEN_VERIFICATION.400.OTP_EXPIRED');
                            $analytics.eventTrack('Request New OTP : Error', {
                                category: 'Error 400',
                                label: 'Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                            });
                        } else {
                            $scope.otpVerificationErrorMsg = $translate('ERRORS.OTP.TOKEN_VERIFICATION.400.FALLBACK');
                            $analytics.eventTrack('Request New OTP : Error', {
                                category: 'Error 400',
                                label: 'Request New OTP : Error : ' + response.status + ' : ' + response.statusText
                            });
                        }
                    } else {
                        $scope.otpVerificationErrorMsg = $translate('ERRORS.OTP.TOKEN_VERIFICATION.GENERIC');
                        $analytics.eventTrack('Verification OTP : Error', {
                            category: 'OTP',
                            label: 'Verification OTP : Error : ' + response.status + ' : ' + response.statusText
                        });
                    }
                    $scope.otpVerifyError = true;
                    $scope.verifyingOtp = false;
                });
        };
    });
