/* global inject */
/* global expect */
/* global it */
/* global beforeEach */
/* global describe */
'use strict';
describe('Controller: otpCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var otpCtrl,
      scope,
      httpBackend,
      authMobileFactory,
      API_BASE,
      userData,
      dialog;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _authMobileFactory_, API_BASE, _ngDialog_) {
    scope = $rootScope.$new();
    authMobileFactory = _authMobileFactory_;
    API_BASE = API_BASE;
    dialog = _ngDialog_;
    userData = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "authentications": {
            "email_verified": true,
            "mobile_verified": false
          }
        };
    otpCtrl = $controller('otpCtrl', {
      $scope: scope
    });
    httpBackend.whenPOST(API_BASE+'users/authentications/phone').respond(200,'');
    httpBackend.flush();
  }));
  afterEach( function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  it('should have token', function(){
    expect(scope.token).not.toBe(null);
  });
  it('should Have initial Scope variables defined', function () {
    expect(scope.otpVerify).toBeDefined();
    expect(scope.changeMobile).toBeDefined();
    expect(scope.otpSent).toBeDefined();
  });
  it('The scope variables should be correctly initiallized', function () {
    expect(scope.otpVerify).toBeFalsy();
    expect(scope.changeMobile).toBeFalsy();
    expect(scope.otpSent).toBeTruthy();
  });
  it('should have new token send failed', function(){
      expect(scope.newTokenSendFailed).toBeDefined();
  });
  describe('authMobileFactory requestVerificationOtp', function(){
    it('Error 500', function(){
      httpBackend.whenPOST(API_BASE+'users/authentications/phone').respond(500,'');
      //httpBackend.flush();
      expect(scope.otpDeliveryError).not.toBe(null);
      expect(scope.newTokenSendFailed).toBeDefined();
    });
  });
  describe('resend token', function(){
      beforeEach(inject(function(){
          scope.resendToken();
          httpBackend.flush();
      }));
      describe('authMobileFactory requestVerificationOtp', function(){
        it('Error 500', function(){
          httpBackend.whenPOST(API_BASE+'users/authentications/phone').respond(500,'');
          expect(scope.otpDeliveryError).not.toBe(null);
          expect(scope.newTokenSendFailed).toBeDefined();
        });
      });
      it('have new token sent', function(){
        
          expect(scope.newTokenSent).toBeDefined();
      });
      it('have new token send failed', function(){
        //httpBackend.flush();
          expect(scope.newTokenSendFailed).toBeDefined();
      });
  });
  describe('verify otp on success', function(){
      beforeEach(inject(function(_$httpBackend_,API_BASE){
          httpBackend = _$httpBackend_;
          API_BASE = API_BASE;
          httpBackend.expectPUT(API_BASE+'users/authentications/phone').respond(200,'');
          httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
          httpBackend.whenGET(API_BASE + 'users/authentications/documents').respond(200, {
            "count": "n/a",
            "status": "not_submitted"
          });
          scope.token = '27ccba12efb3cfcf00708386a297efef';
          scope.verification.otp = 'OTP verified';
      }));
      it('should verify OTP correctly 200',function(){
        spyOn(authMobileFactory, 'verifyOtp').and.callThrough();
        spyOn(dialog, 'closeAll');
        scope.verifyOtp(scope.token, scope.verification.otp);
        httpBackend.flush();
        expect(authMobileFactory.verifyOtp).toHaveBeenCalled();
        expect(scope.otpVerify).toBe(true);
        expect(scope.verifyingOtp).toBe(false);      
      });
  });
  describe('verify otp on error', function(){
      beforeEach(inject(function(_$httpBackend_,API_BASE){
          httpBackend = _$httpBackend_;
          API_BASE = API_BASE;
          httpBackend.expectPUT(API_BASE+'users/authentications/phone').respond(500,'');
          scope.token = '27ccba12efb3cfcf00708386a297efef';
          scope.verification.otp = 'OTP verified';
      }));
      it('should verify OTP correctly 500',function(){
        spyOn(authMobileFactory, 'verifyOtp').and.callThrough();
        scope.verifyOtp(scope.token, scope.verification.otp);
        httpBackend.flush();
        expect(authMobileFactory.verifyOtp).toHaveBeenCalled();     
      });
      it('shuold have otp verify error', function(){
        spyOn(authMobileFactory, 'verifyOtp').and.callThrough();
        scope.verifyOtp(scope.token, scope.verification.otp);
        httpBackend.flush();
          expect(scope.otpVerificationErrorMsg).not.toBe(null);
      });
  });
});
