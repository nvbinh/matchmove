'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:comsatPassword
 * @description Show/Hide Password Fields
 * # comsatPassword
 */
angular.module('viewMultipleWallet')
    .directive('comsatPassword', function($compile, $filter, $translate) {

        function link(scope, element, attrs) {
            var template = '<div class="comsat-wrapper">' +
                '<a href="#" ng-click="showHidePw($event)" class="comsat--btn">' +
                "{{'COMPONENT.COMSAT.BUTTON_SHOW' | translate}}" +
                '</a></div>',
                wrapper = angular.element(template);

            $compile(wrapper)(scope);
            element.after(wrapper);
            element.addClass('comsat--element');
            wrapper.prepend(element);

            scope.showHidePw = function($event) {
                $event.preventDefault();

                if ($event.currentTarget.previousElementSibling.getAttribute('type') === 'text') {
                    $event.currentTarget.previousElementSibling.setAttribute('type', 'password');
                    $event.currentTarget.text = $translate.instant('COMPONENT.COMSAT.BUTTON_SHOW');
                } else {
                    $event.currentTarget.previousElementSibling.setAttribute('type', 'text');
                    $event.currentTarget.text = $translate.instant('COMPONENT.COMSAT.BUTTON_HIDE');
                }
            };
        }

        return {
            restrict: 'A',
            link: link,
        };
    });
