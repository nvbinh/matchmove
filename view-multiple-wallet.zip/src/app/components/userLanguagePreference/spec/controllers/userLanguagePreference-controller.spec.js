'use strict';
describe( 'Controller: userLanguagePreferenceCtrl', function () {
    var userLanguagePreferenceCtrl,
        scope,
        user,
        httpBackend,
        API_BASE,
        userInfo,
        ngDialog,
        timeout,
        state;
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_US",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );

    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, $httpBackend, TRANSLATION_PROVIDER, TRANSLATION_PARAMS, _userFactory_, _API_BASE_, store, _ngDialog_, _$timeout_, _$state_ ) {
        scope = $rootScope.$new();
        userInfo = {
            "id": "837cfbb91b156eb17f2b74f245ff5029",
            "email": "balajiv+24@chimeratechnologies.com",
            "name": {
                "first": "Balaji",
                "last": "Two Four",
                "preferred": "balaji two four"
            },
            "mobile": {
                "country_code": "65",
                "number": "65123123"
            },
            "countryofissue": "Singapore",
            "identification": {
                "type": "wp",
                "number": "ABCDEFG"
            },
            "birthday": "1990-01-01",
            "gender": "male",
            "title": "Mr",
            "status": {
                "is_active": true,
                "text": "active"
            },
            "language": {
                "locale": "vi_vn",
                "name": "Vietnamese"
            },
            "authentications": {
                "email_verified": true,
                "mobile_verified": false
            }
        };

        scope.user = {};
        scope.user.language = {
            locale: 'vi_vn',
            name: 'Vietnamese'
        };

        //console.log(scope.user.language);
        userLanguagePreferenceCtrl = $controller( 'userLanguagePreferenceCtrl', {
            $scope: scope
        } );
        user = _userFactory_;
        httpBackend = $httpBackend;
        API_BASE = _API_BASE_;
        ngDialog = _ngDialog_;
        timeout = _$timeout_;
        state = _$state_;
        spyOn( user, 'updateUser' ).and.callThrough();
        spyOn( scope, 'changeLanguage' ).and.callThrough();
        spyOn( ngDialog, 'closeAll' ).and.callFake( function () {
            return;
        } );
        spyOn( state, 'go' ).and.callFake( function () {
            return;
        } );
        httpBackend.whenPUT( API_BASE + 'users' ).respond( 200, 'updated successfully', {}, 'HTTP/1.1 OK' );

        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
        httpBackend.whenGET( TRANSLATION_PROVIDER + '?lang=enUS' ).respond( 200, '' );
        httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).source + '"' + window.navigator.language + '".json' ).respond( 200, '' );
        httpBackend.flush();

    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );


    /* TODO fix this test spec later
    it('Language update success', function(){
      scope.changeLanguage();
      //httpBackend.flush();
      expect(scope.updateLangSuccess).toBeTruthy();
    });
   TODO :: complete this error scenario
  describe('Error in updating users language - error scenario', function(){
    beforeEach(inject(function(){

    }));
    it('Error updating language', function(){

    });
  });
  */
} );
