'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:userLanguagePreferenceCtrl
 * @description
 * # userLanguagePreferenceCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('userLanguagePreferenceCtrl', function ($scope, TRANSLATION_PARAMS, ACCOUNT_DETAILS_PARAMS, store, userFactory, $analytics, $translate, ngDialog, $timeout, $state, PubSub, helperFactory) {
    store.set( 'controller', 'userLanguagePreferenceCtrl' );
    $scope.configTransParams = angular.fromJson(TRANSLATION_PARAMS);
    if($scope.configTransParams.supportedLanguages.length > 1){
        $scope.flagMultiLang = true;
    }

    $scope.user = {};
    $scope.user.language = {};
    $scope.user = store.get('user');
    $scope.changeLanguage = function(){
    	$scope.isLoading = true;
    	$scope.turnonFlag = false;
    	$scope.updateLangSuccess = false;
    	$scope.updateLangError = false;
        // change the website langugage
        $translate.use( $scope.user.language.locale );
    	$scope.payload = {};
    	$scope.payload.language = $scope.user.language.locale;

    	userFactory.updateUser($scope.payload).then(function(response){
    		$analytics.eventTrack( 'Updated User Language Preference', {
                        category: 'User Details : Language Preference',
                        label: 'Updated User Langugage Preference'
                    } );
    		$scope.updateLangSuccess = true;
            $scope.isLoading = false;
            $scope.messageText = $translate.instant('COMPONENT.LANGUAGE_CHANGE.UPDATE_SUCCESS');
            $scope.messageIcon = 'mcw-common-congratulations';
            $scope.messageType = 'success';
            $scope.turnonFlag = true;
            helperFactory.removeUserCache();
            userFactory.getUser(false);
            $timeout(function(){
              ngDialog.closeAll();
              $state.go('.', {}, {reload:true});
            }, 2000);
    	}, function(error){
    		$scope.isLoading = false;
    		$scope.turnonFlag = true;
    		$scope.updateLangError = true;
    		$scope.messageIcon = 'mcw-common-alert';
        $scope.messageType = 'error';
    		$analytics.eventTrack( 'Error Updating User Language Preference', {
            category: 'User Details : Language Preference',
            label: 'Error Updating User Langugage Preference'
        } );
        $scope.messageText = $translate.instant('COMPONENT.LANGUAGE_CHANGE.UPDATE_ERROR');
    	})
    };
  });
