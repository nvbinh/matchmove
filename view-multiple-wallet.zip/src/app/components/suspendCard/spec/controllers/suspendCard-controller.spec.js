'use strict';
describe('Controller: suspendCardCtrl', function () {
// load the controller's module
    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var suspendCardCtrl,
        scope,
        API_BASE,
        httpBackend,
        cardDetail,
        Cards,
        rootScope,
        ngDialog;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach(inject(function ($controller, $rootScope, _API_BASE_, _Cards_, _ngDialog_) {
        rootScope = $rootScope;
        scope = $rootScope.$new();
        suspendCardCtrl = $controller('suspendCardCtrl', {
            $scope: scope
        });
        API_BASE = _API_BASE_;
        Cards = _Cards_;
        ngDialog = _ngDialog_;
        scope.card = "464d9a323e583498f76860aef89a32b3";

        cardDetail = {
              "id": "464d9a323e583498f76860aef89a32b3",
              "number": "5363950000255600",
              "holder": {
                "name": "Balaji"
              },
              "funds": {
                "available": {
                  "currency": "SGD",
                  "amount": "60.00"
                }
              },
              "type": {
                "type": "mcmmgpcard",
                "name": "MatchMove Physical Card",
                "description": "Matchmove Physical Card",
                "code_type": "Physical Card"
              },
              "date": {
                "expiry": "2020-12",
                "issued": "2016-02-10"
              },
              "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
              },
              "status": {
                "is_active": true,
                "text": "active"
              },
              "links": [
                {
                  "rel": "securities.tokens",
                  "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/securities/tokens",
                  "method": "GET"
                },
                {
                  "rel": "cards.transactions",
                  "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/transactions",
                  "method": "GET"
                },
                {
                  "rel": "wallets.funds.transfers",
                  "href": API_BASE + "users/wallets/funds",
                  "method": "GET"
                },
                {
                  "rel": "cards.pins.set",
                  "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/pins",
                  "method": "POST"
                },
                {
                  "rel": "cards.pins.verify",
                  "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/pins",
                  "method": "PUT"
                }
              ]
            };
        httpBackend.whenGET(API_BASE + "users/wallets/cards/undefined").respond(200, '');
        httpBackend.flush();

    }));
    afterEach(function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    });
    it('should fetch card Data', function() {
        httpBackend.whenGET(API_BASE + "users/wallets/cards/").respond(200, angular.fromJson(cardDetail), {}, "HTTP/4.1 200 OK");
        Cards.getCard(scope.card).then(function(response){
            scope.card = response.data;
            expect(response.data).toBeDefined();
            expect(scope.card.number).toBe('5363950000255600');
        });
        httpBackend.flush();
    });
    it('confirm suspend function :: success', function(){
        scope.card = cardDetail;
        httpBackend.whenDELETE(API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3").respond(200, 'Card suspended success', {}, "HTTP/4.1 200 OK");
        scope.confirmSuspendCard();
        httpBackend.flush();
    });
});
