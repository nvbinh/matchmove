'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:suspendCardCtrl
 * @description
 * # suspendCardCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('suspendCardCtrl', function ($scope , ngDialog, $http, Cards, $log, API_BASE, $rootScope) {
      $scope.card = $scope.$parent.cardToSuspend;

      Cards.getCard($scope.card).then(function(response) {
          $scope.card = response.data;
      });

      $scope.confirmSuspendCard = function() {
        var url = API_BASE + 'users/wallets/cards/' + $scope.card.id;
        $http({
          method: 'DELETE',
          url: url,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }).then(function success(response) {

          ngDialog.closeAll();
          $rootScope.$broadcast('updateSuspendCard');
        }, function error(response) {

        });
      };
  });
