'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:balanceBarCtrl
 * @description
 * # balanceBarCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'balanceBarCtrl', function ( $scope, Wallet, helperFactory, usersloyaltyfactoryFactory, $timeout, PubSub, $rootScope, $state, LOYALTY_PARAMS, CURRENCY_DISPLAY_SETTINGS ) {

        $scope.backendError = false;
        helperFactory.resetData();

        $scope.loyaltyParams = angular.fromJson(LOYALTY_PARAMS);
        $scope.loyaltyEnabled = $scope.loyaltyParams.enabled;
        $scope.loyaltyCurrency = $scope.loyaltyParams.denomination;

        function updateBalanceBar( cache ) {
            if ( cache === true ) {
                $scope.widgetLoading = true;
                ///console.log('with cahche data');
                //$scope.wallet = $scope.wallet;console.log($scope.wallet);
                $scope.userCards = $scope.wallet.usercards;
                $scope.dataLoaded = true;
                if ( $scope.wallet.hasOwnProperty( 'cards' ) ) {
                    $scope.hasCards = true;
                    $scope.isLoading = false;
                    $scope.sectionLoading = false;
                } else {
                    $scope.hasCards = false;
                }
                $scope.widgetLoading = false;
                $scope.widgetDataLoaded = true;
            } else {
                //console.log('wallet fetch');
                $scope.widgetLoading = true;
                Wallet.getWallet( false )
                    .then( function ( data ) {
                        $scope.wallet = data;
                        $scope.userCards = $scope.wallet.usercards;
                        $scope.dataLoaded = true;
                        if ( $scope.wallet.hasOwnProperty( 'cards' ) ) {
                            $scope.hasCards = true;
                            $scope.isLoading = false;
                            $scope.sectionLoading = false;
                        } else {
                            $scope.hasCards = false;
                        }
                        $scope.widgetLoading = false;
                        $scope.widgetDataLoaded = true;
                    }, function ( response ) {
                        if ( response.status === 500 ) {
                            $scope.backendError = true;
                        } else {
                            $scope.backendError = true;
                        }
                        $scope.widgetLoading = false;
                    } );
            }
            PubSub.unsubscribe({});
        };
        if($scope.loyaltyEnabled) {
          usersloyaltyfactoryFactory.history({sort_field: 'date_added', sort_direction: 'DESC'})
              .then( function ( resp ) {
                  $scope.totalPoints = resp.data.total_points; // jshint ignore:line
                  $scope.transactions = []
                  var count = 0;
                  angular.forEach( resp.data.transactions.items, function ( item ) {
                      if ( count < 5 ) {
                          $scope.transactions.push( item );
                      }
                      count++;
                  } );
                  if ( $scope.transactions.length === 0 ) {
                      $scope.noLoyalty = true;
                  }
              }, function ( err ) {} );
          $scope.goToLoyaltyList = function () {
              $rootScope.$emit( 'ngDropover.closeAll' );
              $state.go( 'wallet.loyalty.list', {
                  active: 1
              } );
          };
        }

        $scope.updateBalanceBar = updateBalanceBar;

        $scope.roundDecimal = function (decimal) {
            var currencyDisplaySettings = angular.fromJson(CURRENCY_DISPLAY_SETTINGS);
            if (currencyDisplaySettings.decimalRoundOff == true) {
                return Math.round(parseFloat(decimal));
            } else {
                return decimal;
            }
        };

        $scope.updateBalanceBar( true );
        PubSub.subscribe( 'topup-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'load-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'unload-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'fundsend-email-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'fundsend-sms-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'claim-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'cancel-success', $scope.updateBalanceBar );
        PubSub.subscribe( 'card-added', $scope.updateBalanceBar );
        PubSub.subscribe( 'card-activated', $scope.updateBalanceBar );
    } );
