'use strict';
describe('Controller: balanceBarCtrl Success fetching Wallet with cards Info', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
 // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("CURRENCY_DISPLAY_SETTINGS", {
              "decimalSeparator": ".",
              "thousandsSeparator": ",",
              "thousandsGroupSize": "3",
              "currencySymbol": "VND",
              "currencyPosition": "prefix",
              "numberDecimalPlaces": "2",
              "decimalRoundOff": true
            });
    } ) );
  var balanceBarCtrl,
      scope,
      Wallet,
      walletInfo,
      loyaltyList,
      usersloyaltyfactoryFactory,
      httpBackend,
      API_BASE,
      cardInfo,
      pSub,
      ctrl,
      spyUpdateBalanceBar,
      $controller,
      CURRENCY_DISPLAY_SETTINGS;
      // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function (_$controller_, $rootScope, _Wallet_, _usersloyaltyfactoryFactory_, _API_BASE_, _PubSub_, _CURRENCY_DISPLAY_SETTINGS_ ) {
    scope = $rootScope.$new();
    $controller = _$controller_;
    Wallet = _Wallet_;
    usersloyaltyfactoryFactory = _usersloyaltyfactoryFactory_;
    API_BASE = _API_BASE_;
    CURRENCY_DISPLAY_SETTINGS = _CURRENCY_DISPLAY_SETTINGS_;
    pSub = _PubSub_;
    loyaltyList = {"total_points":"5300.00","transactions":{"items":[{"id":"1628","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-01-29 07:26:21 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C4","date_added":"2016-01-29 07:26:21"},{"id":"1629","loyalty_type":"Topups","loyalty_type_id":"2","points":"5100.00","remarks":"2016-01-29 07:46:52 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C5","date_added":"2016-01-29 07:46:52"},{"id":"3456","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-02-17 11:32:29 --- Topup Successful for ref_id 6444e64fd5793132f7b136b5a72dfd920295bb1835cec60cdeb0191dd9348cc2","date_added":"2016-02-17 11:32:29"}],"first":1,"before":1,"current":1,"last":1,"next":1,"total_pages":1,"total_items":3,"limit":10}};
    walletInfo = angular.toJson({
          "funds": {
            "withholding": {
              "currency": "SGD",
              "amount": "27.00"
            },
            "available": {
              "currency": "SGD",
              "amount": "162.00"
            }
          },
          "id": "dfa7916f06e9640daeb0bbe413012659",
          "number": "6377020000009969",
          "holder": {
            "name": "Balaji"
          },
          "date": {
            "expiry": "2024-03",
            "issued": "2015-12-15"
          },
          "image": {
            "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
            "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
            "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
          },
          "status": {
            "is_active": true,
            "text": "active"
          },
          "details": {
            "min_load_limit": 10,
            "max_load_limit": 999,
            "network_type": "mastercard",
            "fee": 0,
            "topup_limits": {
              "pre_kyc": {
                "frequency": null,
                "allowed": null,
                "monthly_transactional_limit": 9999999999
              },
              "post_kyc": {
                "frequency": null,
                "monthly_transactional_limit": 5000
              },
              "current": {
                "lifetime_count": 4,
                "lifetime_transactional": 175,
                "monthly_transactional": 10
              }
            }
          },
          "cards": [
            {
              "id": "464d9a323e583498f76860aef89a32b3",
              "type": [
                {
                  "rel": "self",
                  "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                  "method": "GET"
                }
              ],
              "links": [
                {
                  "rel": "self",
                  "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3",
                  "method": "GET"
                }
              ]
            }
          ],
        "walletBalance": 550,
        "usercards": [{
            "id": "464d9a323e583498f76860aef89a32b3",
            "number": "5363950000003117",
            "holder": {
                "name": "Balaji"
            },
            "funds": {
                "withholding": {
                    "currency": "SGD",
                    "amount": "20.00"
                },
                "available": {
                    "currency": "SGD",
                    "amount": "0.00"
                }
            },
            "type": {
                "type": "mcmmgcard",
                "name": "MatchMove Virtual MasterCard",
                "description": "MatchMove Virtual MasterCard",
                "code_type": "Virtual Card"
            },
            "date": {
                "expiry": "2021-04",
                "issued": "2016-04-04"
            },
            "image": {
                "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-small.png",
                "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-medium.png",
                "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-large.png"
            },
            "status": {
                "is_active": true,
                "text": "active"
            },
            "links": [{
                "rel": "securities.tokens",
                "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/securities/tokens",
                "method": "GET"
            }, {
                "rel": "cards.transactions",
                "href": API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/transactions",
                "method": "GET"
            }, {
                "rel": "wallets.funds.transfers",
                "href": API_BASE + "users/wallets/funds",
                "method": "GET"
            }]
          }]
        });

    cardInfo = angular.toJson({
          "id": "464d9a323e583498f76860aef89a32b3",
          "number": "5363950000255600",
          "holder": {
            "name": "Balaji"
          },
          "funds": {
            "available": {
              "currency": "SGD",
              "amount": "6.00"
            }
          },
          "type": {
            "type": "mcmmgpcard",
            "name": "MatchMove Physical Card",
            "description": "Matchmove Physical Card",
            "code_type": "Physical Card"
          },
          "date": {
            "expiry": "2020-12",
            "issued": "2016-02-10"
          },
          "image": {
            "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
            "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
            "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
          },
          "status": {
            "is_active": true,
            "text": "active"
          },
          "links": [
            {
              "rel": "securities.tokens",
              "href": "",
              "method": "GET"
            }
          ]
        });
    spyUpdateBalanceBar = jasmine.createSpy(function(){return walletInfo;});
    scope.wallet = walletInfo;
    balanceBarCtrl = $controller('balanceBarCtrl', {
      $scope: scope
    });
    spyOn(Wallet, 'getWallet').and.callThrough();
    spyOn(usersloyaltyfactoryFactory, 'history').and.callThrough();
    spyOn(pSub, 'subscribeOnce').and.callThrough();

    httpBackend.whenGET(API_BASE + "users/wallets").respond(200, walletInfo);
    httpBackend.whenGET(API_BASE + "loyalty?sort_direction=DESC&sort_field=date_added").respond(200, loyaltyList);
    httpBackend.whenGET(API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3").respond(200, cardInfo);
    httpBackend.flush();
  }));

  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  describe('Wallet data retrieved successfully', function(){
      it ('should not display walletBalance when page loading', function(){
        scope.walletBalance = '';
        expect(scope.walletBalance).toBe('');
      });
      it ('set value for walletBalance if we have cards in it', function(){
        scope.walletBalance = '';
        scope.walletBalance = Wallet.getWallet();
        httpBackend.flush();
        expect(scope.walletBalance).toBeDefined();
      });
      it('should get Wallet detailed info', function(){
           scope.updateBalanceBar(false);
          httpBackend.flush();
          expect(scope.wallet).toBeDefined();
          expect(scope.wallet.funds.available.amount).toBe("162.00");
          expect(scope.userCards).toBeDefined();
          expect(scope.dataLoaded).toBeTruthy();
          expect(scope.hasCards).toBeTruthy();
      });
      it('should be rounded value if flag of currencyDisplaySettings decimal rounded off', function () {
          var decimal = 43001.33;
          expect(scope.roundDecimal(decimal)).toEqual(43001.00);
      });
  });
});

describe('Controller: balanceBarCtrl Success fetching Wallet WITHOUT cards Info', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var balanceBarCtrl,
      scope,
      Wallet,
      usersloyaltyfactoryFactory,
      walletInfo,
      loyaltyList,
      httpBackend,
      API_BASE,
      cardInfo,
      pSub;
      // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _Wallet_, _usersloyaltyfactoryFactory_, _API_BASE_, _PubSub_) {
    scope = $rootScope.$new();
    pSub = _PubSub_;
    usersloyaltyfactoryFactory = _usersloyaltyfactoryFactory_;
    scope.wallet = {};
    balanceBarCtrl = $controller('balanceBarCtrl', {
      $scope: scope
    });
    Wallet = _Wallet_;
    API_BASE = _API_BASE_;
    walletInfo = angular.toJson({
          "funds": {
            "withholding": {
              "currency": "SGD",
              "amount": "27.00"
            },
            "available": {
              "currency": "SGD",
              "amount": "162.00"
            }
          },
          "id": "dfa7916f06e9640daeb0bbe413012659",
          "number": "6377020000009969",
          "holder": {
            "name": "Balaji"
          },
          "date": {
            "expiry": "2024-03",
            "issued": "2015-12-15"
          },
          "image": {
            "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
            "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
            "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
          },
          "status": {
            "is_active": true,
            "text": "active"
          },
          "details": {
            "min_load_limit": 10,
            "max_load_limit": 999,
            "network_type": "mastercard",
            "fee": 0,
            "topup_limits": {
              "pre_kyc": {
                "frequency": null,
                "allowed": null,
                "monthly_transactional_limit": 9999999999
              },
              "post_kyc": {
                "frequency": null,
                "monthly_transactional_limit": 5000
              },
              "current": {
                "lifetime_count": 4,
                "lifetime_transactional": 175,
                "monthly_transactional": 10
              }
            }
          }
        });
    loyaltyList = {"total_points":"5300.00","transactions":{"items":[{"id":"1628","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-01-29 07:26:21 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C4","date_added":"2016-01-29 07:26:21"},{"id":"1629","loyalty_type":"Topups","loyalty_type_id":"2","points":"5100.00","remarks":"2016-01-29 07:46:52 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C5","date_added":"2016-01-29 07:46:52"},{"id":"3456","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-02-17 11:32:29 --- Topup Successful for ref_id 6444e64fd5793132f7b136b5a72dfd920295bb1835cec60cdeb0191dd9348cc2","date_added":"2016-02-17 11:32:29"}],"first":1,"before":1,"current":1,"last":1,"next":1,"total_pages":1,"total_items":3,"limit":10}};
    spyOn(Wallet, 'getWallet').and.callThrough();
    spyOn(usersloyaltyfactoryFactory, 'history').and.callThrough();
    httpBackend.whenGET(API_BASE + "users/wallets").respond(200, walletInfo);
    httpBackend.whenGET(API_BASE + "loyalty?sort_direction=DESC&sort_field=date_added").respond(200, loyaltyList);
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  describe('Wallet data retrieved successfully', function(){
      it('should get Wallet detailed info', function(){
          scope.updateBalanceBar();
          httpBackend.flush();
          expect(scope.wallet).toBeDefined();
          expect(scope.wallet.funds.available.amount).toBe("162.00");
          expect(scope.userCards).not.toBeDefined();
          expect(scope.dataLoaded).toBeTruthy();
          expect(scope.hasCards).toBeFalsy();
      });
  });
  describe('Wallet data retrieved successfully upon broadcast of event::updateBalanceBar', function(){
      it('should get Wallet detailed info', function(){
          var subs = spyOn(pSub ,'subscribeOnce');
          var updateBalanceBar = spyOn(scope, 'updateBalanceBar');
          spyOn(pSub, 'publish').and.callThrough();
          pSub.subscribeOnce('topup-success', updateBalanceBar);
          pSub.publish('topup-success');
          expect(pSub.publish).toHaveBeenCalledWith('topup-success');
          expect(subs).toHaveBeenCalled();
      });
  });
});

describe('Controller: balanceBarCtrl Error 500 Fetching wallet Info', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var balanceBarCtrl,
      scope,
      Wallet,
      walletInfo,
      httpBackend,
      loyaltyList,
      usersloyaltyfactoryFactory,
      API_BASE,
      cardInfo;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope,_usersloyaltyfactoryFactory_, _Wallet_, _API_BASE_ ) {
    scope = $rootScope.$new();
    balanceBarCtrl = $controller('balanceBarCtrl', {
      $scope: scope
    });
    Wallet = _Wallet_;
    usersloyaltyfactoryFactory = _usersloyaltyfactoryFactory_;
    API_BASE = _API_BASE_;
    loyaltyList = {"total_points":"5300.00","transactions":{"items":[{"id":"1628","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-01-29 07:26:21 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C4","date_added":"2016-01-29 07:26:21"},{"id":"1629","loyalty_type":"Topups","loyalty_type_id":"2","points":"5100.00","remarks":"2016-01-29 07:46:52 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C5","date_added":"2016-01-29 07:46:52"},{"id":"3456","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-02-17 11:32:29 --- Topup Successful for ref_id 6444e64fd5793132f7b136b5a72dfd920295bb1835cec60cdeb0191dd9348cc2","date_added":"2016-02-17 11:32:29"}],"first":1,"before":1,"current":1,"last":1,"next":1,"total_pages":1,"total_items":3,"limit":10}};
    spyOn(Wallet, 'getWallet').and.callThrough();
    spyOn(usersloyaltyfactoryFactory, 'history').and.callThrough();
    httpBackend.whenGET(API_BASE + "loyalty?sort_direction=DESC&sort_field=date_added").respond(200, loyaltyList);
    httpBackend.whenGET(API_BASE + "users/wallets").respond(500, 'error body', undefined, '(HTTP/1.1 500 errorRetrievingWalletInfo)');
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('should get Error fetching wallet info', function(){
      scope.updateBalanceBar();
      httpBackend.flush();
      expect(scope.wallet).toEqual({});
      expect(scope.userCards).not.toBeDefined();
      expect(scope.backendError).toBeTruthy();
  });
});

describe('Controller: balanceBarCtrl Error 503 Fetching wallet Info', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var balanceBarCtrl,
      scope,
      Wallet,
      walletInfo,
      httpBackend,
      loyaltyList,
      usersloyaltyfactoryFactory,
      API_BASE,
      cardInfo;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _Wallet_, _usersloyaltyfactoryFactory_, _API_BASE_ ) {
    scope = $rootScope.$new();
    usersloyaltyfactoryFactory =_usersloyaltyfactoryFactory_;
    balanceBarCtrl = $controller('balanceBarCtrl', {
      $scope: scope
    });
    Wallet = _Wallet_;
    API_BASE = _API_BASE_;
    loyaltyList = {"total_points":"5300.00","transactions":{"items":[{"id":"1628","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-01-29 07:26:21 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C4","date_added":"2016-01-29 07:26:21"},{"id":"1629","loyalty_type":"Topups","loyalty_type_id":"2","points":"5100.00","remarks":"2016-01-29 07:46:52 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C5","date_added":"2016-01-29 07:46:52"},{"id":"3456","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-02-17 11:32:29 --- Topup Successful for ref_id 6444e64fd5793132f7b136b5a72dfd920295bb1835cec60cdeb0191dd9348cc2","date_added":"2016-02-17 11:32:29"}],"first":1,"before":1,"current":1,"last":1,"next":1,"total_pages":1,"total_items":3,"limit":10}};
    spyOn(Wallet, 'getWallet').and.callThrough();
    spyOn(usersloyaltyfactoryFactory, 'history').and.callThrough();
    httpBackend.whenGET(API_BASE + "loyalty?sort_direction=DESC&sort_field=date_added").respond(200, loyaltyList);
    httpBackend.whenGET(API_BASE + "users/wallets").respond(503, 'error body', undefined, '(HTTP/1.1 500 errorRetrievingWalletInfo)');
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('should get Error fetching wallet info', function(){
      scope.updateBalanceBar();
      httpBackend.flush();
      expect(scope.wallet).toEqual({});
      expect(scope.userCards).not.toBeDefined();
      expect(scope.backendError).toBeTruthy();
  });
});
