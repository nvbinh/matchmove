'use strict';
describe( 'Directive: balanceBar', function() {
	// load the directive's module
	beforeEach( module( 'viewMultipleWallet' ) );
	// mock constants
	beforeEach( module( 'viewMultipleWallet', function( $provide ) {
		$provide.constant( "TRANSLATION_PARAMS", {
			"partFilesPath": "../assets/locales/",
			"preferredLanguage": "vi_vn",
			"client": "hdb",
			"source": "http://localhost:3000/assets/hdb/locales\/",
			"supportedLanguages": [ {
				"i18n": "en_us",
				"name": "English"
			}, {
				"i18n": "vi_vn",
				"name": "Vietnamese"
			} ]
		} );
	} ) );
	var scope, element, compile, controller, Wallet, httpBackend, API_BASE, compiledElement, loyaltyList;
	// language based mock calls
	beforeEach( inject( function( _$httpBackend_, TRANSLATION_PARAMS ) {
		httpBackend = _$httpBackend_;
		var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
		for ( var i = 0; i < lngth; i++ ) {
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
		}
	} ) );
	beforeEach( inject( function( $rootScope, $compile, $controller, _Wallet_, _API_BASE_ ) {
		scope = $rootScope.$new();
		compile = $compile;
		API_BASE = _API_BASE_;
		$rootScope.$broadcast('balanceBarCtrl');
		element = angular.element( '<balance-bar></balance-bar>' );
		compiledElement = $compile(element)(scope);
	} ) );
	afterEach( function() {
		httpBackend.verifyNoOutstandingExpectation();
		httpBackend.verifyNoOutstandingRequest();
	} );
	it( 'should make hidden element visible', function() {
		loyaltyList = {"total_points":"5300.00","transactions":{"items":[{"id":"1628","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-01-29 07:26:21 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C4","date_added":"2016-01-29 07:26:21"},{"id":"1629","loyalty_type":"Topups","loyalty_type_id":"2","points":"5100.00","remarks":"2016-01-29 07:46:52 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C5","date_added":"2016-01-29 07:46:52"},{"id":"3456","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-02-17 11:32:29 --- Topup Successful for ref_id 6444e64fd5793132f7b136b5a72dfd920295bb1835cec60cdeb0191dd9348cc2","date_added":"2016-02-17 11:32:29"}],"first":1,"before":1,"current":1,"last":1,"next":1,"total_pages":1,"total_items":3,"limit":10}};
		httpBackend.whenGET( API_BASE + 'loyalty?sort_direction=DESC&sort_field=date_added' ).respond( 200, loyaltyList );
		httpBackend.flush();
		scope.$digest();
		var compiledDIV = compiledElement.find( '.content-left' );
		compiledDIV.click();
		expect( compiledDIV.hasClass( 'ngdo-open' ) );

		var compiledUL = compiledElement.find( 'ul' );
		expect( compiledUL.show() );
		compiledDIV.click();

		expect( compiledDIV.removeClass( 'ngdo-open' ) );
		expect( compiledUL.hide() );
	} );
} );
