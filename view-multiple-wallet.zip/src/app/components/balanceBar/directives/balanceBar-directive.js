'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:balance
 * @description
 * # balance
 */
angular.module('viewMultipleWallet')
	.directive('balanceBar', function () {
		return {
			scope: true,
			templateUrl: 'app/components/balanceBar/partials/balanceBar.html',
			restrict: 'E',
			controller: 'balanceBarCtrl',
			controllerAs: 'ctrl',
			bindToController: {
				wallet: '='
			}
		};
	});
