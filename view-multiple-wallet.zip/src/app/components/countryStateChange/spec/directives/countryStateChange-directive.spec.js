'use strict';
describe( 'Directive: countryStateChange', function() {
  // load the directive's module
  beforeEach( module( 'viewMultipleWallet' ) );
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var compile,
    scope,
    compiledElement,
    helper,
    element, httpBackend;
  // langugage based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  beforeEach( inject( function( $rootScope, $compile, _helperFactory_ ) {
    scope = $rootScope.$new();
    compile = $compile;
    helper = _helperFactory_;

    spyOn( helper, 'isDefaultCountry' ).and.callFake( function() {
      return true;
    } )
  } ) );
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  describe( "country State change directive is called", function() {
    it( "residential address", function() {
      scope.residential = {};
      scope.residential.city = 'Bangalore';
      scope.residential.state = 'Karnataka';
      scope.residential.country = 'India';
      element = angular.element( '<country-state-change form-name="residential" countryCity="{{residential.city}}" countryState="{{residential.state}}" country="{{residential.country}}" is-dropdown="true"></country-state-change>' );
      compiledElement = compile( element )( scope );
      scope.$digest();
      expect( compiledElement.find( 'section' ).length ).toEqual( 1 );
    } );
    it( "billing address", function() {
      scope.billing = {};
      scope.billing.city = 'Bangalore';
      scope.billing.state = 'Karnataka';
      scope.billing.country = 'India';
      element = angular.element( '<country-state-change form-name="billing" countryCity="{{billing.city}}" countryState="{{billing.state}}" country="{{billing.country}}" is-dropdown="true"></country-state-change>' );
      compiledElement = compile( element )( scope );
      scope.$digest();
      expect( compiledElement.find( 'section' ).length ).toEqual( 1 );
    } );
  } );


} );