'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:notifyMobileVerifyCtrl
 * @description
 * # notifyMobileVerifyCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('notifyMobileVerifyCtrl', function ($scope, authMobileFactory, HTTP_HOST, $log, ngDialog) {
        $scope.verificationSent = false;
        $scope.payload = {};
        $scope.payload.endpoint = $scope.endpoint;
        $scope.openOtp = function() {
            ngDialog.closeAll();
            ngDialog.open({
                template: 'app/components/otp/partials/otp.html',
                className: 'modal-otp',
                controller: 'otpCtrl'
            });
        };
    });
