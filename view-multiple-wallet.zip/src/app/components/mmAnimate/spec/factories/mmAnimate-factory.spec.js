'use strict';
describe('animate', function() {
  beforeEach(module('viewMultipleWallet', 'mmMocks'));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );

  var $library, $rootScope, $timeout, $$mmAnimate;
  var httpBackend;

	// langugage based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
	afterEach( function() {
		httpBackend.verifyNoOutstandingExpectation();
		httpBackend.verifyNoOutstandingRequest();
	} );

  beforeEach( inject(function(_$library_,_$rootScope_,_$timeout_, _$$mmAnimate_, $mmUtil) {
      $$mmAnimate = _$$mmAnimate_($mmUtil);
      $library = _$library_;
      $rootScope = _$rootScope_;
      $timeout = _$timeout_;
      httpBackend.flush();
  }));

  describe('waitTransitionEnd', function(){

    describe('should reject without an in-progress animation', function(){

      it('using the default fallback timeout',inject(function() {
        var element = build('<div>');
        var expired = false;

        $$mmAnimate
          .waitTransitionEnd(element)
          .catch(function() {
            expired = true;
          });
        flush();

        expect(expired).not.toBe(true);
      }));

      it('using custom timeout duration',inject(function() {
        var element = build('<div>');
        var expired = false;

        $$mmAnimate
          .waitTransitionEnd(element, {timeout:200} )
          .catch(function() {
            expired = true;
          });
        flush();

        expect(expired).not.toBe(true);
      }));

    });

    describe('should resolve ', function(){

      it('after an animation finishes',inject(function($document) {
        var expired = false;
        var response = false;
        var element = build('<div>');
        var animation = { display:'absolute;', transition : 'all 1.5s ease;' };
            animation['transform'] = 'translate3d(240px, 120px, 0px);';

        // Animate move the element...
        element.css(animation);

        $$mmAnimate
          .waitTransitionEnd(element)
          .then(
            function() { response = true; },
            function() { expired = true; }
          );

        'transitionend'.split(" ")
               .forEach(function(eventType){
                  element.triggerHandler(eventType);
               });
        flush();

        expect(expired).toBe(false);
        expect(response).toBe(true);

      }));

    });

    describe( 'centerPointFor', function() {
      it( 'calculate centerPoint for', inject( function() {
        var targetRect = {
          left: 50,
          top: 100,
          width: 20,
          height: 10
        };
        var center = $$mmAnimate.centerPointFor( targetRect );

        expect( center ).toEqual( {
          x: 60,
          y: 105
        } );
      } ) );
    } );

    describe( 'clientRect', function() {
      it( 'return null for the bounding rect', inject( function() {
        var elem = '<div><div id="content">ABCDEFGH</div></div>';
        var cliRect = $$mmAnimate.clientRect( elem );
        expect( cliRect ).toBe( null );
      } ) );
    } );

    describe( 'copyRect', function() {
      it( 'return copy of input rectangle', inject( function() {
        var elem = {
          top: 10,
          left: 10,
          right: 100,
          bottom: 30,
          width: 90,
          height: 20
        };
        var copy = $$mmAnimate.copyRect( elem, {
          top: '100px',
          left: '50px'
        } );
        expect( copy ).toEqual( elem );
      } ) );
    } );

    describe( 'toTransformCss', function() {
      it( 'return transform as key value pair', inject( function() {
        var trans = 'all 0.6s cubic-bezier(0.1, 0.5, 0.2, 1)';
        var modifiedTrans = $$mmAnimate.toTransformCss( trans, true );
        expect( modifiedTrans.transform ).toBeDefined();
        expect( modifiedTrans.transition ).toBeDefined();
      } ) );
    } );
    function build(template) {
      var el;
      inject(function($compile, $rootScope) {
        el = angular.element(template || '<div>');
        $compile(el)($rootScope);
        $rootScope.$apply();
      });
      return el;
    }
  });

  function flush() {
    $rootScope.$digest();
    $library.flushOutstandingAnimations();
  }
});