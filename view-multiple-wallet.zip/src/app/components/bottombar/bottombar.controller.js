'use strict';

angular.module( 'viewMultipleWallet' )
    .controller( 'BottombarCtrl', function ( $scope , REFERRAL_CANDY_PARAMS) {
        $scope.bottombarActive = false;
        $scope.itemPrimary = [ {
            name: 'COMPONENT.MENUBAR.SEND',
            path: 'wallet.send.select',
            icon: 'mcw-menu-send'
        }, {
            name: 'COMPONENT.MENUBAR.HISTORY',
            path: 'wallet.transaction',
            icon: 'mcw-menu-history'
        }, {
            name: 'COMPONENT.MENUBAR.TOPUP',
            path: 'wallet.topup.select',
            icon: 'mcw-menu-topup'
        }, {
            name: 'COMPONENT.MENUBAR.OFFERS',
            path: 'wallet.offers.list',
            icon: 'mcw-menu-offers'
        } ];
        $scope.itemSecondary = [ {
            name: 'COMPONENT.MENUBAR.LOYALTY',
            path: 'wallet.loyalty.list',
            icon: 'mcw-menu-loyalty'
        }, {
            name: 'COMPONENT.MENUBAR.SUSPEND',
            path: 'wallet.suspend',
            icon: 'mcw-menu-suspend'
        }, {
            name: 'COMPONENT.MENUBAR.ACCOUNT',
            path: 'wallet.details.my',
            icon: 'mcw-menu-account'
        }];
        // if(JSON.parse(REFERRAL_CANDY_PARAMS).enabled) {
        //   $scope.itemSecondary.push({
        //       name: 'COMPONENT.MENUBAR.SHARE',
        //       path: 'wallet.share',
        //       icon: 'mcw-menu-share'
        //   });
        // }
    } );
