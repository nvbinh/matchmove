'use strict';
describe('Directive: addressComponent', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var element,
    scope,
    httpBackend;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
  beforeEach(inject(function ($rootScope, $compile) {
    scope = $rootScope.$new();
	  element = angular.element('<address-component id="addressForm"></address-component>');
	  $compile(element)(scope);
	  scope.$digest();
  }));
  afterEach(function() {
      httpBackend.flush();
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    });
  it('should have ul elem with class split--double',function(){
      var formElem = element.find('form[name="residentialAddress"]');
      expect(formElem).toBeDefined();
    });
});
