'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:addressComponent
 * @description
 * # addressComponent
 */
angular.module('viewMultipleWallet')
  .directive('addressComponent', function () {

    return {
      scope: true,
      restrict: 'E',
      templateUrl: 'app/components/addressComponent/partials/addressComponent.html',
      link: function(scope, element, attrs){

      }
    };
  });
