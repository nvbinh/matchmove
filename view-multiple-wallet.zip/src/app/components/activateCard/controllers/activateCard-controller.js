'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:otpCtrl
 * @description
 * # otpCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('activateCardCtrl', function (PHYSICAL_CARD_CODE, $scope, $analytics, $rootScope, $state,  $filter, $timeout, store, Cards, helperFactory, userFactory, authDocumentFactory, ngDialog, Wallet, PubSub) {
      var self = this;
      $scope.verification = {};
      $scope.verification.otp = '';


      $scope.modalOtpMessageTranslate = {};
      if(store.get('user')){
        $scope.userdetails = store.get('user');
        $scope.modalOtpMessageTranslate.userMobile = $scope.userdetails.mobile.country_code + ' ' + $scope.userdetails.mobile.number;// jshint ignore:line
      }

      $scope.otpVerify = false;
      $scope.otpSent = true;

      var $translate = $filter('translate');
      self.getUser = function() {
        userFactory.getUser()
            .then(function(response) {
                userFactory.setCurrentUser(response.data);
                $analytics.setUsername(response.data.id);
                $rootScope.$broadcast('authorized');
                $analytics.setUserProperties({'$email':response.data.email, '$registration_date':response.data.date.registration,'$mobile':response.data.mobile.country_code + response.data.mobile.number, '$name':response.data.name.first + ' ' +  response.data.name.first}); // jshint ignore:line
                $state.go('wallet.home');
                $scope.isLoading = false;
            },function(response){
                if(response.status === 500) {
                    $scope.isLoading = false;
                    $scope.errorLoginGenric = true;
                    $analytics.eventTrack('Error getting User Info after login', {  category: 'Error 500', label: 'Error getting User Info after login' });
                }
                else {
                    $scope.isLoading = false;
                    $scope.errorLoginGenric = true;
                    $analytics.eventTrack('Error getting User Info after login', {  category: 'Login', label: 'Login error : ' + response.status + ' : ' +response.statusText });
                }
            });
            authDocumentFactory.getStatus()
                .then(function(response){
                    store.set('kycStatus',response.data.status);
                },function(error){

                });
      };

      self.cardLinkError = function(data) {
        $scope.errorCardLink = true;
        if(data.status === 400) {
            if (data.statusText.indexOf('userAuthenticationValidationTokenExpired') > -1) {
                $scope.validationError = $translate('ERRORS.VALIDATION.CARD_ACTIVATE.400.TOKENEXPIRED');
                $analytics.eventTrack('OTP Expired', {  category: 'Error 400', label: 'OTP code already expired'});
            } else {
                $scope.validationError = $translate('VALIDATION.WALLET_LINK.ERROR400');
                $analytics.eventTrack('OTP Expired', {  category: 'Error 400', label: 'OTP is invalid'});
            }
        }
        else if(data.status === 401) {
          $scope.validationError = $translate('VALIDATION.WALLET_LINK.ERROR401');
        }
        else if(data.status === 500) {
          $scope.validationError = $translate('VALIDATION.WALLET_LINK.ERROR500');
        }
        else {
          $scope.validationError = $translate('VALIDATION.WALLET_LINK.ERRORFALLBACK');
        }
        $scope.otpVerifyError = true;
        $scope.verifyingOtp = false;
      };
      self.otpDeliveryError = function(response) {
        $scope.newTokenSendFailed = true;
        if (response.status === 500) {
          $scope.otpDeliveryError = $translate('ERRORS.OTP.TOKEN_RESEND_FAILED.500');
        }
        else {
          $scope.otpDeliveryError = $translate('ERRORS.OTP.TOKEN_RESEND_FAILED.GENERIC');
        }
      };
      $scope.resendToken = function() {
        $scope.physicalCard = {};
        $scope.physicalCard.type = PHYSICAL_CARD_CODE;
        $scope.physicalCard.assoc_number = $scope.activationInfo.assocNo; // jshint ignore:line
        $scope.newTokenSendFailed = false;
        $scope.newTokenSent = false;
        Cards.cardCreate($scope.physicalCard)
          .then(function(response){
            $scope.activationInfo.activation = {};
            $scope.activationInfo.activation.status = response.data.activation.status;
            $scope.activationInfo.activation.token = response.data.activation.token;
            $scope.activationInfo.cardId = response.data.id;
            $scope.activationInfo.assocNo = $scope.physicalCard.assoc_number; // jshint ignore:line
            $scope.newTokenSent = true;
          },function(error){
            self.otpDeliveryError(error);
          });
      };
      $scope.goDashboard = function() {
          ngDialog.closeAll();
          // helperFactory.resetUser();
          self.getUser();

      };
      $scope.verifyCardLink = function() {
          $scope.verifyingOtp = true;
          $scope.otpVerifyError = false;
          Cards.cardVerify(PHYSICAL_CARD_CODE, $scope.activationInfo.cardId, $scope.activationInfo.activation.token, $scope.verification.otp.toString())
            .then(function(){
                $scope.cardLinkVerified = true;
                $scope.otpVerify = true;
                $scope.verifyingOtp = false;
                $timeout(function(){
                  ngDialog.closeAll();
                  //helperFactory.resetUser();
                  //getUser();
                  $scope.activationInfo = {};
                  if($state.current.name === 'wallet.card.new'){
                    //Wallet.getWallet(false);
                    //$rootScope.$broadcast('updateBalanceBar');
                    PubSub.publish('card-activated');
                    $state.reload();
                  }else if($state.current.name === 'wallet.home') {
                    $state.reload();
                  }
                  else {
                    $state.go('wallet.home');
                  }
                }, 1000);
                $analytics.eventTrack('Verification OTP : Success', {  category: 'OTP', label: 'Verification OTP : Success' });
            },function(response){
              self.cardLinkError(response);
            });
      };
  });
