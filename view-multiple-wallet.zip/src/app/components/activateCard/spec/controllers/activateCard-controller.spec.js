/* global inject */
/* global expect */
/* global it */
/* global beforeEach */
/* global describe */
'use strict';
describe('Controller: activateCardCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  beforeEach(module(function($provide) {
      $provide.decorator('$timeout', function($delegate) {
          return  jasmine.createSpy($delegate);
      });
  }));
  var activateCard,
      scope,
      store,
      helper,
      ngDialog,
      user,
      authDocument,
      userData,
      API_BASE,
      httpBackend,
      state,
      cards,
      rc4,
      PHYSICAL_CARD_CODE,
      $timeout,
      cardCreateResp;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _store_, _helperFactory_, _ngDialog_, _userFactory_, _authDocumentFactory_, _API_BASE_, _$state_, _Cards_, _PHYSICAL_CARD_CODE_, _rc4Factory_, _$timeout_) {
    scope = $rootScope.$new();
    store = _store_;
    helper = _helperFactory_;
    ngDialog = _ngDialog_;
    user = _userFactory_;
    authDocument = _authDocumentFactory_;
    API_BASE = _API_BASE_;
    state = _$state_;
    cards = _Cards_;
    rc4 = _rc4Factory_;
    PHYSICAL_CARD_CODE = _PHYSICAL_CARD_CODE_;
    $timeout = _$timeout_;
    activateCard = $controller('activateCardCtrl', {
      $scope: scope,
      $rootScope: $rootScope
    });

    userData = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "birthday": "1998-01-05",
          "gender": "male",
          "title": "Mr",
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            },
            {
              "rel": "addresses.residential",
              "href": API_BASE + "users/addresses/residential",
              "method": "GET"
            },
            {
              "rel": "addresses.billing",
              "href": API_BASE + "users/addresses/billing",
              "method": "GET"
            }
          ],
          "status": {
            "is_active": true,
            "text": "active"
          },
          "date": {
            "registration": "2015-12-15T16:26:17+08:00"
          },
          "authentications": {
            "email_verified": true,
            "mobile_verified": false
          },
          "login_info": {
            "logins": 156,
            "last_login": "2016-02-08T17:31:24+08:00"
          }
        };
       cardCreateResp = angular.toJson({
          "id": "a7df5f592070060fa38ddaf8363363f3",
          "number": "5363950000261301",
          "holder": {
            "name": "Balaji"
          },
         "activation": {
            "status": "pending",
            "token": "c76145b3fe4c11b378af4b7cd3a0bf96"
         },
          "funds": {
            "available": {
              "currency": "SGD",
              "amount": "0.00"
            }
          },
          "type": {
            "type": "mcmmgpcard",
            "name": "MatchMove Physical Card",
            "description": "Matchmove Physical Card",
            "code_type": "Physical Card"
          },
          "date": {
            "expiry": "2020-12",
            "issued": "2016-01-29"
          },
          "image": {
            "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
            "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
            "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
          },
          "status": {
            "is_active": true,
            "text": "inactive"
          },
          "links": [
            {
              "rel": "securities.tokens",
              "href": API_BASE + "users/wallets/cards/a7df5f592070060fa38ddaf8363363f3/securities/tokens",
              "method": "GET"
            },
            {
              "rel": "cards.transactions",
              "href": API_BASE + "users/wallets/cards/a7df5f592070060fa38ddaf8363363f3/transactions",
              "method": "GET"
            },
            {
              "rel": "wallets.funds.transfers",
              "href": API_BASE + "users/wallets/funds",
              "method": "GET"
            },
            {
              "rel": "cards.pins.set",
              "href": API_BASE + "users/wallets/cards/a7df5f592070060fa38ddaf8363363f3/pins",
              "method": "POST"
            },
            {
              "rel": "cards.pins.verify",
              "href": API_BASE + "users/wallets/cards/a7df5f592070060fa38ddaf8363363f3/pins",
              "method": "PUT"
            },
            {
              "rel": "cards.activation",
              "href": API_BASE + "https://beta-ih.mmvpay.com/api/v1/users/wallets/cards/a7df5f592070060fa38ddaf8363363f3",
              "method": "PUT"
            }
          ],
          "activation_code": "397328"
        });
    httpBackend.whenGET(API_BASE + 'users/authentications/documents').respond(200, {
          "count": "n/a",
          "status": "not_submitted"
        });
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('should Have initial Scope variables defined', function () {
    expect(scope.verification).toBeDefined();
  });

  describe('go to dashboard functionality', function(){
      beforeEach(inject(function(){
          spyOn(helper, 'resetUser').and.callThrough();
          spyOn(ngDialog, 'closeAll').and.callThrough();
          spyOn(activateCard, 'getUser').and.callThrough();
          spyOn(user, 'getUser').and.callThrough();
          spyOn(user, 'setCurrentUser').and.callThrough();
          spyOn(authDocument, 'getStatus').and.callThrough();
          spyOn(state, 'go');
      }));
      it('should goTo Dashboard when user data present', function(){
          httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
          scope.goDashboard();
          httpBackend.flush();
          expect(ngDialog.closeAll).toHaveBeenCalled();
          expect(state.go).toHaveBeenCalledWith('wallet.home');
      });
      it('dashboard handle 500 error', function(){
          httpBackend.whenGET(API_BASE + 'users').respond(500, {error: 'No user info'});
          scope.goDashboard();
          httpBackend.flush();
          expect(ngDialog.closeAll).toHaveBeenCalled();
      });
      it('dashboard handle Geneirc error', function(){
          httpBackend.whenGET(API_BASE + 'users').respond(503, {error: 'generic error'});
          scope.goDashboard();
          httpBackend.flush();
          expect(ngDialog.closeAll).toHaveBeenCalled();
      });
  });
  describe('verifyCardLink function', function(){
      beforeEach(inject(function(){
          scope.activationInfo = {};
          scope.verification = {};
          scope.activationInfo.cardId = '2a808c8041d56c407b5d55cfa445a479';
          scope.activationInfo.activation = {};
          scope.activationInfo.activation.token = 'df82098e0d7484eb4105808f89951675';
          scope.verification.otp = 829528;

          spyOn(rc4, 'encode').and.callThrough();
          spyOn(cards, 'cardVerify').and.callThrough();
      }));
      it('Verify card successfully', function(){
          httpBackend.whenPUT(API_BASE + 'users/wallets/cards/'+ PHYSICAL_CARD_CODE).respond(200, 'Card Activated Successfully');
          scope.verifyCardLink();
          httpBackend.flush();
          expect(cards.cardVerify).toHaveBeenCalledWith(PHYSICAL_CARD_CODE, scope.activationInfo.cardId, scope.activationInfo.activation.token, scope.verification.otp.toString());
          expect(scope.cardLinkVerified).toBeTruthy();
          expect(scope.otpVerify).toBeTruthy();
          expect(scope.verifyingOtp).toBeFalsy();
          expect(scope.validationError).not.toBeDefined();
      });
      it('Verify card failure 400 status code', function(){
          httpBackend.whenPUT(API_BASE + 'users/wallets/cards/'+ PHYSICAL_CARD_CODE).respond(400, 'Error 400');
          scope.verifyCardLink();
          httpBackend.flush();
          expect(cards.cardVerify).toHaveBeenCalledWith(PHYSICAL_CARD_CODE, scope.activationInfo.cardId, scope.activationInfo.activation.token, scope.verification.otp.toString());
          expect(scope.errorCardLink).toBeTruthy();
          expect(scope.otpVerifyError).toBeTruthy();
          expect(scope.verifyingOtp).toBeFalsy();
          expect(scope.validationError).toBeDefined();
      });
      it('Verify card failure 401 status code', function(){
          httpBackend.whenPUT(API_BASE + 'users/wallets/cards/'+ PHYSICAL_CARD_CODE).respond(401, 'Error 401');
          scope.verifyCardLink();
          httpBackend.flush();
          expect(cards.cardVerify).toHaveBeenCalledWith(PHYSICAL_CARD_CODE, scope.activationInfo.cardId, scope.activationInfo.activation.token, scope.verification.otp.toString());
          expect(scope.errorCardLink).toBeTruthy();
          expect(scope.otpVerifyError).toBeTruthy();
          expect(scope.verifyingOtp).toBeFalsy();
          expect(scope.validationError).toBeDefined();
      });
      it('Verify card failure 500 status code', function(){
          httpBackend.whenPUT(API_BASE + 'users/wallets/cards/'+ PHYSICAL_CARD_CODE).respond(500, 'Error 500 Generic');
          scope.verifyCardLink();
          httpBackend.flush();
          expect(cards.cardVerify).toHaveBeenCalledWith(PHYSICAL_CARD_CODE, scope.activationInfo.cardId, scope.activationInfo.activation.token, scope.verification.otp.toString());
          expect(scope.errorCardLink).toBeTruthy();
          expect(scope.otpVerifyError).toBeTruthy();
          expect(scope.verifyingOtp).toBeFalsy();
          expect(scope.validationError).toBeDefined();
      });
      it('Verify card failure 503 status code', function(){
          httpBackend.whenPUT(API_BASE + 'users/wallets/cards/'+ PHYSICAL_CARD_CODE).respond(503, 'Error 503 fallback');
          scope.verifyCardLink();
          httpBackend.flush();
          expect(cards.cardVerify).toHaveBeenCalledWith(PHYSICAL_CARD_CODE, scope.activationInfo.cardId, scope.activationInfo.activation.token, scope.verification.otp.toString());
          expect(scope.errorCardLink).toBeTruthy();
          expect(scope.otpVerifyError).toBeTruthy();
          expect(scope.verifyingOtp).toBeFalsy();
          expect(scope.validationError).toBeDefined();
      });
  });
  describe('verify resendToken function', function(){
      beforeEach(inject(function(){
        scope.physicalCard = {};
        scope.physicalCard.type = PHYSICAL_CARD_CODE;
        scope.physicalCard.assoc_number = 'PY000000019090';
        spyOn(cards, 'cardCreate').and.callThrough();
        scope.activationInfo = {};
      }));
      it('should verify otp delivery success', function(){
         httpBackend.whenPOST(API_BASE + 'users/wallets/cards/').respond(200, cardCreateResp);
         scope.resendToken();
         httpBackend.flush();
         expect(scope.activationInfo.activation.status).toBe('pending');
         expect(scope.activationInfo.activation.token).toBe('c76145b3fe4c11b378af4b7cd3a0bf96');
         expect(scope.newTokenSent).toBeTruthy();
      });
      it('should check otp delivery failure 500 generic', function(){
         httpBackend.whenPOST(API_BASE + 'users/wallets/cards/').respond(500, {message:'Error 500 generic'});
         scope.resendToken();
         httpBackend.flush();
         expect(scope.newTokenSendFailed).toBeTruthy();
         expect(scope.otpDeliveryError).toBeDefined();
      });
      it('should check otp delivery failure 503 fallback', function(){
         httpBackend.whenPOST(API_BASE + 'users/wallets/cards/').respond(503, {message:'Error 503 fallback'});
         scope.resendToken();
         httpBackend.flush();
         expect(scope.newTokenSendFailed).toBeTruthy();
         expect(scope.otpDeliveryError).toBeDefined();
      });
  });
});
