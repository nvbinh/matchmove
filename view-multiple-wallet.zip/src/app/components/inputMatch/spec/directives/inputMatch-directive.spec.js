'use strict';

// console.log(" >>>>>>>>>> Directive: inputMatch >>>>>>>>>>");

describe('Directive: inputMatch', function() {
    // load the directive's module
    beforeEach(module('viewMultipleWallet'));

    var passwordElem, confirmPasswordElem, scope;

    beforeEach(inject(function($rootScope, $compile) {
        scope = $rootScope.$new();
        passwordElem = '<input type="password" name="confirmPassword" ng-model="registration.user.confirmPassword" required compare-to="registration.user.password" />';

        confirmPasswordElem = '<div ng-messages="registrationForm.confirmPassword.$error" ng-messages-include="messages.html"></div>';
        $compile(element)(scope);
        scope.$digest();
    }));



    afterEach(function() {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    });
});
