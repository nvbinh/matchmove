'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:inputMatch
 * @description
 * # inputMatch
 */
angular.module('viewMultipleWallet')
    .directive('inputMatch', function() {
        return {
            require: "ngModel",
            scope: {
                otherModelValue: "=inputMatch"
            },
            link: function(scope, element, attributes, ngModel) {

                ngModel.$validators.inputMatch = function(modelValue) {

                    console.log(">>>>>>>>")
                    return modelValue == scope.otherModelValue;
                };

                scope.$watch("otherModelValue", function() {
                    ngModel.$validate();
                });
            }
        };
    });
