'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:cardNumberCtrl
 * @description
 * # cardNumberCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('cardNumberCtrl', function ($scope, $translate, GET_ANOTHER_CARD, PHYSICAL_CARD_CODE, Cards, ngDialog, $timeout) {
    $scope.newCardModes = {
          active:0
        };
    $scope.forms = {};
    $scope.activationInfo = {};

    $scope.getAnotherCardConfig = angular.fromJson(GET_ANOTHER_CARD);

    if($scope.cardAcquiredMode === 'purchased'){
        $scope.cardNumberMode = $scope.getAnotherCardConfig.physicalCard.activationMode.purchased.cardNumber;
        $scope.proxyNumberMode = $scope.getAnotherCardConfig.physicalCard.activationMode.purchased.proxyNumber;
    }else{
        $scope.cardNumberMode = $scope.getAnotherCardConfig.physicalCard.activationMode.ordered.cardNumber;
        $scope.proxyNumberMode = $scope.getAnotherCardConfig.physicalCard.activationMode.ordered.proxyNumber;
    }
    function cardLinkError(data, mode) {
          $scope.errorCardLink = true;
          if(data.status === 400) {
            if (data.statusText.indexOf('is already in use') > -1) {
             if (mode == 'cardNumber') {
                   $scope.validationError = $translate.instant('ERRORS.VALIDATION.WALLET_LINK.ERROR400_CARDINUSE');
             }
             if (mode == 'proxyNumber') {
                   $scope.validationError = $translate.instant('ERRORS.VALIDATION.WALLET_LINK.ERROR400_PROXYINUSE');
             }
            }
            else if (data.statusText.indexOf('card type reached') > -1) {
              $scope.validationError = $translate.instant('PAGES.WALLET_LINK.ERROR400_MAXIMUMCARDTYPEREACHED');
            }
            else if(data.statusText.indexOf('cardOrderFailed : Maximum card limit reached') >-1){
              $scope.validationError = $translate.instant('PAGES.WALLET_LINK.ERROR400_MAXIMUMCARDTYPEREACHED');
            }
            else{
              $scope.validationError = $translate.instant('PAGES.WALLET_LINK.ERROR400');
            }
          }
          else if(data.status === 401) {
            $scope.validationError = $translate.instant('PAGES.WALLET_LINK.ERROR401');
          }
          else if(data.status === 500) {
            $scope.validationError = $translate.instant('PAGES.WALLET_LINK.ERROR500');
          }
          else {
            $scope.validationError = $translate.instant('PAGES.WALLET_LINK.ERRORFALLBACK');
          }
    }
    $scope.validateNumber = function(inputObj){
        $scope.physicalCard = {};

        $scope.cardAdded = false;
        $scope.cardActivated = false;
        $scope.cardAddedErr = false;
        $scope.cardActivatedErr = false;

        $scope.errorCardLink = false;
        $scope.physicalCard.assoc_number = inputObj.value;
        $scope.physicalCard.type = inputObj.cardCode || PHYSICAL_CARD_CODE;
        if($scope.physicalCard.assoc_number.length === 12)  {
          $scope.physicalCard.assoc_number = 'PY' + $scope.physicalCard.assoc_number;
        }
        if(inputObj.hash_id !== undefined){
           $scope.physicalCard.hash_id = inputObj.hash_id;
        }
        $scope.isCardLoading = true;
        Cards.cardCreate($scope.physicalCard)
                  .then(function(response){
                    $scope.activationInfo.activation = {};
                    $scope.activationInfo.activation.status = response.data.activation.status;
                    $scope.activationInfo.activation.token = response.data.activation.token;
                    $scope.activationInfo.cardId = response.data.id;
                    $scope.activationInfo.assocNo = $scope.physicalCard.assoc_number;
                    $timeout(launchActivationModal($scope.activationInfo), 1500);
                  },function(error){
                    cardLinkError(error, inputObj.mode);
                    $scope.isCardLoading = false;
                  });
    };

    function launchActivationModal(data) {
        $scope.cardToLink = data;
        ngDialog.open({
            template: 'app/components/activateCard/partials/activateCard.html',
            className: 'modal-otp',
            controller: 'activateCardCtrl',
            scope: $scope,
            showClose: false,
            closeByDocument: false,
            closeByEscape: false
        });
    }

  });
