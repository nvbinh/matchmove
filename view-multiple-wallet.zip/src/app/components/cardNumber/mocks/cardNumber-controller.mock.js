/**
 * cardNumber-controller.mock.js
 */
'use strict'
var API_BASE = angular.module('viewMultipleWallet').constant("API_BASE");
angular.module('cardNumber.JSONData',[])
.value('cardNumberJSON',{
    createCardInfo: {
                    "id": "96e5b38dcbfbc33b4d6686d784a2edb1",
                    "number": "5363950000250379",
                    "holder": {
                        "name": "Balaji"
                    },
                    "funds": {
                        "available": {
                            "currency": "SGD",
                            "amount": "0.00"
                        }
                    },
                    "type": {
                        "type": "mcmmgpcard",
                        "name": "MatchMove Physical Card",
                        "description": "Matchmove Physical Card"
                    },
                    "date": {
                        "expiry": "2020-12",
                        "issued": "2016-02-25"
                    },
                    "status": {
                        "is_active":true,
                        "text": "inactive"
                    },
                    "links": [{
                        "rel": "cards.transactions",
                        "href": API_BASE + "users/wallets/cards/96e5b38dcbfbc33b4d6686d784a2edb1/transactions",
                        "method": "GET"
                    }],
                    "activation": {
                        "status": "pending",
                        "token" : "f51c8c9cdf82dc52debdedd6b7a64871"
                    }
                },     
    walletData: {
                  "funds": {
                    "withholding": {
                      "currency": "SGD",
                      "amount": "0.00"
                    },
                    "available": {
                      "currency": "SGD",
                      "amount": "165.00"
                    }
                  },
                  "id": "dfa7916f06e9640daeb0bbe413012659",
                  "number": "6377020000009969",
                  "holder": {
                    "name": "Balaji"
                  },
                  "date": {
                    "expiry": "2024-03",
                    "issued": "2015-12-15"
                  },
                  "image": {
                    "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                    "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                    "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
                  },
                  "status": {
                    "is_active": true,
                    "text": "active"
                  },
                  "details": {
                    "min_load_limit": 10,
                    "fee": 0,
                    "topup_limits": {
                      "pre_kyc": {
                        "frequency": null,
                        "allowed": 1
                      },
                      "post_kyc": {
                        "frequency": null
                      },
                      "current": {
                        "lifetime_count": 3
                      }
                    }
                  },
                  "cards": [
                    {
                      "id": "25302c8a90917740e0fc6057113bb70f",
                      "type": [
                        {
                          "rel": "self",
                          "href": API_BASE + "users/wallets/cards/types/mcmmgpcard",
                          "method": "GET"
                        }
                      ],
                      "links": [
                        {
                          "rel": "self",
                          "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f",
                          "method": "GET"
                        }
                      ]
                    }
                  ]
                }
});
