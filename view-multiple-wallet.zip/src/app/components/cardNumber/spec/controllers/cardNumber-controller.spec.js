'use strict';
describe('Controller: cardNumberCtrl', function () {
// Load custom config constant
 beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( 'GET_ANOTHER_CARD', {
      "isStatic": true,
      "preKyc": {
        "totalCount": 1,
        "maxVirtualCards": 1,
        "maxPhysicalCards": 0
      },
      "postKyc": {
        "totalCount": 2,
        "maxVirtualCards": 0,
        "maxPhysicalCards": 2
      },
      "physicalCard": {
        "activationMode": {
          "ordered": {
            "proxyNumber": true,
            "cardNumber": true
          },
          "purchased": {
            "proxyNumber": true,
            "cardNumber": true
          }
        },
        "constants": {
          "orderPlaced": "Card Order placed",
          "orderDispatched": "Card Order Dispatched",
          "orderAdded": "Card Added",
          "orderActivated": "Card Activated"
        },
        "cardOrderEnabled": true,
        "cardActivationEnabled": true
      },
      "cardsSupported": [ {
        "name": "MatchMove Physical Card",
        "cardCode": "mcmmgpcard",
        "orderFee": 23,
        "type": "physical",
        "image": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-large.png"
      }, {
        "name": "MatchMove Imba Card",
        "cardCode": "mcimbacard",
        "orderFee": 0,
        "type": "virtual",
        "image": "https://vcard-assets.s3.amazonaws.com/sg/product/mcimbacard/card-large.png"
      }, {
        "name": "MatchMove Virtual MasterCard",
        "cardCode": "mcmmgcard",
        "orderFee": 0,
        "type": "virtual",
        "image": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-large.png"
      } ]
    } );
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
// load the controller's module
  beforeEach(module('viewMultipleWallet', 'cardNumber.JSONData'));
  var cardNumberCtrl,
      scope,
      GET_ANOTHER_CARD,
      httpBackend,
      walletData,
      createCardInfo,
      store,
      Cards,
      Wallet,
      API_BASE;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, cardNumberJSON, _GET_ANOTHER_CARD_, _store_, _Cards_, _Wallet_, _API_BASE_ ) {
    scope = $rootScope.$new();
    GET_ANOTHER_CARD = _GET_ANOTHER_CARD_;
    store = _store_;
    Cards = _Cards_;
    Wallet = _Wallet_;
    API_BASE = _API_BASE_;
    cardNumberCtrl = $controller('cardNumberCtrl', {
      $scope: scope
    });

    walletData = cardNumberJSON.walletData;
    createCardInfo = cardNumberJSON.createCardInfo;
    store.set( 'kycStatus', 'approved' );
    spyOn( Cards, 'cardCreate' ).and.callThrough();
    httpBackend.flush();
  }));
  afterEach( function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  describe('cardNumber Functionality', function(){
  	it('variables check', function(){
  		expect(scope.newCardModes).toBeDefined();
  		expect(scope.forms).toEqual({});
  	});
  	it('card create function: successful card creation using Proxy number', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 200, createCardInfo );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
		scope.activationInfo.activation = {};
		scope.physicalCard.assoc_number = inputObj.value;
        scope.physicalCard.type = inputObj.cardCode;
        scope.physicalCard.hash_id = inputObj.hash_id;
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  		expect(scope.activationInfo.assocNo).toBe('PY000000019090');
  	});it('card create function: successful card creation using Card number', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 200, createCardInfo );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '1234123412341234',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
		scope.activationInfo.activation = {};
		scope.physicalCard.assoc_number = inputObj.value;
        scope.physicalCard.type = inputObj.cardCode;
        scope.physicalCard.hash_id = inputObj.hash_id;
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  		expect(scope.activationInfo.assocNo).toBe('1234123412341234');
  	});
  	it('card create function: 400 error - already in use', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 400, '', {}, "HTTP/1.1 400 assoc number is already in use" );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  		expect(scope.errorCardLink).toBeTruthy();
  	});
  	it('card create function: 400 error - max card type reached', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 400, '', {}, "HTTP/1.1 400 max card type reached" );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  		expect(scope.errorCardLink).toBeTruthy();
  	});
  	it('card create function: 400 other error', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 400, '', {}, "HTTP/1.1 400 other error" );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  	});
  	it('card create function: 401 error', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 401, '', {}, "HTTP/1.1 401 error occured here" );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  	});
  	it('card create function: 500 error', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 500, '', {}, "HTTP/1.1 500 server error occured here" );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  	});
  	it('card create function: 503 error', function(){
  		httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 503, '', {}, "HTTP/1.1 503 some internal error here" );
    	httpBackend.whenGET( API_BASE + 'users/wallets' ).respond( 200, walletData );
		var inputObj = {
			value: '000000019090',
			cardCode: 'mcmmgpcard',
			hash_id: 'ertg4y56756'
		}
		scope.physicalCard = {};
		scope.activationInfo = {};
  		scope.validateNumber(inputObj);
  		httpBackend.flush();
  	});
  });
});

describe( 'Controller: cardNumberCtrl : Ordered Card', function() {
  // load the controller's module
  beforeEach( module( 'viewMultipleWallet' ) );
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var cardNumberCtrl,
    scope,
    Cards,
    httpBackend,
    API_BASE;
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
  // Initialize the controller and a mock scope
  beforeEach( inject( function( $controller, $rootScope, GET_ANOTHER_CARD ) {
    scope = $rootScope.$new();
    scope.activationInfo = {};
    cardNumberCtrl = $controller( 'cardNumberCtrl', {
      $scope: scope
    } );
  } ) );
  describe( 'CardNumber initial Variables', function() {
    it( 'should have scope variable: getAnotherCardConfig', function() {
      expect( scope.getAnotherCardConfig ).toBeDefined();
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      var responseActivationInfo = {};
      responseActivationInfo.activation = {};
      responseActivationInfo.activation.status = 'Card Added';
      responseActivationInfo.activation.token = '123646';
      responseActivationInfo.id = '7e44d2be136976e9fe153';
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 200, responseActivationInfo );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number fn call', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.activationInfo.cardId ).toEqual( '7e44d2be136976e9fe153' );
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number: Error 400 is already in use', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 400, '', {}, 'HTTP1.1/400 assoc number is already in use' );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number error: 400', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.errorCardLink ).toBeTruthy();
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number: Error 400 card type reached', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 400, '', {}, 'HTTP1.1/400 maximum card type reached' );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number error: 400', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.errorCardLink ).toBeTruthy();
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number: Error 400 other error', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 400, '', {}, 'HTTP1.1/400 other error' );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number error: 400', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.errorCardLink ).toBeTruthy();
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number: Error 401 ', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 401, '', {}, 'HTTP1.1/401 other error' );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number error: 401', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.errorCardLink ).toBeTruthy();
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number: Error 500', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 500, '', {}, 'HTTP1.1/500 Internal Server error' );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number error: 500', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.errorCardLink ).toBeTruthy();
    } );
  } );
  describe( 'Call validateNumber fn to verify Assoc number: Error 503 server error', function() {
    beforeEach( inject( function( _Cards_, _API_BASE_ ) {
      Cards = _Cards_;
      API_BASE = _API_BASE_;
      spyOn( Cards, 'cardCreate' ).and.callThrough();
      httpBackend.whenPOST( API_BASE + 'users/wallets/cards/' ).respond( 503, '', {}, 'HTTP1.1/503 other server error' );
      httpBackend.flush();
    } ) );
    afterEach( function() {
      httpBackend.verifyNoOutstandingExpectation();
      httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Validate number error: 503', function() {
      var inputObj = {};
      inputObj.value = '000000019090';
      inputObj.cardCode = 'mcmmgpcard';
      inputObj.hash_id = '7e44d2be136976e9fe15377e654dfef3';
      scope.validateNumber( inputObj );
      httpBackend.flush();
      expect( scope.errorCardLink ).toBeTruthy();
    } );
  } );
} );
describe( 'Controller: cardNumberCtrl : Purchased Card', function() {
  // load the controller's module
  beforeEach( module( 'viewMultipleWallet' ) );
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var cardNumberCtrl,
    scope;

  // Initialize the controller and a mock scope
  beforeEach( inject( function( $controller, $rootScope, GET_ANOTHER_CARD ) {
    scope = $rootScope.$new();
    scope.cardAcquiredMode = 'purchased';
    cardNumberCtrl = $controller( 'cardNumberCtrl', {
      $scope: scope
    } );
  } ) );
  describe( 'CardNumber initial Variables', function() {
    it( 'should have scope variable: getAnotherCardConfig', function() {
      expect( scope.getAnotherCardConfig ).toBeDefined();
    } );
    it( 'card acquired mode is purchased', function() {
      scope.cardAcquiredMode = 'purchased';
      expect( scope.cardNumberMode ).toBeDefined();
    } );
  } );
} );