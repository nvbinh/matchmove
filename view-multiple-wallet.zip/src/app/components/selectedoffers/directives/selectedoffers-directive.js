'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:selectedoffers
 * @description
 * # selectedoffers
 */
angular.module('viewMultipleWallet')
  .directive('selectedoffers', function () {
    return {
      template: '<div></div>',
      restrict: 'E',
      link: function(scope, element) {
        element.text('this is the selectedoffers directive');
      }
    };
  });
