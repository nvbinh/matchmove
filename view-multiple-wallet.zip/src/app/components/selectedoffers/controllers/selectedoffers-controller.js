'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:selectedoffersCtrl
 * @description
 * # selectedoffersCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('selectedoffersCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
