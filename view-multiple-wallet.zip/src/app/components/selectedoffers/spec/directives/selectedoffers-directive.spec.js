'use strict';
describe('Directive: selectedoffers', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var
    scope,
    scopeElem,
    httpBackend,
    API_BASE;
    // language based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  beforeEach(inject(function ($rootScope, $compile, _API_BASE_) {
    scope = $rootScope.$new();
    API_BASE = _API_BASE_;
    scopeElem = angular.element('<selectedoffers></selectedoffers>');

    $compile(scopeElem)(scope);
    scope.$digest();
  }));
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
   it('should display element text', inject(function ($compile) {
     expect(scopeElem.text()).toBe('this is the selectedoffers directive');
   }));
});
