'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:mmdatePicker
 * @description
 * # mmdatePicker
 */
angular.module('viewMultipleWallet')
  .directive('mmdatePicker', ['helperFactory', function (helperFactory) {
    return {
      restrict: 'E',
      scope: {
        dateValue: '=dateValue'
      },
      templateUrl: 'app/components/mmdatePicker/partials/mmdatePicker.html',
      link: function(scope, element, attrs) {
        scope.isMobile = helperFactory.isMobile();
        scope.date = {};
        scope.date.value = scope.dateValue;
        if (scope.isMobile && scope.dateValue) {
        	scope.date.value = new Date(scope.dateValue);
        }

        scope.$watch('date.value', function () {
          if (scope.$parent.info) {
            scope.$parent.info.birthday = scope.date.value;
          }
          if (scope.$parent.remittanceInfo) {
            scope.$parent.remittanceInfo.birth_date = scope.date.value;
          }
        }, true);

        scope.placeHolder = attrs.placeHolder;
      }
    };
  }]);
