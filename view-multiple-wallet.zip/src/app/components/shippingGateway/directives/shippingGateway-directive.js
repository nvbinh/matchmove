'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:shippingGateway
 * @description
 * # shippingGateway
 */
angular.module('viewMultipleWallet')
  .directive('shippingGateway', ['userAddressFactory', '$window', '$analytics', 'store', function (userAddressFactory, $window, $analytics, store) {
    return {
      restrict: 'E',
      templateUrl: 'app/components/shippingGateway/partials/shippingGateway.html',
      controller: ['$scope', function($scope) {

      }],
      link: function(scope, element, attrs) {

      	scope.shippingGatewayErrorTrue = false;
      	var user = store.get('user');
      	if (user && user.email && (user.email.indexOf('+') > -1 || user.email.indexOf('&') > -1)) {
      		scope.shippingGatewayErrorTrue = true;
      	}
        userAddressFactory.getExistingShippingAddress()
          .then(function(response){
            scope.noExistinShipping = false;
            scope.shippingAddress = response.data;
          },function(error){
            scope.noExistinShipping = true;
          });
        scope.connectGateway = function() {
        	userAddressFactory.getShippingAddress()
	          .then(function(response) {
	            if (response && response.data && response.data.links && response.data.links.href) {
	              scope.topupProcessing = true;
	              var shippingGatewayPopup = $window.open(response.data.links.href, 'Shipping Gateway', 'width=500,height=400');
	              if (!shippingGatewayPopup || shippingGatewayPopup.closed || typeof shippingGatewayPopup.closed === 'undefined') {
	                  scope.topupProcessing = false;
	                  return false;
	              } else {
	                  scope.topupProcessing = true;
	              }

	              shippingGatewayPopup.addEventListener('beforeunload', function() {
	              	console.log('catch close event');
	              }, false);
	            }
	        }, function(response) {
	        	if (response && response.status === 400) {
	        		if(response.statusText.indexOf('invalidEmailContainsPlusSign') > -1){
                        $analytics.eventTrack( 'Error Shipping Gateway', {
	                        category: 'Shipping Gateway',
	                        label: 'Email error' + response.status + ' : ' + response.statusText
	                    });
                    }
	        	} else if(response && response.status === 302) {
              if(response.statusText.indexOf('onlyOneRecordShouldBeAllowed') > -1){
                userAddressFactory.getExistingShippingAddress()
                  .then(function(response){

                  });
              }
	        	}
            });
        };
      }
    };
  }]);
