'use strict';

describe('Filter: mmCurrency "numberDecimalPlaces": "2", "thousandsGroupSize": "3", prefix', function () {
// load the filter's module
  beforeEach(module('viewMultipleWallet'));
// initialize a new instance of the filter before each test
// mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("CURRENCY_DISPLAY_SETTINGS", {
              "decimalSeparator": ",",
              "thousandsSeparator": ".",
              "thousandsGroupSize": "3",
              "currencySymbol": "VND",
              "currencyPosition": "prefix",
              "numberDecimalPlaces": "2"
            } );
    } ) );
  var mmCurrency,
    scope,
    element,
    compiledElement,
    httpBackend,
    preFormatters,
    CURRENCY_DISPLAY_SETTINGS;
  beforeEach(inject(function ($filter, $rootScope, $compile, _CURRENCY_DISPLAY_SETTINGS_, _PreFormatters_) {
    scope = $rootScope.$new();
    preFormatters = _PreFormatters_;
    CURRENCY_DISPLAY_SETTINGS = _CURRENCY_DISPLAY_SETTINGS_;
    ;
    mmCurrency = $filter('mmCurrency');
  }));
  it('should apply filter for float value', function () {
    var res =  mmCurrency(12234567.87, 'skipSymbolTrue');
    expect(res).toBe(' 12.234.567,87 ');
  });
  it('should apply filter for integer value', function () {
    var res =  mmCurrency(12234567, 'skipSymbolTrue');
    expect(res).toBe(' 12.234.567,00 ');
  });
  it('should apply filter VND currency symbol as prefix', function () {
    var res =  mmCurrency(12234567.87, 'skipSymbolFalse');
    expect(res).toBe('VND 12.234.567,87 ');
  });
});

describe('Filter: mmCurrency "numberDecimalPlaces": "3", "thousandsGroupSize": "2", suffix', function () {
// load the filter's module
  beforeEach(module('viewMultipleWallet'));
// initialize a new instance of the filter before each test
// mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("CURRENCY_DISPLAY_SETTINGS", {
              "decimalSeparator": ",",
              "thousandsSeparator": ".",
              "thousandsGroupSize": "2",
              "currencySymbol": "VND",
              "currencyPosition": "suffix",
              "numberDecimalPlaces": "3"
            } );
    } ) );
  var mmCurrency,
    scope,
    element,
    compiledElement,
    httpBackend,
    preFormatters,
    CURRENCY_DISPLAY_SETTINGS;
  beforeEach(inject(function ($filter, $rootScope, $compile, _CURRENCY_DISPLAY_SETTINGS_, _PreFormatters_) {
    scope = $rootScope.$new();
    preFormatters = _PreFormatters_;
    CURRENCY_DISPLAY_SETTINGS = _CURRENCY_DISPLAY_SETTINGS_;
    ;
    mmCurrency = $filter('mmCurrency');
  }));
  it('should apply filter for float value', function () {
    var res =  mmCurrency(1223456.787, 'skipSymbolTrue');
    expect(res).toBe(' 12.23.456,787 ');
  });
  it('should apply filter for integer value', function () {
    var res =  mmCurrency(12234567, 'skipSymbolTrue');
    expect(res).toBe(' 1.22.34.567,000 ');
  });
  it('should apply filter VND currency symbol as suffix', function () {
    var res =  mmCurrency(12234567.87, 'skipSymbolFalse');
    expect(res).toBe(' 1.22.34.567,870 VND');
  });
});
