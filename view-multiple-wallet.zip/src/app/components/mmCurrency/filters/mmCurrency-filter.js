'use strict';
/**
 * @ngdoc filter
 * @name viewMultipleWallet.filter:mmCurrency
 * @function
 * @description
 * # mmCurrency
 * Filter in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .filter('mmCurrency', function(CURRENCY_DISPLAY_SETTINGS, $parse, PreFormatters) {
        return function(amount, skipSymbol) {
            // if null or undefined pass it through
            if (amount == null || !(angular.isString(amount) || angular.isNumber(amount))) {
                return amount;
            } else {
                var currencyDisplaySettings = angular.fromJson(CURRENCY_DISPLAY_SETTINGS);
                var decimalDelimiter = currencyDisplaySettings.decimalSeparator,
                    thousandsDelimiter = currencyDisplaySettings.thousandsSeparator,
                    thousandsGroupSize = currencyDisplaySettings.thousandsGroupSize,
                    currencySym = currencyDisplaySettings.currencySymbol,
                    currencyPosition = currencyDisplaySettings.currencyPosition,
                    symbolSeparation = ' ',
                    currencyPosition = currencyDisplaySettings.currencyPosition,
                    decimals = currencyDisplaySettings.numberDecimalPlaces,
                    initialThousand = '###';


                var formattedCurrency,
                    formatedAmount = amount,
                    signAmount = amount < 0 ? '-' : '',
                    rtl = false;

                if (isNaN(decimals)) {
                    decimals = 2;
                }
                decimals = parseInt(decimals);

                var replicate = function(len, char) {
                  return Array(len+1).join(char || ' ');
                };

                var padr = function(text, len, char) {
                    if(text && text.length){
                      if (text.length >= len) {
                        return text.substr(0, len);
                        }else {
                            return text + replicate(len-text.length, char);
                        }
                    }else{
                        return text;
                    }
                };

                var maskPattern = '';
                var decimalsPattern = decimals > 0 ? decimalDelimiter + new Array(decimals + 1).join('0') : '';
                if (thousandsGroupSize === '2') {
                    maskPattern = symbolSeparation + '#' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + '##' + thousandsDelimiter + initialThousand + decimalsPattern + symbolSeparation;
                } else if (thousandsGroupSize === '3') {
                    maskPattern = symbolSeparation + '#' + thousandsDelimiter + '###' + thousandsDelimiter + '###' + thousandsDelimiter + '###' + thousandsDelimiter + '###' + thousandsDelimiter + '###' + thousandsDelimiter + initialThousand + decimalsPattern + symbolSeparation;
                }
                var moneyMask = new StringMask(maskPattern, { reverse: true });

                // check if input is an integer and add the required number of decimal zeroes
                if (/^-?[0-9]+$/.test(amount) === true) {
                    if (decimals == 2) {
                        amount = amount.toString() + '.00';
                    } else if (decimals == 3) {
                        amount = amount.toString() + '.000';
                    }
                }else{
                    // amount is a float point number.
                    //  check the number of decimals and rpad to reqd number of places
                    amount = amount.toString();
                    var splitParts = amount.split(".");
                    var floatPart = splitParts[1];
                    if (decimals == 2) {
                        floatPart = padr(floatPart, 2, "0");
                    } else if (decimals == 3) {
                        floatPart = padr(floatPart, 3, "0");
                    }
                    amount = splitParts[0].concat( ".", floatPart);
                }

                var actualNumber = (angular.isNumber(amount)) ? amount.toString().replace(/[^\d]+/g, '') : amount.replace(/[^\d]+/g, '');
                actualNumber = actualNumber.replace(/^[0]+([1-9])/, '$1');
                actualNumber = actualNumber || '0';

                var formatedValue;
                if (currencyPosition === 'prefix') {
                    if (skipSymbol === 'skipSymbolFalse') {
                        formatedValue = currencySym + moneyMask.apply(actualNumber);
                    } else if (skipSymbol === 'skipSymbolTrue') {
                        formatedValue = moneyMask.apply(actualNumber);
                    }

                } else if (currencyPosition === 'suffix') {
                    if (skipSymbol === 'skipSymbolFalse') {
                        formatedValue = moneyMask.apply(actualNumber) + currencySym;
                    } else if (skipSymbol === 'skipSymbolTrue') {
                        formatedValue = moneyMask.apply(actualNumber);
                    }
                }
                return formatedValue;
            }
        };
    });
