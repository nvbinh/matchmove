'use strict';
describe( 'Controller: topupMoneysendCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet', 'mockFirebaseFunctions' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var topupMoneysendCtrl,
        scope,
        httpBackend,
        moneysendData,
        $timeout,
        fbFnFactory,
        store;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller
    beforeEach( inject( function( $controller, $rootScope, _$timeout_, _firebaseFunctionsFactory_, _store_ ) {
        scope = $rootScope.$new();
        store = _store_;
        fbFnFactory = _firebaseFunctionsFactory_;
        firebase.apps = [];
        $timeout = _$timeout_;
        topupMoneysendCtrl = $controller( 'topupMoneysendCtrl', {
            $scope: scope
        } );
        store.set('selectedLang', 'en_us');
        scope.provider = 'NPN';
        moneysendData = {
            "moneysend": {
                "en_us": {
                  "app": {
                    "-Jy6n0D6CUe5sphZqBJ1": {
                      "description": "<h1>1</h1><p>Login to your iBanking account using POSB/DBS/OCBC mBanking app<br/></p>",
                      "image": "http://vcard-assets.s3.amazonaws.com/sg/assets/multi-card-flexm/img/helpguide/moneysend/app/01.png",
                      "order": "0"
                    }
                  },
                  "ibanking": {
                    "-Jy6n0D6CUe5sphZqBJ2": {
                      "description": "<h1>1</h1><p>Visit POSB/DBS/OCBC iBanking site, and login using your internet banking account<br/></p>",
                      "image": "http://vcard-assets.s3.amazonaws.com/sg/assets/multi-card-flexm/img/helpguide/moneysend/ibank/01.png",
                      "order": "0"
                    }
                  }
                },
                "vi_vn": {
                  "app": {
                    "-Jy6n0D6CUe5sphZqBJ2": {
                      "description": "<h1>1</h1><p>VN Login to your iBanking account using POSB/DBS/OCBC mBanking app<br/></p>",
                      "image": "http://vcard-assets.s3.amazonaws.com/sg/assets/multi-card-flexm/img/helpguide/moneysend/app/01.png",
                      "order": "0"
                    }
                  },
                  "ibanking": {
                    "-Jy6n0D6CUe5sphZqBJ5": {
                      "description": "<h1>1</h1><p>VN Visit POSB/DBS/OCBC iBanking site, and login using your internet banking account<br/></p>",
                      "image": "http://vcard-assets.s3.amazonaws.com/sg/assets/multi-card-flexm/img/helpguide/moneysend/ibank/01.png",
                      "order": "0"
                    }
                  }
                }
              }
            };
    } ) );

    describe(' get ibanking data tests', function(){
        it(' :: should return banking data as a promise', function() {
            scope.ibankingRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang +'/ibanking');
            scope.ibankingRef.on('value', function(snapshot){
                $timeout(function(){
                    scope.ibankingdataArray = [];
                    scope.ibankingHasData = true;
                    scope.ibankingObj = snapshot.val();
                    angular.forEach(scope.ibankingObj, function(value, key){
                        scope.ibankingdataArray.push(value);
                        expect(scope.ibankingdataArray).toBeDefined();
                        expect(scope.ibankingdataArray).toEqual(moneysendData.moneysend.en_us.ibanking);
                    });
                }, 10)


            });
            scope.ibankingRef.fakeEvent('value', null, moneysendData.moneysend.en_us.ibanking);
            scope.loadIBankingData();
            // scope.ibankingRef.flush();
            fbFnFactory.flushAll(scope.ibankingRef);
        });
    });
    describe(' get app data tests', function(){
        it(' :: should return app data as a promise', function() {
            scope.appRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang +'/app');
            scope.appRef.on('value', function(snapshot){
                $timeout(function(){
                    scope.appdataArray = [];
                    scope.appHasData = true;
                    scope.appObj = snapshot.val();
                    angular.forEach(scope.appObj, function(value, key){
                        scope.appdataArray.push(value);
                        expect(scope.appdataArray).toBeDefined();
                        expect(scope.appdataArray).toEqual(moneysendData.moneysend.en_us.app);
                    });
                }, 10)


            });
            scope.appRef.fakeEvent('value', null, moneysendData.moneysend.en_us.app);
            scope.loadAppData();
            // scope.appRef.flush();
            fbFnFactory.flushAll(scope.appRef);
        });
    });
} );
