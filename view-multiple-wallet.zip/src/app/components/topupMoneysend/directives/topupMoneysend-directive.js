'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:doKyc
 * @description
 * # doKyc
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'topupMoneysend', function () {
        return {
            templateUrl: 'app/components/topupMoneysend/partials/topupMoneysend.html',
            restrict: 'A',
            controller: 'topupMoneysendCtrl',
            transclude: true,
            replace: true,
            link: function ( scope, element, attrs ) {

            }
        };
    } );
