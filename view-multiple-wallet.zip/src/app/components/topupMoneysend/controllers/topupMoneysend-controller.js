'use strict';

angular.module( 'viewMultipleWallet' )
    .controller( 'topupMoneysendCtrl', function ( CONTENT_NET, store, $scope, $q, $timeout, PubSub ) {
        $scope.walletTopupMoneySend = {
            active: 0
        };
        var deferred = $q.defer();
        $scope.orderField = 'order';

        $scope.provider = 'Moneysend';

        $scope.loadIBankingData = function () {
            $scope.ibankingdataArray = [];
            $scope.lang = store.get('selectedLang');
            $scope.ibankingRef = firebase.database().ref( 'guides/payments/' + angular.lowercase($scope.provider) + '/' + $scope.lang + '/ibanking' );
            $scope.ibankingRef.on('value', function(snapshot){
               $timeout(function(){
                $scope.ibankingdata = snapshot.val();
                angular.forEach($scope.ibankingdata, function(value, key){
                    $scope.ibankingdataArray.push(value);
                });
                $scope.ibankingHasData = true;
            }, 10)  ;
            })
        };
        PubSub.subscribe('language-changed', $scope.loadIBankingData)
        $scope.loadIBankingData();


        $scope.loadAppData = function () {
            $scope.appdataArray = [];
            $scope.lang = store.get('selectedLang');
            $scope.appRef = firebase.database().ref( 'guides/payments/' + angular.lowercase($scope.provider) + '/' + $scope.lang + '/app' );
            $scope.appRef.on('value', function(snapshot){
                $timeout(function(){
                    $scope.appdata = snapshot.val();
                    angular.forEach($scope.appdata, function(value, key){
                        $scope.appdataArray.push(value);
                    });
                    $scope.appHasData = true;
                }, 10);
            })
        };
        PubSub.subscribe('language-changed', $scope.loadAppData)
        $scope.loadAppData();
    } );
