'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:countryChange
 * @description
 * # countryChange
 */
angular.module('viewMultipleWallet')
    .directive('countryChange', function (helperFactory) {
        return {
            restrict: 'E',
            scope: true,

            controller: ['$scope', function ($scope, attrs) {
                $scope.isBilling = function (formName) {
                    if (formName === 'billing') {
                        return true;
                    }
                    return false;
                };
                $scope.isMailing = function (formName) {
                    if (formName === 'mailing') {
                        return true;
                    }
                    return false;
                };
            }],

            templateUrl: 'app/components/countryChange/partials/countryChange.html',

            link: function (scope, element, attrs) {
                var isDefaultCountry = helperFactory.isDefaultCountry(attrs.country);
                scope.showDetail = !isDefaultCountry;
                scope.hasDropdown = (attrs.isDropdown === 'true') ? true : false;
                scope.form = attrs.formName;

                attrs.$observe('country', function (value) {
                    var defaultCountry = helperFactory.isDefaultCountry(value);
                    scope.showDetail = !defaultCountry;
                });

            }
        };
    });
