'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:autoFocus
 * @description
 * # autoFocus
 */
angular.module('viewMultipleWallet')
    .directive('autoFocus', function () {
        return {
            restrict: 'A',
            link: function ($scope, element) {
                element[0].focus();

            }
        };
    });