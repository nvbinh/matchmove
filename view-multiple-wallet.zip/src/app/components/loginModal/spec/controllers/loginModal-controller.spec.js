'use strict';
describe('Controller: loginModalCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var loginModalCtrl,
      scope,
      _ngDialog;
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, ngDialog) {
    scope = $rootScope.$new();
    _ngDialog = ngDialog;
    loginModalCtrl = $controller('loginModalCtrl', {
      $scope: scope
    });
  }));
  it('should attach a variable to the scope', function () {
    expect(scope.displayLoginModal).toBeTruthy();
  });

  describe('resume session', function(){
      it('should close ngDialog', function(){
          spyOn(_ngDialog, 'closeAll');
          scope.resumeSession();
          expect(_ngDialog.closeAll).toHaveBeenCalled();
      });
  });
});
