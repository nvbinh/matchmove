'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:loginModalCtrl
 * @description
 * # loginModalCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('loginModalCtrl', function ($scope, $rootScope, authenticationFactory, ngDialog, Idle) {
    $scope.displayLoginModal = true;
    $scope.resumeSession = function(){
          Idle.watch();
          ngDialog.closeAll();
      };
  });
