'use strict';
/* global angular */

angular.module('viewMultipleWallet')
    .controller('MmBrandingCtrl', function() {

    });
