'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:loyaltyredeemCtrl
 * @description
 * # loyaltyredeemCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('loyaltyredeemCtrl', function($scope, ngDialog, $log, API_BASE, $rootScope, CONTENT_NET, CONTENT_NET_AUTH, $timeout, store) {

        //! TODO: Create a Loyalty service similar to cards
        $scope.loyaltyItem = $scope.$parent.loyaltyItem;
       $scope.contentNetAuth = angular.fromJson(CONTENT_NET_AUTH);

        $scope.confirmRedeem = function($event, id) {
            $scope.lang = store.get('selectedLang');
            if (firebase.apps.length === 0) {
                $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $rootScope.redeemSuccess = false;
            var btnRedeem = $event.currentTarget;
            btnRedeem.classList.add('loading');
            // prepare loyalty update Object
            // $scope.loyaltyItemUpd = ;

            $scope.loyaltyDetailRef = $rootScope.firebaseApp.database().ref('loyalties/' + id);
            $scope.auth = $rootScope.firebaseApp.auth();
            $scope.auth.signInWithEmailAndPassword($scope.contentNetAuth.uid, $scope.contentNetAuth.cred)
            .then(function(user){
                if (user) {
                    $scope.loyaltyDetailRef.update({
                            "quantity": $scope.loyaltyItem.quantity - 1
                        })
                    .then(function(){
                         $timeout(function(){
                            ngDialog.closeAll();
                            $rootScope.redeemSuccess = true;
                        }, 2000);
                    }, function(error){
                        console.log("Error:", error);
                    })
                    $scope.auth.signOut();
                }
            })
        };
    });
