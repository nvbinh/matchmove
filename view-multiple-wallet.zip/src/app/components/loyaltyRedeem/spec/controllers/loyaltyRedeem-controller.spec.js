'use strict';
describe( 'Controller: loyaltyredeemCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet', 'mockFirebaseFunctions' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var loyaltyredeemCtrl,
        scope,
        httpBackend,
        firebase,
        fbFnFactory,
        loyaltyListData,
        ngdialog,
        btnElem,
        store,
        rootScope;
   // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function( $controller, $rootScope, $compile, $q, _firebaseFunctionsFactory_, _ngDialog_, CONTENT_NET, CONTENT_NET_AUTH, $timeout, _store_ ) {
        rootScope = $rootScope;
        scope = $rootScope.$new();
        firebase = window.firebase;
        fbFnFactory = _firebaseFunctionsFactory_;
        ngdialog = _ngDialog_;
        firebase.apps = [];
        store = _store_;
        loyaltyredeemCtrl = $controller( 'loyaltyredeemCtrl', {
            $scope: scope
        } );
        loyaltyListData = {
                "vNN": {
                        "isHidden": false,
                        "points": 10000,
                        "quantity": 98,
                          "imageUrl": "https://vcard1.s3.amazonaws.com/loyalty_image/1468898350.png",
                        "en_us": {
                          "description": "Redeem $5 Credit for 10,000 points",
                          "title": "$5 Credit"
                        },
                        "vi_vn": {
                          "description": "VN Redeem $5 Credit for 10,000 points",
                          "title": "VN $5 Credit"
                        }
                      },
                      "Q3_vNN": {
                        "isHidden": false,
                        "points": 10000,
                        "quantity": -98,
                          "imageUrl": "https://vcard1.s3.amazonaws.com/loyalty_image/1468898350.png",
                        "en_us": {
                          "description": "Redeem $5 Credit for 10,000 points",
                          "title": "$5 Credit"
                        },
                        "vi_vn": {
                          "description": "VN Redeem $5 Credit for 10,000 points",
                          "title": "VN $5 Credit"
                        }
                      }
                  };
        scope.loyaltyItem = loyaltyListData.vNN;
        btnElem = angular.element( '<button class="button-primary--large" ng-click="confirmRedeem($event, loyaltyItem.key)">redeem<span class="spinner"></span></button>' );
        $compile( btnElem )( scope );
        scope.$digest();
    } ) );
    afterEach( function() {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    it('scope vars defined', function(){
        expect(scope.loyaltyItem).toBeDefined();
    })

// TODO fix this later
    describe('redeem fn is verified', function(){
        it('redeem fn updates the quantity', function(){
            var id = 'vNN';
            scope.loyaltyDetailRef = fbFnFactory.stubRef('loyalties/' + id);
            scope.auth = fbFnFactory.stubAuthRef();
            scope.auth.signInWithEmailAndPassword('abcd', 'efgh').then(function(user){
                    if (user){
                        scope.loyaltyDetailRef.update({
                            "quantity": scope.loyaltyItem.quantity - 1
                        })
                        .then(function(){
                             $timeout(function(){
                                ngDialog.closeAll();
                                rootScope.redeemSuccess = true;
                                expect(rootScope.redeemSuccess).not.toBeTruthy();
                            }, 2000);
                        }, function(error){
                            console.log("Error:", error);
                        })
                        scope.auth.signOut();
                    }
            });
            btnElem.triggerHandler('click');
        });
    })
} );

