'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:noBalanceCtrl
 * @description
 * # noBalanceCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('noBalanceCtrl', function ($scope, $log, $state, ngDialog) {
        $scope.redirectTopup = function() {
            ngDialog.closeAll();
            $state.go('wallet.topup.select');
        };
    });
