/* global inject */
/* global expect */
/* global it */
/* global beforeEach */
/* global describe */

'use strict';
describe( 'Controller: noBalanceCtrl', function() {
  // load the controller's module
  beforeEach( module( 'viewMultipleWallet' ) );
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  } ) );
  var noBalanceCtrl,
    scope,
    API_BASE,
    httpBackend,
    ngDialog,
    state,
    httpBackend;
  // language based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
    httpBackend = $httpBackend;
    var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
    for ( var i = 0; i < lngth; i++ ) {
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
    }
  } ) );
  // Initialize the controller and a mock scope
  beforeEach( inject( function( $controller, $rootScope, _API_BASE_, _ngDialog_, _$state_ ) {
    scope = $rootScope.$new();
    API_BASE = _API_BASE_;

    ngDialog = _ngDialog_;
    state = _$state_;
    noBalanceCtrl = $controller( 'noBalanceCtrl', {
      $scope: scope
    } );
  } ) );
  afterEach( function() {
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  } );
  it( 'should call the state.go & redirect to wallet.topup.select page', function() {
    spyOn( ngDialog, 'closeAll' );
    spyOn( state, 'go' );
    scope.redirectTopup();
    expect( ngDialog.closeAll ).toHaveBeenCalled();
    expect( state.go ).toHaveBeenCalledWith( 'wallet.topup.select' );
  } );
} );