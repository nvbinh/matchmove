'use strict';
describe('Controller: helpCtrl', function () {
    beforeEach(function(){
        window.MockFirebase.override();
    })
    afterEach(function(){
        window.MockFirebase.restore();
    })
// load the controller's module
  beforeEach(module('viewMultipleWallet', 'mockFirebaseFunctions'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var helpCtrl,
      scope,
      arr,
      $timeout,
      httpBackend,
      supportFormText,
      supportRequest,
      supportForm,
      log,
      q,
      deferred,
      FireSpy,
      firebase,
      rootScope,
      store,
      $window,
      faqRef,
      firebaseAuth,
      faqData,
      fbFnFactory,
      timeout,
      $rootScope,
      utils;

  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, $q, _$timeout_,  CONTENT_NET, _store_,  _firebaseFunctionsFactory_) {
    firebase = window.firebase;
    scope = $rootScope.$new();
    fbFnFactory = _firebaseFunctionsFactory_;

    firebase.apps = [];
    $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
    helpCtrl = $controller('helpCtrl', {
      $scope: scope
    });
    store = _store_;
    store.set('selectedLang', 'en_us');

    timeout = _$timeout_;

    faqData = {
                  "en_us": {
                    "-K0-gvWrQge4SbR3eVlx": {
                      "data": "english faq here"
                    }
                  },
                  "vi_vn": {
                    "-K0-gvWrQge4SbR3eVlx": {
                      "data": "VN faq here"
                    }
                  }
                };

  }));

    describe(' FAQ data test specs', function(){
        beforeEach(inject(function($controller, $rootScope, _$timeout_, $q){
            scope = $rootScope.$new();
            helpCtrl = $controller('helpCtrl', {
              $scope: scope
            });
        }));

        it(' :: should return FAQ data as a promise', function() {
            scope.faqRef = fbFnFactory.stubRef('faqs/' + scope.lang);

            scope.faqRef.on('value', function(snapshot){
                    scope.faq = snapshot.val();
                    expect(scope.faq).toBeDefined();
                    expect(scope.faq).toEqual(faqData);
            });
            scope.faqRef.fakeEvent('value', null, faqData);
            scope.loadFAQData();
            scope.faqRef.flush();
        });
    });

    describe('Support Add test specs', function(){
        beforeEach(inject(function($controller, $rootScope, $compile, _$timeout_, $q, _$log_, CONTENT_NET_AUTH){
            scope = $rootScope.$new();
            helpCtrl = $controller('helpCtrl', {
              $scope: scope
            });

            q = $q;
            scope.deferred = q.defer();

            $timeout = _$timeout_;

            supportFormText = '<form class="form__centered" name="supportForm" id="supportForm">'+
            '<input type="email" name="email" ng-model="supportRequest.email" ng-minlength=5 ng-maxlength=50 required>' + '<input type="text" name="name" ng-model="supportRequest.name" ng-minlength=2 ng-maxlength=50 required>' + '<textarea name="content" ng-model="supportRequest.content" ng-minlength=10 ng-maxlength=1000 required></textarea>' + '</form>'

            supportRequest = {'name': 'Shantanu Gautam', 'email': 'shan@matchmove.com', 'content': 'Sample support request here...'};

            $compile(supportFormText)(scope);
            scope.$digest();
            supportForm  = scope.supportForm;
        }));

        it(' :: support request addition add function', function(){
            var dateCreated = new Date().getTime();
            scope.supportRequest.dateCreated = dateCreated.toString();
            supportForm.email.$setViewValue(supportRequest.email);
            supportForm.name.$setViewValue(supportRequest.name);
            supportForm.content.$setViewValue(supportRequest.content);
            var user = {'isAnonymous': false, 'email': 'email@gmail.com'};

            scope.supportRef = fbFnFactory.stubRef('support');
            scope.auth = fbFnFactory.stubAuthRef();


            scope.auth.signInWithEmailAndPassword('nameabc', 'pwdefg').then(function(user){
                if(user){
                    scope.updates['/requests/-Kbi63G76piDzu6mSBjC'] = scope.supportRequest;
                    var spyUpd = spyOn(scope.supportRef, 'update').and.callThrough();
                    scope.supportRef.update($scope.updates)
                    .then(function(){
                        scope.feedbackSubmitted = true;
                        scope.isLoading = false;
                        expect(scope.feedbackSubmitted).not.toBeTruthy();
                    });
                    scope.supportRef.flush();
                }
            });
            scope.submitForm();
        });
        // it(' :: handle form submit error', function(){
        //     scope.supportRef = fbFnFactory.stubRef('support/requests');
        //     scope.support = firebaseArray(scope.supportRef);
        //     var spy = spyOn(scope, 'submitForm').and.callThrough();
        //     var spyAdd = spyOn(scope.support, '$add').and.callFake(function(){
        //         var deferred = q.defer();
        //         deferred.reject('Error while adding data');
        //         return deferred.promise;
        //       });
        //     // var spyLog = spyOn(log, 'log');
        //     scope.submitForm();
        //     fbFnFactory.flushAll(scope.supportRef);
        //     expect(scope.feedbackSubmitted).toBeFalsy();
        // });
    });


});
