/* global Firebase */
'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:helpCtrl
 * @description
 * # helpCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('helpCtrl', function($rootScope, $scope, ngDialog, store, CONTENT_NET, $window, $log, $q, TRANSLATION_PARAMS, CONTENT_NET_AUTH, $timeout ) {
        $scope.helpTabs = {
            active: 0
        };
        $scope.supportRequest = {};
        $scope.supportRequest.data = {};
        $scope.supportRequest.status = 'unread';
        $scope.feedbackSubmitted = false;
        // $scope.feedbackNotSubmitted = true;

        $scope.supportRequest.data.userAgent = $window.navigator.userAgent;
        $scope.contentNetAuth = angular.fromJson(CONTENT_NET_AUTH);
        if (firebase.apps.length === 0) {
            $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
        }

        if (store.get('user')) {
            $scope.userLogged = true;
            $scope.user = store.get('user');
            $scope.supportRequest.email = $scope.user.email;
            $scope.supportRequest.name = $scope.user.name.first + $scope.user.name.last;
        }

        $scope.submitForm = function() {
            $scope.deferred = $q.defer();

            $scope.supportRef = $rootScope.firebaseApp.database().ref('support');
            $scope.auth = $rootScope.firebaseApp.auth();

            var dateCreated = new Date().getTime();
            $scope.supportRequest.dateCreated = dateCreated.toString();
            $scope.isLoading = true;

            $scope.auth.signInWithEmailAndPassword($scope.contentNetAuth.uid, $scope.contentNetAuth.cred)
            .then(function(user){
                if (user) {
                    // update DB with new request data
                    // Get a key for a new Post.
                      $scope.newSupportKey = $scope.supportRef.child('requests').push().key;

                      // Write the new post's data simultaneously in the posts list and the user's post list.
                      $scope.updates = {};
                      $scope.updates['/requests/' + $scope.newSupportKey] = $scope.supportRequest;

                     $scope.supportRef.update($scope.updates)
                     .then(function() {
                            $timeout(function(){
                                $scope.feedbackSubmitted = true;
                                $scope.isLoading = false;
                            }, 1000);
                            $timeout(function() { ngDialog.closeAll(); }, 3800);
                        }, function(error) {
                            $timeout(function(){
                                $scope.feedbackSubmitted = false;
                                $scope.isLoading = false;
                            }, 1000);
                        });
                    $scope.auth.signOut();
                }
            },
            function(error){
                // authentication error
                $scope.feedbackSubmitted = false;
                $scope.isLoading = false;
                console.log('error logging in');
            });
        };

        $scope.loadFAQData = function() {
            $scope.lang = store.get('selectedLang');
            $scope.faqRef = $rootScope.firebaseApp.database().ref('faqs/' + $scope.lang);

            $scope.faqRef.on('value' , function(snapshot){
                    $scope.faq = snapshot.val();
            })
        }
        $scope.loadFAQData();
    });
