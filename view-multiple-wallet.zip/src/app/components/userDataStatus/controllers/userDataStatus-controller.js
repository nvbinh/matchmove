'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:userDataStatusCtrl
 * @description
 * # userDataStatusCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('userDataStatusCtrl', function ($rootScope, $scope, store, userAddressFactory, $q, $anchorScroll, $location, PubSub, $timeout, authDocumentFactory, userFactory, ngDialog, $log, KYC_UPLOAD_SETTINGS, helperFactory, CacheFactory, $translate, jsonPath) {
    /**
     * Make API/localStorage calls to get relevant data
     * 1. from store - auth  > get the email verified/mobile verified/ submitted-or-not
	 * 2. from cache - userCache:user > get user's Profile details
	 * 3. /users/authentications/document > get the KYC status
	 * 4. /users/addresses/residential > get the resi address
	 * 5. /users/addresses/billing > get the billing address
     */

    var hQ = [];
    $scope.isMobile = helperFactory.isMobile();
	$scope.configKYC = angular.fromJson(KYC_UPLOAD_SETTINGS);
    $scope.KycDataSeekPoints = $scope.configKYC.KYCDataSeekPoints;
    $scope.KycStates = $scope.configKYC.KYCProcessStates;
    $scope.kycSucces = false;
    $scope.kycPending = false;

    $scope.infoItemKey = [];

    $scope.verifyItems = jsonPath($scope.KycDataSeekPoints, '$..[?(@.switch=="ON" && @.langKey!=="KYC")]');

    function populateinfoItemKey(){
        angular.forEach($scope.KycDataSeekPoints, function(value, key){
            if (value.switch === 'ON'){
                $scope.infoItemKey.push('PAGES.WALLET_DETAILS_COMPLETE.KYC_DATA_SEEK_POINTS.'+ value.langKey);
            }
        })
    }
    populateinfoItemKey();

	$scope.auth = store.get('auth');
	var promises = [];
    if ( $scope.KycDataSeekPoints.addressInfo.switch == "ON" ) {
        promises.push( userAddressFactory.getAddress( 'residential', true ).then( function( response ) {
            if ( typeof response.data == 'object' && response.data !== null) {
                return true;
            } else {
                return false;
            }
        }, function( error ) {
            return false;
        } ) );
        promises.push( userAddressFactory.getAddress( 'billing', true ).then( function( response ) {
            if ( typeof response.data == 'object' && response.data !== null) {
                return true;
            } else {
                return false;
            }
        }, function( error ) {
            return false;
        } ) );
    }

	$scope.getUserData = function (){
        if (typeof CacheFactory.get('userCache').get('user') !== 'undefined') {
            $scope.cachedUser = CacheFactory.get('userCache').get('user');
            $scope.userData = $scope.cachedUser.data;
        } else {
            $scope.cachedUser = store.get('user');
            $scope.userData = $scope.cachedUser;
        }
	}
	$scope.getUserData();
	PubSub.subscribe('profile-updated', $scope.getUserData);
	PubSub.subscribe('address-updated', $scope.getUserData);
	PubSub.subscribe('email-verified', $scope.getUserData);
	PubSub.subscribe('mobile-verified', $scope.getUserData);
	PubSub.subscribe('kyc-submitted', $scope.getUserData);
	$scope.userDataStatus = [];
	$scope.profileComplete = typeof $scope.userData.identification === 'object';
	$scope.KycComplete = ($scope.auth.document_status == 'approved' ? true : ($scope.auth.document_status != 'approved' ? 'pending' : false));

	$q.all(promises).then(function(response){
		$scope.addresses = response;
		//console.log($scope.addresses);
        if($scope.KycDataSeekPoints.email.switch === 'ON'){
            $scope.userDataStatus.push({key: 'PAGES.WALLET_DETAILS_COMPLETE.KYC_DATA_SEEK_POINTS.EMAIL', value: $scope.auth.email_verified, dialogOpen: 'app/components/notifyEmailVerify/partials/notifyEmailVerify.html', dialogClass:'dialog-notification', dialogController:'notifyEmailVerifyCtrl'});
        }
		if($scope.KycDataSeekPoints.mobile.switch === 'ON'){
            $scope.userDataStatus.push({key: 'PAGES.WALLET_DETAILS_COMPLETE.KYC_DATA_SEEK_POINTS.MOBILE', value:$scope.auth.mobile_verified, dialogOpen: 'app/components/notifyMobileVerify/partials/notifyMobileVerify.html', dialogClass:'dialog-notification', dialogController:'notifyMobileVerifyCtrl'});
        }
		if($scope.KycDataSeekPoints.profile.switch === 'ON'){
            $scope.userDataStatus.push({key: 'PAGES.WALLET_DETAILS_COMPLETE.KYC_DATA_SEEK_POINTS.PROFILE', value: $scope.profileComplete, namedAnchor: 'personalForm', activeTab: 0, dest: 'wallet.details.my.complete'});
        }
        if($scope.KycDataSeekPoints.addressInfo.switch === 'ON'){
            $scope.userDataStatus.push({key: 'PAGES.WALLET_DETAILS_COMPLETE.KYC_DATA_SEEK_POINTS.ADDRESS_INFORMATION', value: $scope.addresses[0] , namedAnchor: 'addressForm', activeTab: 1, dest: 'wallet.details.my.complete'});
        }
		$scope.userDataStatus.push({key: 'PAGES.WALLET_DETAILS_COMPLETE.KYC_DATA_SEEK_POINTS.KYC', value: $scope.KycComplete, dialogOpen: $scope.getDialogVar($scope.userDataStatus, 'template'), dialogClass:'dialog-notification', dialogController:$scope.getDialogVar($scope.userDataStatus, 'controller')});
	})

    $scope.switchTabs = function(tabname){
        if(tabname == 'personalForm'){
            $scope.$parent.detailsTabs = {active: 0};
        }else if(tabname == 'addressForm'){
            $scope.$parent.detailsTabs = {active: 1};
        }
    };
    $scope.getDialogVar = function(userdata, type){
        $scope.numItemsToVerify = $scope.verifyItems.length;

        var retValue;
		$scope.notifyDoPending = false;
        switch ( type ) {
            case 'template':
                if ( $scope.numItemsToVerify === 4 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) &&
                        ( userdata[ 1 ].key == $scope.infoItemKey[ 1 ] && userdata[ 1 ].value == true ) &&
                        ( userdata[ 2 ].key == $scope.infoItemKey[ 2 ] && userdata[ 2 ].value == true ) &&
                        ( userdata[ 3 ].key == $scope.infoItemKey[ 3 ] && userdata[ 3 ].value == true ) ) {
                        retValue = 'app/components/doKyc/partials/doKyc.html';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                } else if ( $scope.numItemsToVerify === 3 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) &&
                        ( userdata[ 1 ].key == $scope.infoItemKey[ 1 ] && userdata[ 1 ].value == true ) &&
                        ( userdata[ 2 ].key == $scope.infoItemKey[ 2 ] && userdata[ 2 ].value == true ) ) {
                        retValue = 'app/components/doKyc/partials/doKyc.html';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                } else if ( $scope.numItemsToVerify === 2 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) &&
                        ( userdata[ 1 ].key == $scope.infoItemKey[ 1 ] && userdata[ 1 ].value == true ) ) {
                        retValue = 'app/components/doKyc/partials/doKyc.html';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                } else if ( $scope.numItemsToVerify === 1 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) ) {
                        retValue = 'app/components/doKyc/partials/doKyc.html';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                }else  {
                    retValue = 'app/components/doKyc/partials/doKyc.html';
                    //$scope.notifyDoPending = true;
                }
                break;
            case 'controller':
                if ( $scope.numItemsToVerify === 4 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) &&
                        ( userdata[ 1 ].key == $scope.infoItemKey[ 1 ] && userdata[ 1 ].value == true ) &&
                        ( userdata[ 2 ].key == $scope.infoItemKey[ 2 ] && userdata[ 2 ].value == true ) &&
                        ( userdata[ 3 ].key == $scope.infoItemKey[ 3 ] && userdata[ 3 ].value == true ) ) {
                        retValue = 'doKycCtrl';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                } else if ( $scope.numItemsToVerify === 3 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) &&
                        ( userdata[ 1 ].key == $scope.infoItemKey[ 1 ] && userdata[ 1 ].value == true ) &&
                        ( userdata[ 2 ].key == $scope.infoItemKey[ 2 ] && userdata[ 2 ].value == true ) ) {
                        retValue = 'doKycCtrl';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                } else if ( $scope.numItemsToVerify === 2 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) &&
                        ( userdata[ 1 ].key == $scope.infoItemKey[ 1 ] && userdata[ 1 ].value == true ) ) {
                        retValue = 'doKycCtrl';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                } else if ( $scope.numItemsToVerify === 1 ) {
                    if ( ( userdata[ 0 ].key == $scope.infoItemKey[ 0 ] && userdata[ 0 ].value == true ) ) {
                        retValue = 'doKycCtrl';
                    } else {
                        $scope.notifyDoPending = true;
                        retValue = '';
                    }
                }else {
                    retValue = 'doKycCtrl';
                    //$scope.notifyDoPending = true;
                }
                break;
        }
		return retValue;
	}

	$scope.completedParts = function(input){
		var partsCompleted = 0;
		angular.forEach(input, function(item){
			if(item.value == true){
				partsCompleted += 1;
			}
		})
		return (partsCompleted * (100/($scope.userDataStatus.length)));
	}
	$scope.gotoAnchor = function(x) {//console.log(x);
      var newHash = x;
      if ($location.hash() !== newHash) {
        // set the $location.hash to `newHash` and
        // $anchorScroll will automatically scroll to it
        $location.hash(x);
      } else {
        // call $anchorScroll() explicitly,
        // since $location.hash hasn't changed
        $anchorScroll();
      }
    };
	$scope.setActiveTab = function(activeTab){
		$scope.$parent.detailsTabs = {
            active: activeTab
        };
	}

    $scope.closeDialog = function(){
        ngDialog.closeAll();
    }

    // START: functions are moved here from wallet.verification.upload file
    // minor customizations: $scope.$parent.$parent.kycSucces, $scope.$parent.$parent.kycPending, $scope.$parent.$parent.doPreKyc added to communicate the status back to calling template
    function getKycStatus() {
        return authDocumentFactory.getStatus(true)
            .then(function (response) {
                // status – document submission status.
                // Value can be [not_submitted -> pending -> submitted, approved, rejected, ]
                $scope.kycStatus = response;
                if ($scope.kycStatus === 'approved') {
                    $scope.$parent.$parent.kycSucces = $scope.kycSucces = true;
                    $scope.sectionLoading = false;
                    showUploaderBlock();
                } else if ($scope.kycStatus === 'submitted' || $scope.kycStatus === 'f2f_approved' || $scope.kycStatus === 'f2f_request') {
                    $scope.$parent.$parent.kycPending = $scope.kycPending = true;
                    $scope.sectionLoading = false;
                    showUploaderBlock();
                } else {
                    $scope.doKyc = true;
                    $scope.sectionLoading = false;

                    $scope.doPreKycProfile = false;
                    $scope.$parent.$parent.doPreKyc = $scope.doPreKyc = false;
                    $scope.currentPreKyc = -1;
                    $scope.doPreKycVerification = false;
                    $scope.doEmailVerification = false;
                    $scope.doMobileVerification = false;
                    hQ.push(userFactory.isUserDetailsComplete()
                        .then(function (resp) {
                            if (resp.status === false) {
                                $scope.kycPending = false;
                                $scope.doPreKycProfile = true;
                                showUploaderBlock();
                            }
                        }));
                    $q.all(hQ)
                        .then(function (resp) {
                            if (!$scope.doPreKycProfile) {
                                $scope.kycPending = false;
                                userFactory.checkUserVerification()
                                    .then(function (resp) {
                                        if ($scope.KycDataSeekPoints.email.switch === 'ON' && resp.email_verified === false) { // jshint ignore:line
                                            $scope.doPreKycVerification = true;
                                            $scope.doEmailVerification = true;
                                            if ($scope.currentPreKyc === -1) {
                                                $scope.currentPreKyc = 1;
                                            }
                                        }
                                        if ($scope.KycDataSeekPoints.mobile.switch === 'ON' && resp.mobile_verified === false) { // jshint ignore:line
                                            $scope.doPreKycVerification = true;
                                            $scope.doMobileVerification = true;
                                            if ($scope.currentPreKyc === -1) {
                                                $scope.currentPreKyc = 2;
                                            }
                                        }
                                        //show uploader if verification is all met and done pre kyc profile
                                        $scope.$parent.$parent.doPreKyc = $scope.doPreKyc = ((($scope.doMobileVerification === true || $scope.doEmailVerification === true) || $scope.doPreKycProfile === true));
                                    });
                                showUploaderBlock();
                            } else {
                                //show uploader if verification is all met and done pre kyc profile and if kyc is already submitted or failed
                                $scope.$parent.$parent.doPreKyc = $scope.doPreKyc = ((($scope.doMobileVerification === true || $scope.doEmailVerification === true) || $scope.doPreKycProfile === true) && !$scope.kycPending);
                                showUploaderBlock();
                            }
                        });
                }
            }, function (response) {
                if (response.status === 500) {

                } else {

                }
                $scope.backendError = true;
                $scope.sectionLoading = false;
            });
        }
      function showUploaderBlock() {
        if ($scope.kycPending) {
	           $scope.$parent.$parent.showUploader = $scope.showUploader = false;
	        } else if ($scope.kycSucces) {
	            $scope.$parent.$parent.showUploader = $scope.showUploader = false;
	        } else {
	            $scope.$parent.$parent.showUploader = $scope.showUploader = true;
	        }
        }

      $scope.verifyEmail = function () {
            var template = 'app/components/notifyEmailVerify/partials/notifyEmailVerify.html',
                controller = 'notifyEmailVerifyCtrl';
            notificationDialog(template, controller);
        };

        $scope.verifyMobile = function () {
            var template = 'app/components/notifyMobileVerify/partials/notifyMobileVerify.html',
                controller = 'notifyMobileVerifyCtrl';
            notificationDialog(template, controller);
        };

      function notificationDialog(template, controller) {
            ngDialog.open({
                template: template,
                className: 'dialog-notification',
                controller: controller,
                scope: $scope,
                showClose: false
            });
        }
    // END:: functions moved from wallet.verifcations.upload

    // run this code only if the state is wallet.verification.upload
    if($scope.state == 'wallet.verification.upload'){
        getKycStatus();
    }
  });
