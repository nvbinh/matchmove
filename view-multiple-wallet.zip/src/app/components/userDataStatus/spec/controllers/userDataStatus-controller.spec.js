'use strict';
describe('Controller: userDataStatusCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  // mock config constants
  beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  var userDataStatusCtrl,
      scope,
      authDocumentFactory,
      ngDialog,
      httpBackend,
      API_BASE,
      cache,
      userCache,
      userCacheSpy,
      userData,
      user,
      deferred,
      addressData,
      helper;

   // langugage based mock calls
   beforeEach(inject(function($httpBackend, TRANSLATION_PROVIDER, TRANSLATION_PARAMS ){
      httpBackend = $httpBackend;
      var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
      for ( var i = 0; i < lngth; i++ ) {
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      }
   }));
   beforeEach(inject(function( _CacheFactory_, store){
    userData = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            },
            {
              "rel": "addresses.residential",
              "href": API_BASE + "users/addresses/residential",
              "method": "GET"
            },
            {
              "rel": "addresses.billing",
              "href": API_BASE + "users/addresses/billing",
              "method": "GET"
            }
          ],
          "authentications": {
            "email_verified": true,
            "mobile_verified": true
          }
      };
      cache = _CacheFactory_;
      userCacheSpy = spyOn(cache, 'get').and.callThrough();

      userCache = cache.get('userCache');
      userCache.put('user', {data:userData});

      store.set('auth', {"email_verified":true,"mobile_verified":true,"document_status":"submitted"});
   }));
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, _authDocumentFactory_, _$httpBackend_, API_BASE, _ngDialog_, _userFactory_, _helperFactory_, KYC_UPLOAD_SETTINGS) {
    scope = $rootScope.$new();
    authDocumentFactory = _authDocumentFactory_;
    API_BASE = API_BASE;
    ngDialog = _ngDialog_;
    httpBackend = _$httpBackend_;
    user = _userFactory_;
    helper = _helperFactory_;
    addressData = {
      "address_1": "line 11",
      "address_2": "line 22",
      "city": "Singapore",
      "country": "Singapore",
      "state": "Singapore",
      "zipcode": "333333"
    };

    scope.state = 'wallet.verification.upload';
    // scope.cachedUser = {};
    // scope.cachedUser.data = userData;
    userDataStatusCtrl = $controller('userDataStatusCtrl', {
      $scope: scope
    });
    spyOn( authDocumentFactory, 'getStatus' ).and.callThrough();
    spyOn( user, 'isUserDetailsComplete').and.callThrough();
    spyOn(helper, 'isMobile').and.callThrough();
    httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, addressData);
      httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, addressData);
      httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, {
                status: 'approved'
            }, {}, 'HTTP/1.1 200 OK' );
      httpBackend.flush();
  }));
  afterEach(function(){
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

  // describe( ' case kycStatus = approved', function () {
  //       it( 'kycStatus = approved',  function ( ) {
  //           expect( scope.kycSucces ).toBe( true );
  //           //expect( scope.sectionLoading ).toBe( false );
  //           expect( scope.kycPending ).toBe( false );
  //           //expect( scope.showUploader ).toBe( false );
  //       } );
  //   } );

  //   describe( ' case kycStatus = submitted', function () {
  //       it( 'kycStatus = submitted', inject( function ( API_BASE ) {
  //           httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, {
  //               status: 'submitted'
  //           } );
  //           spyOn( authDocumentFactory, 'getStatus' ).and.callThrough();
  //           httpBackend.flush();
  //           expect( scope.kycSucces ).toBe( false );
  //           expect( scope.sectionLoading ).toBe( false );
  //           expect( scope.kycPending ).toBe( true );
  //           expect( scope.showUploader ).toBe( false );
  //       } ) );
  //   } );

  //   describe( ' case kycStatus = f2f_approved', function () {
  //       it( 'kycStatus = f2f_approved', inject( function ( API_BASE ) {
  //           httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 200, {
  //               status: 'f2f_approved'
  //           } );
  //           spyOn( authDocumentFactory, 'getStatus' ).and.callThrough();
  //           httpBackend.flush();
  //           expect( scope.kycSucces ).toBe( false );
  //           expect( scope.sectionLoading ).toBe( false );
  //           expect( scope.kycPending ).toBe( true );
  //           expect( scope.showUploader ).toBe( false );
  //       } ) );
  //   } );

  //   describe( ' case 500', function () {
  //       it( 'Error 500', inject( function ( API_BASE ) {
  //           httpBackend.whenGET( API_BASE + 'users/authentications/documents' ).respond( 500 );
  //           spyOn( authDocumentFactory, 'getStatus' ).and.callThrough();
  //           httpBackend.flush();
  //           expect( scope.backendError ).toBe( true );
  //           expect( scope.sectionLoading ).toBe( false );
  //       } ) );
  //   } );
});
