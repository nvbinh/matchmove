'use strict';
describe('Directive: userDataStatus', function () {
// load the directive's module
  beforeEach(module('viewMultipleWallet'));
  var element,
    scope,
    cache,
    store,
    userData,
    userCache,
    httpBackend,
    API_BASE;
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function( $provide ) {
    $provide.constant( "TRANSLATION_PARAMS", {
      "partFilesPath": "../assets/locales/",
      "preferredLanguage": "vi_vn",
      "client": "hdb",
      "source": "http://localhost:3000/assets/hdb/locales\/",
      "supportedLanguages": [ {
        "i18n": "en_us",
        "name": "English"
      }, {
        "i18n": "vi_vn",
        "name": "Vietnamese"
      } ]
    } );
  }));
  // langugage based mock calls
   beforeEach(inject(function($httpBackend, TRANSLATION_PARAMS ){
      httpBackend = $httpBackend;
      var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
      for ( var i = 0; i < lngth; i++ ) {
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      }
   }));
  beforeEach(inject(function ($rootScope, $compile, _CacheFactory_, _store_, _API_BASE_) {
    scope = $rootScope.$new();
    userData = {
          "id": "7e44d2be136976e9fe15377e654dff63",
          "email": "balaji_b_v@yahoo.com",
          "name": {
            "first": "Balaji",
            "last": "V",
            "preferred": "Balaji"
          },
          "mobile": {
            "country_code": "65",
            "number": "12345675"
          },
          "countryofissue": "India",
          "identification": {
            "type": "passport",
            "number": "ABCDEFGH"
          },
          "birthday": "1998-01-05",
          "gender": "male",
          "title": "Mr",
          "status": {
            "is_active": true,
            "text": "active"
          },
          "authentications": {
            "email_verified": true,
            "mobile_verified": false
          },
          "links": [
            {
              "rel": "users.wallets",
              "href": API_BASE + "users/wallets",
              "method": "GET"
            },
            {
              "rel": "addresses.residential",
              "href": API_BASE + "users/addresses/residential",
              "method": "GET"
            },
            {
              "rel": "addresses.billing",
              "href": API_BASE + "users/addresses/billing",
              "method": "GET"
            }
          ]
        };

    store = _store_;
    store.set('auth', {"email_verified":true,"mobile_verified":true,"document_status":"not_submitted"});
    API_BASE = _API_BASE_;
    httpBackend.whenGET(API_BASE + 'users').respond(200, userData);
    httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, {});
    httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, {});
    httpBackend.whenGET(API_BASE + 'users/authentications/documents').respond(200, {});

    cache = _CacheFactory_;
    userCache = cache.get('userCache');
    userCache.put('user', userData);
    spyOn(userCache, 'get').and.callFake(function(){
      return {data: userData};
    });
    scope.userData = userData;
    scope.state = 'wallet.verification.upload';
    element = angular.element('<user-data-status message-heading="{{messageHeading}}" message-text="{{messageText}}" state="{{state}}"></user-data-status>');
    $compile(element)(scope);
    scope.$digest();
    httpBackend.flush();
  }));
  afterEach(function(){
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('directive scope is intialized', function(){    
  	expect(scope.userData).toBeDefined();
    expect(scope.userData.identification).toBeDefined();
  });
});
