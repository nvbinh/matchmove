'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:userDataStatus
 * @description
 * # userDataStatus
 */
angular.module( 'viewMultipleWallet' )
  .directive( 'userDataStatus', function() {
    return {
      templateUrl: 'app/components/userDataStatus/partials/userDataStatus.html',
      restrict: 'E',
      controller: 'userDataStatusCtrl',
      scope: {
        messageHeading: '@',
        messageText: '@',
        state: '@'
      }
    };
  } );