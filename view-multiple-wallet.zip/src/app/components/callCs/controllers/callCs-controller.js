'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:callCsCtrl
 * @description
 * # callCsCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
  .controller('callCsCtrl', function ($scope, CONTACT_DETAILS) {
    var configObj = angular.fromJson(CONTACT_DETAILS);
    if (configObj) {
    	$scope.tollFree = configObj.tollFree;
    	$scope.internationalCalling = configObj.internationalCalling;
    	$scope.eMail = configObj.eMail;
    }
  });
