'use strict';
describe('Controller: callCsCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var callCsCtrl,
      scope;
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    callCsCtrl = $controller('callCsCtrl', {
      $scope: scope,
      CONTACT_DETAILS: {'tollFree': 1, 'internationalCalling': 2, 'eMail': 3}
    });
  }));
  it('the settings defined', function () {
    expect(scope.tollFree).toBe(1);
  });
});
