'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:callCs
 * @description
 * # callCs
 */
angular.module('viewMultipleWallet')
  .directive('callCs', function () {
    return {
      templateUrl: 'app/components/callCs/partials/callCs.partial.html',
      scope: {
        mainMessage: '=',
        subMessage: '='
      },
      restrict: 'E',
      replace: true,
      controller: 'callCsCtrl',
      link: function() {

      }
    };
  });
