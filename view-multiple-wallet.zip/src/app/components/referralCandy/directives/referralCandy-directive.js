'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:doKyc
 * @description
 * # doKyc
 */
angular.module('viewMultipleWallet')
    .directive('referralCandy', function () {
        return {
            templateUrl: 'app/components/referralCandy/partials/referralCandy.html',
            restrict: 'A',
            controller: 'referralCandyCtrl',
            transclude: true,
            replace: true,
            link: function (scope, element, attrs) {

            }
        };
    });
