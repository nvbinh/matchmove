// 'use strict';
// describe('Directive: doKyc', function () {
// // load the directive's module
//   beforeEach(module('viewMultipleWallet'));
//   var element,
//     scope,
//     scopeElem,
//     httpBackend;
//   beforeEach(inject(function ($rootScope, $compile, TRANSLATION_PROVIDER, $httpBackend) {
//     scope = $rootScope.$new();
//     httpBackend = $httpBackend;
//     scopeElem = angular.element('<section class="page page-cardnew" do-kyc  enable title="KYC Title" message="KYC.MESSAGE" img="https://vcard-assets.s3.amazonaws.com/sg/assets/multi-card-sg/img/kyc-verifypls.png"></section>');
//
//     httpBackend.whenGET(TRANSLATION_PROVIDER + '?lang=enUS').respond(200, '');
//     $compile(scopeElem)(scope);
//     scope.$digest();
//   }));
//
// });
