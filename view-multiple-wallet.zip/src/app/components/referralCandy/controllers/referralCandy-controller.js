'use strict';

angular.module('viewMultipleWallet')
    .controller('referralCandyCtrl', function (REFERRAL_CANDY_PARAMS, store, md5, $scope) {
        var configObj = JSON.parse(REFERRAL_CANDY_PARAMS);
        if (configObj) {
            $scope.referralCandyConfigLoaded = true;
            $scope.referralCandyConfig = configObj;
        } else {
            $scope.referralCandyConfigLoaded = false;
        }
        if ($scope.referralCandyConfigLoaded && $scope.referralCandyConfig.enabled) {
            $scope.timestamp = Math.floor(Date.now() / 1000);
            $scope.fname = store.get('user')
                .name.first;
            $scope.lname = store.get('user')
                .name.last;
            $scope.email = store.get('user')
                .email;
            $scope.appId = $scope.referralCandyConfig.appId;
            $scope.currency = $scope.referralCandyConfig.referalCurrency;
            $scope.amount = $scope.referralCandyConfig.referalAmount;
            $scope.externalReferenceId = 'WEB-' + Math.floor(Date.now() / 1000);
            $scope.secret = $scope.referralCandyConfig.secret;
            $scope.signature = md5.createHash($scope.email + ',' + $scope.fname + ',' + $scope.amount + ',' + $scope.timestamp + ',' + $scope.secret);
        }
    });
