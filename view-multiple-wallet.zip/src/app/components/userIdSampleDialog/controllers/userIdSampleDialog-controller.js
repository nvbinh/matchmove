
'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:userIdSampleDialogCtrl
 * @description
 * # userIdSampleDialogCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('userIdSampleDialogCtrl', function ($scope, ngDialog, store, userFactory, $log, TRANSLATION_PARAMS, $timeout, KYC_UPLOAD_SETTINGS) {

        $scope.allowedIds = angular.fromJson(KYC_UPLOAD_SETTINGS);
        $scope.allowedIds = $scope.allowedIds.allowedIdType;
        $scope.allowedIds = $scope.allowedIds[0];
        $scope.sectionLoading = true;
        // Get the ID samples
        $scope.idSamplesRef;
        $scope.lang = store.get('selectedLang');
        $scope.idSamples = [];
        angular.forEach($scope.allowedIds, function(value, key){
            $scope.sectionLoading = true;
            $scope.idSamplesRef = firebase.database().ref('guides/id_samples/' + key + '/' + $scope.lang);
            $scope.idSamplesRef.on('value', function(snapshot){
                $timeout(function() {
                    $scope.idSamples.push(snapshot.val());
                }, 10);
                $scope.sectionLoading = false;
                $scope.modalContent = true;
            });
        })
    });
