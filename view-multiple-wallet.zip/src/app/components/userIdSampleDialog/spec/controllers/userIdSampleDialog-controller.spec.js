'use strict';
describe('Controller: userIdSampleDialogCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
    // load the controller's module
    beforeEach(module('viewMultipleWallet', 'mockFirebaseFunctions'));
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("KYC_UPLOAD_SETTINGS", {
              "allowedIdType": [
                {
                  "cmnd": "PAGES.WALLET_DETAILS.ID_TYPE_TEXT.CMND",
                  "passport": "PAGES.WALLET_DETAILS.ID_TYPE_TEXT.PASSPORT"
                }
              ]
            })
    } ) );
    var userIdSampleDialogCtrl,
        scope,
        httpBackend,
        idSampleData,
        $timeout,
        fbFnFactory,
        store,
        KYC_UPLOAD_SETTINGS;
        // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach(inject(function($controller, $rootScope, _$timeout_, _firebaseFunctionsFactory_, _store_, _KYC_UPLOAD_SETTINGS_) {
        scope = $rootScope.$new();
        store = _store_;
        fbFnFactory = _firebaseFunctionsFactory_;
        firebase.apps = [];
        $timeout = _$timeout_;
        KYC_UPLOAD_SETTINGS = _KYC_UPLOAD_SETTINGS_;
        userIdSampleDialogCtrl = $controller('userIdSampleDialogCtrl', {
            $scope: scope
        });
        store.set('selectedLang', 'en_us');
    }));
    afterEach( function() {
        httpBackend.flush();
          httpBackend.verifyNoOutstandingExpectation();
          httpBackend.verifyNoOutstandingRequest();
        } );

    describe(' get idSample data ', function(){
        it(' :: should return idSampleData data as a promise', function() {
            angular.forEach(scope.allowedIds, function(value, key){
                scope.idSamplesRef = firebase.database().ref('guides/id_samples/' + key + '/' + scope.lang);
                scope.idSamplesRef.on('value', function(snapshot){
                    $timeout(function() {
                        scope.idSamples.push(snapshot.val());
                    }, 10);
                    $timeout.flush(10);
                    expect(scope.sectionLoading).toBeTruthy();
                });
        })
            scope.idSamplesRef.fakeEvent('value', null, idSampleData);
            fbFnFactory.flushAll(scope.idSamplesRef);
        });
    });
});
