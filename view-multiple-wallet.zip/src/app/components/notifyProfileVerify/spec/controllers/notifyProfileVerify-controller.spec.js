'use strict';
describe('Controller: notifyProfileVerifyCtrl', function() {
    // load the controller's module
    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach(module('viewMultipleWallet', function($provide) {
        $provide.constant("TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [{
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            }]
        });
    }));
    // langugage based mock calls
    beforeEach(inject(function($httpBackend, TRANSLATION_PARAMS) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson(TRANSLATION_PARAMS).supportedLanguages.length;
        for (var i = 0; i < lngth; i++) {
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'common/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'login/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'modal/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
        }
    }));
    var notifyProfileVerifyCtrl,
        scope,
        state,
        httpBackend;
    // Initialize the controller and a mock scope
    beforeEach(inject(function($controller, $rootScope, _$state_) {
        scope = $rootScope.$new();
        state = _$state_;
        notifyProfileVerifyCtrl = $controller('notifyProfileVerifyCtrl', {
            $scope: scope
        });
        spyOn(state, 'go').and.callThrough();
    }));
    it('should invoke state change', function() {
        scope.goToProfile();
        expect(state.go).toHaveBeenCalled();
    });
});
