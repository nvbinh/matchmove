'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:notifyProfileVerifyCtrl
 * @description
 * # notifyProfileVerifyCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('notifyProfileVerifyCtrl', function($scope, $state) {
        $scope.goToProfile = function() {
            $state.go('wallet.details.my.complete', { activeTab: 'personalForm' }, {});
        }
    });
