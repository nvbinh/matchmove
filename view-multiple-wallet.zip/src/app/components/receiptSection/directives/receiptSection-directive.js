'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:receipt
 * @description
 * # receipt
 */
angular.module('viewMultipleWallet')
    .directive('receiptSection', function (BASE_CURRENCY, $rootScope) {
        return {
            templateUrl: 'app/components/receiptSection/partials/receiptSection.html',
            restrict: 'E',
            scope: {
                value: '=topupAmount',
                provider: '=?provider',
                fees: '=providerFee',
                vatFee: '=vatFee',
                total: '=totalAmount',
                refId: '=?refId',
                paymentRefId: '=?paymentRefId',
                date: '=?transactionDate',
                showRef: '=?showRef'
            },
            link: function(scope) {
                scope.baseCurrency = BASE_CURRENCY;
                scope.showRef = scope.showRef ? false : true;
                if (typeof $rootScope.transfer !== 'undefined') {
                    scope.paymentRefId = $rootScope.transfer.paymentRefId;
                    scope.date = $rootScope.transfer.transactionDate;
                }
            }
        };
    });
