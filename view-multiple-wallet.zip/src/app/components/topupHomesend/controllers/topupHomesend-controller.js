'use strict';

angular.module( 'viewMultipleWallet' )
    .controller( 'topupHomesendCtrl', function ( $rootScope, CONTENT_NET, store, $scope,  $timeout, PubSub ) {
        $scope.provider = 'HomeSend';

        $scope.orderField = 'order';
        $scope.ibankingHasData = false;
        $scope.loadIBankingData = function () {
            if (firebase.apps.length === 0) {
              $rootScope.firebaseApp = firebase.initializeApp(angular.fromJson(CONTENT_NET));
            }
            $scope.lang = store.get('selectedLang');
            $scope.ibankingRef = $rootScope.firebaseApp.database().ref( 'guides/payments/'+angular.lowercase($scope.provider)+ '/' + $scope.lang );

            $scope.ibankingRef.on('value', function(snapshot){
                $scope.ibankingdata = [];
                $timeout(function(){
                    $scope.ibankingHasData = true;
                    $scope.ibankObj = snapshot.val();
                    angular.forEach($scope.ibankObj, function(value, key){
                        $scope.ibankingdata.push(value);
                      });
                }, 100)
            });
        };
        $scope.loadIBankingData();
        PubSub.subscribe('language-changed', $scope.loadIBankingData);
    } );
