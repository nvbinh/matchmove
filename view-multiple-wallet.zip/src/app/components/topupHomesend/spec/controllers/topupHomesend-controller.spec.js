'use strict';
describe( 'Controller: topupHomesendCtrl', function() {
    beforeEach(function(){
        window.MockFirebase.override();
    });
    afterEach(function(){
        window.MockFirebase.restore();
    });
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet', 'mockFirebaseFunctions' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var topupHomesendCtrl,
        scope,
        httpBackend,
        homesendData,
        $timeout,
        fbFnFactory,
        store;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize controller
    beforeEach( inject( function( $controller, $rootScope, _$timeout_, _firebaseFunctionsFactory_, _store_ ) {
        scope = $rootScope.$new();
        store = _store_;
        fbFnFactory = _firebaseFunctionsFactory_;
        firebase.apps = [];
        $timeout = _$timeout_;
        topupHomesendCtrl = $controller( 'topupHomesendCtrl', {
            $scope: scope
        } );
        store.set('selectedLang', 'en_us');
        scope.provider = 'HomeSend';
        homesendData = {
          "homesend": {
                "en_us": {
                  "-KKEoQd_zZpA0F6U67zB": {
                    "description": "<h1>1</h1><p>Select “More Services”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                    "order": "0"
                  },
                  "-KKEojQWx5U5Jxnvopcp": {
                    "description": "<h1>2</h1><p>Select “Bill Payments”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/ibanking/step-02.png",
                    "order": "1"
                  }
                },
                "vi_vn": {
                  "-KKEoQd_zZpA0F6U67zC": {
                    "description": "<h1>1</h1><p>VN- Select “More Services”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/atm/step-01.png",
                    "order": "0"
                  },
                  "-KKEojQWx5U5Jxnvopcq": {
                    "description": "<h1>2</h1><p>VN - Select “Bill Payments”.</p>",
                    "image": "https://vcard-sg-assets.s3.amazonaws.com/application-assets/modules/posb/ibanking/step-02.png",
                    "order": "1"
                  }
                }
            }
        };
    } ) );

    describe(' get Homesend data ', function(){
        it(' :: should return homesend data as a promise', function() {
            scope.ibankingRef = fbFnFactory.stubRef('guides/payments/'+ angular.lowercase(scope.provider)+ '/' + scope.lang );
            scope.ibankingRef.on('value', function(snapshot){
                scope.homesendData = [];
                $timeout(function(){
                    scope.ibankingHasData = true;
                    scope.ibankObj = snapshot.val();
                    angular.forEach(scope.ibankObj, function(value, key){
                        scope.homesendData.push(value);
                        expect(scope.homesendData).toBeDefined();
                        expect(scope.homesendData).toEqual(homesendData.homesend.en_us);
                    });
                }, 10);
            });
            scope.ibankingRef.fakeEvent('value', null, homesendData.homesend.en_us);
            scope.loadIBankingData();
            // scope.atmRef.flush();
            fbFnFactory.flushAll(scope.ibankingRef);
        });
    });
} );
