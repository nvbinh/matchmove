'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:doKyc
 * @description
 * # doKyc
 */
angular.module( 'viewMultipleWallet' )
    .directive( 'topupHomesend', function () {
        return {
            templateUrl: 'app/components/topupHomesend/partials/topupHomesend.html',
            restrict: 'A',
            controller: 'topupHomesendCtrl',
            transclude: true,
            replace: true,
            link: function ( scope, element, attrs ) {

            }
        };
    } );
