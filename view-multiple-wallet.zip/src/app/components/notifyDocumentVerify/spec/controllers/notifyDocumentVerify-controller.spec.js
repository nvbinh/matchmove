/* global inject */
/* global expect */
/* global it */
/* global beforeEach */
/* global describe */

'use strict';
describe('Controller: notifyDocumentVerifyCtrl', function () {
// load the controller's module
  beforeEach(module('viewMultipleWallet'));
  var notifyDocumentVerifyCtrl,
      _ngDialog,
      state,
      scope;
// Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope, ngDialog, $state) {
    scope = $rootScope.$new();
    _ngDialog = ngDialog;
    state = $state;
    notifyDocumentVerifyCtrl = $controller('notifyDocumentVerifyCtrl', {
      $scope: scope
    });
  }));
  it('should close all ngDialog', function(){
      spyOn(_ngDialog, 'closeAll');
      spyOn(state, 'go').and.callThrough();
      scope.redirectVerification();
      expect(_ngDialog.closeAll).toHaveBeenCalled();
      expect(state.go).toHaveBeenCalledWith('wallet.verification.upload');
  });
});
