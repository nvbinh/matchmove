'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:notifyDocumentVerifyCtrl
 * @description
 * # notifyDocumentVerifyCtrl
 * Controller of the viewMultipleWallet
 */
angular.module('viewMultipleWallet')
    .controller('notifyDocumentVerifyCtrl', function ($scope, $log, $state, ngDialog) {
        $scope.redirectVerification = function() {
            ngDialog.closeAll();
            $state.go('wallet.verification.upload');
        };
    });
