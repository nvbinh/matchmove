'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:emptyField
 * @description
 * # emptyField
 */
angular.module('viewMultipleWallet')
  .directive('emptyField', function () {
    return {      
      restrict: 'A',
      require: 'ngModel',
      link: function(scope, element, attrs, controller) {
          var labelElem = element.parent('span').parent('div').parent('li').children();
          labelElem = labelElem[0];
          var radioElem = angular.element(labelElem).children();
          function noChars(ngModelValue){
              if(radioElem.attr('checked') === 'checked' ){
                 if (ngModelValue === null || element.val() === '' ) {
                    controller.$setValidity('fieldEmpty', false);
                  } else {
                    controller.$setValidity('fieldEmpty', true);
                  } 
              }else{
                  controller.$setValidity('fieldEmpty', true);
              }         
              return ngModelValue;
          }
          controller.$parsers.push(noChars);
      }
    };
  });
