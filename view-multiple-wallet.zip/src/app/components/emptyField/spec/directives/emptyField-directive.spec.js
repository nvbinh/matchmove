'use strict';
describe( 'Directive: emptyField :: custom Amount Field selected', function () {
    // load the directive's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( "PAYMENT_DETAILS", [ {
            "name": "Easypay2",
            "providerType": "online",
            "feesFlat": 0,
            "feesPercent": 2.5,
            "topupDuration": "Instant",
            "minimumAmt": 10,
            "maximumAmt": 999,
            "rates": [ 10, 50, 100, 250 ],
            "consumerKey": "5q1bwe"
        }, {
            "name": "DBS",
            "providerType": "offline",
            "feesFlat": 0.9,
            "feesPercent": 0,
            "topupDuration": "2-3 days",
            "minimumAmt": 10,
            "maximumAmt": 999
        } ] );
    } ) );
    var element,
        scope,
        topupForm,
        httpBackend,
        PAYMENT_DETAILS,
        timeout;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize directive scope
    beforeEach( inject( function ( $rootScope, $compile, BASE_CURRENCY, PAYMENT_ASSETS, _PAYMENT_DETAILS_, $filter, $timeout ) {
        PAYMENT_DETAILS = _PAYMENT_DETAILS_;
        scope = $rootScope.$new();
        timeout = $timeout;
        
        scope.isDisabled = true;
        scope.hasCustomAmount = false;
        scope.hasAmount = true;
        scope.providerDetails = {};
        scope.baseCurrency = BASE_CURRENCY;
        scope.paymentAssets = PAYMENT_ASSETS;
        scope.currentProviderName = 'Easypay2';
        scope.providerDetails = angular.fromJson( PAYMENT_DETAILS );
        scope.currentProvider = $filter( 'filter' )( scope.providerDetails, {
            name: scope.currentProviderName
        } );
        scope.rates = scope.currentProvider[ 0 ].rates;
        scope.feePercent = scope.currentProvider[ 0 ].feesPercent;
        scope.minimumAmt = scope.currentProvider[ 0 ].minimumAmt;
        scope.maximumAmt = scope.currentProvider[ 0 ].maximumAmt;
        scope.consumerKey = scope.currentProvider[ 0 ].consumerKey;

        if ( scope.currentProvider[ 0 ].rates ) {
            scope.currentAmount = parseInt( scope.currentProvider[ 0 ].rates[ 0 ] );
        }

        scope.forms = {};
        scope.rates = [ 10, 50, 100, 250 ];
        element = angular.element( '<form name="forms.topupEnter" class="" ng-if="currentProviderName === \'Easypay2\'" novalidate>' +
            '<ul class="content-rates">' +
            '<li class="rate-block" ng-repeat="rate in rates">' +
            '<label for="amount-{{rate}}">' +
            '<input type="radio" id="amount-{{rate}}" ng-change="newValue(\'radio-rate\', $parent.currentAmount)" ng-model="$parent.currentAmount" value={{rate}} name="currentAmount" data-index="{{$index}}" ng-click="disableCustom();" ng-focus="clearCustomAmount();">' +
            '<p class="value">' +
            '<span class="value-currency">{{baseCurrency}}</span>' +
            '<span class="value-amount">{{rate}}</span>' +
            '</p>' +
            '</label>' +
            '</li>' +
            '<li class="rate-block--fullwidth">' +
            '<label for="amount-custom">' +
            '<input type="radio" id="amount-custom" ng-change="newValue(\'radio-custom\', $parent.currentAmount)" ng-model="$parent.currentAmount" name="currentAmount" data-index="4" ng-click="enableCustom();"  checked="checked">' +
            '</label>' +
            '<div class="custom-wrapper">' +
            '<span class="custom-description">{{ \'PAGES.WALLET_TOPUP_ENTER.CUSTOM_AMOUNT_TEXT\' | translate }}</span>' +
            '<span class="wrap-text-input" ng-click="disableRates();enableCustom()">' +
            '<span class="value-currency">{{baseCurrency}}</span>' +
            '<input id="amount-custom-text" name="customAmount" type="number" class=\'value\' ng-disabled="isDisabled" ng-model=\'customAmount\' novalidate ng-change=\'newValue("textbox", customAmount)\' min="{{minimumAmt}}" max="{{maximumAmt}}" ng-pattern="/[0-9]*/" empty-field>' +
            '</span>' +
            '</div>' +
            '</li>' +
            '</ul>' +
            '</form>' );

        scope.disableRates = function () {
            var radioElem10 = angular.element( element ).find( '#amount-10' );
            radioElem10.removeAttr( 'checked' );
            var radioElem50 = angular.element( element ).find( '#amount-50' );
            radioElem50.removeAttr( 'checked' );
            var radioElem100 = angular.element( element ).find( '#amount-100' );
            radioElem100.removeAttr( 'checked' );
            var radioElem250 = angular.element( element ).find( '#amount-250' );
            radioElem250.removeAttr( 'checked' );
        };
        scope.disableCustom = function () {
            var elem = angular.element( element ).find( '#amount-custom-text' );
            elem.attr( 'disabled', true );
            var radioelem = angular.element( element ).find( '#amount-custom' );
            radioelem.removeAttr( 'checked' );
            radioelem.removeClass( 'ng-touched' ).addClass( 'ng-untouched' );
        };
        scope.clearCustomAmount = function () {
            scope.forms.topupEnter.customAmount.$setViewValue( '' );
            scope.forms.topupEnter.customAmount.$render();
            scope.forms.topupEnter.customAmount.$dirty = false;
            scope.forms.topupEnter.customAmount.$pristine = true;
            scope.forms.topupEnter.customAmount.$setPristine();
        }
        scope.newValue = function ( type, value ) {
            if ( typeof value === 'undefined' || type === 'textbox' || type === 'radio-custom' ) {
                scope.isDisabled = false;
                scope.hasCustomAmount = true;
                scope.hasAmount = false;
                scope.disableRates();
                scope.enableCustom();
            } else if ( typeof value === 'undefined' || type === 'radio-rate' ) {
                scope.isDisabled = true;
                scope.hasCustomAmount = false;
                scope.hasAmount = true;
                scope.disableCustom();
            }
        }
        scope.enableCustom = function () {
            var customRadioElem = angular.element( element ).find( '#amount-custom' );
            //customRadioElem.parent().trigger('click');
            customRadioElem.trigger( 'click' );
            var elem = angular.element( element ).find( '#amount-custom-text' );
            elem.attr( 'disabled', false );
            elem.removeAttr( 'disabled' );
            elem.focus();
        };
        $compile( element )( scope );
        scope.$digest();
        topupForm = scope.forms.topupEnter;
    } ) );

    it( ' :: forms.topupForm form is defined', function () {
        expect( scope.currentAmount ).toEqual( 10 );
    } );

    it( ' :: custom rate is input a valid value', function () {
        var spyDisable = spyOn( scope, 'disableRates' ).and.callThrough();
        var spyEnable = spyOn( scope, 'enableCustom' ).and.callThrough();
        expect( topupForm.customAmount.$pristine ).toBeTruthy();

        scope.enableCustom();
        scope.customAmount = 100;
        scope.$digest();
        topupForm.customAmount.$setViewValue( 100 );
        topupForm.customAmount.$render();

        expect( topupForm.customAmount.$pristine ).toBeFalsy();
        expect( topupForm.customAmount.$dirty ).toBeTruthy();
        expect( topupForm.customAmount.$error.fieldEmpty ).toBeFalsy();
    } );
    it( ' :: Flag error when custom rate is empty', function () {
        var spyDisable = spyOn( scope, 'disableRates' ).and.callThrough();
        var spyEnable = spyOn( scope, 'enableCustom' ).and.callThrough();
        expect( topupForm.customAmount.$pristine ).toBeTruthy();
        //scope.isDisabled = false;
        scope.disableRates();
        scope.disableCustom();
        scope.enableCustom();
        topupForm.customAmount.$setViewValue( 100 );
        topupForm.customAmount.$render();
        scope.customAmount = '';
        topupForm.customAmount.$setViewValue( '' );
        topupForm.customAmount.$render();
        scope.$digest();
        expect( topupForm.customAmount.$error.fieldEmpty ).toBeTruthy();
        expect( spyDisable ).toHaveBeenCalled();
        expect( spyEnable ).toHaveBeenCalled();
    } );

} );

describe( 'Directive: emptyField :: rate Field selected', function () {
    // load the directive's module
    beforeEach( module( 'viewMultipleWallet' ) );
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( 'PAYMENT_DETAILS', "[{\"name\":\"Easypay2\",\"providerType\":\"online\",\"feesFlat\":0,\"feesPercent\":2.5,\"topupDuration\":\"Instant\",\"minimumAmt\":10,\"maximumAmt\":999,\"rates\":[10,50,100,250],\"consumerKey\":\"5q1bwPRzW8tH2R4DQmAUPzx6UtGoc1Be\"},{\"name\":\"DBS\",\"providerType\":\"offline\",\"feesFlat\":0.9,\"feesPercent\":0,\"topupDuration\":\"2-3 days\",\"minimumAmt\":10,\"maximumAmt\":999}]" );
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var element,
        scope,
        topupForm,
        httpBackend,
        PAYMENT_DETAILS,
        timeout;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize directive scope
    beforeEach( inject( function ( $rootScope, $compile, BASE_CURRENCY, PAYMENT_ASSETS, _PAYMENT_DETAILS_, $filter, $timeout ) {
        PAYMENT_DETAILS = _PAYMENT_DETAILS_;
        scope = $rootScope.$new();
        timeout = $timeout;
        
        scope.isDisabled = true;
        scope.hasCustomAmount = false;
        scope.hasAmount = true;
        scope.providerDetails = {};
        scope.baseCurrency = BASE_CURRENCY;
        scope.paymentAssets = PAYMENT_ASSETS;
        scope.currentProviderName = 'Easypay2';
        scope.providerDetails = JSON.parse( PAYMENT_DETAILS );
        scope.currentProvider = $filter( 'filter' )( scope.providerDetails, {
            name: scope.currentProviderName
        } );
        scope.rates = scope.currentProvider[ 0 ].rates;
        scope.feePercent = scope.currentProvider[ 0 ].feesPercent;
        scope.minimumAmt = scope.currentProvider[ 0 ].minimumAmt;
        scope.maximumAmt = scope.currentProvider[ 0 ].maximumAmt;
        scope.consumerKey = scope.currentProvider[ 0 ].consumerKey;

        if ( scope.currentProvider[ 0 ].rates ) {
            scope.currentAmount = parseInt( scope.currentProvider[ 0 ].rates[ 0 ] );
        }

        scope.forms = {};
        scope.rates = [ 10, 50, 100, 250 ];
        element = angular.element( '<form name="forms.topupEnter" class="" ng-if="currentProviderName === \'Easypay2\'" novalidate>' +
            '<ul class="content-rates">' +
            '<li class="rate-block" ng-repeat="rate in rates">' +
            '<label for="amount-{{rate}}">' +
            '<input type="radio" id="amount-{{rate}}" ng-change="newValue(\'radio-rate\', $parent.currentAmount)" ng-model="$parent.currentAmount" value={{rate}} name="currentAmount" data-index="{{$index}}" ng-click="disableCustom();" ng-focus="clearCustomAmount();">' +
            '<p class="value">' +
            '<span class="value-currency">{{baseCurrency}}</span>' +
            '<span class="value-amount">{{rate}}</span>' +
            '</p>' +
            '</label>' +
            '</li>' +
            '<li class="rate-block--fullwidth">' +
            '<label for="amount-custom">' +
            '<input type="radio" id="amount-custom" ng-change="newValue(\'radio-custom\', $parent.currentAmount)" ng-model="$parent.currentAmount" name="currentAmount" data-index="4" ng-click="enableCustom();" >' +
            '</label>' +
            '<div class="custom-wrapper">' +
            '<span class="custom-description">{{ \'PAGES.WALLET_TOPUP_ENTER.CUSTOM_AMOUNT_TEXT\' | translate }}</span>' +
            '<span class="wrap-text-input" ng-click="disableRates();enableCustom()">' +
            '<span class="value-currency">{{baseCurrency}}</span>' +
            '<input id="amount-custom-text" name="customAmount" type="number" class=\'value\' ng-disabled="isDisabled" ng-model=\'customAmount\' novalidate ng-change=\'newValue("textbox", customAmount)\' min="{{minimumAmt}}" max="{{maximumAmt}}" ng-pattern="/[0-9]*/" empty-field>' +
            '</span>' +
            '</div>' +
            '</li>' +
            '</ul>' +
            '</form>' );

        $compile( element )( scope );
        scope.$digest();

        topupForm = scope.forms.topupEnter;

        scope.disableRates = function () {
            var radioElem10 = angular.element( element ).find( '#amount-10' );
            radioElem10.removeAttr( 'checked' );
            var radioElem50 = angular.element( element ).find( '#amount-50' );
            radioElem50.removeAttr( 'checked' );
            var radioElem100 = angular.element( element ).find( '#amount-100' );
            radioElem100.removeAttr( 'checked' );
            var radioElem250 = angular.element( element ).find( '#amount-250' );
            radioElem250.removeAttr( 'checked' );
        };
        scope.disableCustom = function () {
            var elem = angular.element( element ).find( '#amount-custom-text' );
            elem.attr( 'disabled', true );
            var radioelem = angular.element( element ).find( '#amount-custom' );
            radioelem.removeAttr( 'checked' );
            radioelem.removeClass( 'ng-touched' ).addClass( 'ng-untouched' );
        };
        scope.clearCustomAmount = function () {
            scope.forms.topupEnter.customAmount.$setViewValue( '' );
            scope.forms.topupEnter.customAmount.$render();
            scope.forms.topupEnter.customAmount.$dirty = false;
            scope.forms.topupEnter.customAmount.$pristine = true;
            scope.forms.topupEnter.customAmount.$setPristine();
        }
        scope.newValue = function ( type, value ) {
            if ( typeof value === 'undefined' || type === 'textbox' || type === 'radio-custom' ) {
                scope.isDisabled = false;
                scope.hasCustomAmount = true;
                scope.hasAmount = false;
                scope.disableRates();
                scope.enableCustom();
            } else if ( typeof value === 'undefined' || type === 'radio-rate' ) {
                scope.isDisabled = true;
                scope.hasCustomAmount = false;
                scope.hasAmount = true;
                scope.disableCustom();
            }
        }
        scope.enableCustom = function () {
            var customRadioElem = angular.element( element ).find( '#amount-custom' );
            customRadioElem.trigger( 'click' );
            var elem = angular.element( element ).find( '#amount-custom-text' );
            elem.attr( 'disabled', false );
            elem.removeAttr( 'disabled' );
            elem.focus();
        };
    } ) );
    it( ' :: custom rate is input a valid value', function () {
        var spyDisable = spyOn( scope, 'disableRates' ).and.callThrough();
        var spyEnable = spyOn( scope, 'enableCustom' ).and.callThrough();
        expect( topupForm.customAmount.$pristine ).toBeTruthy();

        scope.enableCustom();
        scope.customAmount = '';

        topupForm.customAmount.$setViewValue( '' );
        topupForm.customAmount.$render();
        scope.$digest();
        expect( topupForm.customAmount.$pristine ).toBeFalsy();
        expect( topupForm.customAmount.$dirty ).toBeTruthy();
        expect( topupForm.customAmount.$error.fieldEmpty ).toBeFalsy();
    } );
} );
