'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:mapAutocomplete
 * @description
 * # mapAutocomplete
 */
 /* jshint ignore:start */
angular.module('viewMultipleWallet')
    .directive('googlePlace', function ($document) {
        return {
            require: 'ngModel',
            scope: {
                ngModel: '=',
                myDirectiveFn: "=",
                details: '=?'
            },
            link: function(scope, element, attrs, model) {
                var componentForm = {
                    street_number: 'short_name',
                    route: 'long_name',
                    locality: 'long_name',
                    administrative_area_level_1: 'long_name',
                    administrative_area_level_2: 'long_name',
                    country: 'long_name',
                    postal_code: 'short_name'
                };
                var options = {
                    types: [],
                    componentRestrictions: {}
                };
                scope.gPlace = new google.maps.places.Autocomplete(element[0], options);
                function fillInAddress() {
                    // Get the place details from the autocomplete object.
                    var place = scope.gPlace.getPlace();

                    scope.detail ={};
                    // Get each component of the address from the place details
                    // and fill the corresponding field on the form.
                    for (var i = 0; i < place.address_components.length; i++) {
                    var addressType = place.address_components[i].types[0];
                    if (componentForm[addressType]) {
                        var val = place.address_components[i][componentForm[addressType]];
                        scope.detail[addressType] = val;
                    }
                    }
                }
                google.maps.event.addListener(scope.gPlace, 'place_changed', function() {
                    scope.$apply(function() {
                        // scope.details = scope.gPlace.getPlace();
                        // model.$setViewValue(element.val());
                        fillInAddress();
                        scope.myDirectiveFn(scope.detail);
                    });
                });
            }
        };
    });
/* jshint ignore:end */
