'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:accountInfo
 * @description
 * # accountInfo
 */
angular.module('viewMultipleWallet')
  .directive('accountInfo', function () {
    return {
      scope: true,
      templateUrl: 'app/components/accountInfo/partials/accountInfo.html',
      restrict: 'E',
      link: function(scope, element, attrs) {

      }
    };
  });
