'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.cordova
 * @description
 * # cordova
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .factory('cordovaFactory', function (API_BASE, APPLICATION_PARAMS, store, $state, $rootScope, userFactory, $analytics, $timeout, PubSub, ngDialog, $translate, authDocumentFactory, helperFactory) {

      var params = angular.fromJson( APPLICATION_PARAMS );
      var app = {
        // Application Constructor
        initialize: function() {
                      this.bindEvents();
                    },
        // Bind Event Listeners
        //
        // Bind any events that are required on startup. Common events are:
        // 'load', 'deviceready', 'offline', and 'online'.
        bindEvents: function() {
                      document.addEventListener('deviceready', this.onDeviceReady, false);
                    },
        // deviceready Event Handler
        //
        // The scope of 'this' is the event. In order to call the 'receivedEvent'
        // function, we must explicitly call 'app.receivedEvent(...);'
       isNewVisitor: function() {
                       return store.get('first_time') === true;
                     },
       onDeviceReady: function() {
                         app.receivedEvent('deviceready');
                         return true;
                       },
        // Update DOM on a Received Event
       receivedEvent: function(id) {
                        var firstTime = store.get('launchVal');
                        if(params.platform === 'app' && (firstTime === undefined || typeof firstTime === 'undefined') ){
                          store.set('launchVal', 0);
                          $state.go('auth.app');
                        }
                      },
       takePhoto: function(imageType){
        //navigator.camera.getPicture(successCallback, errorCallback, cameraOptions);
        navigator.camera.getPicture(
          function (imageData) {
            // getPicture success Handler
            // imageTypes - profile, authDocument
            if(imageType === 'profile'){
              userFactory.updateProfileImage({"data":imageData}).then(function(response){
                  // success Handler
                  $analytics.eventTrack('Upload Profile Image Success', {  category: 'profileUpload', label: 'Upload Successfull' });
                  $timeout(function() {
                      ngDialog.closeAll();
                  });
                  userFactory.clearUserCache();
                  PubSub.publish('update-sidebarProfileImage');
                  PubSub.publish('update-accountProfileImage');
                }, function(error){
                  // error handler
                  $analytics.eventTrack('Upload Profile Image Failure', {  category: 'profileUpload', label: 'Upload Fail' });
                });
            }
            if(imageType === 'authDocument'){
              console.log(imageType);
              authDocumentFactory.uploadImage({'data': imageData})
              .then(function(response){
              // POST users/authentications/documents
              // upload image
                $analytics.eventTrack('Upload KYC Auth Document Success', {  category: 'KycDocumentUpload', label: 'Upload Successfull' });
                authDocumentFactory.submitKyc()
                    .then(function (response) {
                        // PUT users/authentications/documents
                        // update user kyc_submitted field
                        helperFactory.removeUserCache();
                        helperFactory.storeUpdateAuthStatus();
                        userFactory.getUser(false);
                        PubSub.publish('kyc-submitted');
                        navigator.notification.alert(
                          $translate.instant('COMMON.DO_KYC.SUBMITTED.HEADING'),  // message
                          '',         // callback
                          'KYC Document Upload',            // title
                          'OK'                  // buttonName
                      );
                        $timeout(function() {
                            ngDialog.closeAll();
                        });
                    }, function(errorSubmit){
                      $analytics.eventTrack('Upload KYC Auth Document Submit Failure', {  category: 'KycDocumentSubmit', label: 'Submission Fail' + errorSubmit.statusText });
                    });
                }, function(errorUpload){
                     $analytics.eventTrack('Upload KYC Auth Document Image Upload Failure', {  category: 'KycDocumentUpload', label: 'Image Upload Failed: ' + errorUpload.statusText });
                    switch(errorUpload.status){
                          case 400:
                              navigator.notification.alert(
                              $translate.instant('ERRORS.VALIDATION.VERIFICATIONUPLOAD.KYC_UPLOAD.400'),  // message
                                  '',         // callback
                                  'KYC Document Upload',            // title
                                  'OK'                  // buttonName
                              );
                              break;
                          case 401:
                              navigator.notification.alert(
                              $translate.instant('ERRORS.VALIDATION.VERIFICATIONUPLOAD.KYC_UPLOAD.401'), // message
                                  '',         // callback
                                  'KYC Document Upload',            // title
                                  'OK'                  // buttonName
                              );
                              break;
                          case 403:
                              navigator.notification.alert(
                              $translate.instant('ERRORS.VALIDATION.VERIFICATIONUPLOAD.KYC_UPLOAD.403'),// message
                                  '',         // callback
                                  'KYC Document Upload',            // title
                                  'OK'                  // buttonName
                              );
                              break;
                          case 500:
                            navigator.notification.alert(
                              $translate.instant('ERRORS.VALIDATION.VERIFICATIONUPLOAD.KYC_UPLOAD.500'),  // message
                                  '',         // callback
                                  'KYC Document Upload',            // title
                                  'OK'                  // buttonName
                              );
                              break;
                        }
                });
            }
          },
          function (message) {
            // getPicture error Handler
            navigator.notification.alert('Camera picture capture Failed because: ' + message);
            $analytics.eventTrack('Device Camera Picture capture failure', {  category: 'DeviceCamera', label: 'Picture capture failure : '+ message });
            },
         { quality: 50, destinationType: Camera.DestinationType.DATA_URL } // camera options
        ); // end navigator.camera.getPicture
       },  // End takePhoto function

       handleExternalURLs: function (url) {
           // Handle click events for all external URLs
           if (cordova.platformId.toUpperCase() === 'ANDROID') {
              navigator.app.loadUrl(url, { openExternal: true });
           }
           else if (cordova.platformId.toUpperCase() === 'IOS') {
              window.open(url, '_system');
           }
       }
      };

       return app;
  });