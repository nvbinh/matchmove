describe('Factory: cordovaFactory', function() {
  var cordova,
  	httpBackend,
    store,
    navigator,
    options,
    $state,
    $rootScope;

  beforeEach(module('viewMultipleWallet'));
  
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("APPLICATION_PARAMS", {"platform":"app"});
        $provide.constant("KYC_UPLOAD_SETTINGS",{"allowedIdType":[{"nric": "PAGES.WALLET_DETAILS.ID_TYPE_TEXT.NRIC","epfin":"PAGES.WALLET_DETAILS.ID_TYPE_TEXT.EP_FIN","spass":"PAGES.WALLET_DETAILS.ID_TYPE_TEXT.S_PASS","wp":"PAGES.WALLET_DETAILS.ID_TYPE_TEXT.WORK_PERMIT"}], "numberOfFilesAllowed":4,"allowedTitle":[{"Mr": "PAGES.WALLET_DETAILS.MR","Mrs":"PAGES.WALLET_DETAILS.MRS","Miss":"PAGES.WALLET_DETAILS.MISS","Dr":"PAGES.WALLET_DETAILS.DR","Madam":"PAGES.WALLET_DETAILS.MADAM"}], "KYCProcessStates": ["not_submitted", "pending", "rejected", "submitted", "f2f_request", "f2f_approved", "approved"], "KYCDataSeekPoints":{"email": {"langKey": "EMAIL", "switch":"ON"},"mobile": {"langKey": "MOBILE", "switch":"ON"},"profile": {"langKey": "PROFILE", "switch":"ON"},"addressInfo":{"langKey": "ADDRESS_INFORMATION", "switch":"ON"},"KYC": {"langKey": "KYC", "switch":"ON"}}});
    } ) );

    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Factory instantiation
  beforeEach(inject(function(_cordovaFactory_, _store_, $q, _$window_, _$state_, _$rootScope_) {
    $rootScope = _$rootScope_;
    $state = _$state_;
    cordova = _cordovaFactory_;
    store = _store_;
    
    $window = _$window_;
    navigator = {      
        'userAgent': 'Mozilla/5.0 (Linux; Android 5.1.0; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19',
        "camera":{
          "DestinationType": {"DATA_URL": "true"},
          getPicture: function(successCallback, errorCallback, options){}
        }
    };
    $window.navigator = navigator;
    
    
  }));

  afterEach(function() {
    store.set('first_time', undefined);
    httpBackend.flush();
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

  describe('Factory functions', function () {
		var $rootScope = null;
		var $cordovaCamera = null;
		var cameraOptions = {};

    it('onDeviceReady fn', function(){
      spyOn(cordova, 'onDeviceReady').and.callThrough();
      var deviceRdy = cordova.onDeviceReady();
      expect(deviceRdy).toBeTruthy();
    });

    it('first time visitor', function(){
      store.set('first_time', true);
      spyOn(cordova, 'isNewVisitor').and.callThrough();
      var fstTime = cordova.isNewVisitor();
      expect(fstTime).toBeTruthy();
    });

    it('initialize fn', function(){
      spyOn(cordova, 'initialize').and.callThrough();
      spyOn(cordova, 'bindEvents').and.callThrough();
      cordova.initialize();
      expect(cordova.bindEvents).toHaveBeenCalled();
    });

    it('bindevents fn', function(){
      spyOn(cordova, 'bindEvents').and.callThrough();
      spyOn(document, 'addEventListener').and.callThrough();
      cordova.bindEvents();
      expect(document.addEventListener).toHaveBeenCalled();
    });

    it('receivedEvent fn - call state.go fn', function(){
      store.set('launchVal', undefined);
      spyOn($state, 'go').and.callFake(function(){});
      cordova.receivedEvent(6);
      expect($state.go).toHaveBeenCalled();
    });

    it('receivedEvent fn - doesnt call state.go fn', function(){
      store.set('launchVal', 1);
      spyOn($state, 'go').and.callThrough();
      cordova.receivedEvent(5);
      expect($state.go).not.toHaveBeenCalled();
    });

		/*
    TODO : fix this TC later
     it('should get picture', function () {
      spyOn(cordova, 'takePhoto').and.callThrough();
      console.log(navigator.camera);
      spyOn(navigator.camera, 'getPicture').and.callFake( function () {
                    return {
                       then: function ( callback ) {
                           return callback( {
                                imgdata: "hsghshgf=="
                           });
                        },
                        Camera: Camera 
                      }});
      cordova.takePhoto('profile');
		});

		it('should throw an error while getting the picture.', function() {
			$cordovaCamera.throwsError = true;
			$cordovaCamera.getPicture(cameraOptions)
				.then(
					function() { expect(true).toBe(false); },
					function() { expect(true).toBe(true); }
				)
				.finally(function() { });

		});
    */
	});
});
