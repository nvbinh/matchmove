'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.usersloyaltyfactory
 * @description
 * # usersloyaltyfactory
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .factory('usersloyaltyfactoryFactory', function (API_BASE, $http) {

    return {
      history: function (params) {
        return $http({
                  url: API_BASE + 'loyalty',
                  method: 'GET',
                  params: params
               });
      }
    };
  });
