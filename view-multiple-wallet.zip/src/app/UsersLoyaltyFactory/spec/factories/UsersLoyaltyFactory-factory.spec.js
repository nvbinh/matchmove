'use strict';

describe('Factory: usersloyaltyfactoryFactory', function() {
  var usersloyaltyfactoryFactory,
      notifUpdateResponse,
      loyaltyList,
      API_BASE,
      httpBackend,
      paramData;
  beforeEach(module('viewMultipleWallet'));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
      $provide.constant( "TRANSLATION_PARAMS", {
          "partFilesPath": "../assets/locales/",
          "preferredLanguage": "vi_vn",
          "client": "hdb",
          "source": "http://localhost:3000/assets/hdb/locales\/",
          "supportedLanguages": [ {
              "i18n": "en_us",
              "name": "English"
          }, {
              "i18n": "vi_vn",
              "name": "Vietnamese"
          } ]
      } );
  } ) );
  // langugage based mock calls
  beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
      httpBackend = $httpBackend;
      var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
      for ( var i = 0; i < lngth; i++ ) {
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
      }
      httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).source + '"' + window.navigator.language + '".json' ).respond( 200, '' );
  } ) );
  //  Initialize the factory and a mock rootScope
  beforeEach(inject(function(_usersloyaltyfactoryFactory_, _API_BASE_) {
    API_BASE = _API_BASE_;
    usersloyaltyfactoryFactory = _usersloyaltyfactoryFactory_;

    //paramData = 'filter_condition=%3D&filter_field=is_read&filter_value=0&limit=2&sort_direction=DESC&sort_field=date_added';
    loyaltyList = {"total_points":"5300.00","transactions":{"items":[{"id":"1628","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-01-29 07:26:21 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C4","date_added":"2016-01-29 07:26:21"},{"id":"1629","loyalty_type":"Topups","loyalty_type_id":"2","points":"5100.00","remarks":"2016-01-29 07:46:52 --- Topup Successful for ref_id SGMCEASYPAY200003B9AE16E000033C5","date_added":"2016-01-29 07:46:52"},{"id":"3456","loyalty_type":"Topups","loyalty_type_id":"2","points":"100.00","remarks":"2016-02-17 11:32:29 --- Topup Successful for ref_id 6444e64fd5793132f7b136b5a72dfd920295bb1835cec60cdeb0191dd9348cc2","date_added":"2016-02-17 11:32:29"}],"first":1,"before":1,"current":1,"last":1,"next":1,"total_pages":1,"total_items":3,"limit":10}};
    httpBackend.whenGET(API_BASE + 'loyalty').respond(200, loyaltyList);
    httpBackend.flush();
  }));
   afterEach(function() {
     httpBackend.verifyNoOutstandingExpectation();
     httpBackend.verifyNoOutstandingRequest();
   });
  describe('Notification Listing and Update operations', function(){
      it('should return loyalty list per filter conditions', function(){
          usersloyaltyfactoryFactory.history().then(
              function(response){
                  expect(response.status).toBe(200);
                  expect(response.data.total_points).toBe('5300.00');
                  expect(response.data.transactions.items[0].id).toBe('1628');
              });
         httpBackend.flush();
      });
  });
});
