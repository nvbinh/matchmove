'use strict';

describe('Factory: paymentProvidersFactory', function() {
  var paymentProviders,
  initiatePmtResponse,
  pmtSuccessResponse,
  pmtPendingResponse,
  pmtProviders,
  walletTransactions,
  API_BASE,
  httpBackend,
  pmtData;

  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
  beforeEach(inject(function( _paymentProvidersFactory_, _API_BASE_) {
    
	 API_BASE = _API_BASE_;
    paymentProviders = _paymentProvidersFactory_;

    pmtData = {
        "fee":"0.25",
        "consumerKey": "5q1bwPRzW8tH2R4DQmAUPzx6UtGoc1Be",
        "amount": 17,
        "email": "balajiv+20@chimeratechnologies.com"
    }
    initiatePmtResponse = {
          "payment": {
            "ref_id": "MMP-MLVDN-56B82EFF37",
            "payment_ref_id": "MMP-MLVDN-56B82EFF37",
            "provider": "Easypay2",
            "email": "balajiv+20@chimeratechnologies.com",
            "links": {
              "rel": "self",
              "href": "https://test.wirecard.com.sg/easypay2/paymentpage.do?mid=20140514001&ref=MMP-MLVDN-56B82EFF37&cur=SGD&amt=17.43&transtype=sale&locale=en_US&skipstatuspage=N&rcard=64&version=2&validity=2016-02-08-15%3A00%3A31&signature=34b742432ddb70fffea16e49ab38047d28021e6b3336686976710934c1311da05c36ce666e4eac734692aace2056e3c7dfd02200957100912bc8851ff3dfa225&userfield5=34b742432ddb70fffea16e49ab38047d28021e6b3336686976710934c1311da05c36ce666e4eac734692aace2056e3c7dfd02200957100912bc8851ff3dfa225&statusurl=https%3A%2F%2Fbeta-ih.mmvpay.com%2Fapi%2Fv1%2Fcallback%2FEasypay2%2F34b742432ddb70fffea16e49ab38047d28021e6b3336686976710934c1311da05c36ce666e4eac734692aace2056e3c7dfd02200957100912bc8851ff3dfa225",
              "method": "GET"
            }
          }
        };

    pmtSuccessResponse = {
      "status": "SUCCESS",
      "message": "Topup successful after payment",
      "payment_ref_id": "MMP-JRFBT-56B832751D",
      "ref_id": "f4f086da09511432a135a1fc946619de9bd8c8a5d0bdc2e891bbc805bf996c19"
    };

    pmtProviders = [
          {
            "name": "DBS",
            "provider_type": "Offline",
            "credit_time": "Within 2 days",
            "topup_min_amount": "10",
            "topup_fee": "0.000",
            "description": "Offline Payment providers",
            "image": {
              "source": "https://vcard-assets.s3.amazonaws.com/payments/dbs.png"
            }
          },
          {
            "name": "Easypay2",
            "provider_type": "Credit Cards",
            "credit_time": "Instant",
            "topup_min_amount": "10",
            "topup_fee": "0.000",
            "description": "Credit card options",
            "image": {
              "source": "https://vcard-assets.s3.amazonaws.com/payments/easypay2.png"
            }
          }
        ];

     walletTransactions = {
          "transactions": [
            {
              "id": "SGMCEASYPAY200003B9AD54400004AC7",
              "type": "Topup",
              "amount": 10,
              "currency": "SGD",
              "status": "Success",
              "indicator": "credit",
              "date": "2016-02-08 14:15:35",
              "details": {
                "name": "OP API Topup",
                "amount": 10,
                "fee": 0.25,
                "total": 10
              }
            },
            {
              "id": "6f716d973beb30155b4e393301b23c86",
              "type": "Fund Transfer",
              "amount": 10,
              "currency": "SGD",
              "status": "Success",
              "indicator": "debit",
              "date": "2016-02-04 12:59:37",
              "details": {
                "name": "Money Trasfer",
                "amount": 10,
                "fee": 0,
                "total": 10
              }
            }
          ],
          "count": {
            "total": 2
          }
        } ;
    httpBackend.whenGET(API_BASE + 'users/wallets/funds/providers').respond(200, pmtProviders);
    httpBackend.whenGET(API_BASE + 'users/wallets/funds/MMP-JRFBT-56B832751D').respond(200, walletTransactions);
    httpBackend.whenGET(API_BASE + '/payment/status/MMP-JRFBT-56B832751D').respond(200, pmtSuccessResponse);
    httpBackend.whenPOST(API_BASE + 'users/wallets/funds/providers/Easypay2').respond(200, initiatePmtResponse);
	httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });

   it('should fetch the list of providers', function(){
       paymentProviders.getList().then(
           function(response){
               expect(response.status).toBe(200);
               expect(response.data.length).toBe(2);
           }
       );
       httpBackend.flush();
   });
    it('should initiate payment by Easypay2 provider' , function(){
        paymentProviders.initiatePayment('Easypay2', pmtData).then(
            function(response){
                expect(response.status).toBe(200)
                expect(response.data.payment.provider).toBe('Easypay2');
                expect(response.data.payment.email).toBe('balajiv+20@chimeratechnologies.com');
            }
        );
        httpBackend.flush();
    });
    it('should get the transaction status', function(){
        paymentProviders.getTransactionStatus('MMP-JRFBT-56B832751D').then(
            function(response){
                expect(response.status).toBe(200);
                expect(response.data.status).toBe('SUCCESS');
            }
        );
        httpBackend.flush();
    });
    it('should get the transaction list for the logged in user', function(){
        paymentProviders.getStatus('MMP-JRFBT-56B832751D').then(
            function(response){
                expect(response.status).toBe(200);
                expect(response.data.transactions.length).toBe(2);
                expect(response.data.transactions[0].type).toBe('Topup');
                expect(response.data.transactions[1].type).toBe('Fund Transfer');
            }
        );
        httpBackend.flush();
    });
});
