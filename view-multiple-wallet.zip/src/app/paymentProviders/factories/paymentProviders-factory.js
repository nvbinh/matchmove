'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.paymentProviders
 * @description
 * # paymentProviders
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .service('paymentProvidersFactory', function ($http, API_BASE) {
// Service logic
// ...

// Public API here
    this.getList = function() {
        return $http.get(API_BASE + 'users/wallets/funds/providers');
    };// Public API here

    this.initiatePayment = function(providername, data) {
        return $http({
            method: 'POST',
            url: API_BASE + 'users/wallets/funds/providers/' + providername,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                  str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
                return str.join('&');
            },
            data: data
        });
    };
    this.getStatus = function(id) {
        return $http({
          method: 'GET',
          url: API_BASE + 'users/wallets/funds/' + id,
          cache: false,
          headers: {'Authorization':'Basic'}
        });
    };
    this.getTransactionStatus = function(id) {
      return $http({
        method: 'GET',
        url: API_BASE + '/payment/status/' + id,
        cache: false,
        headers: {'Authorization':'Basic'}
      });
    };
  });
