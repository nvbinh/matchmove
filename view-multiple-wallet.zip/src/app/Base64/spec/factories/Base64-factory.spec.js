'use strict';
describe('Factory: base64Factory', function() {
  var base64,
  	  scope,
      utf8Factory;

  beforeEach(function(){
    // module(function($provide){
    //   $provide.service('utf8Factory', function(){
    //     this.encode = jasmine.createSpy('encode').and.callThrough();
    //     this.decode = jasmine.createSpy('decode').and.callThrough();
    //   });
    // });
    module('viewMultipleWallet');
  });

  beforeEach(inject(function(_base64Factory_, $rootScope, _utf8Factory_) {
    scope = $rootScope.$new();
    base64 = _base64Factory_;
    scope = $rootScope;
    utf8Factory = _utf8Factory_;
    spyOn(base64, 'encode').and.callThrough();
    spyOn(base64, 'decode').and.callThrough();
  }));

  describe(' - base64Factory Function',function(){
  	var strEncode,
  		strDecode;
  	
    it('should have base64 service be defined', function () {
    	expect(base64).toBeDefined();
  	});

  	it(' - encode', function () {
  		var str = 'abcd1234';
      // expect(utf8Factory.encode).toHaveBeenCalledWith(str);
      expect(utf8Factory.encode(str)).toEqual(str);
  		expect(base64.encode(str)).toEqual('YWJjZDEyMzQ=');
	 });

  	it(' - decode', function () {
  		var str = 'YWJjZDEyMzQ=';
      // expect(utf8Factory.decode).toHaveBeenCalledWith(str);
      expect(utf8Factory.decode(str)).toEqual(str);
      expect(base64.decode(str)).toEqual('abcd1234');
  	});
  });

});
