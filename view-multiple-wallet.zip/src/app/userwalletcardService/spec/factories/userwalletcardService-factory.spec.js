'use strict';
describe('Service: Cards', function() {
  var Cards,
      scope,
      httpBackend,
      cache,
      q,
      API_BASE,
      rc4,
      cardTypes,
      defered,
      http,
      userCardOrders,
      cardInfo,
      orderData,
      PHYSICAL_CARD_CODE,
      cardOrderParams,
      cardAddParams,
      cardActivateParams,
      user,
      userCache,
      authCache,
      addressCache,
      userFactory,
      authDocFactory,
      userAddressFactory,
      timeout;
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant("GET_FIRST_CARD", {
            "FirstCardDataSeekPoints": {
              "email": {
                "langKey": "EMAIL",
                "switch": "ON"
              },
              "mobile": {
                "langKey": "MOBILE",
                "switch": "ON"
              },
              "profile": {
                "langKey": "PROFILE",
                "switch": "ON"
              },
              "addressInfo": {
                "langKey": "ADDRESS_INFORMATION",
                "switch": "ON"
              },
              "KYC": {
                "langKey": "KYC",
                "switch": "ON"
              }
            }
          });
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize factory
  beforeEach(inject(function($rootScope, _API_BASE_ , _Cards_, _CacheFactory_, _rc4Factory_, _$q_, _$http_, _PHYSICAL_CARD_CODE_, _userFactory_, _authDocumentFactory_, _userAddressFactory_, _$timeout_ ) {
    Cards = _Cards_;
    cache = _CacheFactory_;
    API_BASE = _API_BASE_;
    rc4 = _rc4Factory_;
    userFactory = _userFactory_;
    authDocFactory = _authDocumentFactory_;
    userAddressFactory = _userAddressFactory_;
    q = _$q_;
    timeout = _$timeout_;
    http = _$http_;
    PHYSICAL_CARD_CODE = _PHYSICAL_CARD_CODE_;
    scope = $rootScope.$new();

    defered = q.defer();
    user = {};
    cardTypes = {
              "types": [
                {
                  "code": "mcmmgcard",
                  "name": "MatchMove Virtual MasterCard",
                  "description": "MatchMove Virtual MasterCard",
                  "token": {
                    "type": "CVV"
                  },
                  "image": {
                    "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-small.png",
                    "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-medium.png",
                    "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgcard/card-large.png"
                  },
                  "details": {
                    "min_load_limit": 10,
                    "fee": 0,
                    "topup_limits": {
                      "pre_kyc": {
                        "frequency": null
                      },
                      "post_kyc": {
                        "frequency": null
                      }
                    }
                  },
                  "type": "Virtual Card"
                },
                {
                  "code": "mcimbacard",
                  "name": "MatchMove Imba Card",
                  "description": "MatchMove Imba Card",
                  "token": {
                    "type": "CVV"
                  },
                  "image": {
                    "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcimbacard/card-small.png",
                    "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcimbacard/card-medium.png",
                    "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcimbacard/card-large.png"
                  },
                  "details": {
                    "min_load_limit": 10,
                    "fee": 0,
                    "topup_limits": {
                      "pre_kyc": {
                        "frequency": null
                      },
                      "post_kyc": {
                        "frequency": null
                      }
                    }
                  },
                  "type": "Virtual Card"
                },
                {
                  "code": "mcmmgpcard",
                  "name": "MatchMove Physical Card",
                  "description": "Matchmove Physical Card",
                  "token": {
                    "type": "CVV"
                  },
                  "image": {
                    "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                    "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                    "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
                  },
                  "details": {
                    "min_load_limit": 10,
                    "fee": 0,
                    "topup_limits": {
                      "pre_kyc": {
                        "frequency": null
                      },
                      "post_kyc": {
                        "frequency": null
                      }
                    }
                  },
                  "type": "Physical Card"
                }
              ],
              "count": {
                "total": 3
              }
            };
       cardInfo = {
                  "id": "25302c8a90917740e0fc6057113bb70f",
                  "number": "5363950000213401",
                  "holder": {
                    "name": "Balaji"
                  },
                  "funds": {
                    "available": {
                      "currency": "SGD",
                      "amount": "0.00"
                    }
                  },
                  "type": {
                    "type": "mcmmgpcard",
                    "name": "MatchMove Physical Card",
                    "description": "Matchmove Physical Card",
                    "code_type": "Physical Card"
                  },
                  "date": {
                    "expiry": "2020-12",
                    "issued": "2016-01-05"
                  },
                  "image": {
                    "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-small.png",
                    "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-medium.png",
                    "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mcmmgpcard/card-large.png"
                  },
                  "status": {
                    "is_active": true,
                    "text": "inactive"
                  },
                  "links": [
                    {
                      "rel": "securities.tokens",
                      "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f/securities/tokens",
                      "method": "GET"
                    },
                    {
                      "rel": "cards.transactions",
                      "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f/transactions",
                      "method": "GET"
                    },
                    {
                      "rel": "wallets.funds.transfers",
                      "href": API_BASE + "users/wallets/funds",
                      "method": "GET"
                    },
                    {
                      "rel": "cards.pins.set",
                      "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f/pins",
                      "method": "POST"
                    },
                    {
                      "rel": "cards.pins.verify",
                      "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f/pins",
                      "method": "PUT"
                    },
                    {
                      "rel": "cards.activation",
                      "href": API_BASE + "users/wallets/cards/25302c8a90917740e0fc6057113bb70f",
                      "method": "PUT"
                    }
                  ],
                  "activation_code": "967209"
                };

            userCardOrders = [{
                "hash_id": "26544a0f200c551ee3ff3ad605ba0db6",
                "order_ref_id": "2c3ad99c817faab0a1eba0ccc953b2f0",
                "payment_ref_id": "3c7d5852f789fb41891cd47a7b4eaa5de9cd21af42b3e57f918a2ed893bd12fe",
                "card_status": "Card Added",
                "details": "Purchase Card : Matchmove Physical Card",
                "date_added": "2016-01-29 22:13:57"
              },
              {
                "hash_id": "c266e46769e46996911d81c148b74bb3",
                "order_ref_id": "3bebeefdeb404248ae3a206ad6f0cb73",
                "payment_ref_id": "6851ed7eb6ef11fa618605d01a64bd9d0435d3fa67ec9b5b7170c4255b7d2203",
                "card_status": "Card Order placed",
                "details": "Purchase Card : Matchmove Physical Card",
                "date_added": "2016-02-01 11:42:08"
              }];

         orderData = {
                "hash_id": "26544a0f200c551ee3ff3ad605ba0db6",
                "order_ref_id": "2c3ad99c817faab0a1eba0ccc953b2f0",
                "payment_ref_id": "3c7d5852f789fb41891cd47a7b4eaa5de9cd21af42b3e57f918a2ed893bd12fe",
                "card_status": "Card Order placed",
                "details": "Purchase Card : Matchmove Physical Card",
                "date_added": "2016-01-29 22:13:57"
              };
          cardOrderParams= {'type': PHYSICAL_CARD_CODE, 'purchase_fee': 10};

          cardAddParams = {
            'type': PHYSICAL_CARD_CODE,
             'assoc_number': 'PY00000019090',
             'hash_id': '26544a0f200c551ee3ff3ad605ba0db6'
          };
          cardActivateParams = {
            'type': PHYSICAL_CARD_CODE,
            'id': '2a808c8041d56c407b5d55cfa445a479',
            'token': 'df82098e0d7484eb4105808f89951675',
            'key': 829528
          };
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/types').respond(200, angular.toJson(cardTypes));
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/orders').respond(200, angular.toJson(userCardOrders));
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/25302c8a90917740e0fc6057113bb70f').respond(200, angular.toJson(cardInfo));
    httpBackend.whenGET(API_BASE + 'users/wallets/cards/25302c8a90917740e0fc6057113bb70f/securities/tokens').respond(200, {'value': 286, 'expiry': '2016-02-02'});

    httpBackend.whenPOST(API_BASE + 'users/wallets/cards/orders').respond(200, orderData);
    httpBackend.whenPOST(API_BASE + 'users/wallets/cards/').respond(200, 'Card Added successfully');
    httpBackend.whenPUT(API_BASE + 'users/wallets/cards/'+ PHYSICAL_CARD_CODE).respond(200, 'Card Activated Successfully');


  }));

   afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
    cache.destroy();
  });

  it('should have the list of card types', function(){
      Cards.cardsList().then(function(response){
         expect(response.data).toBeDefined();
         expect(response.data.types.length).toBe(3);
      });
      httpBackend.flush();
  });
  it('should get the card info', function(){
        Cards.getCard('25302c8a90917740e0fc6057113bb70f').then(function(response){
           expect(response.data).toBeDefined();
           expect(response.data.number).toBe('5363950000213401');
       });
      httpBackend.flush();
  });
  it('should get the existing card orders', function(){
       Cards.cardsOrdersList().then(function(response){
           expect(response.data).toBeDefined();
           expect(response.data.length).toBe(2);
       });
      httpBackend.flush();
  });
  it('should Place a card order', function(){
      Cards.cardOrder(cardOrderParams).then(function(response){
          expect(response.data).toBeDefined();
          expect(response.data.card_status).toBe('Card Order placed');
      });
      httpBackend.flush();
  });
  it('should Add a Card', function(){
     Cards.cardCreate(cardAddParams).then(function(response){
         expect(response.data).toBeDefined();
         expect(response.data).toBe('Card Added successfully');
     });
      httpBackend.flush();
  });
  it('should Activate a Card', function(){
      Cards.cardVerify(cardActivateParams.type,
                        cardActivateParams.id,
                        cardActivateParams.token,
                        cardActivateParams.key).then(function(response){
         expect(response.data).toBeDefined();
         expect(response.data).toBe('Card Activated Successfully');
      });
      httpBackend.flush();
  });
  it('should get security CVV for the given card', function(){
      Cards.getCardCvv('25302c8a90917740e0fc6057113bb70f').then(function(response){
         expect(response.data).toBeDefined();
         expect(response.data.value).toBe(286);
         expect(response.data.expiry).toBe('2016-02-02');
      });
      httpBackend.flush();
  });
  describe('getFirstCardFactory Fn : Card NOT allowed', function() {
    beforeEach(inject(function() {
        httpBackend.whenGET(API_BASE + 'users').respond(200, {
            "id": "54921506c3886d36bf2964e29bf4b38d",
            "email": "balajihdb04@chimeratechnologies.com",
            "authentications": {
                "email_verified": false,
                "mobile_verified": false
            }
        });
        httpBackend.whenGET(API_BASE + 'users/authentications/documents').respond(200, { 'status': 'not_submitted' });
        httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, null );
        httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, null );
        // read caches
        authCache = cache.get('authCache');
        userCache = cache.get('userCache');
        addressCache = cache.get('addressCache');
        //  remove caches
        userCache.remove('user');
        userFactory.getUser(false)

        authCache.remove('kycStatus');
        authDocFactory.getStatus(false);

        addressCache.remove('billing_address');
        userAddressFactory.getAddress('billing', false);

        addressCache.remove('residential_address');
        userAddressFactory.getAddress('residential', false);
        //  setup spies
        spyOn(userFactory, 'getUser').and.callThrough();
        spyOn(authDocFactory, 'getStatus').and.callThrough();
        spyOn(userAddressFactory, 'getAddress').and.callThrough();
        httpBackend.flush();
    }));
    it('all checks fail', function() {
        var allowCard = Cards.getFirstCardFactory();
        expect(allowCard).toEqual({ "email": false, "mobile": false, "profile": false, "addressInfo": false, "kycStatus": false });
    });
  });
  describe('getFirstCardFactory Fn : Card ALLOWED', function() {
    beforeEach(inject(function() {
        httpBackend.whenGET(API_BASE + 'users').respond(200, {
                  "id": "54921506c3886d36bf2964e29bf4b38d",
                  "email": "balajihdb04@chimeratechnologies.com",
                  "authentications": {
                    "email_verified": true,
                    "mobile_verified": true
                  },
                  "links": [
                    {
                      "rel": "users.wallets",
                      "href": API_BASE + "users/wallets",
                      "method": "GET"
                    }
                  ],
                  "identification": {
                    "type": "nationalic",
                    "number": "54545543"
                  }
                });
        httpBackend.whenGET(API_BASE + 'users/authentications/documents').respond(200, { 'status': 'approved' });
        httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, {  "address_1": "line222"  });
        httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, { "address_1": "line333" });
        cache.destroy();
        if ( !cache.get( 'userCache' ) ) {
            cache.createCache( 'userCache', {
                maxAge: 1 * 30 * 1000, // Items added to this cache expire after 30 seconds
                cacheFlushInterval: 60 * 60 * 1000, // This cache will clear itself every hour
                deleteOnExpire: 'passive', // Items will be deleted from this cache when they expire
                storageMode: 'localStorage'
            } );
        }
        // read caches
        authCache = cache.get('authCache');
        userCache = cache.get('userCache');
        addressCache = cache.get('addressCache');
        //  remove caches
        userCache.remove('user');
        userFactory.getUser(false)

        authCache.remove('kycStatus');
        authDocFactory.getStatus(false);

        addressCache.remove('billing_address');
        userAddressFactory.getAddress('billing', false);

        addressCache.remove('residential_address');
        userAddressFactory.getAddress('residential', false);
        //  setup spies
        spyOn(userFactory, 'getUser').and.callThrough();
        spyOn(authDocFactory, 'getStatus').and.callThrough();
        spyOn(userAddressFactory, 'getAddress').and.callThrough();
        httpBackend.flush();
    }));

     afterEach(function() {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
        cache.destroy();
      });
    it('all checks PASS', function() {
        var allowCard = Cards.getFirstCardFactory();
        expect(allowCard).toEqual({ "email": true, "mobile": true, "profile": true, "addressInfo": true, "kycStatus": true });
    });
  });
});
