
'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authService
 * @description
 * # authService
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .service('Cards', function (API_BASE, $http, CacheFactory, rc4Factory, GET_ANOTHER_CARD, store, jsonPath, userFactory, GET_FIRST_CARD) {
    // Service logic
    function cardsList() {
        return $http.get(API_BASE + 'users/wallets/cards/types',{cache:true});
    }

    function getCard(cardId) {
        return $http.get(API_BASE + 'users/wallets/cards/' + cardId,{cache:true});
    }

    function getCardNoCache(cardId) {
        return $http.get(API_BASE + 'users/wallets/cards/' + cardId,{cache:false});
    }

    function getCardCvv(cardId){
        var httpCache = CacheFactory.get('walletCache');
        httpCache.remove(API_BASE + 'users/wallets/cards/' + cardId + '/securities/tokens');
        return $http.get(API_BASE + 'users/wallets/cards/' + cardId + '/securities/tokens',{cache:false});
    }

    // Add a card
    function cardCreate(data) {
        return $http({
        method: 'POST',
        url: API_BASE + 'users/wallets/cards/',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        transformRequest: function(obj) {
            var str = [];
            for(var p in obj) {
                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
            }
            return str.join('&');
        },
        data: data
        });
    }

    function cardVerify(cardtype, id, token, otp) {
        var key = rc4Factory.encode(token, otp.toString());
        return $http({
          method: 'PUT',
          url: API_BASE + 'users/wallets/cards/' + cardtype,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          transformRequest: function(obj) {
              var str = [];
              for(var p in obj) {
                  str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
              }
              return str.join('&');
          },
          data: {'id':id, 'key':key, 'token':token}
        });
    }

    function cardDelete() {
        // return $http({
        // method: 'POST',
        // url: API_BASE + 'users/wallets/cards/',
        // headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        // transformRequest: function(obj) {
        //     var str = [];
        //     for(var p in obj) {
        //       str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
        //     }
        //     return str.join('&');
        // },
        // data: data
        // });
    }
    /*
    * For Physical card order functionality
    */
    // To get the hash_id for the user
    function cardsOrdersList() {
        return $http.get(API_BASE + 'users/wallets/cards/orders',{cache:false});
    }

    // Place Card order
    function cardOrder(data){
        return $http({
        method: 'POST',
        url: API_BASE + 'users/wallets/cards/orders',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        transformRequest: function(obj) {
            var str = [];
            for(var p in obj) {
                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
            }
            return str.join('&');
        },
        data: data
      });
    }

    /** function to check the card order/purchase status for a given user
    * param cardtype: virtual/physical/empty
    * @return true - if user can get another card
    *         false - if user cannot get another card
    */
    function getAnotherCard(cardtype){
        var userStatus = userFactory.getUserPreOrPostKyc();

        var configObj = GET_ANOTHER_CARD;
        configObj = (angular.fromJson(configObj));
        var cardsSupported = jsonPath(configObj, '$.cardsSupported.*');
        //console.log(cardsSupported);
        var userCards = angular.fromJson(store.get('cards'));

        var physicalCards = [], virtualCards = [];
        cardsSupported.forEach(function(item, index){
            if(item.type == 'physical'){
                var phCards = jsonPath(userCards, '$..[?(@.type=="'+item.cardCode+'")]');
                var p;
                for(p in phCards){
                    physicalCards.push(phCards[p]);
                }
            }else{
                var vCards = jsonPath(userCards, '$..[?(@.type=="'+item.cardCode+'")]');
                var v;
               for (v in vCards){
                    virtualCards.push(vCards[v]);
               }
            }

        });

        var countPhysicalCards = parseInt(physicalCards.length);
        var countVirtualCards = parseInt(virtualCards.length);
        var totalCount = countVirtualCards + countPhysicalCards;
        var cardAllowed = false;
        if(cardtype === 'virtual'){
            // return the 'get another card' status for "virtual card" type for the user
            //preKyc check
            if(userStatus.userPreKyc){
                if(countVirtualCards >= configObj.preKyc.maxVirtualCards || configObj.preKyc.maxVirtualCards === 0){
                    cardAllowed = false;
                }else{
                    cardAllowed = true;
                }
            }
            // postKyc check
            if(userStatus.userPostKyc){
                if(countVirtualCards >= configObj.postKyc.maxVirtualCards || configObj.postKyc.maxVirtualCards == 0){
                    cardAllowed = false;
                }else{
                    cardAllowed = true;
                }
            }
        }else if(cardtype === 'physical'){
            //return the 'get another card' status for "physical card" type for the user
            if(userStatus.userPreKyc){
                if((countPhysicalCards >= configObj.preKyc.maxPhysicalCards) || configObj.preKyc.maxPhysicalCards == 0){
                    cardAllowed = false;
                }else{
                    cardAllowed = true;
                }
            }
            if(userStatus.userPostKyc){
                if(countPhysicalCards >= configObj.postKyc.maxPhysicalCards || configObj.postKyc.maxPhysicalCards == 0){
                    cardAllowed = false;
                }else{
                    cardAllowed = true;
                }
            }
        }else{
            // return the overall 'get another card' status for the user
            if(userStatus.userPreKyc){
                if(totalCount >= configObj.preKyc.totalCount || configObj.preKyc.totalCount == 0 ){
                    cardAllowed = false;
                }else{
                    cardAllowed = true;
                }
            }
            if(userStatus.userPostKyc){
                if(totalCount >= configObj.postKyc.totalCount ||  configObj.postKyc.totalCount == 0){
                    cardAllowed = false;
                }else{
                    cardAllowed = true;
                }
            }
        }
        //console.log(cardAllowed);
        return cardAllowed;
    }
    // to check the link enable/disable;
    function getAnotherCardLinkStatus(){
        var configObj = angular.fromJson(GET_ANOTHER_CARD);
        var linkEnabled = false;
        if('approved' == store.get('kycStatus') || (true == getAnotherCard())){
            linkEnabled = true;
        }
        return linkEnabled;
    }

    /**
    * function to check if user has zero cards and then allow/ disallow first card
    * based on the
    *   1. switch ON/OFF
    *   2. users compliance with the switch param
    *       eg: if CardDataSeekPoint email is ON, then user shud verify his email for acquiring his first card
    * pre-checks: check if user has any card presently, before applying the get-First-Card criteria
    */
    function getFirstCardFactory (){
        var userCards, userAuthStatus, user, kycStatus;

        var userCache = CacheFactory.get('userCache');
        user = angular.fromJson(userCache.get('user'));
        user = user.data;

        var authCache = CacheFactory.get('authCache');
        kycStatus = authCache.get('kycStatus');

        var addressCache = CacheFactory.get('addressCache');
        var billingAddress = addressCache.get('billing_address');
        var residentialAddress = addressCache.get('residential_address');

        var configGetFirstCard = angular.fromJson(GET_FIRST_CARD);

        var allowCard = {email: false, mobile:false, profile:false, addressInfo:false, kycStatus:false};

        // email switch ON, check if user email is verified
        if(configGetFirstCard.FirstCardDataSeekPoints.email.switch == 'ON'){
            // verify if user email is verified
            // console.log('email: '+ user.authentications.email_verified);
            if(user.authentications.email_verified){
                allowCard.email = true;
            }else{
                allowCard.email = false;
            }
        }

        // mobile switch ON, check if user mobile is verified
        if(configGetFirstCard.FirstCardDataSeekPoints.mobile.switch == 'ON'){
            // console.log('mob:'+ user.authentications.mobile_verified);
            if(user.authentications.mobile_verified){
                allowCard.mobile = true;
            }else{
                allowCard.mobile = false;
            }
        }

        // profile switch ON, check if user profile is available
        if(configGetFirstCard.FirstCardDataSeekPoints.profile.switch == 'ON'){
            // console.log('profile: '+ (user.identification && typeof user.identification  === 'object'));
            if(user.identification && typeof user.identification  === 'object'){
                allowCard.profile = true;
            }else{
                allowCard.profile = false;
            }
        }

        // address switch ON, check if user address - residential & billing are available
        if(configGetFirstCard.FirstCardDataSeekPoints.addressInfo.switch == 'ON'){
            // console.log('ad: '+ billingAddress && residentialAddress );
            if(billingAddress.data !== null && residentialAddress.data !== null){
                allowCard.addressInfo = true;
            }else{
                allowCard.addressInfo = false;
            }
        }

        // KYC switch ON, check if user is KYC compliant
        if(configGetFirstCard.FirstCardDataSeekPoints.KYC.switch == 'ON'){
            // console.log('kyc: '+ kycStatus == 'approved');
            if(kycStatus == 'approved'){
                allowCard.kycStatus = true;
            }else{
                allowCard.kycStatus = false;
            }
        }
        // console.log('allowCard::: ' + angular.toJson(allowCard));
        return allowCard;
    }

    // Add descriptions
    cardsList.description = 'Cards:cardsList';
    getCard.description = 'Cards:getCard';
    getCardNoCache.description = 'Cards:getCardNoCache';
    getCardCvv.description = 'Cards:getCardCvv';
    cardCreate.description = 'Cards:cardCreate';
    cardVerify.description = 'Cards:cardVerify';
    cardDelete.description = 'Cards:cardDelete';
    cardsOrdersList.description = 'Cards:cardsOrdersList';
    cardOrder.description = 'Cards:cardOrder';
    getAnotherCard.description = 'Cards:getAnotherCard';
    getAnotherCardLinkStatus.description = 'Cards:getAnotherCardLinkStatus';
    getFirstCardFactory.description = 'Cards:getFirstCardFactory';

    //public facing API
    return {
       cardsList: cardsList,
       getCard: getCard,
       getCardNoCache: getCardNoCache,
       getCardCvv: getCardCvv,
       cardCreate: cardCreate,
       cardVerify: cardVerify,
       cardDelete: cardDelete,
       cardsOrdersList: cardsOrdersList,
       cardOrder: cardOrder,
       getAnotherCard: getAnotherCard,
       getAnotherCardLinkStatus: getAnotherCardLinkStatus,
       getFirstCardFactory: getFirstCardFactory
    };
});
