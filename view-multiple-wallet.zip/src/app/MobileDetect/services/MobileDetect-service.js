'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.mobiledetect
 * @description
 * # mobiledetect
 * Service in the viewMultipleWallet.
 */
angular.module( 'viewMultipleWallet' )
    .service( 'mobiledetectService', function() {
        var md = new MobileDetect( window.navigator.userAgent );

        return {
            mobile: function() {
                return md.mobile() != null;
            },
            tablet: function() {
                return md.tablet() != null;
            },
            phone: function() {
                return md.phone() != null;
            }
        }
    } );