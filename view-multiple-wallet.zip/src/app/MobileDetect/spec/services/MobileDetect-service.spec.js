'use strict';
describe( 'Service: mobiledetectService', function() {
	var mobiledetect;
	beforeEach( module( 'viewMultipleWallet' ) );
	beforeEach( inject( function( _mobiledetectService_ ) {
		mobiledetect = _mobiledetectService_;
	} ) );
} );