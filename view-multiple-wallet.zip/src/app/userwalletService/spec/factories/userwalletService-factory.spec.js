'use strict';
describe('Factory: Wallet', function() {
	var wallet,
        httpBackend,
        http,
        walletService,
        scope,
        cookieStore,
        API_BASE;
beforeEach(module('viewMultipleWallet'));
// mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
 // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
 // Initialize factory
beforeEach(inject(function( _API_BASE_, _$http_, _walletService_, $rootScope, _$cookieStore_) {
    API_BASE = _API_BASE_;
    http = _$http_;
    walletService = _walletService_;
    scope = $rootScope.$new();
    cookieStore = _$cookieStore_;

    httpBackend.flush();
}));
  afterEach(function() {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
  });

angular.module("viewMultipleWallet").service("walletService",
        function($http, $rootScope, $cookieStore) {
            return {
                getWallet: function() {
                    return $http.get(API_BASE + 'users/wallets').then(function(response) {
                        return response;
                });
            },
            setWallet: function(data) {
                $rootScope.wallet = {
                    id:data
                };
                $cookieStore.put('wallet', $rootScope.wallet);
            }
        };
    });

describe('getWallet', function() {
    describe('when user doesnt have card', function() {
        it('it should return array with wallet details', function() {
            httpBackend.whenGET(API_BASE + 'users/wallets').respond(
                {
                    'wallet': {
                        'id': '3967eaf6053fbd652d162691dc110fd2',
                'number': '6501110007662669',
                'holder': {
                    'name': 'Shantanu'
                },
                'funds': {
                    'available': {
                        'currency': 'SGD',
                'amount': '5.35'
                    },
                'withholding': {
                    'currency': 'SGD',
                'amount': '0.00'
                }
                },
                'type': {
                    'type': 'mmvwallet',
            'name': 'MatchMove Virtual Wallet',
            'description': 'Matchmove Virtual Wallet'
                },
                'date': {
                    'expiry': '2023-11',
                    'issued': '2015-08-19'
                },
                'image': {
                    'small': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png',
                    'medium': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png',
                    'large': 'https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png'
                },
                'status': {
                    'is_active': true,
                    'text': 'active'
                },
                'links': [
                {
                    'rel': 'securities.tokens',
                    'href': API_BASE + 'users/wallets/cards/3967eaf6053fbd652d162691dc110fd2/securities/tokens',
                    'method': 'GET'
                },
                {
                    'rel': 'cards.transactions',
                    'href': API_BASE + 'users/wallets/cards/3967eaf6053fbd652d162691dc110fd2/transactions',
                    'method': 'GET'
                },
                {
                    'rel': 'cards.funds.transfers',
                    'href': API_BASE + 'users/wallets/cards/3967eaf6053fbd652d162691dc110fd2/funds/transfers',
                    'method': 'GET'
                }
            ]
                    }
                });

        walletService.getWallet().then(function(subreddits) {
            expect(Object.keys(subreddits.data.wallet)).toEqual([ 'id', 'number', 'holder', 'funds', 'type', 'date', 'image', 'status', 'links' ]);
        });
        scope.$digest();
        httpBackend.flush();
        });
    });

    describe('if the user has cards', function(){
        it('loops through the array of cards returned and appends it to a new key usercards.', function(){
            httpBackend.whenGET(API_BASE + 'users/wallets').respond(
                {
                    "wallet": {
                        "id": "3967eaf6053fbd652d162691dc110fd2",
                "number": "6501110007662669",
                "holder": {
                    "name": "Shantanu"
                },
                "funds": {
                    "available": {
                        "currency": "SGD",
                "amount": "5.35"
                    },
                "withholding": {
                    "currency": "SGD",
                "amount": "0.00"
                }
                },
                "type": {
                    "type": "mmvwallet",
            "name": "MatchMove Virtual Wallet",
            "description": "Matchmove Virtual Wallet"
                },
                "date": {
                    "expiry": "2023-11",
                    "issued": "2015-08-19"
                },
                "image": {
                    "small": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-small.png",
                    "medium": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-medium.png",
                    "large": "https://vcard-assets.s3.amazonaws.com/sg/product/mmvwallet/card-large.png"
                },
                "status": {
                    "is_active": true,
                    "text": "active"
                },
                "links": [
                {
                    "rel": "securities.tokens",
                    "href": API_BASE + "users/wallets/cards/3967eaf6053fbd652d162691dc110fd2/securities/tokens",
                    "method": "GET"
                },
                {
                    "rel": "cards.transactions",
                    "href": API_BASE + "users/wallets/cards/3967eaf6053fbd652d162691dc110fd2/transactions",
                    "method": "GET"
                },
                {
                    "rel": "cards.funds.transfers",
                    "href": API_BASE + "users/wallets/cards/3967eaf6053fbd652d162691dc110fd2/funds/transfers",
                    "method": "GET"
                }
            ],
                "usercards": [
                {
                    "id": "1234",
                    "number": "43210",
                    "holder": "",
                    "funds": "",
                    "type": "",
                    "date": "",
                    "image": "",
                    "status": "",
                    "links": []
                }

            ]
                    }
                });

        walletService.getWallet().then(function(wallets) {
            expect(wallets.data.wallet.hasOwnProperty('usercards')).toBeTruthy();
            expect(Array.isArray(wallets.data.wallet.usercards)).toBeTruthy();
        });
        scope.$digest();
        httpBackend.flush();
        });
    });

    describe('If there is any error', function(){
        it('should return error object', function(){
            httpBackend.whenGET(API_BASE + 'users/wallets').respond({
                'responseStatus': 503
            });
            walletService.getWallet().then(function(wallets) {
                expect(wallets.data.hasOwnProperty('responseStatus')).toBeTruthy();
                expect(wallets.data.responseStatus).toEqual(503);
            });
            scope.$digest();
            httpBackend.flush();
        });
    });
 });

describe('setWallet', function(){
    it('should store the user wallet id in cookie, with set expiry',function() {
        cookieStore.remove('wallet');
        walletService.setWallet({ 'id': 1, 'set_expiry': 123213 });
        var test_wallet = cookieStore.get('wallet');
        expect(test_wallet.id.id).toBeDefined()
        expect(test_wallet.id.set_expiry).toBeDefined()
        expect(test_wallet.id.id).toBe(1);
        expect(test_wallet.id.set_expiry).toBe(123213);
    });
});
});
