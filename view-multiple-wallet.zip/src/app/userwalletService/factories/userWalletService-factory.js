'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authService
 * @description
 * # authService
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .factory('Wallet', function (API_BASE, $http, $q, store, CacheFactory) {

    // Service logic
    function getWallet(cache) {
        var walletCache = CacheFactory.get('walletCache');

        // cache is true -> serve the data from angular-cache
        // else make a Service call to get data
        var deferred = $q.defer();
        var items, cacheFlag;
        if(cache === true) {
            cacheFlag = walletCache;
            var wallet;
            if(walletCache && walletCache.get('userWallet')){
                wallet = walletCache.get('userWallet');
                deferred.resolve(wallet);
                return deferred.promise;
            }else{
                cacheFlag = false;
            }
        }else{
            cacheFlag = false;
        }

        $http({
                method: 'GET',
                url: API_BASE + 'users/wallets',
                cache:cacheFlag
            })
            .then(function(data, status, headers, config){
                // var walletCache = CacheFactory.get('walletCache');
                    //data.data = walletInfo
                    var wallet = data.data, i = 0;
                    if (wallet === null){
                      deferred.reject(response);
                    }
                    store.set('wallet',wallet.id);
                    wallet.walletBalance = 0;
                    wallet.walletBalance = parseFloat(wallet.funds.available.amount);
                    if (wallet.hasOwnProperty('cards')) {
                        var items = wallet.cards.length;
                        var promises = [], i = 0;
                        // set up promise array
                        for (i; i < items; i++) {
                            promises.push($http.get(wallet.cards[i].links[0].href, {cache:cacheFlag})
                                .then(function(data){return data.data}));
                        }
                        // reset loop counter
                        i = 0;
                        var itemcards = [];
                        // check for all promises resolved/NOT
                        $q.all(promises).then(function(respAll){
                            // process response array
                            var respLength = respAll.length;
                            wallet.usercards = [];
                            for(i; i < respLength; i++){
                                var card = respAll[i];

                                if (card.funds.available.amount.length) {
                                    wallet.walletBalance += parseFloat(card.funds.available.amount);
                                }
                                // Check if the card is active , Push only active / suspended cards to the array
                                if(!(card.status.text === 'stolen' || card.status.text === 'lost' || card.status.text === 'damaged')) {
                                  wallet.usercards.push(card);
                                  itemcards.push({'id':card.id,'type':card.type.type, 'name': card.type.name, 'number': card.number });
                                }
                            }
                            store.set('cards', itemcards);
                            walletCache.remove('userWallet');
                            walletCache.put('userWallet', wallet);
                            deferred.resolve(wallet);
                        });
                    }
                    else {
                        if(walletCache){walletCache.remove('userWallet');}
                        walletCache.put('userWallet', wallet);
                        deferred.resolve(wallet);
                    }
                },function(response){
                    deferred.reject(response);
                });
            return deferred.promise;
    }
    // add function descriptions
    getWallet.description = 'Wallet:getWallet';
    // Public facing api
    return {
        getWallet: getWallet
    };
});
