'use strict';
/**
 * @ngdoc directive
 * @name viewMultipleWallet.directive:sideBar
 * @description
 * # sideBar
 */
angular.module('viewMultipleWallet')
    .directive('sideBar', function (userFactory, usersloyaltyfactoryFactory, store, $rootScope, ngDialog) {
        return {
            templateUrl: 'app/sideBar/partials/sideBar-directive.html',
            restrict: 'E',
            scope: false,
            controller: function ( $scope, $rootScope, $state, authenticationFactory, helperFactory, store, userFactory, LOYALTY_PARAMS, ACCOUNT_DETAILS_PARAMS, PubSub ) {
                $scope.loyaltyParams = angular.fromJson(LOYALTY_PARAMS),
                $scope.loyaltyEnabled = $scope.loyaltyParams.enabled;

                $scope.profileImagePresent = angular.fromJson(ACCOUNT_DETAILS_PARAMS).has_profile_image;

                $scope.hasProfileImage = false;
                $scope.currentUser =  userFactory.getCurrentUser();
                $scope.callUploadBox = function() {
                  ngDialog.open({
                    template: 'app/profileUpload/partials/profileUpload.html',
                    className: 'profile-dialog',
                    controller: 'profileUploadCtrl',
                    scope: $scope
                  });
                };
                $scope.updateProfileImage = function(){
                  userFactory.getUser(false)
                    .then(function(response) {
                        userFactory.setCurrentUser(response.data);
                        if (response.data.profile_image) {
                          $scope.hasProfileImage = true;
                          $scope.profileImage = response.data.profile_image;
                        }
                    });
                }
                PubSub.subscribe( 'update-sidebarProfileImage', $scope.updateProfileImage );
                if ($scope.currentUser !== null) {
                    $scope.user = $scope.currentUser.name.preferred;
                    userFactory.getUser(true)
                    .then(function(response) {
                        userFactory.setCurrentUser(response.data);
                        if (response.data.profile_image) {
                          $scope.hasProfileImage = true;
                          $scope.profileImage = response.data.profile_image;
                        }
                    });
                }
                if(store.inMemoryCache.cards !== undefined && store.inMemoryCache.cards !== null) {
                    if (store.inMemoryCache.cards.length) {
                        $scope.totalCards = store.inMemoryCache.cards.length;
                    } else {
                        $scope.totalCards = 0;
                    }
                } else {
                    $scope.totalCards = 0;
                }
                if($scope.loyaltyEnabled) {
                    usersloyaltyfactoryFactory.history()
                      .then(function(resp){
                          $scope.totalPoints = parseInt(resp.data.total_points);
                      },function(err){

                      });
                }
                $rootScope.$on( 'authorized', function () {
                    $scope.showLogin = false;
                } );

                $rootScope.$on( 'noauthorized', function () {
                    $scope.showLogin = true;
                } );
                if ( !$rootScope.globals.currentUser ) {
                    $scope.showLogin = true;
                    $scope.logoUrl = '/';
                } else {
                    $scope.showLogin = false;
                    $scope.logoUrl = '/wallet/home';
                    $scope.currentUser = userFactory.getCurrentUser();
                    $scope.user = $scope.currentUser.name.first;
                }

                $scope.itemSidebar = [ {
                    name: 'COMPONENT.MENUBAR.MY_CARDS',
                    path: 'wallet.home',
                    icon: 'mcw-menu-dashboard'
                }, {
                    name: 'COMPONENT.MENUBAR.TOPUP',
                    path: 'wallet.topup.select',
                    icon: 'mcw-menu-topup'
                }, {
                    name: 'COMPONENT.MENUBAR.REMIT',
                    path: 'wallet.remit.select',
                    icon: 'mcw-menu-remit'
                }, {
                    name: 'COMPONENT.MENUBAR.SEND',
                    path: 'wallet.send.select',
                    icon: 'mcw-menu-send'
                }, {
                    name: 'COMPONENT.MENUBAR.CLAIM',
                    path: 'wallet.fund.claim',
                    icon: 'mcw-menu-claim'
                }, {
                    name: 'COMPONENT.MENUBAR.HISTORY',
                    path: 'wallet.transaction',
                    icon: 'mcw-menu-history'
                }, {
                    name: 'COMPONENT.MENUBAR.OFFERS',
                    path: 'wallet.offers.list',
                    icon: 'mcw-menu-offers'
                }, {
                    name: 'COMPONENT.MENUBAR.SUSPEND',
                    path: 'wallet.suspend',
                    icon: 'mcw-menu-suspend'
                }, {
                    name: 'COMPONENT.MENUBAR.ACCOUNT',
                    path: 'wallet.details.my',
                    icon: 'mcw-menu-account'
                }, {
                    name: 'COMPONENT.MENUBAR.GET_ANOTHER_CARD',
                    path: 'wallet.card.new',
                    icon: 'mcw-menu-getcard'
                }, {
                    name: 'COMPONENT.MENUBAR.LOGOUT',
                    path: 'auth.login',
                    icon: 'mcw-menu-logout'
                } ];
                if($scope.loyaltyEnabled){
                  $scope.itemSidebar.splice(7, 0, {
                    name: 'COMPONENT.MENUBAR.LOYALTY',
                    path: 'wallet.loyalty.list',
                    icon: 'mcw-menu-loyalty'
                  });
                }
                $scope.logout = function () {
                    var cards = store.get( 'cards' );
                    authenticationFactory.ClearCredentials();
                    helperFactory.clearCacheTransfer( cards );
                    $state.go( 'auth.login' );
                };
            },
            link: function () {}
        };
    } );
