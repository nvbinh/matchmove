'use strict';
describe('Directive: sideBar', function () {
    // load the directive's module
    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( 'LOYALTY_PARAMS', {
            "enabled": true,
            "denomination": "MMV Points",
            "preKyc": {
                "allowed": true,
                "claimAllowed": false
            },
            "postKyc": {
                "allowed": true,
                "claimAllowed": true
            }
        } );
    } ) );
    var scope, element, compile, API_BASE, httpBackend;
    // langugage based mock calls
      beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
          httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
      } ) );
      afterEach( function() {
          httpBackend.flush();
          httpBackend.verifyNoOutstandingExpectation();
          httpBackend.verifyNoOutstandingRequest();
      } );

    beforeEach(inject(function ($rootScope, $compile, $httpBackend, TRANSLATION_PARAMS, _API_BASE_) {

        element = angular.element('<side-bar></side-bar>');
        scope = $rootScope.$new();
        compile = $compile;
        API_BASE = _API_BASE_;
        httpBackend.whenGET(API_BASE + 'loyalty').respond(200, '');
        httpBackend.whenGET(API_BASE + 'users').respond(200, {"name":{"preferred":"Person Name"}});
    }));
    it('should attach a list of itemSidebar to the scope', function () {
        var compiledElement, list;
        compiledElement = compile(element)(scope);
        scope.$digest();
        expect(element)
            .not.toBe(null);
        list = compiledElement.find('li');
        expect(list.length)
            .toBeGreaterThan(0);
    });
    it('should have name, path and icon', function () {
        var compiledElement, list, anchor, path;
        compiledElement = compile(element)(scope);
        scope.$digest();
        list = compiledElement.find('li');
        anchor = list.find('a');
        expect(anchor.length).toBe(12);
        path = anchor.attr('ui-sref');
        expect(path).not.toBe(null);
        expect(list.text()).not.toBe(null);
    });
});
