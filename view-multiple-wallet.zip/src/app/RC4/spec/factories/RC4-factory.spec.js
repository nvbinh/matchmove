'use strict';

describe('Factory: rc4Factory', function() {
  var rc4;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_rc4Factory_) {
    rc4 = _rc4Factory_;
  }));

  // it('should provide the meaning of life', function() {
    // expect(rc4.someMethod() == 42).toBeTruthy();
  // });
  it('should encode', function(){
      var encoded = rc4.encode('test', 'test');
      expect(encoded).toBeDefined;
      expect(encoded).toEqual('w5rDqlRl');
  });

});
