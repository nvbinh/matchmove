'use strict';
describe('Factory: PreFormatters', function() {
  var preFormatters;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_PreFormatters_) {
    preFormatters = _PreFormatters_;
  }));

  it('should clear delimiters and leading zeroes', function() {
    expect(preFormatters.clearDelimitersAndLeadingZeros('00123,234,345.67')).toBe('12323434567');
  });
  it('verify fn prepareNumberToFormatter',  function(){
    var res = preFormatters.prepareNumberToFormatter(1234567.89, 2);
    expect(res).toBe('123456789');
  });
});

describe('Factory: NumberMasks', function(){
    var numberMasks;
    beforeEach(module('viewMultipleWallet'));
      beforeEach(inject(function(_NumberMasks_) {
        numberMasks = _NumberMasks_;
      }));
    it('verify fn viewMask', function(){
        var res = numberMasks.viewMask(2, ',', '.');
        expect(res.pattern).toBe("#.##0,00");
    });
    it('verify fn modelMask', function(){
        var res = numberMasks.modelMask();
        expect(res.pattern).toBe("###0");
    });
})
