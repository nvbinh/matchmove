'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.userswalletscardsfunds
 * @description
 * # userswalletscardsfunds
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .service('userswalletscardsfundsFactory', function (API_BASE, $http, $q) {
        // Service logic
        function loadCard(id, amount) {
            var data = {};
            data.message = 'Load Card';
            data.amount = amount;
            return $http({
                method: 'POST',
                url: API_BASE + 'users/wallets/cards/' + id + '/funds',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj) {
                        str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                    }
                    return str.join('&');
                },
                data: data
            });
        };

        function unloadCard(id, amount) {
            var data = {};
            data.message = 'Unload Card';
            data.amount = amount;
            return $http({
                method: 'DELETE',
                url: API_BASE + 'users/wallets/cards/' + id + '/funds',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj) {
                        str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                    }
                    return str.join('&');
                },
                data: data
            });
        };

        function transferFund(ref) {
            var id = ref.email || ref.mobile_number; // jshint ignore:line
            return $http({
                method: 'POST',
                url: API_BASE + 'users/wallets/funds',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj) {
                        str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                    }
                    return str.join('&');
                },
                data: ref
            });
        };

        function claimFund(id) {
            return $http({
                method: 'PUT',
                url: API_BASE + 'users/wallets/funds/' + id,
            });
        };

        function checkFund(id) {
            return $http({
                method: 'GET',
                url: API_BASE + 'users/wallets/cards/' + id + '/funds/transfers',
            });
        };


        function getFundTransferList(data) {
            var defer = $q.defer();
            $http({
                    method: 'GET',
                    url: API_BASE + 'users/wallets/funds/transfers',
                    params: data
                })
                .then(function (resp) {
                    defer.resolve(resp);
                });
            return defer.promise;
        }

        function cancelFund(id) {
            return $http({
                method: 'DELETE',
                url: API_BASE + 'users/wallets/funds/' + id,
            });
        };

        // Add descriptions
        loadCard.description = 'userswalletscardsfundsFactory:loadCard';
        unloadCard.description = 'userswalletscardsfundsFactory:unloadCard';
        transferFund.description = 'userswalletscardsfundsFactory:transferFund';
        claimFund.description = 'userswalletscardsfundsFactory:claimFund';
        checkFund.description = 'userswalletscardsfundsFactory:checkFund';
        getFundTransferList.description = 'userswalletscardsfundsFactory:getFundTransferList';
        cancelFund.description = 'userswalletscardsfundsFactory:cancelFund';

        // Public API here
        return {
            loadCard: loadCard,
            unloadCard: unloadCard,
            transferFund: transferFund,
            claimFund: claimFund,
            checkFund: checkFund,
            getFundTransferList: getFundTransferList,
            cancelFund: cancelFund
        };
    });
