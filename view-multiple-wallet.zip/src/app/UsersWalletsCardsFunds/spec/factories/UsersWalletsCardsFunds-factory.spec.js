'use strict';

describe('Factory: userswalletscardsfundsFactory', function () {
    var userswalletscardsfunds,
        httpBackend,
        API_BASE,
        cardLoadResp,
        cardUnloadResp,
        checkFundResp,
        listOptions,
        transferResp;

    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
        httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).source + '"' + window.navigator.language + '".json' ).respond( 200, '' );
    } ) );
    // Initialize Factory
    beforeEach(inject(function (_userswalletscardsfundsFactory_, _API_BASE_) {
        userswalletscardsfunds = _userswalletscardsfundsFactory_;
        API_BASE = _API_BASE_;

        cardLoadResp = angular.toJson({
            "id": "5ac0ba48aa83929537ce1a62ce6747d8",
            "recipient": {
                "id": "464d9a323e583498f76860aef89a32b3",
                "type": "card"
            },
            "status": "active",
            "amount": "11.00",
            "currency": "SGD",
            "date": {
                "created": "2016-02-10T11:21:11+08:00",
                "expiry": "2016-02-17T11:21:11+08:00"
            }
        });
        cardUnloadResp = angular.toJson({
            "id": "f339ae072e4bd270da2b1af5d71cd4f6",
            "recipient": {
                "id": "dfa7916f06e9640daeb0bbe413012659",
                "type": "card"
            },
            "status": "active",
            "amount": "5.00",
            "currency": "SGD",
            "date": {
                "created": "2016-02-10T11:24:36+08:00",
                "expiry": "2016-02-17T11:24:36+08:00"
            }
        });
        checkFundResp = angular.toJson({
            "transfers": [{
                "id": "5ac0ba48aa83929537ce1a62ce6747d8",
                "recipient": {
                    "type": "card",
                    "id": "464d9a323e583498f76860aef89a32b3"
                },
                "status": "active",
                "amount": 11,
                "currency": "SGD",
                "fees": [],
                "date": {
                    "created": "2016-02-10T11:21:11+08:00",
                    "expiry": "2016-02-17T11:21:11+08:00"
                }
            }, {
                "id": "f339ae072e4bd270da2b1af5d71cd4f6",
                "recipient": {
                    "type": "card",
                    "id": "dfa7916f06e9640daeb0bbe413012659"
                },
                "status": "active",
                "amount": 5,
                "currency": "SGD",
                "fees": [],
                "date": {
                    "created": "2016-02-10T11:24:36+08:00",
                    "expiry": "2016-02-17T11:24:36+08:00"
                }
            }],
            "count": {
                "total": 2
            }
        });
        listOptions = {
            type: 'credit',
            status: 'active',
            sort: '-date.added'
        };
        transferResp = angular.toJson({
            "transfers": [{
                "id": "ac283557fdeeff57d123dd626f1c7cd0",
                "sender": {
                    "type": "email",
                    "id": "000000037616",
                    "email": "balajiv+12@chimeratechnologies.com"
                },
                "recipient": {
                    "type": "email",
                    "id": "000000018625",
                    "email": "balaji_b_v@yahoo.com"
                },
                "message": "fegege tjtyuty",
                "status": "active",
                "amount": 10,
                "currency": "SGD",
                "fees": [],
                "date": {
                    "created": "2016-02-04T13:25:56+08:00",
                    "expiry": "2016-02-11T13:25:56+08:00"
                },
                "link": {
                    "rel": "claim",
                    "href": API_BASE + "users/wallets/funds/ac283557fdeeff57d123dd626f1c7cd0",
                    "method": "PUT"
                }
            }, {
                "id": "6a24c13129edf0d7515f50f203e5e7a7",
                "sender": {
                    "type": "email",
                    "id": "000000037616",
                    "email": "balajiv+12@chimeratechnologies.com"
                },
                "recipient": {
                    "type": "email",
                    "id": "000000018625",
                    "email": "balaji_b_v@yahoo.com"
                },
                "message": "dsfdsjk jdshfsd h",
                "status": "active",
                "amount": 10,
                "currency": "SGD",
                "fees": [],
                "date": {
                    "created": "2016-02-04T13:24:37+08:00",
                    "expiry": "2016-02-11T13:24:37+08:00"
                },
                "link": {
                    "rel": "claim",
                    "href": API_BASE + "users/wallets/funds/6a24c13129edf0d7515f50f203e5e7a7",
                    "method": "PUT"
                }
            }],
            "count": {
                "total": 2
            }
        });
        httpBackend.whenPOST(API_BASE + 'users/wallets/funds')
            .respond(200, '');
        httpBackend.whenPOST(API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds")
            .respond(200, cardLoadResp);
        httpBackend.whenDELETE(API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds")
            .respond(200, cardUnloadResp);
        httpBackend.whenGET(API_BASE + "users/wallets/cards/464d9a323e583498f76860aef89a32b3/funds/transfers")
            .respond(200, checkFundResp);
        httpBackend.whenGET(API_BASE + 'users/wallets/funds/transfers?sort=-date.added&status=active&type=credit')
            .respond(200, transferResp);
        httpBackend.whenPUT(API_BASE + "users/wallets/funds/6a24c13129edf0d7515f50f203e5e7a7")
            .respond(200, 'Fund claimed successfully');
        httpBackend.whenDELETE(API_BASE + "users/wallets/funds/6a24c13129edf0d7515f50f203e5e7a7")
            .respond(200, 'Fund transfer cancelled successfully');
        httpBackend.flush();
    }));
    afterEach(function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    });

    it('can transferFund and return a response', function () {
        userswalletscardsfunds.transferFund({
                mobile_number: 123
            })
            .then(function (response) {
                expect(response.data)
                    .toBeDefined();
            });
        httpBackend.flush();
    });
    it('should check the card load function', function () {
        userswalletscardsfunds.loadCard('464d9a323e583498f76860aef89a32b3', 11)
            .then(function (response) {
                expect(response.data)
                    .toBeDefined();
                expect(response.data.amount)
                    .toEqual("11.00");
            });
        httpBackend.flush();
    });
    it('should unload the card', function () {
        userswalletscardsfunds.unloadCard('464d9a323e583498f76860aef89a32b3', 5)
            .then(function (response) {
                expect(response.data)
                    .toBeDefined();
                expect(response.data.amount)
                    .toEqual("5.00");
            });
        httpBackend.flush();
    });
    it('should get a card fund details', function () {
        userswalletscardsfunds.checkFund('464d9a323e583498f76860aef89a32b3')
            .then(function (response) {
                expect(response.data)
                    .toBeDefined();
                expect(response.data.transfers[0].amount)
                    .toEqual(11);
            });
        httpBackend.flush();
    });
    it('should verify fund claim', function () {
        userswalletscardsfunds.claimFund('6a24c13129edf0d7515f50f203e5e7a7')
            .then(function (response) {
                expect(response.data)
                    .toBe('Fund claimed successfully');
            });
        httpBackend.flush();
    });
    it('should verify cancellation of fund transfer ', function () {
        userswalletscardsfunds.cancelFund('6a24c13129edf0d7515f50f203e5e7a7')
            .then(function (response) {
                expect(response.data)
                    .toBe('Fund transfer cancelled successfully');
            });
        httpBackend.flush();
    });
});
