'use strict';

/**
 * Logging in with email and password
 * Handling callback to server for check user
 * Saving user to cookie after login
 * Logging out (removing user object as well as cookie)
 * TODO :: add cookiestore test specs when the same functionality is added to the authFactory file
 */

describe( 'Factory: authenticationFactory', function() {
	var authentication,
		cookieStore,
		API_BASE,
		scope,
		token,
		HTTP_HOST,
		EMAIL_VERIFICATION_URL,
		base64Factory,
		httpBackend;

	beforeEach( module( 'viewMultipleWallet' ) );
	// mock constants
	beforeEach( module( 'viewMultipleWallet', function( $provide ) {
		$provide.constant( "TRANSLATION_PARAMS", {
			"partFilesPath": "../assets/locales/",
			"preferredLanguage": "vi_vn",
			"client": "hdb",
			"source": "http://localhost:3000/assets/hdb/locales\/",
			"supportedLanguages": [ {
				"i18n": "en_us",
				"name": "English"
			}, {
				"i18n": "vi_vn",
				"name": "Vietnamese"
			} ]
		} );
	} ) );
	// langugage based mock calls
	beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
		httpBackend = $httpBackend;
		var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
		for ( var i = 0; i < lngth; i++ ) {
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
			httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
		}
	} ) );
	//  Initialize the controller and a mock scope
	beforeEach( inject( function( _authenticationFactory_, $cookieStore, API_BASE, _base64Factory_, $rootScope, $http, $q, HTTP_HOST, EMAIL_VERIFICATION_URL ) {
		authentication = _authenticationFactory_;

		cookieStore = $cookieStore;
		API_BASE = API_BASE;
		HTTP_HOST = HTTP_HOST;
		EMAIL_VERIFICATION_URL = EMAIL_VERIFICATION_URL;
		base64Factory = _base64Factory_;
		scope = $rootScope;
		authentication.ClearCredentials(); // to remove any previous user settings/credentials
		httpBackend.flush();
	} ) );

	afterEach( function() {
		httpBackend.verifyNoOutstandingExpectation();
		httpBackend.verifyNoOutstandingRequest();
	} );

	it( 'should have authentication service be defined', function() {
		expect( authentication ).toBeDefined();
	} );

	it( 'should not have a user existing upon starting up', function() {
		var username = null,
			password = null;
		window.onload = function() {
			expect( username ).toBe( null );
			expect( password ).toBe( null );
		}
	} );

	describe( ' - authentication Functions', function() {
		var username,
			password,
			secret;
		beforeEach( inject( function( $httpBackend, API_BASE, $rootScope, $q ) {
			scope = $rootScope.$new();
			username = 'test1@nomail.com',
				password = 'abcd1234',
				secret = 'dGVzdDFAbm9tYWlsLmNvbTphYmNkMTIzNA==';

			authentication.Login = function() {
				var deferred = $q.defer();
				deferred.resolve( {
					data: {
						key: 'test1@nomail.com',
						secret: 'dGVzdDFAbm9tYWlsLmNvbTphYmNkMTIzNA=='
					}
				} );
				return deferred.promise; //
			};

			authentication.LoginError = function() {
				var deferred = $q.defer();
				//deferred.resolve({data:{key:'error', secret: 'error'}});
				return $q.reject( 'auth reject' ); //
			};
		} ) );

		it( ' - User auth token is generated correctly', function() {
			authentication.Login().then( function( data, status, headers, config ) {
				expect( data.data.key ).toBe( username );
			} );
		} );
		it( ' - User is set in store after successful login', function() {
			authentication.Login().then( function( data, status, headers, config ) {
				authentication.SetCredentials( data.data.key, password );
				expect( scope.globals.currentUser.username ).toBe( username );
				expect( scope.globals.currentUser.authdata ).toBeDefined();
			} );
		} );

		it( ' - User is cleared in store when logout', function() {
			authentication.Login().then( function( data, status, headers, config ) {
				// set credentials
				authentication.SetCredentials( data.data.key, password );
				expect( scope.globals.currentUser.username ).toBe( username );
				expect( scope.globals.currentUser.authdata ).toBeDefined();
				// clear credentials
				authentication.ClearCredentials( username, password );
				expect( scope.globals ).toEqual( {} );
			} );
		} );

		it( ' - User Login error auth rejected', function() {
			authentication.LoginError().then( function( data ) {

			}, function( error ) {
				expect( error ).toEqual( 'auth reject' );
			} );
		} );
	} );
} );