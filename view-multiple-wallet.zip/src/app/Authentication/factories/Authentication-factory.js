'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authentication
 * @description
 * # authentication
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .factory('authenticationFactory', function (base64Factory, $http, $cookieStore, $rootScope, API_BASE, $log, userFactory, Wallet, CacheFactory, store) {

    // Service logic
    function Login(username, password) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + base64Factory.encode(username + ':' + password);// jshint ignore:line
        $http.defaults.headers.post['Authorization'] = 'Basic ' + base64Factory.encode(username + ':' + password); // jshint ignore:line
        return $http.post(API_BASE + 'auth', { username: username, password: password });
    }

    function SetCredentials(username, password) {
        var authdata = base64Factory.encode(username + ':' + password);
        $rootScope.globals = {
            currentUser: {
                username: username,
                authdata: authdata
            }
        };
        store.set('globals', $rootScope.globals);

        $http.defaults.headers.common['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
        $http.defaults.headers.post['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
        $http.defaults.headers.put['Authorization'] = 'Basic ' + authdata; // jshint ignore:line

    }

    function ClearCredentials() {
        $rootScope.globals = {};
        store.remove('globals');
        //var httpCache = CacheFactory.get('httpCache');
        var walletCache = CacheFactory.get('walletCache');
        var userCache = CacheFactory.get('userCache');
        var authCache = CacheFactory.get('authCache');
        var addressCache = CacheFactory.get('addressCache');
        store.remove('user');
        store.remove('wallet');
        store.remove('cards');
        store.remove('notify');
        store.remove('globals');
        store.remove('kycStatus');
        store.remove('orderPhysicalCard');
        store.remove('auth');
        store.remove('userWallet');
        store.remove('billing_address');
        store.remove('residential_address');
        store.remove('allowOrderPhysicalCard');
        store.remove('lang_locale');
        store.remove('NG_TRANSLATE_LANG_KEY');
        if(walletCache){walletCache.removeAll();}
        if(authCache){authCache.removeAll();}
        if(addressCache){addressCache.removeAll();}
        if(userCache){
            userCache.remove('user');
            userCache.remove(API_BASE + 'users');
        }

        //httpCache.removeAll();
        $http.defaults.headers.common.Authorization = 'Basic';
    }

    // Descriptions
    Login.description = 'authenticationFactory:Login';
    SetCredentials.description = 'authenticationFactory:SetCredentials';
    ClearCredentials.description = 'authenticationFactory:ClearCredentials';

    // Public facing API
    return {
        Login: Login,
        ClearCredentials: ClearCredentials,
        SetCredentials: SetCredentials
    };
});
