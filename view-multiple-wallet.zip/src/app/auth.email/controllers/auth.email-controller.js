'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authEmailCtrl
 * @description
 * # authEmailCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authEmailCtrl', function () {

    } );
