'use strict';
describe( 'Controller: authEmailCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    var authEmailCtrl,
        scope;
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope ) {
        scope = $rootScope.$new();
        authEmailCtrl = $controller( 'authEmailCtrl', {} );
    } ) );
} );
