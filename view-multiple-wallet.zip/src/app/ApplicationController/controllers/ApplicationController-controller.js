'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:applicationcontrollerCtrl
 * @description
 * # applicationcontrollerCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'applicationcontrollerCtrl', function ( API_BASE, $scope, $log, $rootScope, $state, CacheFactory, $window, store, Idle, Keepalive, ngDialog, $timeout, LOG_DEBUG, ngProgressFactory, helperFactory, $translate, $translateLocalStorage ) {
        $scope.started = false;

        // set the selectedLanguage
        store.set('selectedLang', $translate.use());

        /*
        Helper Function to trigger modal closure irrespective of the state which is active
        */
        function closeModals() {
            ngDialog.closeAll();
            if ( $scope.warning ) {
                $scope.warning.close();
                $scope.warning = null;
            }

            if ( $scope.timedout ) {
                $scope.timedout.close();
                $scope.timedout = null;
            }
        }

        function clearUser() {
            $state.go( 'auth.login' );
            //var httpCache = CacheFactory.get('httpCache');
            var walletCache = CacheFactory.get( 'walletCache' );
            var userCache = CacheFactory.get( 'userCache' );
            var authCache = CacheFactory.get('authCache');
            var addressCache = CacheFactory.get('addressCache');
            store.remove( 'auth' );
            store.remove( 'user' );
            store.remove( 'wallet' );
            store.remove( 'cards' );
            store.remove( 'notify' );
            store.remove( 'kycStatus' );
            store.remove( 'globals' );
            store.remove('billing_address');
            store.remove('residential_address');
            store.remove('allowOrderPhysicalCard');
            store.remove('lang_locale');
            store.remove('NG_TRANSLATE_LANG_KEY');
            //httpCache.removeAll();
            /*httpCache.remove(API_BASE + 'users');
            httpCache.remove(API_BASE + 'users/wallets');
            httpCache.remove(API_BASE + 'users/notifications');
            httpCache.remove(API_BASE + 'users/wallets/funds/transfers');
            httpCache.remove(API_BASE + 'users/authentications/documents');*/
            //httpCache.destroy();
            if(walletCache){walletCache.removeAll();}
            if(authCache){authCache.removeAll();}
            if(addressCache){addressCache.removeAll();}
            if(userCache){
                userCache.remove( API_BASE + '/users' );
                userCache.remove( 'userCache' );
            }
        }
        $rootScope.$on( 'unauthorized', function () {
            clearUser();
            closeModals();
            if ( $rootScope.loaded === undefined ) {
                $rootScope.loaded = true;
                ngDialog.open( {
                    template: 'app/components/timeoutModal/partials/timeoutModal.html',
                    className: 'dialog-timeout',
                    controller: 'timeoutModalCtrl',
                    scope: $scope
                } );
            }
        } );
        $scope.progressbar = ngProgressFactory.createInstance();

        $rootScope.$on( '$stateChangeStart', function ( event, toState, toParams, fromState, fromParams, options ) {
            if ( LOG_DEBUG ) {
                $log.debug( '$stateChangeStart: from - ' + fromState.name + ' to - ' + toState.name );
            }
            // This code is to prevent from showing a blank page when the user taps on the bottom menu bar 'Account'
            // menu item repeatedly
            if((fromState.name === 'wallet.details.my.list' || fromState.name === 'wallet.details.my.complete')
             && toState.name === 'wallet.details.my'){
                event.preventDefault();
                return;
            };
            $scope.progressbar.setColor( '#fff' );
            $scope.progressbar.start();
        } );

        $rootScope.$on( '$stateChangeSuccess', function ( event, toState, toParams, fromState, fromParams ) {
            if ( LOG_DEBUG ) {
                $log.debug( '$stateChangeSuccess: from - ' + fromState.name + ' to - ' + toState.name );
            }
            store.set( 'controller', toState.controller );
            $rootScope.curStateName = toState.name;

            var varKey = helperFactory.mapControllerToPageTitle( $rootScope.curStateName );
            $rootScope.pagetitle = $translate.instant( 'PAGE_TITLE_TEXT', {
                pagename: $translate.instant( varKey )
            } );
            // $timeout( function () {
            //     angular.element( '.content-main' ).css( 'opacity', 1 );
            //     angular.element( '.loading-container' ).hide();
            //     $scope.loadingTextMsg = '';
            // }, 300 );
            $timeout( function () {
                $scope.progressbar.complete();
            }, 300 );
            $rootScope.isLoading = false;

        } );

        $rootScope.$on( '$stateChangeError', function ( event, toState, toParams, fromState, fromParams, error ) {
            if ( LOG_DEBUG ) {
              var err = error.config;
              $log.debug( '$stateChangeError: from - ' + fromState.name + ' to - ' + toState.name + ' : errObject - ' + angular.toJson(err) );
            }

            $scope.isLoading = false;
            $rootScope.loaded = true;
            $rootScope.backendError = true;
            $rootScope.backEndErrorMessagetext = $rootScope.errorHandler.errors[ 0 ];
            $timeout( function() {
                angular.element( '.content-main' ).css( 'opacity', 1 );
                angular.element( '.loading-container' ).hide();
                $scope.loadingTextMsg = '';
            }, 0 );
        } );

        // $window.addEventListener('beforeunload',function(event){
        //     clearUser();
        // });
        // $scope.$on('IdleStart', function() {
        // // the user appears to have gone idle
        // $scope.warning = ngDialog.open({
        //     preCloseCallback: function(value) {
        //         var nestedConfirmDialog = ngDialog.openConfirm({
        //             template:'\
        //                 <p>Are you sure you want to close the parent dialog?</p>\
        //                 <div class="ngdialog-buttons">\
        //                     <button type="button" class="ngdialog-button ngdialog-button-secondary" ng-click="closeThisDialog(0)">No</button>\
        //                     <button type="button" class="ngdialog-button ngdialog-button-primary" ng-click="confirm(1)">Yes</button>\
        //                 </div>',
        //             plain: true
        //         });

        //         // NOTE: return the promise from openConfirm
        //         return nestedConfirmDialog;
        //     }
        // });
        // });

        $scope.$on( 'IdleWarn', function () {
            // follows after the IdleStart event, but includes a countdown until the user is considered timed out
            // the countdown arg is the number of seconds remaining until then.
            // you can change the title or display a warning dialog from here.
            // you can let them resume their session by calling Idle.watch()
        } );

        $scope.$on( 'IdleTimeout', function () {
            // the user has timed out (meaning idleDuration + timeout has passed without any activity)
            // this is where you'd log them
            $scope.isIdle = true;
            $scope.timedout = ngDialog.open( {
                template: 'app/components/timeoutModal/partials/timeoutModal.html',
                className: 'dialog-timeout',
                controller: 'timeoutModalCtrl',
                scope: $scope,
                showClose: false,
                closeByEscape: false,
                closeByNavigation: false,
                closeByDocument: false
            } );
        } );

        $scope.$on( 'IdleEnd', function () {
            // the user has come back from AFK and is doing stuff. if you are warning them, you can use this to hide the dialog
            closeModals();
        } );

        $scope.start = function () {
            closeModals();
            //Idle.watch();
            $scope.started = true;
        };

        $scope.stop = function () {
            closeModals();
            Idle.unwatch();
            $scope.started = false;
        };

        // $scope.$on('sideBarActive', function (event, arg) {
        //     $scope.sideBarActive = true;
        // });
        $scope.start();
    } );
