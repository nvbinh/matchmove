'use strict';
describe( 'Controller: applicationcontrollerCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
        $provide.constant( "LOG_DEBUG", false );
    } ) );
    var applicationcontrollerCtrl,
        _ngDialog,
        rootScope,
        httpBackend,
        scope,
        cache,
        walletCache,
        userCache,
        timeout;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, ngDialog, CacheFactory, _$timeout_ ) {
        scope = $rootScope.$new();
        rootScope = $rootScope;
        _ngDialog = ngDialog;
        timeout = _$timeout_;
        cache = CacheFactory;

        applicationcontrollerCtrl = $controller( 'applicationcontrollerCtrl', {
            $scope: scope
        } );
        walletCache = cache.get( 'walletCache' );
        userCache = cache.get( 'userCache' );
        spyOn( cache, 'createCache' ).and.callFake( function () {} );
        spyOn( userCache, 'remove' ).and.callFake( function () {} );
        spyOn( walletCache, 'removeAll' ).and.callFake( function () {} );
    } ) );

    afterEach( function () {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
        walletCache.destroy();
        userCache.destroy();
    } );

    describe( 'unauthorized', function () {
        it( 'should call unauthorized', function () {
            spyOn( _ngDialog, 'open' );
            rootScope.$broadcast( 'unauthorized' );
            expect( _ngDialog.open ).toHaveBeenCalled();
        } );
        it( 'should call popup once', function () {
            rootScope.$broadcast( 'unauthorized' );
            expect( rootScope.loaded ).toBeTruthy();
        } );

    } );

    it( 'should set isIdle to true when IdleTimeout is broadcasted', function () {
        rootScope.$broadcast( 'IdleTimeout' );
        expect( scope.isIdle ).toBeTruthy();
    } );
    it( 'should open ngdialog when IdleTimeout is broadcasted', function () {
        rootScope.$broadcast( 'IdleTimeout' );
        expect( scope.timedout ).toBeDefined();
    } );
    it( 'should close modals when IdleEnd is broadcasted', function () {
        spyOn( _ngDialog, 'closeAll' );
        rootScope.$broadcast( 'IdleEnd' );
        expect( _ngDialog.closeAll ).toHaveBeenCalled();
    } );
    it( 'should start idle watch', function () {
        expect( scope.started ).toBeTruthy();
    } );
    it( 'should stop watch', function () {
        scope.stop();
        expect( scope.started ).toBeFalsy();
    } );
    it( 'statechangeError', function() {
        rootScope.$broadcast('$stateChangeError');
        expect( rootScope.backendError ).toBeTruthy();
    } );
} );
