'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authPasswordCreateCtrl
 * @description
 * # authPasswordCreateCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authPasswordCreateCtrl', function ( $scope, $stateParams, rc4Factory, authPasswordFactory, store, $log, $translate, $state, $timeout ) {
        $scope.token = $stateParams.token;
        $scope.validationError = '';

        $scope.verifyingToken = true;
        $scope.success = false;

        function postSuccessRedirection() {
            $state.transitionTo( 'auth.login', null, {
                'reload': true
            } );
        }
        $scope.changePassword = function () {
            $scope.isLoading = true;
            if ( $scope.password === $scope.rePassword ) {
                authPasswordFactory.verifyToken( $scope.token, $scope.password )
                    .then( function () {
                        $scope.isLoading = false;
                        $scope.success = true;
                        $scope.timeout = $timeout( postSuccessRedirection, 10000 );
                    }, function ( errResponse ) {
                        if ( errResponse.status === 400 ) {
                            if ( errResponse.statusText.indexOf( 'userAuthenticationValidationFailed' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.400.TOKEN_USED' );
                            } else if( errResponse.statusText.indexOf( 'userAuthenticationValidationTokenExpired' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.400.TOKEN_EXPIRED' );
                            } else if( errResponse.statusText.indexOf( 'failedPasswordChange' ) > -1 ) {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.400.FAILED_PASSWORD_CHANGE' );
                            } else {
                                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.400.GENERIC' );
                            }
                        } else if ( errResponse.status === 401 ) {
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.401.GENERIC' );
                        } else if ( errResponse.status === 500 ) {
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.500.GENERIC' );
                        } else {
                            $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.GENERIC' );
                        }
                        $scope.errorGeneric = true;
                        $scope.isLoading = false;
                    } );
            } else {
                $scope.errorGeneric = true;
                $scope.isLoading = false;
                $scope.validationError = $translate.instant( 'ERRORS.VALIDATION.WALLET_PASSWORD_CREATE.PASSWORD_DONT_MATCH' );
            }
        };
    } );
