'use strict';
describe( 'Controller: authPasswordCreateCtrl - Error Scenarios', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authPasswordCreateCtrl,
        scope,
        httpBackend,
        API_BASE,
        authPasswordFactory,
        rc4Factory,
        q,
        base64;
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, _API_BASE_, _authPasswordFactory_, _rc4Factory_, _base64Factory_, $q ) {
        scope = $rootScope.$new();
        API_BASE = _API_BASE_;
        authPasswordFactory = _authPasswordFactory_;
        rc4Factory = _rc4Factory_;
        q = $q;
        base64 = _base64Factory_;
        authPasswordCreateCtrl = $controller( 'authPasswordCreateCtrl', {
            $scope: scope
        } );
        scope.token = '27ccba12efb3cfcf00708386a297efef';
        scope.password = 'asdefg12';
        scope.rePassword = 'asdefg12';
        spyOn( rc4Factory, 'encode' ).and.callThrough();
        spyOn( base64, 'encode' ).and.callThrough();
        spyOn( authPasswordFactory, 'verifyToken' ).and.callThrough();
        httpBackend.flush();
    } ) );
    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );
    it( 'Error 500', function () {
        httpBackend.whenPUT( API_BASE + 'users/authentications/password' ).respond( 500, '500 error', {}, 'HTTP/4.1 500 Token Verify error 500' );
        scope.changePassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
        expect( scope.errorGeneric ).toBeTruthy();
    } );
    it( 'Error 503', function () {
        httpBackend.whenPUT( API_BASE + 'users/authentications/password' ).respond( 503, '503 error', {}, 'HTTP/1.1 503 error here' );
        scope.changePassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
        expect( scope.errorGeneric ).toBeTruthy();
    } );
    it( 'Error 400', function () {
        httpBackend.whenPUT( API_BASE + 'users/authentications/password' ).respond( 400, '400 error', {}, 'HTTP/1.1 400 Token Verify error 400' );
        scope.changePassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
        expect( scope.errorGeneric ).toBeTruthy();
    } );
    it( 'Error 400 userAuthenticationValidationFailed ', function () {
        httpBackend.whenPUT( API_BASE + 'users/authentications/password' ).respond( 400, '400 error', {}, 'HTTP/1.1 400 some userAuthenticationValidationFailed error' );
        scope.changePassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
        expect( scope.errorGeneric ).toBeTruthy();
    } );
    it( 'Error 401', function () {
        httpBackend.whenPUT( API_BASE + 'users/authentications/password' ).respond( 401, '401 error', {}, 'HTTP/1.1 401 Token Verify error 401' );
        scope.changePassword();
        httpBackend.flush();
        expect( scope.validationError ).toBeDefined();
        expect( scope.errorGeneric ).toBeTruthy();
    } );
} );
describe( 'Controller: authPasswordCreateCtrl - success scenarios', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    var authPasswordCreateCtrl,
        scope,
        changePassForm,
        httpBackend,
        API_BASE,
        authPasswordFactory,
        rc4Factory;
        // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, $compile, $httpBackend, API_BASE, _authPasswordFactory_, _rc4Factory_ ) {
        scope = $rootScope.$new();
        API_BASE = API_BASE;
        authPasswordFactory = _authPasswordFactory_;
        rc4Factory = _rc4Factory_;
        authPasswordCreateCtrl = $controller( 'authPasswordCreateCtrl', {
            $scope: scope
        } );
        httpBackend.whenPUT( API_BASE + 'users/authentications/password' ).respond( 200,'success', {}, 'HTTP/4.01 some text(userPasswordChangeSuccessful)' );
        httpBackend.flush();
    } ) );

    afterEach( function () {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    } );

    describe( 'Response for 200 status', function () {
        beforeEach( inject( function () {
            scope.token = '27ccba12efb3cfcf00708386a297efef';
            scope.password = 'asdefg12';
            scope.rePassword = 'asdefg12';
            spyOn( rc4Factory, 'encode' ).and.callThrough();
        } ) );

        it( 'should verify token correctly 200', function () {
            spyOn( authPasswordFactory, 'verifyToken' ).and.callThrough();
            scope.changePassword( scope.token, scope.password );
            httpBackend.flush();
            expect( authPasswordFactory.verifyToken ).toHaveBeenCalled();
            expect( scope.success ).toBe( true );
        } );
    } );
    it( 'Should have the variables properly defined', function () {
        expect( scope.validationError ).toBeDefined();
        expect( scope.verifyingToken ).toBeDefined();
        expect( scope.success ).toBeDefined();
    } );
    it( 'Should have variables properly initialized', function () {
        expect( scope.success ).toBe( false );
        expect( scope.verifyingToken ).toBe( true );
    } );
    describe( 'Error msg Response for unmatched passwords', function () {
        beforeEach( inject( function () {
            scope.token = '27ccba12efb3cfcf00708386a297efef';
            scope.password = 'hgjhgg12';
            scope.rePassword = 'asdefg12';
            spyOn( rc4Factory, 'encode' ).and.callThrough();
        } ) );

        it( 'should throw error when differing passwords are sent', function () {
            scope.changePassword( scope.token, scope.password );
            expect( scope.errorGeneric ).toBeTruthy();
            expect( scope.validationError ).toBeDefined();
        } );
    } );
} );
