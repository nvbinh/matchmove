'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.userAddress
 * @description
 * # userAddress
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .service('userAddressFactory', function ($http, API_BASE, CacheFactory, $q, store) {
        // Service Logic
        function getShippingAddress() {
            return $http.post(API_BASE + 'users/addresses/comgateway', {
                cache: false
            });
        }

        function getExistingShippingAddress() {
            return $http.get(API_BASE + 'users/addresses/comgateway', {
                cache: false
            });
        }

        // function getAddress(type) {
        //     return $http.get(API_BASE + 'users/addresses/' + type, {
        //         cache: false
        //     });
        // }
        function getAddress( type, cache ) {
            var addressCache = CacheFactory.get('addressCache');

            var deferred = $q.defer();
            var cacheFlag;
            if ( cache === true ) {
                cacheFlag = addressCache;
                var address;
                if (addressCache && addressCache.get( type + '_address' )) {
                    address = addressCache.get( type + '_address' );
                    deferred.resolve( address );
                    return deferred.promise;
                }else{
                    cacheFlag = false;
                }
            } else {
                cacheFlag = false;
            }
            $http( {
                    method: 'GET',
                    url: API_BASE + 'users/addresses/' + type,
                    cache: cacheFlag,
                    timeout: 18000
                } ).then( function ( data, status, headers, config ) {
                    var address = data;
                    addressCache.put( type + '_address', address );
                    store.set( type + '_address', address.data );
                    deferred.resolve( address );
                }, function ( errorResponse ) {
                    // Here upstream sends 403 for non-existing address
                    // This is cached as {data: null}
                    var address = {data: null};
                    addressCache.put( type + '_address', address );
                    store.set( type + '_address', null );
                    deferred.resolve( address );
                } )
                return deferred.promise;
        };

        function updateAddress(type, data) {
            if (data.country === 'Singapore') {
                data.city = 'Singapore';
                data.state = 'Singapore';
            }
            return $http({
                method: 'PUT',
                url: API_BASE + 'users/addresses/' + type,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                transformRequest: function (obj) {
                    var str = [];
                    for (var p in obj) {
                        str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                    }
                    return str.join('&');
                },
                data: data
            });
        }

        function getCountryByISO(countryList, iso) {
            if (countryList && iso) {
                for (var i in countryList) {
                    if (countryList[i] && countryList[i].hasOwnProperty('iso2') && countryList[i].iso2.toLowerCase() === iso) {
                        return countryList[i];
                    }
                }
            }
            return null;
        }

        function getCountryNameByISOAlpha3(countryList, iso3) {
            if (countryList && iso3) {
                for (var i in countryList) {
                    if (countryList[i] && countryList[i].hasOwnProperty('iso3166_alpha3') && countryList[i].iso3166_alpha3 === iso3) {
                        return countryList[i].name;
                    }
                }
            }
            return null;
        }

        function getNationalityNameByISOAlpha3(countryList, iso3) {
            if (countryList && iso3) {
                for (var i in countryList) {
                    if (countryList[i] && countryList[i].hasOwnProperty('iso3166_alpha3') && countryList[i].iso3166_alpha3 === iso3) {
                        return countryList[i].nationality;
                    }
                }
            }
            return null;
        }

        function getCountries() {
          /* jshint ignore:start */
            return [{
                "id": "1",
                "iso2": "AD",
                "iso3166_alpha3": "AND",
                "iso4217": "EUR",
                "name": "Andorra",
                "nationality": "Andorran"
            }, {
                "id": "2",
                "iso2": "AE",
                "iso3166_alpha3": "AED",
                "iso4217": "ARE",
                "name": "United Arab Emirates",
                "nationality": "United Arab Emirates"
            }, {
                "id": "3",
                "iso2": "AF",
                "iso3166_alpha3": "AFG",
                "iso4217": "AFN",
                "name": "Afghanistan",
                "nationality": "Afghan"
            }, {
                "id": "4",
                "iso2": "AG",
                "iso3166_alpha3": "ATG",
                "iso4217": "XCD",
                "name": "Antigua and Barbuda",
                "nationality": "Antiguan and Barbudan"
            }, {
                "id": "5",
                "iso2": "AI",
                "iso3166_alpha3": "AIA",
                "iso4217": "XCD",
                "name": "Anguilla",
                "nationality": "Anguillan"
            }, {
                "id": "6",
                "iso2": "AL",
                "iso3166_alpha3": "ALB",
                "iso4217": "ALL",
                "name": "Albania",
                "nationality": "Albanian"
            }, {
                "id": "7",
                "iso2": "AM",
                "iso3166_alpha3": "ARM",
                "iso4217": "AMD",
                "name": "Armenia",
                "nationality": "Armenian"
            }, {
                "id": "8",
                "iso2": "AN",
                "iso3166_alpha3": "ANT",
                "iso4217": null,
                "name": "Netherlands Antilles",
                "nationality": "Netherlands Antilles"
            }, {
                "id": "9",
                "iso2": "AO",
                "iso3166_alpha3": "AGO",
                "iso4217": "AOA",
                "name": "Angola",
                "nationality": "Angolan"
            }, {
                "id": "10",
                "iso2": "AR",
                "iso3166_alpha3": "ARG",
                "iso4217": "ARS",
                "name": "Argentina",
                "nationality": "Argentinian"
            }, {
                "id": "11",
                "iso2": "AS",
                "iso3166_alpha3": "ASM",
                "iso4217": "USD",
                "name": "American Samoa",
                "nationality": "American Samoan"
            }, {
                "id": "12",
                "iso2": "AT",
                "iso3166_alpha3": "AUT",
                "iso4217": "EUR",
                "name": "Austria",
                "nationality": "Austrian"
            }, {
                "id": "13",
                "iso2": "AU",
                "iso3166_alpha3": "AUS",
                "iso4217": "AUD",
                "name": "Australia",
                "nationality": "Australian"
            }, {
                "id": "14",
                "iso2": "AW",
                "iso3166_alpha3": "ABW",
                "iso4217": "AWG",
                "name": "Aruba",
                "nationality": "Aruban"
            }, {
                "id": "15",
                "iso2": "AX",
                "iso3166_alpha3": "ALA",
                "iso4217": "EUR",
                "name": "Aland Islands",
                "nationality": "Landers"
            }, {
                "id": "16",
                "iso2": "AZ",
                "iso3166_alpha3": "AZE",
                "iso4217": "AZN",
                "name": "Azerbaijan",
                "nationality": "Azerbaijani"
            }, {
                "id": "17",
                "iso2": "BA",
                "iso3166_alpha3": "BIH",
                "iso4217": "BAM",
                "name": "Bosnia and Herzegovina",
                "nationality": "Bosnian"
            }, {
                "id": "18",
                "iso2": "BB",
                "iso3166_alpha3": "BRB",
                "iso4217": "USD",
                "name": "Barbados",
                "nationality": "Barbadian"
            }, {
                "id": "19",
                "iso2": "BD",
                "iso3166_alpha3": "BGD",
                "iso4217": "BDT",
                "name": "Bangladesh",
                "nationality": "Bangladeshi"
            }, {
                "id": "20",
                "iso2": "BE",
                "iso3166_alpha3": "BEL",
                "iso4217": "EUR",
                "name": "Belgium",
                "nationality": "Belgian"
            }, {
                "id": "21",
                "iso2": "BF",
                "iso3166_alpha3": "BFA",
                "iso4217": "XOF",
                "name": "Burkina Faso",
                "nationality": "Burkinab"
            }, {
                "id": "22",
                "iso2": "BG",
                "iso3166_alpha3": "BGR",
                "iso4217": "BGN",
                "name": "Bulgaria",
                "nationality": "Bulgarian"
            }, {
                "id": "23",
                "iso2": "BH",
                "iso3166_alpha3": "BHR",
                "iso4217": "BHD",
                "name": "Bahrain",
                "nationality": "Bahraini"
            }, {
                "id": "24",
                "iso2": "BI",
                "iso3166_alpha3": "BDI",
                "iso4217": "BIF",
                "name": "Burundi",
                "nationality": "Burundian"
            }, {
                "id": "25",
                "iso2": "BJ",
                "iso3166_alpha3": "BEN",
                "iso4217": "XOF",
                "name": "Benin",
                "nationality": "Beninese"
            }, {
                "id": "26",
                "iso2": "BM",
                "iso3166_alpha3": "BMU",
                "iso4217": "BMD",
                "name": "Bermuda",
                "nationality": "Bermudian"
            }, {
                "id": "27",
                "iso2": "BN",
                "iso3166_alpha3": "BRN",
                "iso4217": "SGD",
                "name": "Brunei Darussalam",
                "nationality": "Bruneian"
            }, {
                "id": "28",
                "iso2": "BO",
                "iso3166_alpha3": "BOL",
                "iso4217": "BOV",
                "name": "Bolivia",
                "nationality": "Bolivian"
            }, {
                "id": "29",
                "iso2": "BR",
                "iso3166_alpha3": "BRA",
                "iso4217": "BRL",
                "name": "Brazil",
                "nationality": "Brazilian"
            }, {
                "id": "30",
                "iso2": "BS",
                "iso3166_alpha3": "BHS",
                "iso4217": "BSD",
                "name": "Bahamas",
                "nationality": "Bahamian"
            }, {
                "id": "31",
                "iso2": "BT",
                "iso3166_alpha3": "BTN",
                "iso4217": "BTN",
                "name": "Bhutan",
                "nationality": "Bhutanese"
            }, {
                "id": "32",
                "iso2": "BV",
                "iso3166_alpha3": "BVT",
                "iso4217": "NOK",
                "name": "Bouvet Island",
                "nationality": "Bouvet Island"
            }, {
                "id": "33",
                "iso2": "BW",
                "iso3166_alpha3": "BWA",
                "iso4217": "BWP",
                "name": "Botswana",
                "nationality": "Tswana"
            }, {
                "id": "34",
                "iso2": "BY",
                "iso3166_alpha3": "BLR",
                "iso4217": "BYR",
                "name": "Belarus",
                "nationality": "Belarusan"
            }, {
                "id": "35",
                "iso2": "BZ",
                "iso3166_alpha3": "BLZ",
                "iso4217": "BZD",
                "name": "Belize",
                "nationality": "Belizian"
            }, {
                "id": "36",
                "iso2": "CA",
                "iso3166_alpha3": "CAN",
                "iso4217": "CAD",
                "name": "Canada",
                "nationality": "Canadian"
            }, {
                "id": "37",
                "iso2": "CD",
                "iso3166_alpha3": "COD",
                "iso4217": "CDF",
                "name": "Congo, The Democratic Republic",
                "nationality": "Congolese"
            }, {
                "id": "38",
                "iso2": "CF",
                "iso3166_alpha3": "CAF",
                "iso4217": "XAF",
                "name": "Central African Republic",
                "nationality": "Central African"
            }, {
                "id": "39",
                "iso2": "CG",
                "iso3166_alpha3": "COG",
                "iso4217": "XAF",
                "name": "Congo",
                "nationality": "Congolese"
            }, {
                "id": "40",
                "iso2": "CH",
                "iso3166_alpha3": "CHE",
                "iso4217": "CHF",
                "name": "Switzerland",
                "nationality": "Swiss"
            }, {
                "id": "41",
                "iso2": "CI",
                "iso3166_alpha3": "CIV",
                "iso4217": "XOF",
                "name": "Cote D'Ivoire",
                "nationality": "Ivoirian"
            }, {
                "id": "42",
                "iso2": "CK",
                "iso3166_alpha3": "COK",
                "iso4217": "NZD",
                "name": "Cook Islands",
                "nationality": "Cook Islander"
            }, {
                "id": "43",
                "iso2": "CL",
                "iso3166_alpha3": "CHL",
                "iso4217": "CLP",
                "name": "Chile",
                "nationality": "Chilean"
            }, {
                "id": "44",
                "iso2": "CM",
                "iso3166_alpha3": "CMR",
                "iso4217": "XAF",
                "name": "Cameroon",
                "nationality": "Cameroonian"
            }, {
                "id": "45",
                "iso2": "CN",
                "iso3166_alpha3": "CHN",
                "iso4217": "CNY",
                "name": "China",
                "nationality": "Chinese"
            }, {
                "id": "46",
                "iso2": "CO",
                "iso3166_alpha3": "COL",
                "iso4217": "COP",
                "name": "Colombia",
                "nationality": "Colombian"
            }, {
                "id": "47",
                "iso2": "CR",
                "iso3166_alpha3": "CRI",
                "iso4217": "CRC",
                "name": "Costa Rica",
                "nationality": "Costa Rican"
            }, {
                "id": "48",
                "iso2": "CU",
                "iso3166_alpha3": "CUB",
                "iso4217": "CUC",
                "name": "Cuba",
                "nationality": "Cuban"
            }, {
                "id": "49",
                "iso2": "CV",
                "iso3166_alpha3": "CPV",
                "iso4217": "CVE",
                "name": "Cape Verde",
                "nationality": "Cape Verdean"
            }, {
                "id": "50",
                "iso2": "CY",
                "iso3166_alpha3": "CYP",
                "iso4217": "EUR",
                "name": "Cyprus",
                "nationality": "Cypriot"
            }, {
                "id": "51",
                "iso2": "CZ",
                "iso3166_alpha3": "CZE",
                "iso4217": "CZK",
                "name": "Czech Republic",
                "nationality": "Czech"
            }, {
                "id": "52",
                "iso2": "DE",
                "iso3166_alpha3": "DEU",
                "iso4217": "EUR",
                "name": "Germany",
                "nationality": "German"
            }, {
                "id": "53",
                "iso2": "DJ",
                "iso3166_alpha3": "DJI",
                "iso4217": "DJF",
                "name": "Djibouti",
                "nationality": "Djiboutian"
            }, {
                "id": "54",
                "iso2": "DK",
                "iso3166_alpha3": "DNK",
                "iso4217": "DKK",
                "name": "Denmark",
                "nationality": "Dane"
            }, {
                "id": "55",
                "iso2": "DO",
                "iso3166_alpha3": "DOM",
                "iso4217": "DOP",
                "name": "Dominican Republic",
                "nationality": "Dominican"
            }, {
                "id": "56",
                "iso2": "DZ",
                "iso3166_alpha3": "DZA",
                "iso4217": "DZD",
                "name": "Algeria",
                "nationality": "Algerian"
            }, {
                "id": "57",
                "iso2": "EC",
                "iso3166_alpha3": "ECU",
                "iso4217": "USD",
                "name": "Ecuador",
                "nationality": "Ecuadorean"
            }, {
                "id": "58",
                "iso2": "EE",
                "iso3166_alpha3": "EST",
                "iso4217": "EUR",
                "name": "Estonia",
                "nationality": "Estonian"
            }, {
                "id": "59",
                "iso2": "EG",
                "iso3166_alpha3": "EGY",
                "iso4217": "EGP",
                "name": "Egypt",
                "nationality": "Egyptian"
            }, {
                "id": "60",
                "iso2": "ER",
                "iso3166_alpha3": "ERI",
                "iso4217": "ERN",
                "name": "Eritrea",
                "nationality": "Eritrean"
            }, {
                "id": "61",
                "iso2": "ES",
                "iso3166_alpha3": "ESP",
                "iso4217": "EUR",
                "name": "Spain",
                "nationality": "Spaniard"
            }, {
                "id": "62",
                "iso2": "ET",
                "iso3166_alpha3": "ETH",
                "iso4217": "ETB",
                "name": "Ethiopia",
                "nationality": "Ethiopian"
            }, {
                "id": "63",
                "iso2": "EU",
                "iso3166_alpha3": null,
                "iso4217": null,
                "name": "Europe",
                "nationality": "European"
            }, {
                "id": "64",
                "iso2": "FI",
                "iso3166_alpha3": "FIN",
                "iso4217": "EUR",
                "name": "Finland",
                "nationality": "Finn"
            }, {
                "id": "65",
                "iso2": "FJ",
                "iso3166_alpha3": "FJI",
                "iso4217": "FJD",
                "name": "Fiji",
                "nationality": "Fijian"
            }, {
                "id": "66",
                "iso2": "FK",
                "iso3166_alpha3": "FLK",
                "iso4217": "FKP",
                "name": "Falkland Islands (Malvinas)",
                "nationality": "Falkland Islander"
            }, {
                "id": "67",
                "iso2": "FM",
                "iso3166_alpha3": "FSM",
                "iso4217": null,
                "name": "Micronesia, Federated States o",
                "nationality": "Micronesian"
            }, {
                "id": "68",
                "iso2": "FO",
                "iso3166_alpha3": "FRO",
                "iso4217": "DKK",
                "name": "Faroe Islands",
                "nationality": "Faroese"
            }, {
                "id": "69",
                "iso2": "FR",
                "iso3166_alpha3": "FRA",
                "iso4217": "EUR",
                "name": "France",
                "nationality": "French"
            }, {
                "id": "70",
                "iso2": "GA",
                "iso3166_alpha3": "GAB",
                "iso4217": "XAF",
                "name": "Gabon",
                "nationality": "Gabonese"
            }, {
                "id": "71",
                "iso2": "GB",
                "iso3166_alpha3": "GBR",
                "iso4217": "GBP",
                "name": "United Kingdom",
                "nationality": "British"
            }, {
                "id": "72",
                "iso2": "GD",
                "iso3166_alpha3": "GRD",
                "iso4217": "XCD",
                "name": "Grenada",
                "nationality": "Grenadian"
            }, {
                "id": "73",
                "iso2": "GE",
                "iso3166_alpha3": "GEO",
                "iso4217": "GEL",
                "name": "Georgia",
                "nationality": "Georgian"
            }, {
                "id": "74",
                "iso2": "GF",
                "iso3166_alpha3": "GUF",
                "iso4217": "EUR",
                "name": "French Guiana",
                "nationality": "French Guiana"
            }, {
                "id": "75",
                "iso2": "GG",
                "iso3166_alpha3": "GGY",
                "iso4217": "GBP",
                "name": "Guernsey",
                "nationality": "Channel Islander"
            }, {
                "id": "76",
                "iso2": "GH",
                "iso3166_alpha3": "GHA",
                "iso4217": "GHS",
                "name": "Ghana",
                "nationality": "Ghanaian"
            }, {
                "id": "77",
                "iso2": "GI",
                "iso3166_alpha3": "GIB",
                "iso4217": "GIP",
                "name": "Gibraltar",
                "nationality": "Gibraltar"
            }, {
                "id": "78",
                "iso2": "GL",
                "iso3166_alpha3": "GRL",
                "iso4217": "DKK",
                "name": "Greenland",
                "nationality": "Greenlander"
            }, {
                "id": "79",
                "iso2": "GM",
                "iso3166_alpha3": "GMB",
                "iso4217": "GMD",
                "name": "Gambia",
                "nationality": "Gambian"
            }, {
                "id": "80",
                "iso2": "GN",
                "iso3166_alpha3": "GIN",
                "iso4217": "GNF",
                "name": "Guinea",
                "nationality": "Guinean"
            }, {
                "id": "81",
                "iso2": "GP",
                "iso3166_alpha3": "GLP",
                "iso4217": "EUR",
                "name": "Guadeloupe",
                "nationality": "Guadeloupian"
            }, {
                "id": "82",
                "iso2": "GQ",
                "iso3166_alpha3": "GNQ",
                "iso4217": "XAF",
                "name": "Equatorial Guinea",
                "nationality": "Equatoguinean"
            }, {
                "id": "83",
                "iso2": "GR",
                "iso3166_alpha3": "GRC",
                "iso4217": "EUR",
                "name": "Greece",
                "nationality": "Greek"
            }, {
                "id": "84",
                "iso2": "GT",
                "iso3166_alpha3": "GTM",
                "iso4217": "GTQ",
                "name": "Guatemala",
                "nationality": "Guatemalan"
            }, {
                "id": "85",
                "iso2": "GU",
                "iso3166_alpha3": "GUM",
                "iso4217": "USD",
                "name": "Guam",
                "nationality": "Guamanian"
            }, {
                "id": "86",
                "iso2": "GW",
                "iso3166_alpha3": "GNB",
                "iso4217": "XOF",
                "name": "Guinea-Bissau",
                "nationality": "Bissau-Guinean"
            }, {
                "id": "87",
                "iso2": "GY",
                "iso3166_alpha3": "GUY",
                "iso4217": "GYD",
                "name": "Guyana",
                "nationality": "Guyanese"
            }, {
                "id": "88",
                "iso2": "HK",
                "iso3166_alpha3": "HKG",
                "iso4217": "HKD",
                "name": "Hong Kong",
                "nationality": "Hong Konger"
            }, {
                "id": "89",
                "iso2": "HN",
                "iso3166_alpha3": "HND",
                "iso4217": "HNL",
                "name": "Honduras",
                "nationality": "Honduran"
            }, {
                "id": "90",
                "iso2": "HR",
                "iso3166_alpha3": "HRV",
                "iso4217": "HRK",
                "name": "Croatia",
                "nationality": "Croatian"
            }, {
                "id": "91",
                "iso2": "HT",
                "iso3166_alpha3": "HTI",
                "iso4217": "USD",
                "name": "Haiti",
                "nationality": "Haitian"
            }, {
                "id": "92",
                "iso2": "HU",
                "iso3166_alpha3": "HUN",
                "iso4217": "HUF",
                "name": "Hungary",
                "nationality": "Hungarian"
            }, {
                "id": "93",
                "iso2": "ID",
                "iso3166_alpha3": "IDN",
                "iso4217": "IDR",
                "name": "Indonesia",
                "nationality": "Indonesian"
            }, {
                "id": "94",
                "iso2": "IE",
                "iso3166_alpha3": "IRL",
                "iso4217": "EUR",
                "name": "Ireland",
                "nationality": "Irish "
            }, {
                "id": "95",
                "iso2": "IL",
                "iso3166_alpha3": "ISR",
                "iso4217": "ILS",
                "name": "Israel",
                "nationality": "Israeli"
            }, {
                "id": "96",
                "iso2": "IM",
                "iso3166_alpha3": "IMN",
                "iso4217": "IMP",
                "name": "Isle of Man",
                "nationality": "Manx"
            }, {
                "id": "97",
                "iso2": "IN",
                "iso3166_alpha3": "IND",
                "iso4217": "INR",
                "name": "India",
                "nationality": "Indian"
            }, {
                "id": "98",
                "iso2": "IQ",
                "iso3166_alpha3": "IRQ",
                "iso4217": "IQD",
                "name": "Iraq",
                "nationality": "Iraqi"
            }, {
                "id": "99",
                "iso2": "IR",
                "iso3166_alpha3": "IRN",
                "iso4217": "IRR",
                "name": "Iran, Islamic Republic of",
                "nationality": "Iranian"
            }, {
                "id": "100",
                "iso2": "IS",
                "iso3166_alpha3": "ISL",
                "iso4217": "ISK",
                "name": "Iceland",
                "nationality": "Icelander"
            }, {
                "id": "101",
                "iso2": "IT",
                "iso3166_alpha3": "ITA",
                "iso4217": "EUR",
                "name": "Italy",
                "nationality": "Italian"
            }, {
                "id": "102",
                "iso2": "JE",
                "iso3166_alpha3": "JEY",
                "iso4217": "JEP",
                "name": "Jersey",
                "nationality": "Channel Islander"
            }, {
                "id": "103",
                "iso2": "JM",
                "iso3166_alpha3": "JAM",
                "iso4217": "JMD",
                "name": "Jamaica",
                "nationality": "Jamaican"
            }, {
                "id": "104",
                "iso2": "JO",
                "iso3166_alpha3": "JOR",
                "iso4217": "JOD",
                "name": "Jordan",
                "nationality": "Jordanian"
            }, {
                "id": "105",
                "iso2": "JP",
                "iso3166_alpha3": "JPN",
                "iso4217": "JPY",
                "name": "Japan",
                "nationality": "Japanese"
            }, {
                "id": "106",
                "iso2": "KE",
                "iso3166_alpha3": "KEN",
                "iso4217": "KES",
                "name": "Kenya",
                "nationality": "Kenyan"
            }, {
                "id": "107",
                "iso2": "KG",
                "iso3166_alpha3": "KGZ",
                "iso4217": "KGS",
                "name": "Kyrgyzstan",
                "nationality": "Kyrgyzstani"
            }, {
                "id": "108",
                "iso2": "KH",
                "iso3166_alpha3": "KHM",
                "iso4217": "KHR",
                "name": "Cambodia",
                "nationality": "Cambodian"
            }, {
                "id": "109",
                "iso2": "KI",
                "iso3166_alpha3": "KIR",
                "iso4217": "AUD",
                "name": "Kiribati",
                "nationality": "I-Kiribati"
            }, {
                "id": "110",
                "iso2": "KM",
                "iso3166_alpha3": "COM",
                "iso4217": "KMF",
                "name": "Comoros",
                "nationality": "Comoran"
            }, {
                "id": "111",
                "iso2": "KN",
                "iso3166_alpha3": "KNA",
                "iso4217": "XCD",
                "name": "Saint Kitts and Nevis",
                "nationality": "Kittitian, Nevisian"
            }, {
                "id": "112",
                "iso2": "KP",
                "iso3166_alpha3": "PRK",
                "iso4217": "KPW",
                "name": "Korea, Democratic People's Rep",
                "nationality": "North Korean"
            }, {
                "id": "113",
                "iso2": "KR",
                "iso3166_alpha3": "KOR",
                "iso4217": "KRW",
                "name": "Korea, Republic of",
                "nationality": "South Korean"
            }, {
                "id": "114",
                "iso2": "KW",
                "iso3166_alpha3": "KWT",
                "iso4217": "KWD",
                "name": "Kuwait",
                "nationality": "Kuwaiti"
            }, {
                "id": "115",
                "iso2": "KY",
                "iso3166_alpha3": "CYM",
                "iso4217": "KYD",
                "name": "Cayman Islands",
                "nationality": "Caymanian"
            }, {
                "id": "116",
                "iso2": "KZ",
                "iso3166_alpha3": "KAZ",
                "iso4217": "KZT",
                "name": "Kazakhstan",
                "nationality": "Kazakh"
            }, {
                "id": "117",
                "iso2": "LA",
                "iso3166_alpha3": "LAO",
                "iso4217": "LAK",
                "name": "Lao People's Democratic Republ",
                "nationality": "Laotian"
            }, {
                "id": "118",
                "iso2": "LB",
                "iso3166_alpha3": "LBN",
                "iso4217": "LBP",
                "name": "Lebanon",
                "nationality": "Lebanese"
            }, {
                "id": "119",
                "iso2": "LC",
                "iso3166_alpha3": "LCA",
                "iso4217": null,
                "name": "Saint Lucia",
                "nationality": "Saint Lucian"
            }, {
                "id": "120",
                "iso2": "LI",
                "iso3166_alpha3": "LIE",
                "iso4217": "CHF",
                "name": "Liechtenstein",
                "nationality": "Liechtensteiner"
            }, {
                "id": "121",
                "iso2": "LK",
                "iso3166_alpha3": "LKA",
                "iso4217": null,
                "name": "Sri Lanka",
                "nationality": "Sri Lankan"
            }, {
                "id": "122",
                "iso2": "LR",
                "iso3166_alpha3": "LBR",
                "iso4217": "LRD",
                "name": "Liberia",
                "nationality": "Liberian"
            }, {
                "id": "123",
                "iso2": "LS",
                "iso3166_alpha3": "LSO",
                "iso4217": "LSL",
                "name": "Lesotho",
                "nationality": "Basotho"
            }, {
                "id": "124",
                "iso2": "LT",
                "iso3166_alpha3": "LTU",
                "iso4217": "EUR",
                "name": "Lithuania",
                "nationality": "Lithuanian"
            }, {
                "id": "125",
                "iso2": "LU",
                "iso3166_alpha3": "LUX",
                "iso4217": "EUR",
                "name": "Luxembourg",
                "nationality": "Luxembourger"
            }, {
                "id": "126",
                "iso2": "LV",
                "iso3166_alpha3": "LVA",
                "iso4217": "EUR",
                "name": "Latvia",
                "nationality": "Latvian"
            }, {
                "id": "127",
                "iso2": "LY",
                "iso3166_alpha3": "LBY",
                "iso4217": "LYD",
                "name": "Libyan Arab Jamahiriya",
                "nationality": "Libyan"
            }, {
                "id": "128",
                "iso2": "MA",
                "iso3166_alpha3": "MAR",
                "iso4217": null,
                "name": "Morocco",
                "nationality": "Moroccan"
            }, {
                "id": "129",
                "iso2": "MC",
                "iso3166_alpha3": "MCO",
                "iso4217": "EUR",
                "name": "Monaco",
                "nationality": "Monacan"
            }, {
                "id": "130",
                "iso2": "MD",
                "iso3166_alpha3": "MDA",
                "iso4217": null,
                "name": "Moldova, Republic of",
                "nationality": "Moldovan"
            }, {
                "id": "131",
                "iso2": "ME",
                "iso3166_alpha3": "MNE",
                "iso4217": "EUR",
                "name": "Montenegro",
                "nationality": "Montenegrin"
            }, {
                "id": "132",
                "iso2": "MF",
                "iso3166_alpha3": "MAF",
                "iso4217": null,
                "name": "Saint Martin",
                "nationality": "St. Maarten"
            }, {
                "id": "133",
                "iso2": "MG",
                "iso3166_alpha3": "MDG",
                "iso4217": "MGA",
                "name": "Madagascar",
                "nationality": "Madagascan"
            }, {
                "id": "134",
                "iso2": "MH",
                "iso3166_alpha3": "MHL",
                "iso4217": "USD",
                "name": "Marshall Islands",
                "nationality": "Marshallese"
            }, {
                "id": "135",
                "iso2": "MK",
                "iso3166_alpha3": "MKD",
                "iso4217": "MKD",
                "name": "Macedonia",
                "nationality": "Macedonian"
            }, {
                "id": "136",
                "iso2": "ML",
                "iso3166_alpha3": "MLI",
                "iso4217": "XOF",
                "name": "Mali",
                "nationality": "Malian"
            }, {
                "id": "137",
                "iso2": "MM",
                "iso3166_alpha3": "MMR",
                "iso4217": null,
                "name": "Myanmar",
                "nationality": "Burmese"
            }, {
                "id": "138",
                "iso2": "MN",
                "iso3166_alpha3": "MNG",
                "iso4217": null,
                "name": "Mongolia",
                "nationality": "Mongolian"
            }, {
                "id": "139",
                "iso2": "MO",
                "iso3166_alpha3": "MAC",
                "iso4217": "HKD",
                "name": "Macau",
                "nationality": "Macau Chinese"
            }, {
                "id": "140",
                "iso2": "MQ",
                "iso3166_alpha3": "MTQ",
                "iso4217": "EUR",
                "name": "Martinique",
                "nationality": "Martiniquais"
            }, {
                "id": "141",
                "iso2": "MR",
                "iso3166_alpha3": "MRT",
                "iso4217": null,
                "name": "Mauritania",
                "nationality": "Mauritanian"
            }, {
                "id": "142",
                "iso2": "MS",
                "iso3166_alpha3": "MSR",
                "iso4217": "XCD",
                "name": "Montserrat",
                "nationality": "Montserratian"
            }, {
                "id": "143",
                "iso2": "MT",
                "iso3166_alpha3": "MLT",
                "iso4217": "EUR",
                "name": "Malta",
                "nationality": "Maltese"
            }, {
                "id": "144",
                "iso2": "MU",
                "iso3166_alpha3": "MUS",
                "iso4217": null,
                "name": "Mauritius",
                "nationality": "Mauritian"
            }, {
                "id": "145",
                "iso2": "MV",
                "iso3166_alpha3": "MDV",
                "iso4217": "MVR",
                "name": "Maldives",
                "nationality": "Maldivian"
            }, {
                "id": "146",
                "iso2": "MW",
                "iso3166_alpha3": "MWI",
                "iso4217": "MWK",
                "name": "Malawi",
                "nationality": "Malawian"
            }, {
                "id": "147",
                "iso2": "MX",
                "iso3166_alpha3": "MEX",
                "iso4217": null,
                "name": "Mexico",
                "nationality": "Mexican"
            }, {
                "id": "148",
                "iso2": "MY",
                "iso3166_alpha3": "MYS",
                "iso4217": "MYR",
                "name": "Malaysia",
                "nationality": "Malaysian"
            }, {
                "id": "149",
                "iso2": "MZ",
                "iso3166_alpha3": "MOZ",
                "iso4217": null,
                "name": "Mozambique",
                "nationality": "Mozambican"
            }, {
                "id": "150",
                "iso2": "NA",
                "iso3166_alpha3": "NAM",
                "iso4217": null,
                "name": "Namibia",
                "nationality": "Namibian"
            }, {
                "id": "151",
                "iso2": "NC",
                "iso3166_alpha3": "NCL",
                "iso4217": null,
                "name": "New Caledonia",
                "nationality": "New Caledonian"
            }, {
                "id": "152",
                "iso2": "NF",
                "iso3166_alpha3": "NFK",
                "iso4217": "AUD",
                "name": "Norfolk Island",
                "nationality": "Norfolk Islander"
            }, {
                "id": "153",
                "iso2": "NG",
                "iso3166_alpha3": "NGA",
                "iso4217": null,
                "name": "Nigeria",
                "nationality": "Nigerian"
            }, {
                "id": "154",
                "iso2": "NI",
                "iso3166_alpha3": "NIC",
                "iso4217": null,
                "name": "Nicaragua",
                "nationality": "Nicaraguan"
            }, {
                "id": "155",
                "iso2": "NL",
                "iso3166_alpha3": "NLD",
                "iso4217": "EUR",
                "name": "Netherlands",
                "nationality": "Dutch"
            }, {
                "id": "156",
                "iso2": "NO",
                "iso3166_alpha3": "NOR",
                "iso4217": null,
                "name": "Norway",
                "nationality": "Norwegian"
            }, {
                "id": "157",
                "iso2": "NP",
                "iso3166_alpha3": "NPL",
                "iso4217": "INR",
                "name": "Nepal",
                "nationality": "Nepalese"
            }, {
                "id": "158",
                "iso2": "NR",
                "iso3166_alpha3": "NRU",
                "iso4217": "AUD",
                "name": "Nauru",
                "nationality": "Nauruan"
            }, {
                "id": "159",
                "iso2": "NU",
                "iso3166_alpha3": "NIU",
                "iso4217": "NZD",
                "name": "Niue",
                "nationality": "Niuean"
            }, {
                "id": "160",
                "iso2": "NZ",
                "iso3166_alpha3": "NZL",
                "iso4217": "NZD",
                "name": "New Zealand",
                "nationality": "New Zealander"
            }, {
                "id": "161",
                "iso2": "OM",
                "iso3166_alpha3": "OMN",
                "iso4217": null,
                "name": "Oman",
                "nationality": "Omani"
            }, {
                "id": "162",
                "iso2": "PA",
                "iso3166_alpha3": "PAN",
                "iso4217": "USD",
                "name": "Panama",
                "nationality": "Panamanian"
            }, {
                "id": "163",
                "iso2": "PE",
                "iso3166_alpha3": "PER",
                "iso4217": null,
                "name": "Peru",
                "nationality": "Peruvian"
            }, {
                "id": "164",
                "iso2": "PF",
                "iso3166_alpha3": "PYF",
                "iso4217": "XPF",
                "name": "French Polynesia",
                "nationality": "French Polynesian"
            }, {
                "id": "165",
                "iso2": "PG",
                "iso3166_alpha3": "PNG",
                "iso4217": null,
                "name": "Papua New Guinea",
                "nationality": "Papua New Guinean"
            }, {
                "id": "166",
                "iso2": "PH",
                "iso3166_alpha3": "PHL",
                "iso4217": null,
                "name": "Philippines",
                "nationality": "Filipino"
            }, {
                "id": "167",
                "iso2": "PK",
                "iso3166_alpha3": "PAK",
                "iso4217": null,
                "name": "Pakistan",
                "nationality": "Pakistani"
            }, {
                "id": "168",
                "iso2": "PL",
                "iso3166_alpha3": "POL",
                "iso4217": null,
                "name": "Poland",
                "nationality": "Pole"
            }, {
                "id": "169",
                "iso2": "PM",
                "iso3166_alpha3": "SPM",
                "iso4217": "EUR",
                "name": "Saint Pierre and Miquelon",
                "nationality": "French"
            }, {
                "id": "170",
                "iso2": "PN",
                "iso3166_alpha3": "PCN",
                "iso4217": "NZD",
                "name": "Pitcairn Islands",
                "nationality": "Pitcairn Islander"
            }, {
                "id": "171",
                "iso2": "PR",
                "iso3166_alpha3": "PRI",
                "iso4217": "USD",
                "name": "Puerto Rico",
                "nationality": "Puerto Rican"
            }, {
                "id": "172",
                "iso2": "PS",
                "iso3166_alpha3": "PSE",
                "iso4217": null,
                "name": "Palestinian Territory, Occupie",
                "nationality": "Palestinian"
            }, {
                "id": "173",
                "iso2": "PT",
                "iso3166_alpha3": "PRT",
                "iso4217": "EUR",
                "name": "Portugal",
                "nationality": "Portuguese"
            }, {
                "id": "174",
                "iso2": "PW",
                "iso3166_alpha3": "PLW",
                "iso4217": "USD",
                "name": "Palau",
                "nationality": "Palauan"
            }, {
                "id": "175",
                "iso2": "PY",
                "iso3166_alpha3": "PRY",
                "iso4217": null,
                "name": "Paraguay",
                "nationality": "Paraguayan"
            }, {
                "id": "176",
                "iso2": "QA",
                "iso3166_alpha3": "QAT",
                "iso4217": null,
                "name": "Qatar",
                "nationality": "Qatari"
            }, {
                "id": "177",
                "iso2": "RE",
                "iso3166_alpha3": "REU",
                "iso4217": "EUR",
                "name": "Reunion",
                "nationality": "Reunionese"
            }, {
                "id": "178",
                "iso2": "RO",
                "iso3166_alpha3": "ROU",
                "iso4217": null,
                "name": "Romania",
                "nationality": "Romanian"
            }, {
                "id": "179",
                "iso2": "RS",
                "iso3166_alpha3": "SRB",
                "iso4217": null,
                "name": "Serbia",
                "nationality": "Serbian"
            }, {
                "id": "180",
                "iso2": "RU",
                "iso3166_alpha3": "RUS",
                "iso4217": null,
                "name": "Russian Federation",
                "nationality": "Russian"
            }, {
                "id": "181",
                "iso2": "RW",
                "iso3166_alpha3": "RWA",
                "iso4217": null,
                "name": "Rwanda",
                "nationality": "Rwandan"
            }, {
                "id": "182",
                "iso2": "SA",
                "iso3166_alpha3": "SAU",
                "iso4217": null,
                "name": "Saudi Arabia",
                "nationality": "Saudi Arabian"
            }, {
                "id": "183",
                "iso2": "SB",
                "iso3166_alpha3": "SLB",
                "iso4217": null,
                "name": "Solomon Islands",
                "nationality": "Solomon Islander"
            }, {
                "id": "184",
                "iso2": "SC",
                "iso3166_alpha3": "SYC",
                "iso4217": null,
                "name": "Seychelles",
                "nationality": "Seychellois"
            }, {
                "id": "185",
                "iso2": "SD",
                "iso3166_alpha3": "SDN",
                "iso4217": null,
                "name": "Sudan",
                "nationality": "Sudanese"
            }, {
                "id": "186",
                "iso2": "SE",
                "iso3166_alpha3": "SWE",
                "iso4217": null,
                "name": "Sweden",
                "nationality": "Swede"
            }, {
                "id": "187",
                "iso2": "SG",
                "iso3166_alpha3": "SGP",
                "iso4217": "SGD",
                "name": "Singapore",
                "nationality": "Singaporean"
            }, {
                "id": "188",
                "iso2": "SI",
                "iso3166_alpha3": "SVN",
                "iso4217": "EUR",
                "name": "Slovenia",
                "nationality": "Slovenian"
            }, {
                "id": "189",
                "iso2": "SK",
                "iso3166_alpha3": "SVK",
                "iso4217": "EUR",
                "name": "Slovakia",
                "nationality": "Slovak"
            }, {
                "id": "190",
                "iso2": "SL",
                "iso3166_alpha3": "SLE",
                "iso4217": null,
                "name": "Sierra Leone",
                "nationality": "Sierra Leonian"
            }, {
                "id": "191",
                "iso2": "SM",
                "iso3166_alpha3": "SMR",
                "iso4217": "EUR",
                "name": "San Marino",
                "nationality": "Sammarinese"
            }, {
                "id": "192",
                "iso2": "SN",
                "iso3166_alpha3": "SEN",
                "iso4217": "XOF",
                "name": "Senegal",
                "nationality": "Senegalese"
            }, {
                "id": "193",
                "iso2": "SO",
                "iso3166_alpha3": "SOM",
                "iso4217": null,
                "name": "Somalia",
                "nationality": "Somali"
            }, {
                "id": "194",
                "iso2": "SR",
                "iso3166_alpha3": "SUR",
                "iso4217": null,
                "name": "Suriname",
                "nationality": "Surinamese"
            }, {
                "id": "195",
                "iso2": "ST",
                "iso3166_alpha3": "STP",
                "iso4217": null,
                "name": "Sao Tome and Principe",
                "nationality": "Sao Tomean"
            }, {
                "id": "196",
                "iso2": "SV",
                "iso3166_alpha3": "SLV",
                "iso4217": "USD",
                "name": "El Salvador",
                "nationality": "Salvadorean"
            }, {
                "id": "197",
                "iso2": "SY",
                "iso3166_alpha3": "SYR",
                "iso4217": null,
                "name": "Syrian Arab Republic",
                "nationality": "Syrian"
            }, {
                "id": "198",
                "iso2": "SZ",
                "iso3166_alpha3": "SWZ",
                "iso4217": null,
                "name": "Swaziland",
                "nationality": "Swazi"
            }, {
                "id": "199",
                "iso2": "TC",
                "iso3166_alpha3": "TCA",
                "iso4217": "USD",
                "name": "Turks and Caicos Islands",
                "nationality": "Turks and Caicos Islands"
            }, {
                "id": "200",
                "iso2": "TD",
                "iso3166_alpha3": "TCD",
                "iso4217": "XAF",
                "name": "Chad",
                "nationality": "Chadian"
            }, {
                "id": "201",
                "iso2": "TG",
                "iso3166_alpha3": "TGO",
                "iso4217": "XOF",
                "name": "Togo",
                "nationality": "Togolese"
            }, {
                "id": "202",
                "iso2": "TH",
                "iso3166_alpha3": "THA",
                "iso4217": null,
                "name": "Thailand",
                "nationality": "Thai"
            }, {
                "id": "203",
                "iso2": "TJ",
                "iso3166_alpha3": "TJK",
                "iso4217": null,
                "name": "Tajikistan",
                "nationality": "Tadjik"
            }, {
                "id": "204",
                "iso2": "TK",
                "iso3166_alpha3": "TKL",
                "iso4217": "NZD",
                "name": "Tokelau",
                "nationality": "Tokelauan"
            }, {
                "id": "205",
                "iso2": "TL",
                "iso3166_alpha3": "TLS",
                "iso4217": "USD",
                "name": "Timor-Leste",
                "nationality": "Timorese"
            }, {
                "id": "206",
                "iso2": "TM",
                "iso3166_alpha3": "TKM",
                "iso4217": "TMT",
                "name": "Turkmenistan",
                "nationality": "Turkmen"
            }, {
                "id": "207",
                "iso2": "TN",
                "iso3166_alpha3": "TUN",
                "iso4217": "TND",
                "name": "Tunisia",
                "nationality": "Tunisian"
            }, {
                "id": "208",
                "iso2": "TO",
                "iso3166_alpha3": "TON",
                "iso4217": null,
                "name": "Tonga",
                "nationality": "Tongan"
            }, {
                "id": "209",
                "iso2": "TR",
                "iso3166_alpha3": "TUR",
                "iso4217": "TRY",
                "name": "Turkey",
                "nationality": "Turk"
            }, {
                "id": "210",
                "iso2": "TT",
                "iso3166_alpha3": "TTO",
                "iso4217": null,
                "name": "Trinidad and Tobago",
                "nationality": "Trinidadian"
            }, {
                "id": "211",
                "iso2": "TV",
                "iso3166_alpha3": "TUV",
                "iso4217": "AUD",
                "name": "Tuvalu",
                "nationality": "Tuvaluan"
            }, {
                "id": "212",
                "iso2": "TW",
                "iso3166_alpha3": "TWN",
                "iso4217": null,
                "name": "Taiwan",
                "nationality": "Taiwanese"
            }, {
                "id": "213",
                "iso2": "TZ",
                "iso3166_alpha3": "TZA",
                "iso4217": null,
                "name": "Tanzania, United Republic of",
                "nationality": "Tanzanian"
            }, {
                "id": "214",
                "iso2": "UA",
                "iso3166_alpha3": "UKR",
                "iso4217": "UAH",
                "name": "Ukraine",
                "nationality": "Ukrainian"
            }, {
                "id": "215",
                "iso2": "UG",
                "iso3166_alpha3": "UGA",
                "iso4217": "UGX",
                "name": "Uganda",
                "nationality": "Ugandan"
            }, {
                "id": "216",
                "iso2": "UK",
                "iso3166_alpha3": null,
                "iso4217": null,
                "name": "United Kingdom",
                "nationality": "British"
            }, {
                "id": "217",
                "iso2": "US",
                "iso3166_alpha3": "USA",
                "iso4217": "USD",
                "name": "United States",
                "nationality": "American"
            }, {
                "id": "218",
                "iso2": "UY",
                "iso3166_alpha3": "URY",
                "iso4217": "UYU",
                "name": "Uruguay",
                "nationality": "Uruguayan"
            }, {
                "id": "219",
                "iso2": "UZ",
                "iso3166_alpha3": "UZB",
                "iso4217": "UZS",
                "name": "Uzbekistan",
                "nationality": "Uzbek"
            }, {
                "id": "220",
                "iso2": "VC",
                "iso3166_alpha3": "VCT",
                "iso4217": "XCD",
                "name": "Saint Vincent and the Grenadin",
                "nationality": "Vincentian"
            }, {
                "id": "221",
                "iso2": "VE",
                "iso3166_alpha3": "VEN",
                "iso4217": "VEF",
                "name": "Venezuela",
                "nationality": "Venezuelan"
            }, {
                "id": "222",
                "iso2": "VG",
                "iso3166_alpha3": "VGB",
                "iso4217": "USD",
                "name": "Virgin Islands, British",
                "nationality": "British Virgin Islander"
            }, {
                "id": "223",
                "iso2": "VI",
                "iso3166_alpha3": "VIR",
                "iso4217": "USD",
                "name": "Virgin Islands, U.S.",
                "nationality": "Virgin Islander"
            }, {
                "id": "224",
                "iso2": "VN",
                "iso3166_alpha3": "VNM",
                "iso4217": "VND",
                "name": "Vietnam",
                "nationality": "Vietnamese"
            }, {
                "id": "225",
                "iso2": "VU",
                "iso3166_alpha3": "VUT",
                "iso4217": "VUV",
                "name": "Vanuatu",
                "nationality": "Ni-Vanuatu"
            }, {
                "id": "226",
                "iso2": "WF",
                "iso3166_alpha3": "WLF",
                "iso4217": "XPF",
                "name": "Wallis and Futuna",
                "nationality": "Futuna Islander"
            }, {
                "id": "227",
                "iso2": "WS",
                "iso3166_alpha3": "WSM",
                "iso4217": null,
                "name": "Samoa",
                "nationality": "Samoan"
            }, {
                "id": "228",
                "iso2": "YE",
                "iso3166_alpha3": "YEM",
                "iso4217": "YER",
                "name": "Yemen",
                "nationality": "Yemeni"
            }, {
                "id": "229",
                "iso2": "YT",
                "iso3166_alpha3": "MYT",
                "iso4217": "EUR",
                "name": "Mayotte",
                "nationality": "Mahorais"
            }, {
                "id": "230",
                "iso2": "ZA",
                "iso3166_alpha3": "ZAF",
                "iso4217": null,
                "name": "South Africa",
                "nationality": "South African"
            }, {
                "id": "231",
                "iso2": "ZM",
                "iso3166_alpha3": "ZMB",
                "iso4217": "ZMW",
                "name": "Zambia",
                "nationality": "Zambian"
            }, {
                "id": "232",
                "iso2": "ZW",
                "iso3166_alpha3": "ZWE",
                "iso4217": "USD",
                "name": "Zimbabwe",
                "nationality": "Zimbabwean"
            }];
            /* jshint ignore:end */
        };



        // Add descriptions
        getAddress.description = 'userAddressFactory:getAddress';
        updateAddress.description = 'userAddressFactory:updateAddress';
        getCountries.description = 'userAddressFactory:getCountries';
        getCountryByISO.description = 'userAddressFactory:getCountryByISO';
        getCountryNameByISOAlpha3.description = 'userAddressFactory:getCountryNameByISOAlpha3';
        getShippingAddress.description = 'userAddressFactory:getShippingAddress';
        getExistingShippingAddress.description = 'userAddressFactory:getExistingShippingAddress';
        getNationalityNameByISOAlpha3.description = 'userAddressFactory:getNationalityNameByISOAlpha3';

        // Public Facing API
        return {
            getAddress: getAddress,
            updateAddress: updateAddress,
            getCountries: getCountries,
            getCountryByISO: getCountryByISO,
            getNationalityNameByISOAlpha3: getNationalityNameByISOAlpha3,
            getCountryNameByISOAlpha3: getCountryNameByISOAlpha3,
            getShippingAddress: getShippingAddress,
            getExistingShippingAddress:getExistingShippingAddress
        };
    });
