'use strict';

describe('Factory: userAddressFactory', function() {
    var userAddress,
        http,
        httpBackend,
        raddress,
        baddress,
        gaddress,
        countries,
        userAddress,
        API_BASE,
        scope,
        cache,
        addressCache;

    beforeEach(module('viewMultipleWallet'));
    // mock constants
    beforeEach(module('viewMultipleWallet', function($provide) {
        $provide.constant("TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [{
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            }]
        });
    }));
    // langugage based mock calls
    beforeEach(inject(function($httpBackend, TRANSLATION_PARAMS) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson(TRANSLATION_PARAMS).supportedLanguages.length;
        for (var i = 0; i < lngth; i++) {
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'common/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'login/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
            httpBackend.whenGET(angular.fromJson(TRANSLATION_PARAMS).partFilesPath + 'modal/' + angular.fromJson(TRANSLATION_PARAMS).supportedLanguages[i].i18n + '.json').respond(200, '');
        }
    }));
    // Initialize factory
    beforeEach(inject(function($http, $rootScope, _userAddressFactory_, _API_BASE_, _CacheFactory_) {
        userAddress = _userAddressFactory_;
        http = $http;
        scope = $rootScope;
        API_BASE = _API_BASE_;
        cache = _CacheFactory_;
        raddress = { data: { 'address_1': '25, Street ABC', 'address_2': '', 'city': '', 'state': '', 'country': '', 'zipcode': '' } };
        baddress = { data: { 'address_1': '26, Street ABC', 'address_2': '', 'city': '', 'state': '', 'country': '', 'zipcode': '' } };
        gaddress = { data: { 'email': 'test@nomail.com', 'status': 'active', 'suite': '', 'address': '12345', 'address_1': '27, Street XYZ', 'address_2': '', 'city': '', 'state': '', 'country': '', 'zipcode': '' } };
        countries = [{
            "id": "1",
            "iso2": "AD",
            "iso3166_alpha3": "AND",
            "iso4217": "EUR",
            "name": "Andorra",
            "nationality": "Andorran"
        }, {
            "id": "2",
            "iso2": "AE",
            "iso3166_alpha3": "AED",
            "iso4217": "ARE",
            "name": "United Arab Emirates",
            "nationality": "United Arab Emirates"
        }];

        httpBackend.whenGET(API_BASE + 'users/addresses/residential').respond(200, raddress.data);
        httpBackend.whenGET(API_BASE + 'users/addresses/billing').respond(200, baddress.data);
        httpBackend.whenGET(API_BASE + 'users/addresses/comgateway').respond(200, gaddress.data);
        httpBackend.whenPUT(API_BASE + 'users/addresses/residential').respond(200, 'success: Address updated successfully');
        httpBackend.whenPOST(API_BASE + 'users/addresses/comgateway').respond(200, 'opening a popup');
        httpBackend.flush();
        spyOn(userAddress, 'getCountries').and.callFake(function() {
            return countries; });
        addressCache = cache.get('addressCache');

        spyOn(cache, 'createCache').and.callThrough();

        spyOn(addressCache, 'removeAll').and.callFake(function() {});
        spyOn(http, 'get').and.callThrough();
    }));

    afterEach(function() {
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
        addressCache.destroy();
    });

    it('Should get address of type billing', function() {
        userAddress.getAddress('billing', false).then(
            function(response) {
                expect(response.data.address_1).toBe('26, Street ABC');
                expect(response.status).toBe(200);
            });
        httpBackend.flush();
    });
    it('Should get address of type residential from cache', function() {
        userAddress.getAddress('residential', true).then(
            function(response) {
                expect(response.status).toBe(200);
            });
        // httpBackend.flush();
    });
    it('Should get address of type comgateway', function() {
        userAddress.getAddress('comgateway', false).then(
            function(response) {
                expect(response.data.address_1).toBe('27, Street XYZ');
                expect(response.status).toBe(200);
            });
        httpBackend.flush();
    });
    it('Should get list of countries', function() {
        scope.countries = userAddress.getCountries();
        expect(scope.countries).toEqual(countries);
    });
    it('Should update a given address with new details', function() {
        userAddress.updateAddress('residential', raddress).then(
            function(response) {
                expect(response.data).toEqual('success: Address updated successfully');
                expect(response.status).toBe(200);
            });
        httpBackend.flush();
    });
    it('Should call comGateway popup', function() {
        userAddress.getShippingAddress().then(function(response) {
            expect(response.data).toEqual('opening a popup');
        });
        httpBackend.flush();
    });
    it('Should fetch existing comgateway Address', function() {
        userAddress.getExistingShippingAddress().then(function(response) {
            expect(response.data).toEqual(gaddress.data);
        });
        httpBackend.flush();
    });
    it('Fn getCountryNameByISOAlpha3 verification: when countryList is present', function() {
        var alpha3CountryNames = userAddress.getCountryNameByISOAlpha3(countries, 'AND');
        expect(alpha3CountryNames).toBe("Andorra");
    });
    it('Fn getNationalityNameByISOAlpha3 verification: when countryList is present', function() {
        var alpha3NationalityNames = userAddress.getNationalityNameByISOAlpha3(countries, 'AND');
        expect(alpha3NationalityNames).toBe("Andorran");
    });
    it('Fn getCountryByISO verification: when countryList is null', function() {
        var isoCountryNames = userAddress.getCountryByISO(null, null);
        expect(isoCountryNames).toBe(null);
    });
    it('Fn getCountryNameByISOAlpha3 verification: when countryList is null', function() {
        var alpha3CountryNames = userAddress.getCountryNameByISOAlpha3(null, null);
        expect(alpha3CountryNames).toBe(null);
    });
    it('Fn getNationalityNameByISOAlpha3 verification: when countryList is null', function() {
        var alpha3NationalityNames = userAddress.getNationalityNameByISOAlpha3(null, null);
        expect(alpha3NationalityNames).toBe(null);
    });
    it('Fn updateAddress: for Singapore', function() {
        var data = {};
        data.address_1 = 'lane 1';
        data.country = "Singapore";
        userAddress.updateAddress('residential', data).then(function(response) {
            expect(response.data).toEqual('success: Address updated successfully');
            expect(response.status).toBe(200);
        })
        httpBackend.flush();
    });
});
