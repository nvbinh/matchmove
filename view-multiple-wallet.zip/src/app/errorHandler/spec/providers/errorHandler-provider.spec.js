describe('Provider: errorHandler', function() {
  var errorHandler;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_errorHandler_) {
    errorHandler = _errorHandler_;
  }));

   it('should say hello', function() {
  //   expect(errorHandler.greet()).toEqual('Hello');
   });

});
