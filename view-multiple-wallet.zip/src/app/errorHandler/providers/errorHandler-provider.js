'use strict';

/**
 * @ngdoc service
 * @name viewMultipleWallet.errorHandler
 * @description
 * # errorHandler
 * Provider in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .constant('httpErrors', {
     '-1': 'Unexpected error occurred.',
      0: '0',
    404: '404',
    500: '500',
    401: '401'
  })
  .provider('errorHandler', function (LOG_DEBUG) {
// Wrap a single function [func] in another function that handles both synchronous and asynchonous errors.
    function decorate($injector, obj, func) {
      return angular.extend(function() {
        var handler = $injector.get('errorHandler');
        return handler.call(func, obj, arguments);
      }, func);
    }

    // Decorate all functions of the service [$delegate] with error handling. This function should be used as decorator
    // function in a call to $provide.decorator().
    var decorator = ['$delegate', '$injector', function($delegate, $injector) {
      // Loop over all functions in $delegate and wrap these functions using the [decorate] functions above.
      for (var prop in $delegate) {
        if (angular.isFunction($delegate[prop])) {
          $delegate[prop] = decorate($injector, $delegate, $delegate[prop]);
        }
      }
      return $delegate;
    }];

    // The actual service:
    return {
      // Decorate the mentioned [services] with automatic error handling. See demo.js for an example.
      decorate: function ($provide, services) {
        angular.forEach(services, function (service) {
          $provide.decorator(service, decorator);
        });
      },

      $get: function ($log, httpErrors, $analytics, $rootScope, $translate, $state, store) {

        var handler = {

          // The list of errors.
          errors: [],


          // Report the error [err] in relation to the function [func].
          funcError: function (func, err) {

            // This is a very limited error handler... you would probably want to check for user-friendly error messages
            // that were returned by the server, etc, etc, etc. Our original code contains a lot of checks and handling
            // of error messages to create the "perfect" error message for our users, you should probably do the same. :)
// console.log(err);
// console.log(func.name);
            if (err && !angular.isUndefined(err.status)) {
              // A lot of errors occur in relation to HTTP calls... translate these into user-friendly msgs.
              var errDisp = '';//httpErrors[err.status];
              //var ers = err.statusText;

              if(err.status === 500) {
                switch(func.description){
                  case 'authenticationFactory:Login':
                    $analytics.eventTrack('Error Logging in', {  category: 'Error 500', label: 'Error Logging in' });
                    break;
                  case 'Cards:getCardNoCache':
                    $analytics.eventTrack('YCS error', {  category: 'YCS Error 500', label: 'YCS Error' });
                    break;
                  case 'userswalletscardsfundsFactory:loadCard':
                    $analytics.eventTrack('Error loading card in Dashboard', {  category: 'Error 500', label: 'Error loading card in Dashboard' });
                    errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.500_SERVICE_ERROR');
                    break;
                  case 'userswalletscardsfundsFactory:unloadCard':
                    $analytics.eventTrack('Error unloading card in Dashboard', {  category: 'Error 500', label: 'Error unloading card in Dashboard' });
                    errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.500_SERVICE_ERROR');
                    break;
                  case 'Wallet:getWallet':
                    $rootScope.backendError = true;
                    $analytics.eventTrack('Error fetching Wallet information in the dashboard', {
                        category: 'Error 500',
                        label: 'Error fetching Wallet information in the dashboard'
                    });
                    break;
                  default:
                    break;
                }
              }
              else if (err.status === 401) {
                switch (func.description) {
                    case 'authenticationFactory:Login':
                        if (err.statusText.indexOf('userTemporarilyBlocked') > -1) {
                            $analytics.eventTrack('Login error', {
                                category: 'Login',
                                label: 'Login Error : ' + err.status + ' : ' + err.statusText
                            });
                            errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.BLOCK');
                        } else {
                            $analytics.eventTrack('Login error', {
                                category: 'Login',
                                label: 'Login Error : ' + err.status + ' : ' + err.statusText
                            });
                            errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.GENERIC');
                        }
                        break;
                    case 'userswalletscardsfundsFactory:unloadCard':
                        errDisp = err.statusText;
                        $analytics.eventTrack('Uncaught Error Unload Card', {
                            category: 'Unload Card',
                            label: 'Uncaught Error Unload Card :' + err.status + ' : ' + err.statusText
                        });
                        break;
                    default:
                        break;
                }
              }
              else if(err.status === 404){
                switch(func.description){
                  case 'Cards:getCardNoCache':
                   $analytics.eventTrack('Card Fetch error', {  category: 'Cards', label: 'Card Fetch Error : ' + err.status + ' : ' + err.statusText });
                    break;
                  case 'userswalletscardsfundsFactory:unloadCard':
                    errDisp = err.statusText;
                    $analytics.eventTrack('Uncaught Error Unload Card', {
                            category: 'Unload Card',
                            label: 'Uncaught Error Unload Card :' + err.status + ' : ' + err.statusText
                          });
                    break;
                  default:
                    break;
                }
              }
              else if(err.status === 403){
                switch(func.description){
                  case 'authenticationFactory:Login':
                     if (err.statusText.indexOf('user_blocked_risk_threshold_exceeded') > -1)  {
                       $analytics.eventTrack('Login Error', {  category: 'Risk Activity', label: 'Login Forbidden : ' + err.status + ' : ' + err.statusText });
                       errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.RISK');
                     }
                     else {
                       $analytics.eventTrack('Login Error', {  category: 'Login', label: 'Login Error : ' + err.status + ' : ' + err.statusText });
                       errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.FALLBACK');
                     }
                    break;
                  default:
                    break;
                }
              }
              else if(err.status === 400){
                  switch(func.description){
                    case 'userswalletscardsfundsFactory:loadCard':
                      if (err.statusText.indexOf('greater_than_limit') > -1) {
                          errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.400.GREATER_THAN_LIMIT');
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                        else if (err.statusText.indexOf('card_fund_transfer_purse_daily_limit_reached') > -1) {
                          errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_DAILY_LIMIT_REACHED');
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                        else if (err.statusText.indexOf('card_fund_transfer_purse_weekly_limit_reached') > -1) {
                          errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_WEEKLY_LIMIT_REACHED');
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                        else if (err.statusText.indexOf('card_fund_transfer_purse_monthly_limit_reached') > -1) {
                          errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_MONTHLY_LIMIT_REACHED');
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                        else if (err.statusText.indexOf('card_fund_transfer_purse_lifetime_transactional_limit_reached') > -1) {
                          errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_PURSE_LIFETIME_LIMIT_REACHED');
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                        else if (err.statusText.indexOf('resource_card_fund_transfer_maximum_credit_limit_reached') > -1) {
                          errDisp = $translate.instant('ERRORS.VALIDATION.LOAD.400.CARD_FUND_TRANSFER_MAX_CREDIT_LIMIT_REACHED');
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                        else {
                          errDisp = err.statusText;
                          $analytics.eventTrack('Invalid Request Load Card', {  category: 'Load Card', label: 'Invalid Request Load Card :' + err.statusText });
                        }
                      break;
                    case 'userswalletscardsfundsFactory:unloadCard':
                      if (err.statusText.indexOf('greater_than_limit') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.GREATER_THAN_LIMIT');
                            $analytics.eventTrack('Invalid Request Unload Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Unload Card :' + err.statusText
                            });
                        } else if (err.statusText.indexOf('card_fund_transfer_purse_daily_limit_reached') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_DAILY_LIMIT_REACHED');
                            $analytics.eventTrack('Invalid Request Unload Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Unload Card :' + err.statusText
                            });
                        } else if (err.statusText.indexOf('card_fund_transfer_purse_weekly_limit_reached') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_WEEKLY_LIMIT_REACHED');
                            $analytics.eventTrack('Invalid Request Unload Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Unload Card :' + err.statusText
                            });
                        } else if (err.statusText.indexOf('card_fund_transfer_purse_monthly_limit_reached') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_MONTHLY_LIMIT_REACHED');
                            $analytics.eventTrack('Invalid Request Unload Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Unload Card :' + err.statusText
                            });
                        } else if (err.statusText.indexOf('resource_card_fund_transfer_maximum_credit_limit_reached') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_MAX_CREDIT_LIMIT_REACHED');
                            $analytics.eventTrack('Invalid Request Unload Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Unload Card :' + err.statusText
                            });
                        } else if (err.statusText.indexOf('lifetime transactional limit') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_PURSE_LIFETIME_LIMIT_REACHED');
                            $analytics.eventTrack('Invalid Request Load Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Load Card :' + err.statusText
                            });
                        } else if (err.statusText.indexOf('resource_card_fund_transfer_minimum_credit_limit_reached') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.UNLOAD.400.CARD_FUND_TRANSFER_MIN_CREDIT_LIMIT_REACHED');
                            $analytics.eventTrack('Invalid Request Load Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Load Card :' + err.statusText
                            });
                        } else {
                            errDisp = err.statusText;
                            $analytics.eventTrack('Invalid Request Unload Card', {
                                category: 'Unload Card',
                                label: 'Invalid Request Unload Card :' + err.statusText
                            });
                        }
                      break;
                    case 'Cards:cardCreate':
                         if (err.statusText.indexOf('cardOrderFailed') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.CARDNEW.400.CARD_TYPE_MAX');
                            $analytics.eventTrack('Error creating an additional card', {  category: 'Error 400', label: 'Error creating an additional card maximum card type reached'});
                        } else if (err.statusText.indexOf('assoc_number') > -1) {
                           errDisp = $translate.instant('ERRORS.VALIDATION.WALLET_LINK.ERROR400_PROXYINUSE');
                           $analytics.eventTrack('Error activating a card', {  category: 'Error 400', label: 'Proxy number already in use'});
                       } else {
                           errDisp = $translate.instant('ERRORS.VALIDATION.WALLET_LINK.ERROR400_CARDINUSE');
                           $analytics.eventTrack('Error activating a card', {  category: 'Error 400', label: 'Card number already in use'});
                       }
                      break;
                    case 'authMobileFactory:verifyOtp':
                        if (err.statusText.indexOf('userAuthenticationValidationTokenExpired') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.400.EXPIRED');
                            $analytics.eventTrack('OTP Expired', {  category: 'Error 400', label: 'OTP code already expired'});
                        }
                        break;
                    case 'Cards:cardVerify':
                        if (err.statusText.indexOf('userAuthenticationValidationTokenExpired') > -1) {
                            errDisp = $translate.instant('ERRORS.VALIDATION.CARD_ACTIVATE.400.TOKENEXPIRED');
                            $analytics.eventTrack('OTP Expired', {  category: 'Error 400', label: 'OTP code already expired'});
                        }
                        break;
		    case 'userAddressFactory:updateAddress':
                    	if(err.statusText.indexOf('`zipcode` is too long, it cannot exceed 15 characters')>-1){
                    		errDisp = $translate.instant('ERRORS.VALIDATION.WALLET_DETAILS.BILLING_ADDRESS.ZIPCODE_MAXLENGTH');
                    		$analytics.eventTrack('Update address', {
                                category: 'Error 400 ',
                                label: 'Zipcode is too long'
                            });
                    	}
                    	break;
                    default:
                      break;
                  } // end switch
              } // end status 400
              else if(err.status === 504){
                // handle msg for gateway timeout
                $analytics.eventTrack('Uncaught error Gateway timeout', {  category: 'Connectivity', label: 'Gateway timeout Error : ' + err.status });
                errDisp = $translate.instant('ERRORS.GENERIC.GATEWAY_TIMEOUT');
              }
              else if(err.status === 498){
                  switch(func.description){
                    case 'authenticationFactory:Login':
                       if (err.statusText.indexOf('access_token_expired') > -1)  {
                         $analytics.eventTrack('Login Error', {  category: 'Risk Activity', label: 'Login Forbidden : ' + err.status + ' : ' + err.statusText });
                         errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.INTERNAL_SERVER');
                       }
                       else {
                         $analytics.eventTrack('Login Error', {  category: 'Login', label: 'Login Error : ' + err.status + ' : ' + err.statusText });
                         errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.FALLBACK');
                       }
                      break;
                    default:
                      break;
                  }
              }
              else if(err.status === -1){
                // Do nothing. allow passthrough. as connectivity is handled by Offline.js
                // when -1 status is received
                //$analytics.eventTrack('Uncaught error Connectivity', {  category: 'Connectivity', label: 'Uncaught Connectivity Error : ' + err.status });
                //errDisp = $translate.instant('ERRORS.VALIDATION.LOGIN.CONNECTIVITY');
              }
            } else if (err && (err.message || err.statusText)) {
              // Exceptions are unwrapped.
              errDisp = err.message || err.statusText;
            }
            /*if (typeof ers === undefined && !angular.isString(err.statustext)) {
              ers = 'An unknown error occurred.';
            }*/

            // Use the context provided by the service.
            /*if (func && func.description) {console.log(func.description);
              ers = 'Unable to ' + func.description + '-' + err.statusText.replace(/HTTP\/\d.\d \d\d\d/, "");
            }*/
            if(errDisp === ''){
              errDisp = 'Error '+ err.status + ' at ' + func.description + ' -' + err.statusText.replace(/HTTP\/\d.\d \d\d\d/, "");
            }

            if(LOG_DEBUG === true) {
              console.log(errDisp);
              $log.info('Caught error: ' + errDisp);
            }
            handler.errors[0] = errDisp;
          },


          // Call the provided function [func] with the provided [args] and error handling enabled.
          call: function (func, self, args) {
            if(LOG_DEBUG === true){
              $log.debug('Called Factory:Function - ' + func.description + ' from ' + store.get('controller'));
            }

            var result;
            try {
              result = func.apply(self, args);
            } catch (err) {
              // Catch synchronous errors.
              handler.funcError(func, err);
              throw err;
            }

            // Catch asynchronous errors.
            var promise = result && result.$promise || result;
            if (promise && angular.isFunction(promise.then) && angular.isFunction(promise['catch'])) {
              // promise is a genuine promise, so we call [handler.async].
              handler.async(func, promise);
            }

            return result;
          },


          // Automatically record rejections of the provided [promise].
          async: function (func, promise) {
            promise['catch'](function (err) {
              handler.funcError(func, err);
            });
            return promise;
          }
        };

        return handler;
      }
    };
  });
