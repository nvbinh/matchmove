describe('Factory: usersremittancesFactory', function() {
  var usersremittances,
      http,
      httpBackend,
      API_BASE,
      scope;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function($http, $httpBackend, $rootScope,_usersremittancesFactory_, _API_BASE_) {
    usersremittances = _usersremittancesFactory_;
    httpBackend = $httpBackend;
    http = $http;
    scope = $rootScope;
    API_BASE = _API_BASE_;
  }));

  // describe('get data wallet', function() {
  //   beforeEach(inject(function() {
  //     httpBackend.when('GET', API_BASE + 'users/wallets').respond(200, '');
  //     httpBackend.flush();
  //   }));
  //
  //   it('should have a response status after get wallet info', function () {
  //     userswalletscardsfundsoverseas.getWalletData().then(function(response){
  //         expect(response.data).toBeDefined();
  //     });
  //   });
  // });

});
