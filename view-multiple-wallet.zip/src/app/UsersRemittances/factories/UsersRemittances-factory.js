'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.usersremittances
 * @description
 * # usersremittances
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .factory('usersremittancesFactory', function (API_BASE, $http) {
    return {
      getProviders: function () {
        return $http.get(API_BASE + 'users/wallets/funds/transfers/overseas/types');
      },
      getFees : function(type,payload) {
        return $http({
            method: 'POST',
            url: API_BASE + 'users/wallets/funds/transfers/overseas/' + type + '/calculate',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                    str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
                return str.join('&');
            },
            data: payload
        });
      },
      getRates : function(payload) {
        return $http({
            method: 'GET',
            url: API_BASE + 'users/wallets/funds/transfers/overseas/rates',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                    str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
                return str.join('&');
            },
            params: payload
        });
      },
      calculateFees : function(type,payload) {
        return $http.get(API_BASE + 'users/wallets/funds/transfers/overseas/' + type + '/fees', {params:payload});
      },
      confirmTransfer : function(id) {
        return $http({
            method: 'PUT',
            url: API_BASE + 'users/wallets/funds/transfers/overseas/' + id,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                    str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
                return str.join('&');
            }
        });
      },
      doTransfer : function(type,payload) {
        return $http({
            method: 'POST',
            url: API_BASE + 'users/wallets/funds/transfers/overseas/' + type,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                    str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                }
                return str.join('&');
            },
            data: payload
        });
      },
      getOverseasTransfer :function(id) {
        return $http.get(API_BASE + 'users/wallets/funds/transfers/overseas/' + id );
      },
      deleteOverseasTransfer :function(id,payload) {
        return $http.delete(API_BASE + 'users/wallets/funds/transfers/overseas/' + id, {data:payload});
      }
    };
  });
