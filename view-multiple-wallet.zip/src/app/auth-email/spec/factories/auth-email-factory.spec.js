'use strict';

describe('Factory: authEmailFactory', function() {
  var authEmail,
    rc4Factory,
    API_BASE,
    EMAIL_VERIFICATION_URL,
    base64Factory,
    cookieStore,
    httpBackend,
    rootScope,
    scope,
    HTTP_HOST;

  beforeEach(module('viewMultipleWallet'));
  // mock constants
  beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
      $provide.constant( "TRANSLATION_PARAMS", {
          "partFilesPath": "../assets/locales/",
          "preferredLanguage": "vi_vn",
          "client": "hdb",
          "source": "http://localhost:3000/assets/hdb/locales\/",
          "supportedLanguages": [ {
              "i18n": "en_us",
              "name": "English"
          }, {
              "i18n": "vi_vn",
              "name": "Vietnamese"
          } ]
      } );
  } ) );
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize factory
  beforeEach(inject(function(_authEmailFactory_, $cookieStore, API_BASE, $rootScope, $http, HTTP_HOST, EMAIL_VERIFICATION_URL, _rc4Factory_) {
    authEmail = _authEmailFactory_;
    cookieStore = $cookieStore;
    API_BASE = API_BASE;
    HTTP_HOST = HTTP_HOST;
    rc4Factory = _rc4Factory_;
    EMAIL_VERIFICATION_URL = EMAIL_VERIFICATION_URL;
    scope = $rootScope;
    rootScope = $rootScope;
    httpBackend.whenPOST(API_BASE + 'users/authentications/email').respond(200, {
          "status": "success",
          "token": "fb0a39227cd35a8a82460d5119083a6a"
        });
    httpBackend.whenPUT(API_BASE + 'users/authentications/email').respond(200, {status: 'email activated'});
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingRequest();
    httpBackend.verifyNoOutstandingRequest();
  });

  it('should have authMobile service be defined', function () {
    expect(authEmail).toBeDefined();
  });

  it('getToken', function () {
    var endpointdata = HTTP_HOST + EMAIL_VERIFICATION_URL;
    authEmail.getToken(endpointdata).then(function(response){
        expect(response.data).toBeDefined();
        expect(response.data.status).toBe('success');
    });
    httpBackend.flush();
  });

  it('setToken', function () {
    var token = 'd42b9fc638e77119588b86abeca087f2';
    authEmail.setToken(token);
    expect(rootScope.authorization.email.token).toEqual(token);
  });

  it('verifyToken', function () {
     var user = {email: "balajiv+12@chimeratechnologies.com"};
    spyOn(rc4Factory, 'encode').and.callThrough();
    authEmail.verifyToken("fb0a39227cd35a8a82460d5119083a6a", user).then(function(response){
        expect(response.data).toBeDefined();
        expect(response.data.status).toBe('email activated');
    });
    httpBackend.flush();
  });

});
