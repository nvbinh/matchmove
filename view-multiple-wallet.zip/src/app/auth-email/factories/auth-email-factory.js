'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authEmail
 * @description
 * # authEmail
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .service('authEmailFactory', function (API_BASE, rc4Factory, base64Factory, $http, $cookieStore, $rootScope) {
// Service logic
// ...
    function getToken(endpointdata) {
        return $http({
           method: 'POST',
           url : API_BASE + 'users/authentications/email',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          transformRequest: function(obj) {
              var str = [];
              for(var p in obj) {
                  str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
              }
              return str.join('&');
          },
           data : endpointdata
        });
    };

    function setToken(token) {
        $rootScope.authorization = {
            email: {
                token: token
            }
        };
        $cookieStore.put('authorization', $rootScope.authorization);
    };

    function verifyToken(token, user) {
        return $http({
          method: 'PUT',
          url: API_BASE + 'users/authentications/email',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          transformRequest: function(obj) {
              var str = [];
              for(var p in obj) {
                  str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
              }
              return str.join('&');
          },
          data: {'key':rc4Factory.encode(token, user), 'token':token}
        });
    };

    // Add descriptions
    getToken.description = 'authEmailFactory:getToken';
    setToken.description = 'authEmailFactory:setToken';
    verifyToken.description = 'authEmailFactory:verifyToken';

    // Public facing API
    return {
        getToken: getToken,
        setToken: setToken,
        verifyToken: verifyToken
    };
  });
