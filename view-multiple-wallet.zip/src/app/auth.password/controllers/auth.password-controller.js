'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:walletPasswordCtrl
 * @description
 * # walletPasswordCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authPasswordCtrl', function () {

    } );
