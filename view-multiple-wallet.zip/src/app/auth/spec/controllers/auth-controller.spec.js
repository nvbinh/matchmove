'use strict';
describe( 'Controller: authCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    var authCtrl,
        scope,
        rootScope,
        x,
        httpBackend,
        mobiledetectService;
    //Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, MM_BRANDING, _mobiledetectService_ ) {
        scope = $rootScope.$new();
        rootScope = $rootScope;
        mobiledetectService = _mobiledetectService_;

        x = {"x": 45, "y": 35};
        authCtrl = $controller( 'authCtrl', {
            $scope: scope
        } );
    } ) );
    afterEach(function() {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    });
    it( 'should have showBranding', inject( function ( MM_BRANDING ) {
        expect( scope.showBranding ).toBe( MM_BRANDING );
    } ) );
    it( 'scope.openSidebar', function () {
        expect( scope.openSidebar ).toBeDefined();
    } );
    it( 'scope.closeSidebar', function () {
        expect( scope.closeSidebar ).toBeDefined();
    } );
    it('Fn call closeSidebar', function(){
        spyOn(scope, 'closeSidebar').and.callThrough();
        scope.closeSidebar();
        expect(rootScope.sideBarActive).toBeFalsy();
    })
    it('Fn call openSidebar', function(){
        spyOn(scope, 'openSidebar').and.callThrough();
        spyOn(mobiledetectService, 'tablet').and.returnValue(true);
        spyOn(mobiledetectService, 'mobile').and.returnValue(true);
        spyOn(mobiledetectService, 'phone').and.returnValue(false);
        scope.openSidebar({touches:[1,2,3]});
        // TODO:: fix this expectation
        // expect(rootScope.sideBarActive).toBeTruthy();
    })
} );
