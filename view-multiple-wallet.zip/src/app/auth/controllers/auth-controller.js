'use strict';
/* global angular */

/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:walletCtrl
 * @description
 * # walletCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authCtrl', function ( MM_BRANDING, $scope, $rootScope, mobiledetectService ) {
        $scope.showBranding = MM_BRANDING;

        // Return X-Coordinate
        function getCoordinates( event ) {
            var touches = event.touches && event.touches.length ? event.touches : [ event ];
            var e = ( event.changedTouches && event.changedTouches[ 0 ] ) ||
                ( event.originalEvent && event.originalEvent.changedTouches &&
                    event.originalEvent.changedTouches[ 0 ] ) ||
                touches[ 0 ].originalEvent || touches[ 0 ];

            return {
                x: e.clientX
            };
        };

        // Swipe-right will call function
        $scope.openSidebar = function ( $event ) {
            var x = getCoordinates( $event );
            var QuarterWidth = $( window ).width() / 4;
            var OctateWidth = $( window ).width() / 8;
            var UAString = (mobiledetectService.mobile() && mobiledetectService.tablet()) ||
                            (mobiledetectService.mobile() && mobiledetectService.phone());
            if ( UAString ) {
                if ( x.x > OctateWidth && x.x < QuarterWidth ) {
                    $rootScope.sideBarActive = true;
                }
            }
        };

        // Swipe-left will call function
        $scope.closeSidebar = function () {
            $rootScope.sideBarActive = false;
        };

    } );
