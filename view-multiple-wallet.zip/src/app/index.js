
'use strict';
/* global angular */

angular.module( 'viewMultipleWallet', [
        'ngAnimate',
        'ngCookies',
        'ngTouch',
        'ngMessages',
        'angular-storage',
        'ngSanitize',
        'ui.router',
        'pascalprecht.translate',
        'ngDialog',
        'angular.filter',
        'firebase',
        'betsol.intlTelInput',
        'ngIdle',
        'vTabs',
        'vAccordion',
        'ngDropover',
        'datePicker',
        'angulartics',
        'angulartics.google.analytics',
        'angularUtils.directives.dirPagination',
        'angulartics.mixpanel',
        'flow',
        'timer',
        'ngMap',
        'angular-cache',
        'PubSub',
        'ngJSONPath',
        'ui.router.title',
        'ngProgress',
        'angular-md5',
        'ngAria',
        'angularMoment'
    ] )
    .config( function ( errorHandlerProvider, KeepaliveProvider, flowFactoryProvider, IdleProvider, $urlRouterProvider, $stateProvider, $locationProvider, $translateProvider, $httpProvider, $logProvider, $analyticsProvider, $compileProvider, $provide, CacheFactoryProvider, intlTelInputOptions, TRANSLATION_PARAMS, LOG_DEBUG, $translatePartialLoaderProvider,  $touchProvider ) {


        /**
         * CacheFactory settings
         */
        angular.extend( CacheFactoryProvider.defaults, {
            maxAge: 15 * 60 * 1000
        } );

        // this setting handles touch based devices responding to ng-click without the documented 300ms browser delay
        $touchProvider.ngClickOverrideEnabled(true);

        /**
         * Hide debug helper from angular for production
         **/
        if(!LOG_DEBUG) {
          $compileProvider.debugInfoEnabled(false);
        }

        /* Offline js options*/
        window.Offline.options = {
                checks:{
                  xhr:{
                    url:function() {
                      return "http://localhost/favicon.ico?_=" + ((new Date()).getTime());
                    }
                  },
                  image:{
                    url:function() {
                      return "http://localhost/favicon.ico?_=" + ((new Date()).getTime());
                    }
                  }
                }
            };

        /* offline settings */
        $provide.constant('Offline', window.Offline);

        /**
         * Translate provider to handle localizations
         **/
        var translationUrl = angular.fromJson( TRANSLATION_PARAMS ).source;
        $translateProvider.useLocalStorage();

        $translateProvider.useLoader( '$translatePartialLoader', {
            urlTemplate: angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + '{part}/{lang}.json'
        } );
        $translateProvider.useSanitizeValueStrategy( null );

        $translateProvider.preferredLanguage( 'en_us' );
        $translateProvider.use( 'en_us' );
        $translateProvider.fallbackLanguage( 'en_us' );

        $provide.decorator('$$rAF', ["$delegate", function ($delegate) {
          /**
           * Use this to throttle events that come in often.
           * The throttled function will always use the *last* invocation before the
           * coming frame.
           *
           * For example, window resize events that fire many times a second:
           * If we set to use an raf-throttled callback on window resize, then
           * our callback will only be fired once per frame, with the last resize
           * event that happened before that frame.
           *
           * @param {function} callback function to debounce
           */
          $delegate.throttle = function(cb) {
            var queuedArgs, alreadyQueued, queueCb, context;
            return function debounced() {
              queuedArgs = arguments;
              context = this;
              queueCb = cb;
              if (!alreadyQueued) {
                alreadyQueued = true;
                $delegate(function() {
                  queueCb.apply(context, Array.prototype.slice.call(queuedArgs));
                  alreadyQueued = false;
                });
              }
            };
          };
          return $delegate;
        }]);

        $provide.decorator('$mmUtil', ['$delegate', function ($delegate) {

          // Inject the prefixer into our original $mmUtil service.
          $delegate.prefixer = MmPrefixer;

          return $delegate;
        }]);
        $provide.decorator( 'mFormatFilter', function () {
            return function newFilter( m, format, tz ) {
                // console.log(moment.isMoment(m + format + tz));
                if ( !m ) {
                    return '';
                }
                return tz ? moment.tz( m, tz )
                    .format( format ) : m.format( format );
            };
        } );
        // resolve functions
        $httpProvider.interceptors.push( 'apiinterceptorService' );
        errorHandlerProvider.decorate( $provide, [ 'authenticationFactory',
            'userFactory',
            'Wallet',
            'Cards',
            'userswalletscardsfundsFactory',
            'userTransactionsFactory',
            'authDocumentFactory',
            'authEmailFactory',
            'authMobileFactory',
            'authPasswordFactory',
            'userAddressFactory',
            'userNotificationsFactory'
        ] );

        $httpProvider.defaults.headers.post = {
            'Content-Type': 'application/json; charset=utf-8'
        };


        IdleProvider.idle( 800 );
        IdleProvider.timeout( 100 );
        KeepaliveProvider.interval( 10 );

        $locationProvider.html5Mode( {
            enabled: true,
            requireBase: false
        } );

        flowFactoryProvider.defaults = {
            target: '',
            permanentErrors: [ 500, 501 ],
            maxChunkRetries: 1,
            chunkRetryInterval: 5000,
            simultaneousUploads: 1
        };
        flowFactoryProvider.on( 'catchAll', function () {
            // console.log('catchAll', arguments);
        } );
        // Can be used with different implementations of Flow.js
        // flowFactoryProvider.factory = fustyFlowFactory;

        $analyticsProvider.firstPageview( true ); /* Records pages that don't use $state or $route */
        $analyticsProvider.withAutoBase( true ); /* Records full path */

        var walletData = function (Wallet, $q) {
                        var deferred = $q.defer();
                        Wallet.getWallet(true).then(function(response){
                            deferred.resolve(response);
                        }, function(error){
                            deferred.reject(error);
                        });
                        return deferred.promise;
                    };

        angular.extend( intlTelInputOptions, {
            autoFormat: false,
            skipUtilScriptDownload: false,
            utilsScript: 'https://assets.mmvpay.com/common/scripts/utils.min.js'
        } );

        function getTranslateForPageTitle( part, $q, $translate ) {
            var deferred = $q.defer();
            //console.log($translate.use());
            var partResponse, mainText;
            var promises = [];
            promises.push( $translate( part ).then( function ( partResponse ) {
                return partResponse
            } ) );
            promises.push( $translate( 'PAGE_TITLE_TEXT', {
                pagename: partResponse
            } ).then( function ( mainText ) {
                return mainText
            } ) );
            $q.all( promises ).then( function ( response ) {
                deferred.resolve( response[ 0 ] + response[ 1 ] );
            } )
            return deferred.promise;
        }

        /**
         * Define the application routes
         */
        $stateProvider
            .state( 'auth', {
                url: '/auth',
                abstract: true,
                templateUrl: 'app/auth/partials/auth.html',
                controller: 'authCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'common', 'modal' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH', $q, $translate );
                    }
                }
            } )
            .state( 'auth.login', {
                url: '/login?referrer',
                templateUrl: 'app/auth.login/partials/auth.login.html',
                controller: 'authLoginCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'login' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_LOGIN', $q, $translate );
                    }
                },
                onEnter: function($stateParams, $state,store) {
                    if (store.get('user') && $stateParams.referrer === "transfer")
                        {$state.go('wallet.fund.claim');}
                }
            } )
            .state( 'auth.create', {
                url: '/create/:transferToken',
                params: {
                    transferToken: {
                        value: null,
                        squash: false
                    }
                },
                templateUrl: 'app/auth.create/partials/auth.create.html',
                controller: 'authCreateCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'login', 'wallet.create' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_CREATE', $q, $translate );
                    }
                }
            } )
            .state( 'auth.close', {
                url: '/close?user_id?token',
                templateUrl: 'app/auth.close/partials/auth.close.html',
                controller: 'authCloseCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'auth.close', 'login' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_CLOSE', $q, $translate );
                    }
                }
            } )
            .state( 'auth.password', {
                url: '/password',
                templateUrl: 'app/auth.password/partials/auth.password.html',
                controller: 'authPasswordCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_PASSWORD', $q, $translate );
                    }
                }
            } )
            .state( 'auth.password.forgot', {
                url: '/forgot/:token',
                templateUrl: 'app/auth.password.forgot/partials/auth.password.forgot.html',
                controller: 'authPasswordForgotCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.password.temporary', 'wallet.password.change', 'login' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_PASSWORD_FORGOT', $q, $translate );
                    }
                }
            } )
            .state( 'auth.password.recover', {
                url: '/recover',
                templateUrl: 'app/auth.password.recover/partials/auth.password.recover.html',
                controller: 'authPasswordRecoverCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.password.recover', 'login' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_PASSWORD_RECOVER', $q, $translate );
                    }
                }
            } )
            .state( 'auth.password.change', {
                url: '/change/:token',
                templateUrl: 'app/auth.password.change/partials/auth.password.change.html',
                controller: 'authPasswordChangeCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.password.change', 'login' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_PASSWORD_CHANGE', $q, $translate );
                    }
                }
            } )
            .state( 'auth.password.create', {
                url: '/create/:token',
                templateUrl: 'app/auth.password.create/partials/auth.password.create.html',
                controller: 'authPasswordCreateCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.password.create', 'login' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_PASSWORD_CREATE', $q, $translate );
                    }
                }
            } )
            .state( 'auth.email', {
                url: '/email',
                templateUrl: 'app/auth.email/partials/auth.email.html',
                controller: 'authEmailCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.activate' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_EMAIL', $q, $translate );
                    }
                }
            } )
            .state( 'auth.email.activate', {
                url: '/activate/:token',
                templateUrl: 'app/auth.email.activate/partials/auth.email.activate.html',
                controller: 'authEmailActivateCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'login','wallet.create', 'wallet.activate.email' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.AUTH_EMAIL_ACTIVATE', $q, $translate );
                    }
                }
            } )
            .state( 'wallet', {
                url: '/wallet',
                abstract: true,
                templateUrl: 'app/wallet/partials/wallet.html',
                controller: 'walletCtrl',
                history: {trace: false, button:'none'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'common', 'modal', 'wallet.loyalty.list' );
                    }
                }
            } )
            .state( 'wallet.home', {
                url: '/home',
                templateUrl: 'app/wallet.home/partials/wallet.home.html',
                controller: 'walletHomeCtrl',
                history: {trace: true, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    userdata: function (userFactory) {
                        return userFactory.getUser(true);
                    },
                    cardslistdata: function ( Cards ) {
                        return Cards.cardsList();
                    },
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.home', 'wallet.card.new' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_HOME', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.card', {
                url: '/card',
                templateUrl: 'app/wallet.card/partials/wallet.card.html',
                controller: 'walletCardCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.card' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_CARD', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.card.new', {
                url: '/new',
                templateUrl: 'app/wallet.card.new/partials/wallet.card.new.html',
                controller: 'walletCardNewCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.card.new', 'wallet.link' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_CARD_NEW', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.remit', {
                url: '/remit',
                templateUrl: 'app/wallet.remit/partials/wallet.remit.html',
                controller: 'walletRemitCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.remit' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_REMIT', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.remit.select', {
                url: '/select',
                templateUrl: 'app/wallet.remit.select/partials/wallet.remit.select.html',
                controller: 'walletRemitSelectCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.remit.select' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_REMIT_SELECT', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.remit.enter', {
                url: '/enter?providerName&partner_name&transfer_currency&calculation_mode&amount&receive_country&receive_currency&send_currency&payment_mode&first_name&last_name&address_1&address_2&birth_date&city&state&country&nationality&zipcode&routing_type&routing_param&reason',
                templateUrl: 'app/wallet.remit.enter/partials/wallet.remit.enter.html',
                controller: 'walletRemitEnterCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.remit.enter' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_REMIT_ENTER', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.remit.confirm', {
                url: '/confirm?providerName&partner_name&transfer_currency&calculation_mode&amount&receive_country&receive_currency&send_currency&payment_mode&first_name&last_name&address_1&address_2&birth_date&city&state&country&nationality&zipcode&routing_type&routing_param&reason',
                templateUrl: 'app/wallet.remit.confirm/partials/wallet.remit.confirm.html',
                controller: 'walletRemitConfirmCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.remit.confirm' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_REMIT_CONFIRM', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.remit.summary', {
                url: '/summary?transactionId&providerName&partner_name&transfer_currency&calculation_mode&amount&receive_country&receive_currency&send_currency&payment_mode&first_name&last_name&address_1&address_2&birth_date&city&state&country&nationality&zipcode&routing_type&routing_param&reason',
                templateUrl: 'app/wallet.remit.summary/partials/wallet.remit.summary.html',
                controller: 'walletRemitSummaryCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.remit.summary' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_REMIT_SUMMARY', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.send', {
                url: '/send',
                templateUrl: 'app/wallet.send/partials/wallet.send.html',
                controller: 'walletSendCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.send' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_SEND', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.send.select', {
                url: '/select',
                templateUrl: 'app/wallet.send.select/partials/wallet.send.select.html',
                controller: 'walletSendSelectCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.send.select' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_SEND_SELECT', $q, $translate );
                    }
                }
            })
            .state( 'wallet.send.success', {
                url: '/success',
                templateUrl: 'app/wallet.send.success/partials/wallet.send.success.html',
                params: {
                    'currentAmount': null,
                    'totalAmount': null,
                    'providerFee': null
                },
                controller: 'walletSendSuccessCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.send.success', 'common' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_SEND_SELECT', $q, $translate );
                    }
                }
            })
            .state( 'wallet.suspend', {
                url: '/suspend',
                templateUrl: 'app/wallet.suspend/partials/wallet.suspend.html',
                controller: 'walletSuspendCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.suspend' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_SUSPEND', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.topup', {
                url: '/topup',
                templateUrl: 'app/wallet.topup/partials/wallet.topup.html',
                controller: 'walletTopupCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.topup' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_TOPUP', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.topup.select', {
                url: '/select',
                templateUrl: 'app/wallet.topup.select/partials/wallet.topup.select.html',
                controller: 'walletTopupSelectCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.topup.select' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_TOPUP_SELECT', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.topup.enter', {
                url: '/enter/:name',
                templateUrl: 'app/wallet.topup.enter/partials/wallet.topup.enter.html',
                controller: 'walletTopupEnterCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.topup.enter' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_TOPUP_ENTER', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.topup.success', {
                url: '/success',
                templateUrl: 'app/wallet.topup.success/partials/wallet.topup.success.html',
                controller: 'walletTopupSuccessCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_TOPUP_SUCCESS', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.details', {
                url: '/details',
                abstract: true,
                templateUrl: 'app/wallet.details/partials/wallet.details.html',
                controller: 'walletDetailsCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    userdata: function ( userFactory ) {
                        return userFactory.getUser( true );
                    },
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.details' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_DETAILS', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.details.my', {
                url: '/my',
                templateUrl: 'app/wallet.details.my/partials/wallet.details.my.html',
                controller: 'walletDetailsMyCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    activeTab: function($stateParams){
                        return $stateParams.activeTab;
                    },
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.details', 'wallet.details.complete' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_DETAILS', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.details.my.list', {
                url: '/list/:activeTab',
                templateUrl: 'app/wallet.details.my.list/partials/wallet.details.my.list.html',
                controller: 'walletDetailsMyCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    activeTab: function($stateParams){
                        return $stateParams.activeTab;
                    },
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.password.change' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_DETAILS_LIST', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.details.my.complete', {
                url: '/complete/:activeTab',
                templateUrl: 'app/wallet.details.my.complete/partials/wallet.details.my.complete.html',
                controller: 'walletDetailsMyCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    activeTab: function($stateParams){
                        return $stateParams.activeTab;
                    },
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.details.complete' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_DETAILS_COMPLETE', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.offers', {
                url: '/offers',
                templateUrl: 'app/wallet.offers/partials/wallet.offers.html',
                controller: 'walletOffersCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.offers' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_OFFERS', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.offers.list', {
                url: '/list',
                templateUrl: 'app/wallet.offers.list/partials/wallet.offers.list.html',
                controller: 'walletOffersListCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.offers.list' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_OFFERS_LIST', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.offers.detail', {
                url: '/detail/:id',
                templateUrl: 'app/wallet.offers.detail/partials/wallet.offers.detail.html',
                controller: 'walletOffersDetailCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.offers.detail' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_OFFERS_DETAIL', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.transaction', {
                url: '/transaction',
                templateUrl: 'app/wallet.transaction/partials/wallet.transaction.html',
                controller: 'walletTransactionCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.history' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_TRANSACTION', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.loyalty', {
                url: '/loyalty',
                templateUrl: 'app/wallet.loyalty/partials/wallet.loyalty.html',
                controller: 'walletLoyaltyCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.loyalty' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_LOYALTY', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.loyalty.list', {
                url: '/list',
                templateUrl: 'app/wallet.loyalty.list/partials/wallet.loyalty.list.html',
                controller: 'walletLoyaltyListCtrl',
                params: {
                    active: null
                },
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.loyalty.list' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_LOYALTY_LIST', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.notification', {
                url: '/notification',
                templateUrl: 'app/wallet.notification/partials/wallet.notification.html',
                controller: 'walletNotificationCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.notification' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_NOTIFICATION', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.verification', {
                url: '/verification',
                templateUrl: 'app/wallet.verification/partials/wallet.verification.html',
                controller: 'walletVerificationCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.verification' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_VERIFICATION', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.verification.upload', {
                url: '/upload',
                templateUrl: 'app/wallet.verification.upload/partials/wallet.verification.upload.html',
                controller: 'walletVerificationUploadCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.verification.upload', 'wallet.details.complete' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_VERIFICATION_UPLOAD', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.fund', {
                url: '/fund',
                templateUrl: 'app/wallet.fund/partials/wallet.fund.html',
                controller: 'walletFundCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.fund' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_FUND', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.fund.claim', {
                url: '/claim',
                templateUrl: 'app/wallet.fund.claim/partials/wallet.fund.claim.html',
                controller: 'walletFundClaimCtrl',
                history: {trace: true, button:'back'},
                resolve: {
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.fund.claim', 'wallet.send' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_FUND_CLAIM', $q, $translate );
                    }
                }
            } )
            .state( 'wallet.share', {
                url: '/share',
                templateUrl: 'app/wallet.share/partials/wallet.share.html',
                controller: 'walletShareCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                    walletdata: walletData,
                    translations: function ( requireTranslationsService ) {
                        return requireTranslationsService( 'wallet.share' );
                    },
                    $title: function ( $q, $translate, translations ) {
                        return getTranslateForPageTitle( 'PAGE_TITLE.FOR.WALLET_SHARE', $q, $translate );
                    }
                }
            } )
            .state( 'payment', {
                url: '/payment',
                templateUrl: 'app/payment/partials/payment.html',
                controller: 'paymentCtrl',
                history: {trace: false, button:'menu'},
                resolve: {
                     translations: function ( requireTranslationsService ) {
                         return requireTranslationsService( 'common', 'modal' );
                     },
                     $title: function ( $q, $translate, translations ) {
                         return getTranslateForPageTitle( 'PAGE_TITLE.FOR.PAYMENT_CANCEL', $q, $translate );
                     }
                 }
            } )
            .state( 'payment.cancelled', {
                url: '/cancelled',
                templateUrl: 'app/payment.cancelled/partials/payment.cancelled.html',
                controller: 'paymentCancelledCtrl',
                resolve: {
                     translations: function ( requireTranslationsService ) {
                         return requireTranslationsService( 'payment.cancelled' );
                     },
                     $title: function ( $q, $translate, translations ) {
                         return getTranslateForPageTitle( 'PAGE_TITLE.FOR.PAYMENT_CANCELLED', $q, $translate );
                     }
                 }
            } )
            .state( 'payment.error', {
                url: '/error',
                templateUrl: 'app/payment.error/partials/payment.error.html',
                controller: 'paymentErrorCtrl',
                resolve: {
                     translations: function ( requireTranslationsService ) {
                         return requireTranslationsService( 'payment.error' );
                     },
                     $title: function ( $q, $translate, translations ) {
                         return getTranslateForPageTitle( 'PAGE_TITLE.FOR.PAYMENT_ERROR', $q, $translate );
                     }
                 }
            } )
            .state( 'payment.success', {
                url: '/success',
                templateUrl: 'app/payment.success/partials/payment.success.html',
                controller: 'paymentSuccessCtrl',
                resolve: {
                     translations: function ( requireTranslationsService ) {
                         return requireTranslationsService( 'payment.success' );
                     },
                     $title: function ( $q, $translate, translations ) {
                         return getTranslateForPageTitle( 'PAGE_TITLE.FOR.PAYMENT_SUCCESS', $q, $translate );
                     }
                 }
            } )
            .state( 'payment.cancel', {
                url: '/cancel',
                templateUrl: 'app/payment.cancel/partials/payment.cancel.html',
                controller: 'paymentCancelCtrl',
                resolve: {
                     translations: function ( requireTranslationsService ) {
                         return requireTranslationsService( 'payment.cancel' );
                     },
                     $title: function ( $q, $translate, translations ) {
                         return getTranslateForPageTitle( 'PAGE_TITLE.FOR.PAYMENT_CANCEL', $q, $translate );
                     }
                 }
            } );

        $urlRouterProvider.otherwise( '/auth/login' );
    } )
    .constant('moment', moment)
    .run( function ( $rootScope, $cookieStore, $http, $state, $window, Idle, store, errorHandler, $translate, TRANSLATION_PARAMS, CacheFactory, userAddressFactory, authDocumentFactory, Wallet, userFactory ) {
        //Idle.watch();
        $rootScope.firebaseApp;
        $translate.use( store.get('lang_locale') );
        $rootScope.$state = $state;
        $rootScope.typeOf = function ( value ) {
            return typeof value;
        };
        $rootScope.globals = store.get( 'globals' ) || {};
        if ( $rootScope.globals.currentUser ) {
            $http.defaults.headers.common.Authorization = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        } else {
            delete $http.defaults.headers.common.Authorization;
        }
        $rootScope.$on( '$stateChangeStart', function () {
            if ( $rootScope.sideBarActive === true ) {
                $rootScope.sideBarActive = false;
            }
        } );
        $rootScope.goBack = function () {
            $window.history.back();
        };
        $rootScope.errorHandler = errorHandler;

        // console.log('PROCESS ENV:::: in index.js >>>'+ JSON.stringify(process.env));
        // setup the various caches
        // set up userCache
        if ( !CacheFactory.get( 'userCache' ) ) {
            CacheFactory.createCache( 'userCache', {
                maxAge: 15 * 60 * 1000, // Items added to this cache expire after 15 minutes
                cacheFlushInterval: 60 * 60 * 1000, // This cache will clear itself every hour
                deleteOnExpire: 'aggressive', // Items will be deleted from this cache when they expire
                storageMode: 'localStorage', // This cache will use `localStorage`.
                onExpire: function (key, value) {
                    // console.log('user rebuilt')
                    userFactory.getUser(false);
                  }
            } );
        }
        // setup authDocsCache
        if(! CacheFactory.get( 'authCache' )){
           CacheFactory.createCache( 'authCache', {
                maxAge: 15 * 60 * 1000, // Items added to this cache expire after 15 minutes
                cacheFlushInterval: 60 * 60 * 1000, // This cache will clear itself every hour
                deleteOnExpire: 'aggressive', // Items will be deleted from this cache when they expire
                storageMode: 'localStorage', // This cache will use `localStorage`.
                onExpire: function (key, value) {
                    // console.log('auth rebuilt')
                    authDocumentFactory.getStatus(false);
                  }
            } );
        }
        // set up walletCache
        if(!CacheFactory.get('walletCache')){
          CacheFactory.createCache('walletCache', {
            maxAge: 15 * 60 * 1000, // Items added to this cache expire after 15 minutes
            cacheFlushInterval: 60 * 60 * 1000, // This cache will clear itself every hour
            deleteOnExpire: 'aggressive', // Items will be deleted from this cache when they expire
            storageMode: 'localStorage', // This cache will use `localStorage`.
            onExpire: function (key, value) {
                // console.log('wallet rebuilt...');
                Wallet.getWallet(false);
              }
          });
        }
        // set up addressCache
        if(!CacheFactory.get('addressCache')){
          CacheFactory.createCache('addressCache', {
            maxAge: 15 * 60 * 1000, // Items added to this cache expire after 15 minutes
            cacheFlushInterval: 60 * 60 * 1000, // This cache will clear itself every hour
            deleteOnExpire: 'aggressive', // Items will be deleted from this cache when they expire
            storageMode: 'localStorage', // This cache will use `localStorage`.
            onExpire: function (key, value) {
                // console.log('address rebuilt' + angular.toJson(value))
                var type = key.split('_')[0];
                userAddressFactory.getAddress(type, false);
              }
          });
        }
    } );

function MmPrefixer(initialAttributes, buildSelector) {
  var PREFIXES = ['data', 'x'];

  if (initialAttributes) {
    // The prefixer also accepts attributes as a parameter, and immediately builds a list or selector for
    // the specified attributes.
    return buildSelector ? _buildSelector(initialAttributes) : _buildList(initialAttributes);
  }

  return {
    buildList: _buildList,
    buildSelector: _buildSelector,
    hasAttribute: _hasAttribute
  };

  function _buildList(attributes) {
    attributes = angular.isArray(attributes) ? attributes : [attributes];

    attributes.forEach(function(item) {
      PREFIXES.forEach(function(prefix) {
        attributes.push(prefix + '-' + item);
      });
    });

    return attributes;
  }

  function _buildSelector(attributes) {
    attributes = angular.isArray(attributes) ? attributes : [attributes];

    return _buildList(attributes)
      .map(function (item) {
        return '[' + item + ']'
      })
      .join(',');
  }

  function _hasAttribute(element, attribute) {
    element = element[0] || element;

    var prefixedAttrs = _buildList(attribute);

    for (var i = 0; i < prefixedAttrs.length; i++) {
      if (element.hasAttribute(prefixedAttrs[i])) {
        return true;
      }
    }

    return false;
  }
}
