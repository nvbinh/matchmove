'use strict';

describe('Factory: authDocumentFactory', function() {
  var authDocument,
  	  API_BASE,
	  TP,
  	  httpBackend,
      scope,
      rootScope;
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    // Initialize factory
  beforeEach(inject(function(_authDocumentFactory_, _API_BASE_, _$rootScope_) {
    authDocument = _authDocumentFactory_;
    API_BASE = _API_BASE_;
    rootScope = _$rootScope_;
    rootScope.globals = {};
    rootScope.globals.currentUser = {};
    rootScope.globals.currentUser.authdata = "TnpnelltSXdaRFppT0RobE16UXpOR0prTnpNM1pEQmxNbVkxTRZZw==";
    httpBackend.whenGET(API_BASE + 'users/authentications/documents').respond(200, {
          "count": "n/a",
          "status": "not_submitted"
        });
    httpBackend.flush();
  }));
  afterEach(function() {
    httpBackend.verifyNoOutstandingExpectation();
    httpBackend.verifyNoOutstandingRequest();
  });
  it('should have authDocument be defined', function () {
    expect(authDocument).toBeDefined();
  });

  describe('get status', function() {
    it('http call should retrieve document status', function(){
        authDocument.getStatus(false).then(function(response){
            expect(response.data).toBeDefined();
            expect(response.data.status).toBe('not_submitted');
        });
       httpBackend.flush();
    });
    it('Cache should retrieve document status', function(){
        authDocument.getStatus(true).then(function(response){
            expect(response).toBe('not_submitted');
        });
    });
  });

  describe('upload image', function() {
    beforeEach(inject(function($rootScope) {
      httpBackend.when('POST', API_BASE + 'users/authentications/documents').respond(200, {
          "count": 1,
          "status": "pending"
        });

    }));

    it('should have a response status after upload image', function () {
      var fileData = {data:'iVBORw0KGgoAASUVORK5CYII='};
      authDocument.uploadImage(fileData).then(function(response){
          expect(response.data).toBeDefined();
          expect(response.data.count).toBe(1);
      });
      httpBackend.flush();
    });
  });

  describe('submit Kyc', function() {
    beforeEach(inject(function($rootScope) {
      httpBackend.when('PUT', API_BASE + 'users/authentications/documents').respond(200, {
          "count": 2,
          "status": "submitted"
        });

    }));

    it('should have a response status after  submit Kyc', function () {
      authDocument.submitKyc({submit: 'yesno'}).then(function(response){
          expect(response.data).toBeDefined();
          expect(response.data.status).toBe('submitted');
      });
      httpBackend.flush();
    });
  });
});
