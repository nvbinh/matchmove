'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.authDocument
 * @description
 * # authDocument
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .service('authDocumentFactory', function ($http, API_BASE, $rootScope, $q, CacheFactory) {

  // Service logic
  // function getStatus() {
  //     return $http.get(API_BASE + 'users/authentications/documents', {cache:false});
  // };

    // Implement caching for document calls
    function getStatus(cache) {
        var authCache = CacheFactory.get('authCache');
        var deferred = $q.defer();
        var cacheFlag;
        if (cache === true) {
            cacheFlag = authCache;
            var kycStatus;
            if (authCache && authCache.get('kycStatus')) {
                kycStatus = authCache.get('kycStatus');
                deferred.resolve(kycStatus);
                return deferred.promise;
            } else {
                cacheFlag = false;
            }
        } else {
            cacheFlag = false;
        }
        $http({
            method: 'GET',
            url: API_BASE + 'users/authentications/documents',
            cache: cacheFlag,
            timeout: 18000
        }).then(function(data, status, headers, config) {
            var kycStatus = data;
            authCache.put('kycStatus', kycStatus.data.status);
            deferred.resolve(kycStatus);
        }, function(errorResponse) {
            deferred.reject(errorResponse);
        })
        return deferred.promise;
    };

  function uploadImage(document) {
    var url,
    authen,
    url = API_BASE + 'users/authentications/documents';
    authen = 'Basic ' + $rootScope.globals.currentUser.authdata;
    return $http({
      method: 'POST',
      url: url,
      headers: {
        'Authorization': authen,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      transformRequest: function(obj) {
          var str = [];
          for(var p in obj) {
              str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
          }
          return str.join('&');
      },
      data: document
    });
  };

  function submitKyc(){
      var url, authen;
      url = API_BASE + 'users/authentications/documents';
      authen = 'Basic ' + $rootScope.globals.currentUser.authdata;
      return $http({
        method: 'PUT',
        url: url,
        headers: {
          'Authorization': authen,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        transformRequest: function(obj) {
            var str = [];
            for(var p in obj) {
                str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
            }
            return str.join('&');
        },
        data: {}
      });
  };

  // Add description
   getStatus.description = 'authDocumentFactory:getStatus';
   uploadImage.description = 'authDocumentFactory:uploadImage';
   submitKyc.description = 'authDocumentFactory:submitKyc';

   // Public API here
  return {
     getStatus: getStatus,
     uploadImage: uploadImage,
     submitKyc: submitKyc
  };
});
