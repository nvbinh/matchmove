'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.userProvider
 * @description
 * # userProvider
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
    .service('userProviderFactory', function ($http, CacheFactory, API_BASE) {
// Service logic
// ...


      this.putDetails = function(data) {
          return $http({
            method: 'POST',
            url: API_BASE + 'users/wallets/funds/providers/' + data,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            transformRequest: function(obj) {
                var str = [];
                for(var p in obj) {
                  str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                  return str.join('&');
                }
            }
          });
      };
      this.getTransactionData = function(id) {
        var httpCache = CacheFactory.get('walletCache');
        httpCache.remove(API_BASE + 'users/wallets/funds/' + id);
        return $http.get(API_BASE + 'users/wallets/funds/' + id, {cache:false});
      };
  });
