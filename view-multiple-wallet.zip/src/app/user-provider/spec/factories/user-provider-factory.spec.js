'use strict';

describe('Factory: userProviderFactory', function() {
  var userProvider;
  beforeEach(module('viewMultipleWallet'));
  beforeEach(inject(function(_userProviderFactory_) {
    userProvider = _userProviderFactory_;
  }));

  it('should get transaction data', function(){
      var transaction = userProvider.getTransactionData();
      expect(transaction).toBeDefined();
  });
  it('should put details', function(){
      var details = userProvider.putDetails({});
      expect(details).toBeDefined();
  });
});
