'use strict';

describe('Factory: userNotificationsFactory', function() {
  var userNotifications,
      notifUpdateResponse,
      notifList,
      API_BASE,
      httpBackend,
      paramData,
      updateParams;
  beforeEach(module('viewMultipleWallet'));
  // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
  // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
  beforeEach(inject(function( _userNotificationsFactory_, _API_BASE_ ) {
      API_BASE = _API_BASE_;
    userNotifications = _userNotificationsFactory_;
    
    notifUpdateResponse = {
          "notification_id": "22843",
          "update": "success"
        };
        
    //paramData = 'filter_condition=%3D&filter_field=is_read&filter_value=0&limit=2&sort_direction=DESC&sort_field=date_added';
    notifList = {
          "notifications": {
            "0": {
              "id": "22844",
              "type": "_ACT_LOGGED_IN",
              "data": {
                "message": {
                  "class": "Auth",
                  "ip": "58.68.23.246",
                  "device": "Desktop",
                  "browser": "Google Chrome",
                  "version": "48.0.2564.103",
                  "platform": "Windows 7",
                  "mobile": false
                }
              },
              "is_read": "0",
              "date_added": "2016-02-08 16:16:33"
            },
            "1": {
              "id": "22826",
              "type": "_ACT_LOGGED_IN",
              "data": {
                "message": {
                  "class": "Auth",
                  "ip": "58.68.23.246",
                  "device": "Desktop",
                  "browser": "Google Chrome",
                  "version": "48.0.2564.103",
                  "platform": "Windows 7",
                  "mobile": false
                }
              },
              "is_read": "0",
              "date_added": "2016-02-08 14:18:19"
            }
          },
          "pagination": {
            "first": 1,
            "before": 1,
            "current": 1,
            "last": 32,
            "next": 2,
            "total_pages": 32,
            "total_items": 64,
            "total_unread": 64,
            "limit": 2
          }
        };
    updateParams = {
        is_read: 1,
        id: 22826
    };
    httpBackend.whenGET(API_BASE + 'users/notifications').respond(200, notifList);
    httpBackend.whenPUT(API_BASE + 'users/notifications').respond(200, notifUpdateResponse);
    httpBackend.flush();
  }));
   afterEach(function() {
     httpBackend.verifyNoOutstandingExpectation();
     httpBackend.verifyNoOutstandingRequest();
   });
  describe('Notification Listing and Update operations', function(){
      it('should return notification list per filter conditions', function(){
          userNotifications.getList().then(
              function(response){
                  expect(response.status).toBe(200);
                  expect(response.data.notifications[0].id).toBe('22844');
                  expect(response.data.notifications[0].type).toBe('_ACT_LOGGED_IN');
              });
         httpBackend.flush();
      });
      it('should update the is_read state of a  given Notification', function(){
          userNotifications.setRead(updateParams).then(
          function(response){
              expect(response.status).toBe(200);
              expect(response.data.update).toBe('success');
          });
          httpBackend.flush();
      });
  });
});
