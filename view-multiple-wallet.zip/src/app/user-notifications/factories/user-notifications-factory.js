'use strict';
/**
 * @ngdoc service
 * @name viewMultipleWallet.userNotifications
 * @description
 * # userNotifications
 * Factory in the viewMultipleWallet.
 */
angular.module('viewMultipleWallet')
  .service('userNotificationsFactory', function ($http, API_BASE) {
// Service logic
// ...
      function getList(data) {
          return $http({
              method: 'GET',
              url: API_BASE + 'users/notifications',
              params:data
          });
      };// Public API here

      /* The sample data
      endpointdata = {};
      endpointdata.id = 5003;
      endpointdata.is_read = 1;
      */
      function setRead(endpointdata) {
            return $http({
               method: 'PUT',
               url : API_BASE + 'users/notifications',
              headers: {'Content-Type': 'application/x-www-form-urlencoded'},
              transformRequest: function(obj) {
                  var str = [];
                  for(var p in obj) {
                      str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                  }
                  return str.join('&');
              },
              data : endpointdata
            });
        };

       // Add descriptions
        getList.description = 'userNotificationsFactory:getList';
        setRead.description = 'userNotificationsFactory:setRead';

        // Public Facing API
        return {
            getList: getList,
            setRead: setRead
        };
  });
