'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authPasswordChangeCtrl
 * @description
 * # authPasswordChangeCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authPasswordChangeCtrl', function ( $scope, $stateParams, rc4Factory, authPasswordFactory, store, $log, $translate ) {
        $scope.token = $stateParams.token;
        $scope.validationError = '';

        $scope.verifyingToken = true;

        $scope.success = false;
        $scope.changePassword = function () {
            if ( $scope.password === $scope.rePassword ) {
                authPasswordFactory.verifyToken( $scope.token, $scope.password )
                    .then( function ( response ) {
                        switch ( response.status ) {
                        case 200:
                            $scope.success = true;
                            break;
                        }
                    }, function ( errResponse ) {
                        switch ( errResponse.status ) {
                        case 400:
                            $scope.errorGeneric = true;
                            $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR400' );
                            break;
                        case 401:
                            $scope.errorGeneric = true;
                            $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR401' );
                            break;
                        default:
                            $scope.errorGeneric = true;
                            $scope.validationError = $translate.instant( 'PAGES.WALLET_PASSWORD_CHANGE.ERROR500' );
                        }
                    } );
            }
        };
    } );
