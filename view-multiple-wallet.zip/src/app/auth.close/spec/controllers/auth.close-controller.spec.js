'use strict';
describe( 'Controller: authCloseCtrl', function () {
    // load the controller's module
    beforeEach( module( 'viewMultipleWallet' ) );
    // mock constants
    beforeEach( module( 'viewMultipleWallet', function ( $provide ) {
        $provide.constant( "TRANSLATION_PARAMS", {
            "partFilesPath": "../assets/locales/",
            "preferredLanguage": "vi_vn",
            "client": "hdb",
            "source": "http://localhost:3000/assets/hdb/locales\/",
            "supportedLanguages": [ {
                "i18n": "en_us",
                "name": "English"
            }, {
                "i18n": "vi_vn",
                "name": "Vietnamese"
            } ]
        } );
    } ) );
    // langugage based mock calls
    beforeEach( inject( function( $httpBackend, TRANSLATION_PARAMS ) {
        httpBackend = $httpBackend;
        var lngth = angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages.length;
        for ( var i = 0; i < lngth; i++ ) {
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'common/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'login/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
            httpBackend.whenGET( angular.fromJson( TRANSLATION_PARAMS ).partFilesPath + 'modal/' + angular.fromJson( TRANSLATION_PARAMS ).supportedLanguages[ i ].i18n + '.json' ).respond( 200, '' );
        }
    } ) );
    var authCloseCtrl,
        scope,
        httpBackend,
        authFactory,
        userFactory,
        $timeout,
        q,
        deferred,
        state,
        spyAuthCred;
    // Initialize the controller and a mock scope
    beforeEach( inject( function ( $controller, $rootScope, _authenticationFactory_, _userFactory_, _$timeout_, _$q_, _$state_ ) {
        scope = $rootScope.$new();
        authFactory = _authenticationFactory_;
        userFactory = _userFactory_;
        $timeout = _$timeout_;
        q = _$q_;
        state = _$state_;
        authCloseCtrl = $controller('authCloseCtrl', {
          $scope: scope
        });
        spyOn($timeout, 'flush').and.callThrough();
        spyOn(state, 'transitionTo').and.callThrough();
        spyAuthCred = spyOn(authFactory, 'SetCredentials').and.callThrough();
    } ) );
    afterEach(function() {
        httpBackend.flush();
        httpBackend.verifyNoOutstandingExpectation();
        httpBackend.verifyNoOutstandingRequest();
    });
    it('scope vars to be defined', function(){
        expect(scope.successClosure).toBeFalsy();
    })
    // Fix this later
    // it('Fn doLogin - login success, close user success', function(){
    //     var inputdata = {
    //         "email": "balajihdb04@chimeratechnologies.com",
    //         "password":"Chimera1@"
    //     }
    //     spyOn(authFactory, 'Login').and.callFake(function (){
    //         deferred = q.defer();
    //         deferred.resolve({"data": {"key": "sbfsfgskgfka", "secret": "sfsahfkh7"}});
    //         return deferred.promise;
    //     });
    //     spyOn(userFactory, 'closeUser').and.callFake(function(){
    //         deferred = q.defer();
    //         deferred.resolve(true);
    //         return deferred.promise;
    //     });
    //     scope.doLogin(inputdata);
    //     $timeout.flush();
    //     // expect(spyAuthCred).toHaveBeenCalled();
    //     expect(scope.successClosure).toBeTruthy();
    // })
    it('Fn doLogin - login success, close user error', function(){
        var inputdata = {
            "email": "balajihdb04@chimeratechnologies.com",
            "password":"Chimera1@"
        }
        spyOn(authFactory, 'Login').and.callFake(function (){
            deferred = q.defer();
            deferred.resolve({"data": {"key": "sbfsfgskgfka", "secret": "sfsahfkh7"}});
            return deferred.promise;
        });
        spyOn(userFactory, 'closeUser').and.callFake(function(){
            deferred = q.defer();
            deferred.reject({"statusCode":400, "statusText":'HTTP/1.1 400 close reject error here'});
            return deferred.promise;
        });
        scope.doLogin(inputdata);
        // expect(spyAuthCred).toHaveBeenCalled();
        expect(scope.successClosure).toBeFalsy();
    })
    it('Fn doLogin - login error', function(){
        var inputdata = {
            "email": "balajihdb04@chimeratechnologies.com",
            "password":"Chimera1@"
        }
        spyOn(authFactory, 'Login').and.callFake(function (){
            deferred = q.defer();
            deferred.reject({"statusCode":400, "statusText":'HTTP/1.1 400 Login reject here'});
            return deferred.promise;
        });
        scope.doLogin(inputdata);
        scope.$digest();
        expect(spyAuthCred).not.toHaveBeenCalled();
        expect(scope.errorLoginGenric).toBeTruthy();
    })
} );
