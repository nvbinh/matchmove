'use strict';
/**
 * @ngdoc function
 * @name viewMultipleWallet.controller:authEmailCtrl
 * @description
 * # authEmailCtrl
 * Controller of the viewMultipleWallet
 */
angular.module( 'viewMultipleWallet' )
    .controller( 'authCloseCtrl', function ($scope,authenticationFactory,userFactory,$stateParams,$timeout,$rootScope, $state) {
      $scope.successClosure = false;
      $scope.errorLoginGenric = false;
      $scope.errorClosure = false;
      $scope.credentials = {};
      $scope.isLoading = false;
      $scope.payload = {};
      $scope.payload.token = $stateParams.token;
      function postSuccessRedirection() {
          $state.transitionTo( 'auth.login', null, {
              'reload': true
          } );
      }
      function handleClosureVerification() {
        userFactory.closeUser($scope.payload)
          .then(function(response){
            $scope.successClosure = true;
            $scope.isLoading = false;
            $timeout( function(){
                postSuccessRedirection();
            }, 10000 );
          }, function(error){
            $scope.errorClosure = true;
            $scope.isLoading = false;
          });
      }
      $scope.doLogin = function (data) {
        $scope.isLoading = true;
        authenticationFactory.Login( data.email , data.password ).then( function ( response ) {
            authenticationFactory.SetCredentials( response.data.key, response.data.secret );
            $timeout( function(){
                handleClosureVerification();
            }, 5000 );
          }, function ( error ) {
              $scope.errorLoginGenric = true;
              $scope.isLoading = false;
              $scope.errorMessagetext = $rootScope.errorHandler.errors[ 0 ];
          } );
      }
    } );
