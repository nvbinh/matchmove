'use strict';

module.exports = function ( config ) {

    var configuration = {
        autoWatch: false,

        frameworks: [ 'jasmine' ],

        ngHtml2JsPreprocessor: {
            stripPrefix: 'src/',
            moduleName: 'viewMultipleWallet'
        },

        browsers: [ 'PhantomJS' ],

        plugins: [
            'karma-phantomjs-launcher',
            'karma-jasmine',
            'karma-ng-html2js-preprocessor',
            'karma-coverage',
            'karma-bamboo-reporter'
        ],
        bambooReporter: {
            filename: 'util.mocha.json' //optional, defaults to "mocha.json"
        },
        reporters: [ 'progress', 'coverage', 'bamboo' ],
        preprocessors: {
            'src/**/*.html': [ 'ng-html2js' ],
            'src/app/**/**/services/*-service.js': [ 'coverage', 'bamboo' ],
            'src/app/**/**/factories/*-factory.js': [ 'coverage', 'bamboo' ],
            'src/app/**/**/filters/*-filter.js': [ 'coverage', 'bamboo' ],
            'src/app/**/**/directives/*-directive.js': [ 'coverage', 'bamboo' ],
            'src/app/**/**/controllers/*-controller.js': [ 'coverage', 'bamboo' ]
        }
    };
    config.set( configuration );
};
