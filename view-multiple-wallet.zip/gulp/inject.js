'use strict';

var gulp = require('gulp');
var touppercase = require("upper-case");

var $ = require('gulp-load-plugins')();
var appConfig = require('../config.json');

var supLangs = JSON.parse(appConfig.TRANSLATION_PARAMS).supportedLanguages;

var wiredep = require('wiredep')
    .stream;
var path = require('path');

module.exports = function (options) {
    gulp.task('inject', ['scripts', 'styles'], function () {
        var injectStyles = gulp.src([
            options.tmp + '/serve/app/**/*.css',
            '!' + options.tmp + '/serve/app/vendor.css'
        ], {
            read: false
        });

        var injectScripts = gulp.src([
                options.src + '/app/**/*.js',
                '!' + options.src + '/app/**/*.spec.js',
                '!' + options.src + '/app/**/*.mock.js',
                '!' + options.src + '/app/mockFirebase/**/*.*'
            ])
            .pipe($.angularFilesort())
            .on('error', options.errorHandler('AngularFilesort'));

        function fileContents(filePath, file) {
            return file.contents.toString();
        }

        var svginject = gulp.src(options.src + '/assets/icons/*.svg')
            .pipe($.svgmin(function (file) {
                var prefix = path.basename(file.relative, path.extname(file.relative));
                return {
                    plugins: [{
                        cleanupIDs: {
                            prefix: prefix + '-',
                            minify: true
                        }
                    }]
                };
            }))
            .pipe($.rename({
                prefix: 'mcw-'
            }))
            .pipe($.svgstore({
                inlineSvg: true
            }));


        var injectOptions = {
            ignorePath: [options.src, options.tmp + '/serve'],
            addRootSlash: true
        };

        return gulp.src(options.src + '/*.html')
            .pipe($.inject(gulp.src(['./meta.html']), {
              starttag: '<!-- inject:head:{{ext}} -->',
              transform: function (filePath, file) {
                // return file contents as string
                return file.contents.toString('utf8')
              }
            }))
            .pipe($.inject(gulp.src(['./analytics.html']), {
              starttag: '<!-- inject:{{ext}} -->',
              transform: function (filePath, file) {
                // return file contents as string
                return file.contents.toString('utf8')
              }
            }))
            .pipe($.inject(gulp.src(['./momentLocales.html']), {
                starttag: '<!-- inject:momentLocales -->',
                transform: function (filePath, file) {
                    var returnStr = '';
                    for (var i=0; i < supLangs.length; i++){
                        if(supLangs[i].momentLang){
                            if(touppercase(appConfig.DEPLOY_ENV) != 'DEV'){
                                returnStr += '<script src="/scripts/moment/locale/' + supLangs[i].momentLang + '.js"></script>\n';
                            }else{
                                returnStr += '<script src="../bower_components/moment/locale/' + supLangs[i].momentLang + '.js"></script>\n';
                            }

                        }
                    }
                    return returnStr;
                }
            }))
            .pipe($.inject(injectStyles, injectOptions))
            .pipe($.inject(injectScripts, injectOptions))
            .pipe($.inject(svginject, {
                transform: fileContents
            }))
            .pipe(wiredep(options.wiredep))
            .pipe(gulp.dest(options.tmp + '/serve'));

    });
};
