'use strict';

var gulp = require('gulp');
var browserSync = require('browser-sync');

var $ = require('gulp-load-plugins')();

var wiredep = require('wiredep').stream;

module.exports = function(options) {
  gulp.task('css', function () {
    var sassOptions = {
      style: 'expanded'
    };

    return gulp.src([
      options.src + '/app/styles/styleguide/styleguide.scss'
    ])
    .pipe($.sass(sassOptions)).on('error', options.errorHandler('Sass'))
    .pipe($.autoprefixer()).on('error', options.errorHandler('Autoprefixer'))
    .pipe($.rename('./index.css'))
    .pipe(gulp.dest('./'));
  });
};

gulp.task('styleguide', ['css'], function() {
  gulp.src('./index.css')
  .pipe($.styleguidejs())
  .pipe(gulp.dest('./docs'));
});
