'use strict';

var gulp = require('gulp');
var touppercase = require("upper-case");
var appConfig = require('../config.json');

var supLangs = JSON.parse(appConfig.TRANSLATION_PARAMS).supportedLanguages;

var $ = require('gulp-load-plugins')({
    pattern: ['gulp-*', 'main-bower-files', 'uglify-save-license', 'del']
});

var buildEnv = process.env.NODE_ENV === "production";
module.exports = function (options) {
    gulp.task('partials', function () {
        return gulp.src([
                options.src + '/app/**/*.html',
                options.tmp + '/serve/app/**/*.html'
            ])
            .pipe($.debug({title: 'MINIFYING:'}))
            .pipe($.htmlmin({
                empty: true,
                spare: true,
                quotes: true
            }))
            .pipe($.angularTemplatecache('templateCacheHtml.js', {
                module: 'viewMultipleWallet',
                root: 'app'
            }))
            .pipe(gulp.dest(options.tmp + '/partials/'));
    });

    gulp.task('html', ['inject', 'partials'], function () {
        var partialsInjectFile = gulp.src(options.tmp + '/partials/templateCacheHtml.js', {
            read: false
        });
        var partialsInjectOptions = {
            starttag: '<!-- inject:partials -->',
            ignorePath: options.tmp + '/partials',
            addRootSlash: true
        };

        var htmlFilter = $.filter('*.html');
        var jsFilter = $.filter('**/*.js');
        var cssFilter = $.filter('**/*.css');
        var assets = $.useref.assets({ searchPath: './src/assets' });

        return gulp.src(options.tmp + '/serve/*.html')
            .pipe($.inject(partialsInjectFile, partialsInjectOptions))
            .pipe(assets)
            .pipe($.rev())
            .pipe(jsFilter)
            .pipe($.ngAnnotate())
            .pipe($.uglify())
            .on('error', options.errorHandler('Uglify'))
            .pipe(jsFilter.restore())
            .pipe(cssFilter)
            .pipe($.autoprefixer({
                browsers: ['last 2 versions'],
                cascade: false
            }))
            .pipe($.cssmin())
            .pipe(cssFilter.restore())
            .pipe(assets.restore())
            .pipe($.useref())
            .pipe($.revReplace())
            .pipe(htmlFilter)
            .pipe($.htmlmin({
                spare: true,
                conditionals: true
            }))
            .pipe(htmlFilter.restore())
            .pipe(gulp.dest(options.dist + '/'))
            .pipe($.size({
                title: options.dist + '/',
                showFiles: true
            }));
    });

    // Only applies for fonts from bower dependencies
    // Custom fonts are handled by the "other" task
    gulp.task('fonts', function () {
        return gulp.src($.mainBowerFiles())
            .pipe($.filter('**/*.{eot,svg,ttf,woff,woff2}'))
            .pipe($.flatten())
            .pipe(gulp.dest(options.dist + '/fonts/'));
    });

    gulp.task('gzip', function () {
        var gzipOptions = {
            threshold: '1kb',
            append: false,
            gzipOptions: {
                level: 9
            }
        };
        return gulp.src([options.dist + '/**/*.js', options.dist + '/**/*.css'])
            .pipe($.gzip(gzipOptions))
            .pipe(gulp.dest(options.dist + '/'));
    });

    gulp.task('fonts', function () {
        return;
    });

    gulp.task('momentLocale', function(){
        $.del([options.dist + '/scripts/moment/']);
        if(touppercase(appConfig.DEPLOY_ENV) != 'DEV'){
            //  if env is other than dev , write the moment/locale/<>.js file into scripts folder
            //  if env is DEV , the same is picked from bower_components folder. Hence do not write anything to scripts folder
            var fileArray = [];
            for (var i=0; i < supLangs.length; i++){
                if(supLangs[i].momentLang){
                    fileArray.push(options.wiredep.directory + '/moment/locale/' + supLangs[i].momentLang + '.js');
                }
            }
            return gulp.src(fileArray)
                .pipe(gulp.dest(options.dist + '/scripts/moment/locale/'));
        }
    })

    gulp.task('other', function () {
        return gulp.src([
                options.src + '/**/*',
                '!' + options.src + '/**/*.{html,css,js,scss}'
            ])
            .pipe(gulp.dest(options.dist + '/'));
    });

    gulp.task('clean', function (done) {
        $.del([options.dist + '/', options.tmp + '/'], done);
    });

    gulp.task('build', [ 'html', 'fonts', 'other', 'configuration', 'momentLocale']);

    gulp.task('build:prod', [ 'html', 'fonts', 'other', 'configuration', 'momentLocale']);
};
