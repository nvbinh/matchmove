'use strict';

var gulp = require('gulp'),
    gulpNgConfig = require('gulp-ng-config');

var $ = require('gulp-load-plugins')();

var wiredep = require('wiredep');
var karma = require('karma');
var concat = require('concat-stream');
var _ = require('lodash');
var gulpJsonValidator = require('gulp-json-validator');

module.exports = function(options) {
  function listFiles(callback) {
    var wiredepOptions = _.extend({}, options.wiredep, {
      dependencies: true,
      devDependencies: true
    });
    var bowerDeps = wiredep(wiredepOptions);

    var specFiles = [
      options.src + '/**/*.spec.js',
      options.src + '/**/*.mock.js'
    ];

    var htmlFiles = [
      options.src + '/**/*.html'
    ];

    var srcFiles = [
      options.src + '/app/**/*.js'
    ].concat(specFiles.map(function(file) {
      return '!' + file;
    }));


    gulp.src(srcFiles)
      .pipe(concat(function(files) {
        callback(bowerDeps.js
          .concat(_.map(files, 'path'))
          .concat(htmlFiles)
          .concat(specFiles));
      }));
  }

  gulp.task('configuration', function () {
    gulp.src('./config.json')
        .pipe(gulpJsonValidator({ allowDuplicatedKeys: false }))
        .pipe(gulpNgConfig('viewMultipleWallet', {createModule: false}))
        .pipe(gulp.dest('src/app/config/'));
  });

  function runTests (singleRun, done) {
    listFiles(function(files) {
      karma.server.start({
        configFile: __dirname + '/../karma.conf.js',
        files: files,
        singleRun: singleRun,
        autoWatch: !singleRun
      }, function(exitCode) {
          console.log('Karma has exited with ' + exitCode)
          process.exit(exitCode)
        });
    });
  }

  gulp.task('test', ['scripts', 'configuration'], function(done) {
      runTests(true, done);
  });
  gulp.task('test:auto', ['watch'], function(done) {
    runTests(false, done);
  });

};
