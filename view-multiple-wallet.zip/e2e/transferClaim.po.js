'use strict';

var TransferClaimPage = function() {

	this.sendAmount = element(by.model('transfer.transferAmount'));
	this.mobileMode = element(by.css('label[for="mobile"]'));
	this.mobileTransferInput = element(by.model('transfer.mobile'));
	this.invalidFormatMessage = element(by.cssContainingText('p[ng-message="phoneNumber"]', 'invalid format'));
	this.mobileRequiredMessage = element(by.cssContainingText('p[ng-message="required"]', 'is required'));
	this.sameMobileMessage = element(by.cssContainingText('div[ng-if="checkSamePhoneNumber"] p.help-block', 'not be same'));
	this.transferBtn = element(by.css('button.button-primary--medium'));
	this.amountTransfer = element(by.model('transfer.transferAmount'));
	this.amountRequiredMessage = element(by.cssContainingText('p[ng-message="required"]', 'Transfer amount is required.'));
	this.minAmountMessage = element(by.cssContainingText('p[ng-message="min"]', 'Minimum transfer amount'));
	this.maxAmountMessage = element(by.cssContainingText('p[ng-message="max"]', 'should be less than'));
	this.messageInput = element(by.model('transfer.message'));
	this.maxMessageLength = element(by.cssContainingText('p[ng-message="maxlength"]', 'Message should be max'));
	this.printReceiptLink = element(by.css('div.section-action a.link'));
	this.emailMode = element(by.css('label[for="email"]'));
	this.inputTransferEmail = element(by.model('transfer.email'));
	this.emailRequiredMessage = element(by.cssContainingText('p[ng-message="required"]', 'Email address is required.'));
	this.emailInvalidMessage = element(by.cssContainingText('p[ng-message="pattern,email"]', 'Email address entered is invalid'));
	this.sameEmailMessage = element(by.cssContainingText('div[ng-if="checkSameEmail"] p', 'should not be same as your email address'));
	this.claimBtn = element.all(by.css('button.button-primary--medium')).first();
	this.claimSuccessMessage = element(by.cssContainingText('p', 'successfully managed to claim'));
	this.historyTab = element(by.cssContainingText('mm-tab-item span', 'History'));
	this.statusFilter = element(by.model('activeFilter'));
	this.activeStatus = element(by.css('option[value="active"]'));
	this.cancelTransferBtn = element.all(by.css('button.button-warning--medium ')).first();
	this.noTransactionMessage = element(by.cssContainingText('div.content-message--notransaction h4.ng-binding', 'No Transactions!'));
	this.cancelSuccessMessage = element(by.cssContainingText('p.ng-binding', 'successfully managed to cancel'));
	this.claimedStatus = element(by.css('option[value="claimed"]'));
	this.claimedTransaction = element.all(by.css('li.history--claimed')).first();
	this.failedStatus = element(by.css('option[value="failed"]'));
	this.failedTransaction = element.all(by.css('li.history--failed')).first();
	this.expiredStatus = element(by.css('option[value="expired"]'));
	this.expiredTransaction = element.all(by.css('li.history--expired')).first();
	this.cancelledStatus = element(by.css('option[value="cancelled"]'));
	this.cancelledTransaction = element.all(by.css('li.history--cancelled')).first();
	this.claimBtnLast = element.all(by.css('button.button-primary--medium')).last();
	this.reachLimitMessage = element(by.css('div.msg-block__content p'));

};

module.exports = new TransferClaimPage();