/*
*** Please set timeout = 360000
*/

'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var TransferClaimPage = require('./transferClaim.po.js');


describe('Transfer - Claim - History', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber1 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var mobileNumber2 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);


	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;

	var receiverBalanceBefore = 0;
	var receiverBalanceAfter = 0;
	var claimAmount = 0;

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Sign up first account successfully', function() {

		browser.get(configFile.HTTP_HOST);
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber1);

		console.log(mobileNumber1);

		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var accountMenu = element(by.linkText('Account'));
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);

		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Sign up second account successfully', function() {

		browser.sleep(1000);
		DashboardPage.logoutLink.click();

		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);

		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber2);

		console.log(mobileNumber2);

		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var accountMenu = element(by.linkText('Account'));
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);

		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});


	it ('Access Send page, user is required to do topup', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);

		var topupNowBtn = element.all(by.css('button.button-primary--medium')).first();
		var topupNowBtnIsClickable = EC.elementToBeClickable(topupNowBtn);
		browser.wait(sendMenuIsClickable).then(function() {
			DashboardPage.sendMenu.click();
			browser.wait(topupNowBtnIsClickable).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});
		});
	});

	it ('Topup successfully', function() {

		var topupNowBtn = element(by.css('button.button-primary--medium'));
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);

		browser.sleep(2000);
		topupNowBtn.click();
		browser.wait(providerEasypayImageIsVisibility).then(function() {
			TopupPage.walletBalance.getInnerHtml().then(function(balance) {
				var balanceText = balance.replace(",", "");
					balanceBefore = parseFloat(balanceText);
			});
			TopupPage.providerEasypay.click();
			browser.wait(topupBtnIsClickable).then(function() {
				TopupPage.amountCustom.click();
				customAmount = 100;
				TopupPage.amountCustomText.sendKeys(customAmount);
				TopupPage.topupBtn.click();
			});
			browser.wait(windowCount(2), 60000);
			browser.getAllWindowHandles().then(function(handles) {
				var newWindowHandle = handles[1];
				browser.switchTo().window(newWindowHandle).then(function() {
					browser.wait(cancelBtnIsClickable).then(function() {
						EasyGateway.visaChannel.click();
						browser.sleep(2000);
						EasyGateway.creditCardNum.sendKeys('4111111111111111');
						EasyGateway.expMonth.click();
						EasyGateway.expYear.click();
						EasyGateway.creditCardCvv2.sendKeys('989');
						EasyGateway.creditCardName.sendKeys('auto tester');
						EasyGateway.submitBtn.click();
					});
				});
			});

			var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
			browser.wait(transactionSuccessfulIsVisibility).then(function() {
				browser.getAllWindowHandles().then(function(handles) {
					browser.driver.close().then(function () {
						browser.switchTo().window(handles[0]).then(function() {
							browser.sleep(90000); //waiting 90 seconds for balance to be updated
							browser.refresh();
    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
							browser.wait(walletBalanceIsPresence).then(function() {
								TopupPage.walletBalance.getInnerHtml().then(function(balance) {
									balanceAfter = balance;
									var amountIncrese = balanceAfter - balanceBefore;
									expect(amountIncrese).toEqual(customAmount);
								});
							});
						});
					});
				});
			});
		});

	});


	it ('Access Send page again, transfer is allowed', function() {


		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);

		browser.wait(sendMenuIsClickable).then(function() {
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});
		});
	});

	it ('Default amount is 1', function() {

		var defaultAmount = element.all(by.css('div.detail-section p.value span.value-amount')).first();
		var transferAmount = 0;
		defaultAmount.getInnerHtml().then(function(amount) {
			transferAmount = parseFloat(amount);
			console.log(transferAmount);
			expect(transferAmount).toEqual(1);
		});
	});

	it ('Select mobile mode and enter an invalid mobile number', function() {

		var invalidFormatMessageIsVisibility = EC.visibilityOf(TransferClaimPage.invalidFormatMessage);
		TransferClaimPage.mobileMode.click();
		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.sendKeys(12234567);
		browser.wait(invalidFormatMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Leave mobile number of receiver blank', function() {

		var mobileRequiredMessageIsVisibility = EC.visibilityOf(TransferClaimPage.mobileRequiredMessage);

		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.clear();
		browser.wait(mobileRequiredMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Enter special characters and alphabet at amount field', function() {

		var invalidFormatMessageIsVisibility = EC.visibilityOf(TransferClaimPage.invalidFormatMessage);

		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.sendKeys('@#@$%^');
		browser.wait(invalidFormatMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Enter user"s registered mobile number', function() {

		var sameMobileMessageMessageIsVisibility = EC.visibilityOf(TransferClaimPage.sameMobileMessage);

		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.clear();
		TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber2);
		browser.wait(sameMobileMessageMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Enter less than 8 numbers at mobile number field', function() {

		var invalidFormatMessageIsVisibility = EC.visibilityOf(TransferClaimPage.invalidFormatMessage);

		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.clear();
		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.sendKeys(123456);
		browser.wait(invalidFormatMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Enter valid mobile number of receiver, tranfser button is enabled', function() {

		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.clear();
		browser.sleep(1000);
		TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);
		browser.sleep(1000);
		expect(TransferClaimPage.transferBtn.isEnabled()).toBe(true);

	});

	it ('Delete the amount, leave the field blank', function() {

		var amountRequiredMessageIsVisibility = EC.visibilityOf(TransferClaimPage.amountRequiredMessage);

		browser.sleep(1000);
		TransferClaimPage.amountTransfer.clear();
		browser.wait(amountRequiredMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Enter the amount less than SGD 1', function() {

		var minAmountMessageIsVisibility = EC.visibilityOf(TransferClaimPage.minAmountMessage);

		browser.sleep(1000);
		TransferClaimPage.amountTransfer.sendKeys(0.9);
		browser.wait(minAmountMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Enter the amount greater than wallet balance', function() {

		var maxAmountMessageIsVisibility = EC.visibilityOf(TransferClaimPage.maxAmountMessage);

		browser.sleep(1000);
		TransferClaimPage.amountTransfer.clear();
		browser.sleep(1000);
		TransferClaimPage.amountTransfer.sendKeys(101);
		browser.wait(maxAmountMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Enter a message lenth greater than 160 chars', function() {

		var maxMessageLengthIsVisibility = EC.visibilityOf(TransferClaimPage.maxMessageLength);

		browser.sleep(1000);
		TransferClaimPage.messageInput.sendKeys('abcdfgstsht abcdfgstsht  abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht abcdfgstsht ');
		browser.wait(maxMessageLengthIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('All fields filled with valid values, click Transfer successfully', function() {


		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

		browser.sleep(1000);
		TransferClaimPage.messageInput.clear();
		TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
		TransferClaimPage.amountTransfer.clear();
		TransferClaimPage.amountTransfer.sendKeys(10);

		browser.wait(transferBtnIsClickable).then(function() {
			TransferClaimPage.transferBtn.click();
			browser.wait(printReceiptLinkIsClickable).then(function() {
				expect(true).toBe(true);
				browser.sleep(90000);
			});
		});

	});

	it ('Click Print Receipt link, receipt page is displayed', function() {

		var printReview = element(by.id('print-preview'));
		var printReviewIsVisibility = EC.visibilityOf(printReview);

		browser.sleep(1000);
		TransferClaimPage.printReceiptLink.click();
		browser.wait(windowCount(2), 90000);
		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.wait(printReviewIsVisibility).then(function() {
					browser.sleep(60000);
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});


	});

	it ('Access Send page again, select Email mode -  Transfer button is disabled as', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		var cancelPrintBtn = element.all(by.css('div.button-strip button.cancel')).first();

		browser.sleep(2000);
		cancelPrintBtn.click();

		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {

				browser.sleep(90000);
				DashboardPage.logoutLink.click();

				browser.wait(loginPageIsPresent).then(function() {
					LoginPage.userInput.sendKeys(mobileNumber2);
					LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				});

				LoginPage.submitBtn.click();

				browser.wait(sendMenuIsClickable).then(function() {
					DashboardPage.sendMenu.click();
					browser.wait(sendAmountIsVisibility).then(function() {
						TransferClaimPage.emailMode.click();
						browser.sleep(2000);
						expect(TransferClaimPage.transferBtn.isEnabled()).toBe(false);
					});
				});
			});
		});

	});

	it ('Enter an valid email - transfer button is enabled', function() {

		browser.sleep(60000);
		TransferClaimPage.inputTransferEmail.sendKeys('sgmc+65' + mobileNumber1 + '@matchmove.com');
		browser.sleep(2000);
		expect(TransferClaimPage.transferBtn.isEnabled()).toBe(true);

	});

	it ('Leave email of receiver blank', function() {

		var emailRequiredMessageIsVisibility = EC.visibilityOf(TransferClaimPage.emailRequiredMessage);

		browser.sleep(60000);
		TransferClaimPage.inputTransferEmail.clear();
		browser.wait(emailRequiredMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Enter invalid email of receiver', function() {

		var emailInvalidMessageIsVisibility = EC.visibilityOf(TransferClaimPage.emailInvalidMessage);

		browser.sleep(60000);
		TransferClaimPage.inputTransferEmail.sendKeys('abcchdh@dasd');
		browser.wait(emailInvalidMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Enter user"s registered email address', function() {

		var sameEmailMessageIsVisibility = EC.visibilityOf(TransferClaimPage.sameEmailMessage);

		browser.sleep(60000);
		TransferClaimPage.inputTransferEmail.clear();
		browser.sleep(1000);
		TransferClaimPage.inputTransferEmail.sendKeys('sgmc+65' + mobileNumber2 + '@matchmove.com');
		browser.wait(sameEmailMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Enter a valid email and click Transfer successfully', function() {

		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

		browser.sleep(1000);
		TransferClaimPage.amountTransfer.clear();
		browser.sleep(1000);
		TransferClaimPage.amountTransfer.sendKeys(20);
		browser.sleep(1000);
		TransferClaimPage.inputTransferEmail.clear();
		browser.sleep(1000);
		TransferClaimPage.inputTransferEmail.sendKeys('sgmc+65' + mobileNumber1 + '@matchmove.com');
		browser.wait(transferBtnIsClickable).then(function() {
			browser.sleep(1000);
			TransferClaimPage.transferBtn.click();
			browser.wait(printReceiptLinkIsClickable).then(function() {
				expect(true).toBe(true);
				browser.sleep(120000);
			});
		});
	});


	it ('Check Notification page to see if transfer notification was recorded', function() {

		var transferNotification = element.all(by.cssContainingText('p.ng-binding.ng-scope', 'You have successfully transferred money from your wallet')).first();
		var transferNotificationIsPresence = EC.presenceOf(transferNotification);

		browser.sleep(1000);
		DashboardPage.notificationBell.click();
		browser.sleep(1000);
		DashboardPage.goToNotification.click();
		browser.wait(transferNotificationIsPresence).then(function() {
			browser.sleep(15000);
			expect(true).toBe(true);
		})

	});


	it ('Login to receiver account and check Claim page', function() {


		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsVisibility = EC.visibilityOf(TransferClaimPage.claimBtn);

		browser.sleep(60000);
		DashboardPage.logoutLink.click();

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		browser.wait(claimMenuIsClickable).then(function() {

			browser.sleep(2000);
			DashboardPage.claimMenu.click();

			browser.sleep(90000);

			DashboardPage.logoutLink.click();

			browser.wait(loginPageIsPresent).then(function() {
				LoginPage.userInput.sendKeys(mobileNumber1);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});

			LoginPage.submitBtn.click();

			browser.wait(claimMenuIsClickable).then(function() {

				browser.sleep(2000);
				DashboardPage.claimMenu.click();

				browser.sleep(90000);
				DashboardPage.logoutLink.click();

				browser.wait(loginPageIsPresent).then(function() {
					LoginPage.userInput.sendKeys(mobileNumber1);
					LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				});

				LoginPage.submitBtn.click();

			});

			browser.wait(claimMenuIsClickable).then(function() {
				browser.sleep(2000);
				DashboardPage.claimMenu.click();
				browser.wait(claimBtnIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(10000);
				});
			});
		});

	});

	it ('Claim money successfully', function() {

		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);
		var claimAmountTransaction = element.all(by.css('div.transfer-overview div div span.value-amount')).first();

		browser.sleep(5000);

		claimAmountTransaction.getInnerHtml().then(function(amount) {
			claimAmount = parseFloat(amount);
			console.log('claimAmount: ' + claimAmount);
		});

		TopupPage.walletBalance.getInnerHtml().then(function(balance) {
			receiverBalanceBefore = balance;
			console.log('receiverBalanceBefore: ' + receiverBalanceBefore);
		});

		browser.sleep(5000);
		TransferClaimPage.claimBtn.click();
		browser.wait(claimSuccessMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(500);
		});

	});

	it ('Checking if balance was updated correctly', function() {

		browser.sleep(10000); //waiting for balance to be updated
		TopupPage.walletBalance.getInnerHtml().then(function(balance) {
			receiverBalanceAfter = balance;
			console.log('receiverBalanceAfter: ' + receiverBalanceAfter);

			var increaseAmount = receiverBalanceAfter - receiverBalanceBefore;
			console.log('increaseAmount: ' + increaseAmount);
			browser.sleep(1000);

			expect(increaseAmount).toEqual(claimAmount);
		});
	});

	it ('Checking transaction history if Claim transaction was generated', function() {

		var claimTransactionHistory = element.all(by.cssContainingText('span.transaction-description', 'Received Transfer From')).first();
		var claimTransactionHistoryIsVisibility = EC.visibilityOf(claimTransactionHistory);

		browser.sleep(1000);
		DashboardPage.historyMenu.click();

		browser.wait(claimTransactionHistoryIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});

	});

	it ('Make 1st transfer', function() {

		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

		browser.sleep(15000);
		DashboardPage.sendMenu.click();
		browser.wait(sendAmountIsVisibility).then(function() {
			browser.sleep(2000);
			TransferClaimPage.mobileMode.click();
			browser.sleep(1000);
			TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber2);
			TransferClaimPage.amountTransfer.clear();
			TransferClaimPage.amountTransfer.sendKeys(5);
			TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');

			browser.wait(transferBtnIsClickable).then(function() {
				TransferClaimPage.transferBtn.click();
				browser.wait(printReceiptLinkIsClickable).then(function() {
					expect(true).toBe(true);
					browser.sleep(120000);
				});
			});
		});
	});

	it ('Make 2st transfer', function() {

		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);

		browser.sleep(10000);
		DashboardPage.logoutLink.click();

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		browser.wait(sendMenuIsClickable).then(function() {
			browser.sleep(60000);
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(5000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber2);
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(5);
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(60000);
					});
				});
			});
		});
	});


	it ('Access transfer history page', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		//var historyTabIsVisibility = EC.visibilityOf(TransferClaimPage.historyTab);
		var historyTabIsClickable = EC.elementToBeClickable(TransferClaimPage.historyTab);
		var statusFilterIsVisibility = EC.visibilityOf(TransferClaimPage.statusFilter);
		var cancelTransferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.cancelTransferBtn);

		browser.sleep(1000);
		DashboardPage.logoutLink.click();

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		browser.wait(sendMenuIsClickable).then(function() {

			browser.sleep(90000);
			DashboardPage.sendMenu.click();

			browser.sleep(30000);

			DashboardPage.logoutLink.click();

			browser.wait(loginPageIsPresent).then(function() {
				LoginPage.userInput.sendKeys(mobileNumber1);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});

			LoginPage.submitBtn.click();
			browser.wait(sendMenuIsClickable).then(function() {
				browser.sleep(90000);
				DashboardPage.sendMenu.click();
			});

			browser.sleep(20000);

			browser.wait(historyTabIsClickable).then(function() {
				TransferClaimPage.historyTab.click();
				browser.wait(statusFilterIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});

	});

	it ('Select Active status from the filter', function() {

		var cancelTransferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.cancelTransferBtn);
		var noTransactionMessageIsVisibility = EC.visibilityOf(TransferClaimPage.noTransactionMessage);

		browser.sleep(1000);
		TransferClaimPage.activeStatus.click();
		browser.wait(EC.or(cancelTransferBtnIsClickable, noTransactionMessageIsVisibility)).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Cancel transfer successfully', function() {

		var amountOfTransaction = element.all(by.css('li.history--active.history--cancel div div div span.value-amount')).first();
		var balanceBeforeCancel = 0;
		var balanceAfterCancel = 0;
		var cancelAmount = 0;
		var cancelSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.cancelSuccessMessage);
		var cancelTransferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.cancelTransferBtn);
		var noTransactionMessageIsVisibility = EC.visibilityOf(TransferClaimPage.noTransactionMessage);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var historyTabIsClickable = EC.elementToBeClickable(TransferClaimPage.historyTab);
		var statusFilterIsVisibility = EC.visibilityOf(TransferClaimPage.statusFilter);

		browser.sleep(60000);
		DashboardPage.logoutLink.click();

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		browser.wait(sendMenuIsClickable).then(function() {
			browser.sleep(60000);
			DashboardPage.sendMenu.click();
			browser.sleep(60000);

			browser.wait(historyTabIsClickable).then(function() {
				TransferClaimPage.historyTab.click();
				browser.wait(statusFilterIsVisibility).then(function() {
					browser.sleep(1000);
					TransferClaimPage.activeStatus.click();
					browser.wait(EC.or(cancelTransferBtnIsClickable, noTransactionMessageIsVisibility)).then(function() {
						browser.sleep(5000);
						TransferClaimPage.cancelTransferBtn.click();
						browser.wait(cancelSuccessMessageIsVisibility).then(function() {
							expect(true).toBe(true);
							browser.sleep(2000);
						});
					});
				});
			});
		});
	});

	it ('Select Claimed status from the filter', function() {

		var claimedTransactionIsVisibility = EC.visibilityOf(TransferClaimPage.claimedTransaction);

		browser.sleep(1000);
		TransferClaimPage.claimedStatus.click();
		browser.wait(claimedTransactionIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Select Failed status from the filter', function() {

		var failedTransactionIsVisibility = EC.visibilityOf(TransferClaimPage.failedTransaction);
		var noTransactionMessageIsVisibility = EC.visibilityOf(TransferClaimPage.noTransactionMessage);

		browser.sleep(1000);
		TransferClaimPage.failedStatus.click();
		browser.wait(EC.or(failedTransactionIsVisibility, noTransactionMessageIsVisibility)).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Select Expired status from the filter', function() {

		var expiredTransactionIsVisibility = EC.visibilityOf(TransferClaimPage.expiredTransaction);
		var noTransactionMessageIsVisibility = EC.visibilityOf(TransferClaimPage.noTransactionMessage);

		browser.sleep(1000);
		TransferClaimPage.expiredStatus.click();
		browser.sleep(3000);
		browser.wait(EC.or(expiredTransactionIsVisibility, noTransactionMessageIsVisibility)).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

	it ('Select Cancelled status from the filter', function() {

		var cancelledTransactionIsVisibility = EC.visibilityOf(TransferClaimPage.cancelledTransaction);
		var noTransactionMessageIsVisibility = EC.visibilityOf(TransferClaimPage.noTransactionMessage);

		browser.sleep(1000);
		TransferClaimPage.cancelledStatus.click();
		browser.wait(EC.or(cancelledTransactionIsVisibility, noTransactionMessageIsVisibility)).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Checking transaction history', function() {

		var historyMenuIsClickable = EC.elementToBeClickable(DashboardPage.historyMenu);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var transferTransactionHistory = element.all(by.cssContainingText('span.transaction-description', 'Sent Transfer To')).first();
		var transferTransactionHistoryIsVisibility = EC.visibilityOf(transferTransactionHistory);

		browser.sleep(120000); //waiting for transaction history to be recorded
		DashboardPage.logoutLink.click();

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber2);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		browser.wait(historyMenuIsClickable).then(function() {

			browser.sleep(120000); //waiting for transaction history to be recorded
			DashboardPage.logoutLink.click();

			browser.wait(loginPageIsPresent).then(function() {
				LoginPage.userInput.sendKeys(mobileNumber1);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});

			LoginPage.submitBtn.click();
			browser.wait(historyMenuIsClickable).then(function() {
				DashboardPage.historyMenu.click();
				browser.wait(transferTransactionHistoryIsVisibility).then(function() {
					browser.sleep(2000);
					expect(true).toBe(true);
				});
			});
		});
	});


});
