'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
//var configFile = require('./protractor-config-files/SGMCconfig.json');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var RazorPopup = require('./razorpopup.po.js');
var KycValidationPage = require('./kycvalidation.po.js');
var AdminetPage = require('./adminet.po.js');

describe('Loyalty ', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);

	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};


	it ('Sign up successfully', function() {
		browser.get(configFile.HTTP_HOST);
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber);

		console.log(mobileNumber);

		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		if (configFile.VERIFY_EMAIL_ENABLE){
			var verifyEmailClickable = EC.elementToBeClickable(VerifyEmailPage.verifyEmailbutton);
			browser.wait(verifyEmailClickable).then(function() {
				browser.sleep(1000);
				VerifyEmailPage.verifyEmailbutton.click();
				browser.sleep(5000);
				expect(VerifyEmailPage.resendEmailButton.isPresent()).toBe(true);
			});

			browser.sleep(30000); //waiting for verify email was sent to Gmail
			browser.get(configFile.GMAIL);

			var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.Authentication)).first();
			var emailIsClickable = EC.elementToBeClickable(emailSubjects);
			var expandIsPresence = EC.presenceOf(GmailPage.expandEmail);

			GmailPage.emailInput.sendKeys(configFile.G_EMAIL);
			GmailPage.nextBtn.click();

			browser.sleep(1000);
			GmailPage.passwordInput.sendKeys(configFile.G_PASSWORD);
			GmailPage.signInBtn.click();
			browser.wait(emailIsClickable).then(function() {
				emailSubjects.click();
			});

			browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {

				GmailPage.expandEmail.isPresent().then(function(result) {
					if(result) {
					GmailPage.expandEmails.count().then(function(count) {
						if (count >= 1) {
							GmailPage.expandEmails.last().click();
							}
						});
					}

				});
			});

			browser.sleep(1000);
			GmailPage.verifyAuthenEmail.count().then(function(count) {
				if (count > 1) {
					GmailPage.verifyAuthenEmail.last().click();
				}
				else {
					GmailPage.verifyAuthenEmail.first().click();
				}
			});

			browser.sleep(1000);

			browser.getAllWindowHandles().then(function(handles) {
				var newWindowHandle = handles[1];
				browser.switchTo().window(newWindowHandle).then(function() {
					expect(browser.getCurrentUrl()).toContain(configFile.HTTP_HOST);
				});
			});
			var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified email'));
			var verifyEmailSuccessIsVisibility = EC.visibilityOf(verifyEmailSuccess);
			var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);

			browser.wait(loginPageIsPresent).then(function() {
				LoginPage.emailInput.sendKeys(emailAddress);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});

			LoginPage.submitBtn.click();

			//
			var loyaltyMenuIsClickable = EC.elementToBeClickable(DashboardPage.loyaltyMenu);
			browser.wait(loyaltyMenuIsClickable).then(function() {
					expect(true).toBe(true);
			});

		}

		else {
			var loyaltyMenuIsClickable = EC.elementToBeClickable(DashboardPage.loyaltyMenu);
			browser.wait(loyaltyMenuIsClickable).then(function() {
				expect(true).toBe(true);
			});
		}
	});

	it ('Access Loyalty page', function() {

		var loyaltyPage = element.all(by.css('div.title-header')).last();
		var loyaltyPageIsVisibility = EC.visibilityOf(loyaltyPage);
		//var historyTab = element(by.cssContainingText('v-tab.subttitle-icon h3.ng-binding', 'History'));
		var historyTab = element(by.cssContainingText('v-tab.subttitle-icon h3', 'History'));
		var noLoyaltyText = element(by.cssContainingText('div.content-message--notransaction h4', 'No Loyalty Points'));
		var noLoyaltyTextIsVisibility = EC.visibilityOf(noLoyaltyText);


		DashboardPage.loyaltyMenu.click();
		browser.wait(loyaltyPageIsVisibility).then(function() {
			browser.sleep(5000);
			historyTab.click();
			browser.wait(noLoyaltyTextIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});

		});

	});

	it ('Loyalty point = 0', function() {
		var loyaltyPoint = element.all(by.css('div.value p.value-amount')).last();
		loyaltyPoint.getInnerHtml().then(function(value) {
			var point = parseFloat(value);
			console.log(point);
			expect(point).toEqual(0);
		});
	});


	it ('Do first topup successfully', function() {

		browser.sleep(2000);

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

		var providerRazorpayIsClickable = EC.elementToBeClickable(TopupPage.providerRazorpay);
		var paymentPopupIsPresence = EC.presenceOf(RazorPopup.paymentPopup);
		var successBtnIsPresence = EC.presenceOf(RazorPopup.successBtn);
		var cardPaymentMethodIsPresence = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);
		var payBtnIsClickable = EC.elementToBeClickable(RazorPopup.payBtn);

		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
		});

		browser.wait(EC.or(providerEasypayIsClickable, providerRazorpayIsClickable)).then(function() {
			TopupPage.providerEasypay.isPresent().then(function(result) {
			if (result) {

				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
					var balanceText = balance.replace(",", "");
					balanceBefore = parseFloat(balanceText);
				});
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 100;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(2), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[1];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
							EasyGateway.visaChannel.click();
							browser.sleep(2000);
							EasyGateway.creditCardNum.sendKeys('4111111111111111');
							EasyGateway.expMonth.click();
							EasyGateway.expYear.click();
							EasyGateway.creditCardCvv2.sendKeys('989');
							EasyGateway.creditCardName.sendKeys('auto tester');
							EasyGateway.submitBtn.click();
						});
					});
				});

				var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
				browser.wait(transactionSuccessfulIsVisibility).then(function() {
					browser.getAllWindowHandles().then(function(handles) {
						browser.driver.close().then(function () {
							browser.switchTo().window(handles[0]).then(function() {
								browser.sleep(90000); //waiting 90 seconds for balance to be updated
								browser.refresh();
	    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
								browser.wait(walletBalanceIsPresence).then(function() {
									TopupPage.walletBalance.getInnerHtml().then(function(balance) {
										balanceAfter = balance;
										var amountIncrese = balanceAfter - balanceBefore;
										expect(amountIncrese).toEqual(customAmount);
									});
								});
							});
						});
					});
				});

			}

			else {

				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceBefore = parseFloat(balanceText);
				});

				TopupPage.providerRazorpay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					topupAmount = 100;
					TopupPage.amountCustomText.sendKeys(topupAmount);
					TopupPage.topupBtn.click();
				});
				browser.sleep(15000);
				browser.switchTo().frame(0);
				browser.sleep(2000);
				RazorPopup.cardPaymentMethod.click();


				browser.wait(payBtnIsClickable).then(function() {
					RazorPopup.cardNumber.sendKeys(4111111111111111);
					RazorPopup.cardExpiry.sendKeys(1117);
					RazorPopup.cardCvv.sendKeys(989);
				});

				RazorPopup.payBtn.click();
				browser.wait(windowCount(3), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[2];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.sleep(15000);
						RazorPopup.successBtn.click();
						browser.wait(windowCount(2), 60000);
					});

					browser.switchTo().window(handles[1]).then(function() {
						var progressTextIsInvisibility = EC.invisibilityOf(TopupPage.progressText);
						browser.sleep(10000);
						expect(TopupPage.progressText.isPresent()).toBe(false);
					});
				});

				browser.sleep(90000); //waiting for 90s to see if balance is updated
				var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
				browser.refresh();
				browser.wait(walletBalanceIsPresence).then(function() {
					TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceAfter = parseFloat(balanceText);
						var amountIncrese = balanceAfter - balanceBefore;
						expect(amountIncrese).toEqual(topupAmount);
					});
				});

			}
			});
		});

	});

	it ('Check Loyalty History - 2 transactions were generated', function() {

		var showDetail = element.all(by.css('span.trigger-details')).first();
		var showDetailIsVisibility = EC.visibilityOf(showDetail);
		var showDetails = element.all(by.css('span.trigger-details'))
		var loyaltyPage = element.all(by.css('div.title-header')).first();
		var loyaltyPageIsVisibility = EC.visibilityOf(loyaltyPage);
		var historyTab = element(by.cssContainingText('v-tab.subttitle-icon h3', 'History'));

		DashboardPage.loyaltyMenu.click();
		browser.wait(loyaltyPageIsVisibility).then(function() {
			browser.sleep(2000);
			historyTab.click();
			browser.wait(showDetailIsVisibility).then(function() {
				showDetails.count().then(function(count) {
					console.log(count);
					expect(count).toBe(2);
					browser.sleep(1000);
				});
			});
		});

	});

	it ('Loyalty point was increased to 1100', function() {

		var loyaltyPoint = element.all(by.css('div.value p.value-amount')).last();
		loyaltyPoint.getInnerHtml().then(function(value) {
			var point = parseFloat(value);
			console.log(point);
			expect(point).toEqual(1100);
		});

	});

	it ('Do topup successfully again', function() {


		browser.sleep(2000);

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

		var providerRazorpayIsClickable = EC.elementToBeClickable(TopupPage.providerRazorpay);
		var paymentPopupIsPresence = EC.presenceOf(RazorPopup.paymentPopup);
		var successBtnIsPresence = EC.presenceOf(RazorPopup.successBtn);
		var cardPaymentMethodIsPresence = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);
		var payBtnIsClickable = EC.elementToBeClickable(RazorPopup.payBtn);
		var cardPaymentMethodIsClickable = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);

		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
		});

		browser.wait(EC.or(providerEasypayIsClickable, providerRazorpayIsClickable)).then(function() {
			TopupPage.providerEasypay.isPresent().then(function(result) {
			if (result) {

				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
					var balanceText = balance.replace(",", "");
					balanceBefore = parseFloat(balanceText);
				});
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 100;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(2), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[1];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
							EasyGateway.visaChannel.click();
							browser.sleep(2000);
							EasyGateway.creditCardNum.sendKeys('4111111111111111');
							EasyGateway.expMonth.click();
							EasyGateway.expYear.click();
							EasyGateway.creditCardCvv2.sendKeys('989');
							EasyGateway.creditCardName.sendKeys('auto tester');
							EasyGateway.submitBtn.click();
						});
					});
				});

				var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
				browser.wait(transactionSuccessfulIsVisibility).then(function() {
					browser.getAllWindowHandles().then(function(handles) {
						browser.driver.close().then(function () {
							browser.switchTo().window(handles[0]).then(function() {
								browser.sleep(90000); //waiting 90 seconds for balance to be updated
								browser.refresh();
	    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
								browser.wait(walletBalanceIsPresence).then(function() {
									TopupPage.walletBalance.getInnerHtml().then(function(balance) {
										balanceAfter = balance;
										var amountIncrese = balanceAfter - balanceBefore;
										expect(amountIncrese).toEqual(customAmount);
									});
								});
							});
						});
					});
				});

			}

			else {

				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceBefore = parseFloat(balanceText);
				});

				TopupPage.providerRazorpay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					topupAmount = 100;
					TopupPage.amountCustomText.sendKeys(topupAmount);
					TopupPage.topupBtn.click();
				});
				browser.sleep(15000);
				browser.switchTo().frame(1);

				browser.wait(cardPaymentMethodIsClickable).then(function() {
					RazorPopup.cardPaymentMethod.click();
				});
				browser.wait(payBtnIsClickable).then(function() {
					RazorPopup.cardNumber.sendKeys(4111111111111111);
					RazorPopup.cardExpiry.sendKeys(1117);
					RazorPopup.cardCvv.sendKeys(989);
				});

				RazorPopup.payBtn.click();
				browser.wait(windowCount(3), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[2];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.sleep(15000);
						RazorPopup.successBtn.click();
						browser.wait(windowCount(2), 60000);
					});

					browser.switchTo().window(handles[1]).then(function() {
						var progressTextIsInvisibility = EC.invisibilityOf(TopupPage.progressText);
						browser.sleep(10000);
						expect(TopupPage.progressText.isPresent()).toBe(false);
					});
				});

				browser.sleep(90000); //waiting for 90s to see if balance is updated
				var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
				browser.refresh();
				browser.wait(walletBalanceIsPresence).then(function() {
					TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceAfter = parseFloat(balanceText);
						var amountIncrese = balanceAfter - balanceBefore;
						expect(amountIncrese).toEqual(topupAmount);
					});
				});
			}
			});
		});

	});

	it ('Check Loyalty History - there are 3 transactions', function() {

		var showDetail = element.all(by.css('span.trigger-details')).first();
		var showDetailIsVisibility = EC.visibilityOf(showDetail);
		var showDetails = element.all(by.css('span.trigger-details'))
		var loyaltyPage = element.all(by.css('div.title-header')).first();
		var loyaltyPageIsVisibility = EC.visibilityOf(loyaltyPage);
		var historyTab = element(by.cssContainingText('v-tab.subttitle-icon h3', 'History'));

		DashboardPage.loyaltyMenu.click();
		browser.wait(loyaltyPageIsVisibility).then(function() {
			browser.sleep(2000);
			historyTab.click();
			browser.wait(showDetailIsVisibility).then(function() {
				showDetails.count().then(function(count) {
					console.log(count);
					expect(count).toBe(3);
					browser.sleep(1000);
				});
			});
		});

	});


	it ('Loyalty point was increased to 2100', function() {

		var loyaltyPoint = element.all(by.css('div.value p.value-amount')).last();
		loyaltyPoint.getInnerHtml().then(function(value) {
			var point = parseFloat(value);
			console.log(point);
			expect(point).toEqual(2100);
		});

	});

});
