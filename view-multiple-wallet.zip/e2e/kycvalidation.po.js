'use strict';

var KycValidationPage = function() {
	this.uploadDocumentsBtn = element.all(by.css('button[href="/wallet/verification/upload"]')).first();
	this.completeProfileLink= element(by.css('a[href="/wallet/details/my/complete/"]')); ///wallet/details/my/complete/
	this.uploadImage = element.all(by.css('div.section-input--file')).first();
	this.verifyIdentityBtn = element(by.css('button[ng-click="redirectVerification()"]'));
	this.invalidFormatMessage = element(by.cssContainingText('p', 'Invalid Document format'));
	this.inputFile = element.all(by.css('input[type="file"]')).last();
	this.numberOfImagesMessage = element(by.cssContainingText('p', 'up to 4 files'));
	this.submitDocumentBtn = element(by.css('button.button-primary--medium'));
	this.removeFirstImageBtn = element.all(by.css('span.button-warning--small')).first();
	this.maximumImagesMessage = element(by.cssContainingText('p', 'Maximum allowed'));
	this.KYCprogress = element(by.cssContainingText('h4','Identity Verification in Progress'));
	this.f2fVerificationRequiredBanner = element(by.cssContainingText('h4','Face to Face Verificiation Required'));
	this.documentRejectedBanner = element(by.cssContainingText('h4','Verification Documents Rejected'));
	this.documentRejectedMessage = element(by.cssContainingText('p', 'was rejected'));
	this.f2fApprovalBanner = element(by.cssContainingText('h4','verification approved'));
	this.documentSubmittedBanner = element(by.cssContainingText('h4','Documents submitted'));
};

module.exports = new KycValidationPage();