'use strict';
var configFile = require('./e2e.json');
var EasyGateway = function() {
	this.cancelBtn = element(by.css('input.button[value="Cancel"]'));
	this.visaChannel = element(by.css('img[name="visa_button"]'));
	this.visaLogo = element(by.css('img[src="images/icon-visa.jpg"]'));
	this.creditCardNum = element(by.css('input#creditCardNum'));
	this.expMonth = element(by.css('select[name="expMonth"] option[value="11"]'));
	this.expYear = element(by.css('select[name="expYear"] option[value="17"]'));
	this.creditCardCvv2 = element(by.css('input#creditCardCvv2'));
	this.creditCardName = element(by.css('input#creditCardName'));
	this.submitBtn = element(by.css('input#submitBtn'));
	this.transactionSuccessful = element(by.cssContainingText('div h1', 'Your transaction is successful'));
};

module.exports = new EasyGateway();
