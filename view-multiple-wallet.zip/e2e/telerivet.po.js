/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var TelerivetPage = function() {

  var configFile = require('./e2e.json');

  this.emailfield = element(by.id('username'));
  this.passwordfield = element(by.id('password'));
  this.loginButton = element(by.css('.btn-submit'));

  this.logintoTelerivet = function(email, passw){
	  this.emailfield.sendKeys('m');
	  this.emailfield.sendKeys(email);
	  this.passwordfield.sendKeys(passw);
	  this.loginButton.click();
	  browser.sleep(5000);
  }

  this.project = element(by.cssContainingText('.nameLink', configFile.TELERIVET_PROJECT_NAME));
  this.messages = element(by.cssContainingText('.menu-item', 'Messages'));
  this.searchMessage = element(by.css('input[type="text"]'));
  this.actionSearch = element(by.css('.action-search'));
  //this.otpMessage = element.all(by.css('.messageText'));
  //this.otpMessage = element(by.css('.convContent'));


  this.otpMessage = element.all(by.css('span.messageText')).last();//then(function(items) {


  this.goToOTPMessage = function(mobileNumber){
	  console.log(mobileNumber);
	  this.project.click();
	  this.messages.click();
	  this.searchMessage.sendKeys(mobileNumber);
	  this.actionSearch.click();
	  browser.sleep(10000);
  }

  this.getOTPMessage = function(){
	  return this.otpMessage.getText().then(function(text){
		var otp = text.substr(configFile.TELERIVET_SUBSTRINGS.fIndex, configFile.TELERIVET_SUBSTRINGS.leng);
    //var otp = text.substr(48, 6);
		console.log(otp);
		return otp;
	  });
  }


  this.cardselectorItemCount = function (num) {
    var dropdown = element.all(by.options('option.name for option in items track by option.id'));
	expect(dropdown.count()).toEqual(num);
  }


  this.transactions = element(by.repeater('transaction in transactions'));

  this.checkOneTransactionVisible = function(){

		element.all(by.repeater('transaction in transactions')).then(function(posts) {
		var itemImage = posts[0].element(by.className('sub-item--image'));
		var itemDesc  = posts[0].element(by.className('sub-item--description'));
		var itemBalance  = posts[0].element(by.className('sub-item--action'));

		expect(itemImage.isDisplayed()).toBe(true);
		expect(itemDesc.isDisplayed()).toBe(true);
		expect(itemBalance.isDisplayed()).toBe(true);
		})
  };


  this.checkOneDetailedTransactionVisible = function(){
	element.all(by.repeater('transaction in transactions')).then(function(posts) {
	try {
		var titleElement = posts[0].element(by.className('transaction-type'));
		expect(titleElement.isDisplayed()).toBe(true);
	}
	catch(er) {
		console.log('error occured: ' + er);
	}


	});
  }

  this.getTransationtype = function(transaction){
	element.all(by.repeater('transaction in transactions')).then(function(posts) {
    var titleElement = posts[0].element(by.className('transaction-type'));
    expect(titleElement.getText()).toEqual(transaction);
	});
  }



  this.openandLogintoTelerivet = function(){
	   var telerivetUsername = 'tester@matchmove.com';
	   var telerivetPassword = 'mmg123456';
	   var telerivetURL = 'https://telerivet.com/u/Q3CUZ6G7C6/projects';

	  browser.actions().sendKeys(protractor.Key.CONTROL +'t').perform().then(function () {
        browser.sleep(3000);
		browser.getAllWindowHandles().then(function (handles) {
            //var newWindowHandle = handles[1]; // this is your new window
            browser.switchTo().window(handles[1]);
			browser.get(telerivetURL);
			browser.sleep(10000);

			this.emailfield = element(by.id('username'));
			this.passwordfield = element(by.id('password'));
			this.loginButton = element(by.css('.btn-submit'));
			browser.sleep(10000);
			//this.logintoTelerivet(telerivetUsername, telerivetPassword);

			this.emailfield.sendKeys(telerivetUsername);
			this.passwordfield.sendKeys(telerivetPassword);
			this.loginButton.click();

        });
	  });
  }



  this.setEmail = function(email){
	  this.emailInput.clear();
	  this.emailInput.sendKeys(email);
  }

  this.setPassword = function(email){
	  this.pwdInput.clear();
	  this.pwdInput.sendKeys(email);
  }

  this.clickLogin = function(email){
	  this.loginBtn.click();
  }

  this.setScreenSize = function(){
	  browser.driver.manage().window().maximize();
	  //browser.manage().window().setSize(640, 1136);
  }

};

module.exports = new TelerivetPage();
