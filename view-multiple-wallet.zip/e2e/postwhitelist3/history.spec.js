'use strict';

describe('History page', function () {
  var HistoryPage = require('../history.po');
  var LoginPage = require('../login.po');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  var card = " ";
  require('../waitReady.js');


  beforeEach(function () {
    //browser.get(TestData.url);
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });



  it('should verify all elements are displayed', function() {

	//Login
	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(15000);

	/*
	DashboardPage.popupNOtification.isDisplayed().then(function (){
		DashboardPage.popupNOtification.click();
	});
	browser.get(TestData.url + '/wallet/offers/list');
	browser.sleep(5000);
	browser.get(TestData.url + '/wallet/home');
	browser.sleep(5000);
	DashboardPage.getFirstCard();
	browser.sleep(10000);
	*/

	/*
	browser.get(TestData.url);
	LoginPage.setEmail(TestData.existinguser);
    LoginPage.setPassword(TestData.vCardpassword);
	expect(LoginPage.submitBtn.isEnabled()).toBe(true);
    LoginPage.submitBtn.click();
	expect(HistoryPage.homebannerImg.waitReady()).toBeTruthy();
	browser.sleep(2000);
	 */

	browser.get(configFile.HTTP_HOST + configFile.HISTORY_PAGE.redirectionUrl);
	expect(HistoryPage.cardselector.waitReady()).toBeTruthy();
	browser.sleep(2000);

	//HistoryPage.checkOneTransactionVisible();
	//HistoryPage.getTransationtype('Topup');

  });


  it('should verify transactions are displayed', function() {
	  HistoryPage.checkOneTransactionVisible();
  });


  it('should verify transaction details are displayed', function() {
	  HistoryPage.showDetails.click();
	  HistoryPage.checkOneDetailedTransactionVisible();
  });

  it('should verify dropdown display only wallet for accounts contains no wallet', function() {
	  expect(HistoryPage.cardselector.isDisplayed()).toBe(true);
	  //expect(HistoryPage.cardselectorItemCount.count()).toEqual(2);
	if(configFile.HISTORY_PAGE.isCardincludedinDropDown == "true"){
	  HistoryPage.cardselectorItemCountCardinc(1);
	}else{
	  HistoryPage.cardselectorItemCount(1);
	}

  });

  it('verify dropdown displays wallet and card for accounts card created', function() {

	  if (configFile.HISTORY_PAGE.preKYC == "true"){

		  browser.get(configFile.HTTP_HOST + configFile.DASHBOARD_PAGE.redirectionUrl);
		  browser.sleep(5000);
		  DashboardPage.popupNOtification.isPresent().then(function(result){
		    if(result){
			DashboardPage.popupNOtification.click();
		    }
		  });
		  DashboardPage.getFirstCard();
		  browser.sleep(15000);
      browser.sleep(15000);
		  DashboardPage.cardNumber.getText().then(function(text){
			card = Utility.getString(text, 0, 19);
			console.log(card);
			browser.get(configFile.HTTP_HOST + configFile.HISTORY_PAGE.redirectionUrl);
			browser.sleep(5000);
			if(configFile.HISTORY_PAGE.isCardincludedinDropDown == "true"){
	  			HistoryPage.cardselector.$('[label="'+configFile.HISTORY_PAGE.cardName+' ('+ card +')"]').click();
			}else{
	  			HistoryPage.cardselector.$('[label="'+configFile.HISTORY_PAGE.cardName+'"]').click();
			}

		  })
		  //card = Utility.getString(DashboardPage.cardNumber, 0, 18);
		  browser.sleep(3000);
		  expect(HistoryPage.errormessage.isPresent()).toBe(false);
		  HistoryPage.cardselector.$('[label="'+configFile.HISTORY_PAGE.walletName+'"]').click();
		  browser.sleep(2000);
		  expect(HistoryPage.errormessage.isPresent()).toBe(false);
		  HistoryPage.checkOneTransactionVisible();

		  expect(HistoryPage.cardselector.isDisplayed()).toBe(true);

		  if(configFile.HISTORY_PAGE.isCardincludedinDropDown == "true"){
			  HistoryPage.cardselectorItemCountCardinc(2);
	  	  }else{
	  		  HistoryPage.cardselectorItemCount(2);
	 	  }
	  }

	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutToApp();
	browser.sleep(5000);


  });

});
