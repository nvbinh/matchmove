'use strict';

function ConnectDatabase (){
  var mysql = require('../node_modules/mysql');

  this.connection = mysql.createConnection({
    host : "vcard-sg.cjcz2kjzqdbp.ap-southeast-1.rds.amazonaws.com",
    user : "vcard_ops",
    password : "Hi6Uc6oOt5g"
  });

};

module.exports = ConnectDatabase;
