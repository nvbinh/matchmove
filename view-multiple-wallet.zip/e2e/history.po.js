/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var HistoryPage = function() {
  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));
  
  
  
  this.cardselector = element(by.model('activeCard'));  
  //this.errormessage = element(by.css('div.content-message--500 img'));.content-message--500.ng-scope>img
  this.errormessage = element(by.css('.content-message--500.ng-scope>img'));
  this.showDetails  = element(by.css('.trigger-details'));
  this.transactionDetails = element(by.css('.transaction-detail'));
  
  this.cardselectorItemCount = function (num) {
    var dropdown = element.all(by.options('option.name for option in items track by option.id'));	
	//var dropdown = element.all(by.options('option.name + getCardNumber(option.number) for option in items track by option.id'));	
	expect(dropdown.count()).toEqual(num);
  }

  this.cardselectorItemCountCardinc = function (num) {
    	//var dropdown = element.all(by.options('option.name for option in items track by option.id'));	
	var dropdown = element.all(by.options('option.name + getCardNumber(option.number) for option in items track by option.id'));	
	expect(dropdown.count()).toEqual(num);
  }
  
  
  this.transactions = element(by.repeater('transaction in transactions'));
  
  this.checkOneTransactionVisible = function(){
	
		element.all(by.repeater('transaction in transactions')).then(function(posts) {
		var itemImage = posts[0].element(by.className('sub-item--image'));
		var itemDesc  = posts[0].element(by.className('sub-item--description'));
		var itemBalance  = posts[0].element(by.className('sub-item--action'));
	
		expect(itemImage.isDisplayed()).toBe(true);
		expect(itemDesc.isDisplayed()).toBe(true);
		expect(itemBalance.isDisplayed()).toBe(true);
		})		
  };
  
  
  this.checkOneDetailedTransactionVisible = function(){
	element.all(by.repeater('transaction in transactions')).then(function(posts) {
	try {
		var titleElement = posts[0].element(by.className('transaction-type'));
		expect(titleElement.isDisplayed()).toBe(true);
	}
	catch(er) {
		console.log('error occured: ' + er);
	}
    
    
	});
  }
    
  this.getTransationtype = function(transaction){
	element.all(by.repeater('transaction in transactions')).then(function(posts) {
    var titleElement = posts[0].element(by.className('transaction-type'));
    expect(titleElement.getText()).toEqual(transaction);
	});  
  }
  
   
  
  this.setEmail = function(email){
	  this.emailInput.clear();
	  this.emailInput.sendKeys(email);
  }
  
  this.setPassword = function(email){
	  this.pwdInput.clear();
	  this.pwdInput.sendKeys(email);
  }
  
  this.clickLogin = function(email){
	  this.loginBtn.click();
  }
  
  this.setScreenSize = function(){
	  browser.driver.manage().window().maximize();
	  //browser.manage().window().setSize(640, 1136);
  }
  
};

module.exports = new HistoryPage();
