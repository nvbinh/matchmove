'use strict';

describe('Offer Page', function () {
  var OfferPage = require('../offer.po');
  var LoginPage = require('../login.po');
  var SignUpPage = require('../signup.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var DashboardPage = require('../dashboard.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('../waitReady.js');

  beforeEach(function () {
    //browser.get(TestData.url);

  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });



  it('signup and test offer page and details', function() {

	//Login
	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(15000);
browser.sleep(15000);

  });

	/*
	browser.get(TestData.url);
	LoginPage.setEmail(TestData.existinguser);
    LoginPage.setPassword(TestData.vCardpassword);
	expect(LoginPage.submitBtn.isEnabled()).toBe(true);
    LoginPage.submitBtn.click();
	browser.sleep(5000);
	*/

	//Go to offer Page
	//expect(OfferPage.offerMenu.waitReady()).toBeTruthy();
	//OfferPage.offerMenu.click();

  it('should have all the elements on the page', function() {
browser.sleep(15000);
	browser.get(configFile.HTTP_HOST + configFile.OFFER_PAGE.redirectionUrl);
	browser.sleep(5000);

    expect(OfferPage.homebannerImg.isPresent()).toBe(true);
	expect(OfferPage.helpBtn.isPresent()).toBe(true);
	expect(OfferPage.notificationBtn.isPresent()).toBe(true);
	expect(OfferPage.welcomeUser.isPresent()).toBe(true);
	expect(OfferPage.walletBalance.isPresent()).toBe(true);
	expect(OfferPage.walletValue.isPresent()).toBe(true);
	expect(OfferPage.loyaltyPoints.isPresent()).toBe(true);
	expect(OfferPage.loyaltyValue.isPresent()).toBe(true);
	expect(OfferPage.sidemenu.isPresent()).toBe(true);

	expect(OfferPage.pageTitle.isPresent()).toBe(true);
	expect(OfferPage.titleIcon.isPresent()).toBe(true);
	expect(OfferPage.offerList.isPresent()).toBe(true);

	//go to offer detail page
	OfferPage.offerList.click();
	browser.sleep(2000);


	expect(OfferPage.subHeader.isPresent()).toBe(true);
	expect(OfferPage.offerDetails.isPresent()).toBe(true);
	expect(OfferPage.offerInfo.isPresent()).toBe(true);
	expect(OfferPage.offerDescription.isPresent()).toBe(true);

	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutToApp();
	browser.sleep(5000);

  });

});
