'use strict';

describe('Get another card page', function () {

  var LoginPage = require('./login.po');
  var SignUpPage = require('./signup.po');
  var DashboardPage = require('./dashboard.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var AccountDetailPage = require('./accountdetails.po');
  var GetAnotherCardPage = require('./getcard.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  var full_name = configFile.ACCOUNT_INFO.FIRST_NAME + " " + configFile.ACCOUNT_INFO.LAST_NAME;
  var mobileNumVerify = configFile.MOBILE_NUMBER_AREA_CODE + " " + newMobileSignup;
  require('./waitReady.js');

  beforeEach(function () {
    //browser.get(TestData.url);

  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });

  it('sign up new user', function() {

	  Utility.setScreenSize();
  	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
  	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
  	browser.sleep(25000);
  });

  it('should have all the elements on the page', function() {

  browser.get(configFile.HTTP_HOST+ configFile.GET_ANOTHER_CARD_PAGE.redirectionUrl);
  browser.sleep(10000);

  expect(GetAnotherCardPage.homebannerImg.isPresent()).toBe(true);
	expect(GetAnotherCardPage.helpBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.notificationBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.welcomeUser.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletBalance.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyPoints.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.sidemenu.isPresent()).toBe(true);


	// Get another card section
  if (configFile.GET_ANOTHER_CARD_PAGE.isgetcardEnabled == "true"){
  	expect(GetAnotherCardPage.getFreecardTab.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.cardimage.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.getcardDescription.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.getCardButton.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.cardDescription.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.cardDescription.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.purchaseAcard.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.activateCard.isPresent()).toBe(true);
  }

	//purchase card tab
  if (configFile.GET_ANOTHER_CARD_PAGE.isPurchasecardEnabled == "true"){
  	GetAnotherCardPage.purchaseAcard.click();
  	browser.sleep(2000);
  	expect(GetAnotherCardPage.purchaseAcard.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.purchaseCardImage.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.purchaseCardContent.isPresent()).toBe(true);
    expect(GetAnotherCardPage.orderButton.isPresent()).toBe(true);
  }

	//activate card
  if (configFile.GET_ANOTHER_CARD_PAGE.isActivatecardEnabled == "true"){
  	GetAnotherCardPage.activateCard.click();
  	browser.sleep(2000);
  	expect(GetAnotherCardPage.activateCard.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.stepImage.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.stepDescription.isPresent()).toBe(true);
    expect(GetAnotherCardPage.activateButton.isPresent()).toBe(true);
  }

  });

  it('Get card tab should be the default tab', function() {

    browser.get(configFile.HTTP_HOST+ configFile.GET_ANOTHER_CARD_PAGE.redirectionUrl);
    browser.sleep(5000);


    expect(GetAnotherCardPage.homebannerImg.isPresent()).toBe(true);
	expect(GetAnotherCardPage.helpBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.notificationBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.welcomeUser.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletBalance.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyPoints.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.sidemenu.isPresent()).toBe(true);

	// Get another card section
  if (configFile.GET_ANOTHER_CARD_PAGE.isgetcardEnabled == "true"){
  	expect(GetAnotherCardPage.getFreecardTab.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.cardimage.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.getcardDescription.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.getCardButton.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.cardDescription.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.cardDescription.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.purchaseAcard.isPresent()).toBe(true);
  	expect(GetAnotherCardPage.activateCard.isPresent()).toBe(true);
  }

	//purchase card tab
  if (configFile.GET_ANOTHER_CARD_PAGE.isPurchasecardEnabled == "true"){
  	expect(GetAnotherCardPage.purchaseCardImage.isDisplayed()).toBe(false);
  	expect(GetAnotherCardPage.purchaseCardContent.isDisplayed()).toBe(false);

  }

	//activate card
  if (configFile.GET_ANOTHER_CARD_PAGE.isActivatecardEnabled == "true"){
  	expect(GetAnotherCardPage.stepImage.isDisplayed()).toBe(false);
  	expect(GetAnotherCardPage.stepDescription.isDisplayed()).toBe(false);
  }

  });

  it('Get card tab should have all the elements displayed', function() {

    browser.get(configFile.HTTP_HOST+ configFile.GET_ANOTHER_CARD_PAGE.redirectionUrl);
    browser.sleep(5000);

    expect(GetAnotherCardPage.homebannerImg.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.helpBtn.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.notificationBtn.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.welcomeUser.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.walletBalance.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.walletValue.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.loyaltyPoints.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.loyaltyValue.isPresent()).toBe(true);
	  expect(GetAnotherCardPage.sidemenu.isPresent()).toBe(true);

	// Get another card section
  if (configFile.GET_ANOTHER_CARD_PAGE.isgetcardEnabled == "true"){
	expect(GetAnotherCardPage.getFreecardTab.isPresent()).toBe(true);
	expect(GetAnotherCardPage.cardimage.isPresent()).toBe(true);
	expect(GetAnotherCardPage.getcardDescription.isPresent()).toBe(true);
	expect(GetAnotherCardPage.getCardButton.isPresent()).toBe(true);
	expect(GetAnotherCardPage.cardDescription.isPresent()).toBe(true);
	expect(GetAnotherCardPage.cardDescription.isPresent()).toBe(true);
	expect(GetAnotherCardPage.purchaseAcard.isPresent()).toBe(true);
	expect(GetAnotherCardPage.activateCard.isPresent()).toBe(true);
  }

	//purchase card tab
  if (configFile.GET_ANOTHER_CARD_PAGE.isPurchasecardEnabled == "true"){
	expect(GetAnotherCardPage.purchaseCardImage.isDisplayed()).toBe(false);
	expect(GetAnotherCardPage.purchaseCardContent.isDisplayed()).toBe(false);
  }

	//activate card
  if (configFile.GET_ANOTHER_CARD_PAGE.isActivatecardEnabled == "true"){
	expect(GetAnotherCardPage.stepImage.isDisplayed()).toBe(false);
	expect(GetAnotherCardPage.stepDescription.isDisplayed()).toBe(false);
  }

  });

  it('Purchase card tab should display all the elements', function() {

    browser.get(configFile.HTTP_HOST+ configFile.GET_ANOTHER_CARD_PAGE.redirectionUrl);
    browser.sleep(5000);

    expect(GetAnotherCardPage.homebannerImg.isPresent()).toBe(true);
	expect(GetAnotherCardPage.helpBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.notificationBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.welcomeUser.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletBalance.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyPoints.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.sidemenu.isPresent()).toBe(true);

	//purchase card tab
  if (configFile.GET_ANOTHER_CARD_PAGE.isPurchasecardEnabled == "true"){
	GetAnotherCardPage.purchaseAcard.click();
	browser.sleep(2000);
	expect(GetAnotherCardPage.purchaseAcard.isPresent()).toBe(true);
	expect(GetAnotherCardPage.purchaseCardImage.isPresent()).toBe(true);
	expect(GetAnotherCardPage.purchaseCardContent.isPresent()).toBe(true);
  expect(GetAnotherCardPage.orderButton.isPresent()).toBe(true);
  }

	//activate card
  if (configFile.GET_ANOTHER_CARD_PAGE.isActivatecardEnabled == "true"){
	expect(GetAnotherCardPage.stepImage.isDisplayed()).toBe(false);
	expect(GetAnotherCardPage.stepDescription.isDisplayed()).toBe(false);
  }

  });

  it('activate card tab should display all the elements', function() {

    browser.get(configFile.HTTP_HOST+ configFile.GET_ANOTHER_CARD_PAGE.redirectionUrl);
    browser.sleep(5000);

    expect(GetAnotherCardPage.homebannerImg.isPresent()).toBe(true);
	expect(GetAnotherCardPage.helpBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.notificationBtn.isPresent()).toBe(true);
	expect(GetAnotherCardPage.welcomeUser.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletBalance.isPresent()).toBe(true);
	expect(GetAnotherCardPage.walletValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyPoints.isPresent()).toBe(true);
	expect(GetAnotherCardPage.loyaltyValue.isPresent()).toBe(true);
	expect(GetAnotherCardPage.sidemenu.isPresent()).toBe(true);

  if (configFile.GET_ANOTHER_CARD_PAGE.isActivatecardEnabled == "true"){
	GetAnotherCardPage.activateCard.click();
	browser.sleep(2000);
	expect(GetAnotherCardPage.activateCard.isPresent()).toBe(true);
	expect(GetAnotherCardPage.stepImage.isPresent()).toBe(true);
	expect(GetAnotherCardPage.stepDescription.isPresent()).toBe(true);
  expect(GetAnotherCardPage.activateButton.isPresent()).toBe(true);
	//expect(GetAnotherCardPage.leftarrow1.isPresent()).toBe(true);

	//navigate to pages
	//click 1st arrow
	//GetAnotherCardPage.rightarrow1.click();
	browser.sleep(2000);
	expect(GetAnotherCardPage.activateCard.isPresent()).toBe(true);
	expect(GetAnotherCardPage.stepImage.isPresent()).toBe(true);
	expect(GetAnotherCardPage.stepDescription.isPresent()).toBe(true);
	//expect(GetAnotherCardPage.leftarrow2.isPresent()).toBe(true);
  }
  });


});
