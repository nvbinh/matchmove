'use strict';

describe('The main view', function () {
  var LoginPage = require('./login.po');
  var TestData = require('./testdata.js');
  var TelerivetPage = require('./telerivet.po');
  var Utility = require('./utilities.po');
  var x;

  beforeEach(function () {


  });
  /*----------------------------------------------------------
  it('test', function(){
	  browser.get('google.com');
  })

it ('should open new tab', function(){
	Utility.OpenNewTab();
	browser.ignoreSynchronization = true;

  });

it ('should open new tab', function(){
	Utility.chooseActiveTab(1);
	browser.ignoreSynchronization = true;
	browser.get(TestData.telerivetURL);
  });


  it('should have all the elements on the page', function() {

	  //LoginPage.setScreenSize();
	  browser.ignoreSynchronization = true;

	  browser.get(TestData.telerivetURL);
	  browser.sleep(5000);
	  TelerivetPage.logintoTelerivet(TestData.telerivetUsername, TestData.telerivetPassword);
	  browser.sleep(5000);
	  TelerivetPage.goToOTPMessage('1461221986');

	  //TelerivetPage.getOTPMessage().then(function(value){
	  //	console.log(value);
	  //});
	   x = TelerivetPage.getOTPMessage();

	  //x.then(function(value){
		//console.log(value);
	  //});
	  /* browser.actions().sendKeys(protractor.Key.CONTROL +'t').perform().then(function () {
        browser.sleep(1000);
		browser.getAllWindowHandles().then(function (handles) {
            var newWindowHandle = handles[1]; // this is your new window
            browser.switchTo().window(newWindowHandle)
        });
	  }); */
	  /*---------------------------------------------------------------
	  //Utility.logintoTelerivet();
	  //VerifyMobile.otpMobileDisplay(mob);
  });

  it('should have all the elements on the page', function() {


	  //x.then(function(value){
		//console.log(value);
	  //});

  });
---------------------------------------------------------------
*/
});
