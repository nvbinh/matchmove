'use strict';
var configFile = require('./e2e.json');
var RazorPopup = function() {
	this.paymentPopup = element(by.css('div#modal'));
	this.successBtn = element(by.css('p input[value="Success"]'));
	//this.successBtn = element(by.css('.success"]'));
	this.failureBtn = element(by.css('input.danger'));
	this.cardNumber = element(by.css('input#card_number'));
	this.cardExpiry = element(by.css('input#card_expiry'));
	this.cardCvv = element(by.css('input#card_cvv'));
	this.cardPaymentMethod = element(by.css('div.payment-option[tab="card"]'));
	this.payBtn = element(by.css('button#footer'));
};

module.exports = new RazorPopup();
