'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./protractor-config-files/SGMCconfig.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var KycValidationPage = require('./kycvalidation.po.js');
var AdminetPage = require('./adminet.po.js');

describe('KYC validation', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;

	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var remitMenu = element(by.linkText('Remit'));
	//var remitMenuIsClickable = EC.elementToBeClickable(remitMenu);
	var getAnotherCardMenu = element(by.linkText('Get Another Card'));


	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};	

	it ('Signup successfully', function() {
		browser.get(configFile.HTTP_HOST);
		LoginPage.signupBtn.click();
		browser.sleep(5000);
		//SignUpPage.emailInput.sendKeys(emailAddress);
		SignUpPage.firstNameInput.sendKeys('match');
		SignUpPage.lastNameInput.sendKeys('move');
		SignUpPage.preferredNameInput.sendKeys('user');
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		console.log(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()		
		SignUpPage.submitBtn.click();

		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});		
	});

	it ('Complete profile successfully', function() {

		var genderIsClickable = EC.elementToBeClickable(AccountDetailPage.genderMale);

		browser.sleep(2000);
		DashboardPage.accountMenu.click();
		browser.actions().keyDown(protractor.Key.COMMAND).click(DashboardPage.accountMenu).keyUp(protractor.Key.COMMAND).perform();

		browser.wait(genderIsClickable).then(function() {
			browser.sleep(2000);
			browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
		});

		AccountDetailPage.genderMale.click();
		AccountDetailPage.userTitle(1);

		if (configFile.SPASS_TYPE) {
				AccountDetailPage.spassID.click();
		}
		else {
			AccountDetailPage.passportID.click();
		}
		
		var randomID = Utility.autoGenerateMobile(12, 8);
		AccountDetailPage.identificationNumber.sendKeys(randomID);
		AccountDetailPage.completeProfile.click();
		
		browser.sleep(20000);

		if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
	      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
	      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
	      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
	      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
	      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
	    }
		AccountDetailPage.sameAddressBox.click();
		AccountDetailPage.updateAddress.click();
		browser.sleep(3000);

		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);

		browser.wait(kycLinkIsClickable).then(function() {
			browser.sleep(2000);
			expect(true).toBe(true);			
		});						
	});

	it ('Logout and Login KYC popup is displayed', function() {

		browser.sleep(2000);
		DashboardPage.logoutLink.click(); 

		var verifyIdentityBtnIsClickable = EC.elementToBeClickable(KycValidationPage.verifyIdentityBtn);

		var uploadImageIsPresence = EC.presenceOf(KycValidationPage.uploadImage);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			
		});		

		LoginPage.submitBtn.click();
		
		browser.wait(verifyIdentityBtnIsClickable).then(function() {
			expect(true).toBe(true);
		});		
	});

	it ('Click Verify Identity button, user is redirected upload images page', function() {

		var uploadImageIsVisibility = EC.visibilityOf(KycValidationPage.uploadImage);

		browser.sleep(2000);
		KycValidationPage.verifyIdentityBtn.click();
		browser.wait(uploadImageIsVisibility).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Only files of type .png , .jpg are accepted', function() {

		var invalidFormatMessageIsVisibility = EC.visibilityOf(KycValidationPage.invalidFormatMessage);

		var imagePng = './KYC_Image/png.png';
		var imagePngPath = path.resolve(__dirname, imagePng);

		var imageJpg = './KYC_Image/jpg.jpg';
		var imageJpgPath = path.resolve(__dirname, imageJpg);

		var imageBmp = './KYC_Image/bmp.bpm';
		var imageBmpPath = path.resolve(__dirname, imageBmp);

		var txtFile = './KYC_Image/txt.txt';
		var txtFilePath = path.resolve(__dirname, txtFile);

		browser.sleep(1000);
		KycValidationPage.inputFile.sendKeys(imagePngPath);
		KycValidationPage.inputFile.sendKeys(imageJpgPath);
		KycValidationPage.inputFile.sendKeys(imageBmpPath);

		browser.wait(invalidFormatMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(2000);
		});

		KycValidationPage.inputFile.sendKeys(txtFilePath);
		browser.wait(invalidFormatMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(2000);
		});		
	});

	it ('Only allowed to upload up to 4 files.', function() {

		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);
		var numberOfImagesMessageIsVisibility = EC.visibilityOf(KycValidationPage.numberOfImagesMessage);

		browser.sleep(2000);
		KycValidationPage.inputFile.sendKeys(image1Path);
		KycValidationPage.inputFile.sendKeys(image2Path);
		KycValidationPage.inputFile.sendKeys(image3Path);
		browser.sleep(4000);
		KycValidationPage.submitDocumentBtn.click();
		browser.wait(numberOfImagesMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(5000);
		});
	});

	it ('Maximum allowed file size is 8MB', function() {

		var bigSizeImage = './KYC_Image/bigsize.png';
		var bigSizeImagePath = path.resolve(__dirname, bigSizeImage);
		var maximumImagesMessageIsVisibility = EC.visibilityOf(KycValidationPage.maximumImagesMessage);

		KycValidationPage.removeFirstImageBtn.click();
		KycValidationPage.inputFile.sendKeys(bigSizeImagePath);
		browser.wait(maximumImagesMessageIsVisibility).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Upload image successfully', function() {


		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);

		browser.sleep(2000);
		KycValidationPage.submitDocumentBtn.click();

		browser.wait(KYCprogressIsPresence).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Face to Face Verificiation Required', function() {

		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var KYCsubmissionDetailsIsVisibility = EC.visibilityOf(AdminetPage.KYCsubmissionDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationRequiredBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fVerificationRequiredBanner);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);
		var documentSubmittedBannerIsVisibility = EC.visibilityOf(KycValidationPage.documentSubmittedBanner);
		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.get(configFile.HTTP_HOST_ADMINET);
				AdminetPage.emailfield.sendKeys(configFile.ADMINET_ACCOUNT.EMAIL);
				AdminetPage.passwordfield.sendKeys(configFile.ADMINET_ACCOUNT.PASSWORD);
				AdminetPage.loginButton.click();
				browser.wait(actionMenuIsClickable).then(function() {
					AdminetPage.actionMenu.click();
					browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
						browser.sleep(3000);
						AdminetPage.KYCsubmissionDetails.click();
					});
					
					browser.wait(generateBtnIsClickable).then(function() {
						AdminetPage.searchTypeMobile.click();
						AdminetPage.searchKeyword.sendKeys(mobileNumber);
						AdminetPage.generateBtn.click();
						browser.wait(actionMenuIsClickable).then(function() {
							AdminetPage.actionMenu.click();
							browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
								browser.sleep(3000);
								AdminetPage.KYCsubmissionDetails.click();
							});
							browser.wait(f2fVerificationBtnIsClickable).then(function() {
								AdminetPage.f2fVerificationBtn.click();
								browser.wait(f2fVerificationApprovalBtnIsClickable).then(function() {
									browser.switchTo().window(handles[0]).then(function() {
										browser.sleep(2000);
										DashboardPage.logoutLink.click();
										browser.wait(loginPageIsPresent).then(function() {
											LoginPage.userInput.sendKeys(mobileNumber);
											LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
										});	

										LoginPage.submitBtn.click();
										browser.wait(accountMenuIsClickable).then(function() {
											browser.sleep(3000);
											DashboardPage.accountMenu.click();
											browser.wait(kycLinkIsClickable).then(function() {
												browser.sleep(2000);
												AccountDetailPage.kycLink.click();
												browser.wait(documentSubmittedBannerIsVisibility).then(function() {
													expect(true).toBe(true);
													browser.sleep(2000);
												});
											});
										});
									});
								});							
							});
						});			
					});				
				});
			});
		});		
	});


	it ('Verification Documents Rejected', function() {

		var documentRejectedBannerIsVisibility = EC.visibilityOf(KycValidationPage.documentRejectedBanner);
		var documentRejectedMessageIsVisibility = EC.visibilityOf(KycValidationPage.documentRejectedMessage);
		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);
		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				AdminetPage.f2fVerificationRejectBtn.click();
				browser.sleep(3000);
				browser.switchTo().window(handles[0]).then(function() {		
					///
					browser.sleep(2000);
					AccountDetailPage.closeKycPopup.click();
					browser.sleep(2000);
					DashboardPage.logoutLink.click();
					browser.wait(loginPageIsPresent).then(function() {
						LoginPage.userInput.sendKeys(mobileNumber);
						LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
					});	

					LoginPage.submitBtn.click();
					browser.wait(accountMenuIsClickable).then(function() {
						browser.sleep(3000);
						DashboardPage.accountMenu.click();
						browser.wait(kycLinkIsClickable).then(function() {
							browser.sleep(3000);
							AccountDetailPage.kycLink.click();
							browser.wait(documentRejectedBannerIsVisibility).then(function() {
								expect(true).toBe(true);
								browser.sleep(2000);
								KycValidationPage.uploadDocumentsBtn.click();
								browser.wait(documentRejectedMessageIsVisibility).then(function() {
									expect(true).toBe(true);
								});
							});
						});
					});
					///
				});
			});	
		});
	});


	it ('Re-submit documents and click Request More Information in Adminnet', function() {

		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);

		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);
		var requestMoreInfoBtnIsClickable = EC.elementToBeClickable(AdminetPage.requestMoreInfoBtn);

		var documentRejectedBannerIsVisibility = EC.visibilityOf(KycValidationPage.documentRejectedBanner);
		var documentRejectedMessageIsVisibility = EC.visibilityOf(KycValidationPage.documentRejectedMessage);
		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);
		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

			
		KycValidationPage.inputFile.sendKeys(image1Path);
		KycValidationPage.inputFile.sendKeys(image2Path);
		KycValidationPage.inputFile.sendKeys(image3Path);
		browser.sleep(4000);
		KycValidationPage.submitDocumentBtn.click();

		browser.wait(KYCprogressIsPresence).then(function() {
			browser.getAllWindowHandles().then(function(handles) {
				var newWindowHandle = handles[1];
				browser.switchTo().window(newWindowHandle).then(function() {
					browser.sleep(20000);
					browser.refresh();
					browser.wait(requestMoreInfoBtnIsClickable).then(function() {
						AdminetPage.requestMoreInfoBtn.click();
						browser.sleep(3000);
					});
				});

				browser.switchTo().window(handles[0]).then(function() {

					browser.sleep(2000);
					DashboardPage.logoutLink.click();
					browser.wait(loginPageIsPresent).then(function() {
						LoginPage.userInput.sendKeys(mobileNumber);
						LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
					});	

					LoginPage.submitBtn.click();
					browser.wait(accountMenuIsClickable).then(function() {
						browser.sleep(3000);
						DashboardPage.accountMenu.click();
						browser.wait(kycLinkIsClickable).then(function() {
							browser.sleep(2000);
							AccountDetailPage.kycLink.click();
							browser.wait(documentRejectedBannerIsVisibility).then(function() {
								expect(true).toBe(true);
								browser.sleep(2000);
								KycValidationPage.uploadDocumentsBtn.click();
								browser.wait(documentRejectedMessageIsVisibility).then(function() {
									expect(true).toBe(true);
								});
							});
						});
					});
				});
			});	
		});
	});


	it ('Re-submit document and do f2f approval successfully', function() {

		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);

		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var f2fApprovalBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fApprovalBanner);
		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);
		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var documentSubmittedBannerIsVisibility = EC.visibilityOf(KycValidationPage.documentSubmittedBanner);
		var approveBtnIsClickable = EC.elementToBeClickable(AdminetPage.approveBtn);


		KycValidationPage.inputFile.sendKeys(image1Path);
		KycValidationPage.inputFile.sendKeys(image2Path);
		KycValidationPage.inputFile.sendKeys(image3Path);
		browser.sleep(4000);
		KycValidationPage.submitDocumentBtn.click();

		browser.wait(KYCprogressIsPresence).then(function() {
			expect(true).toBe(true);
		});

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.sleep(20000);
				browser.refresh();
				browser.wait(f2fVerificationBtnIsClickable).then(function() {
					AdminetPage.f2fVerificationBtn.click();
					browser.wait(f2fVerificationApprovalBtnIsClickable).then(function() {
						AdminetPage.f2fVerificationApprovalBtn.click();
						browser.wait(approveBtnIsClickable).then(function() {
							browser.sleep(1000);
							expect(true).toBe(true);
						});
					});
				});
			});

			browser.switchTo().window(handles[0]).then(function() {
				////
				browser.sleep(2000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					LoginPage.userInput.sendKeys(mobileNumber);
					LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				});	

				LoginPage.submitBtn.click();
				browser.wait(accountMenuIsClickable).then(function() {
					browser.sleep(3000);
					DashboardPage.accountMenu.click();
					browser.wait(kycLinkIsClickable).then(function() {
						browser.sleep(2000);
						AccountDetailPage.kycLink.click();
						browser.wait(documentSubmittedBannerIsVisibility).then(function() {
							expect(true).toBe(true);
							browser.sleep(2000);
						});
					});
				});
				///
			});
		});				

	});	

	it ('Re-submit document and click Approve button', function() {
		
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var alreadySubmitYCSIsPresence = EC.presenceOf(AdminetPage.alreadySubmitYCS);
		var documentSubmittedBannerIsVisibility = EC.visibilityOf(KycValidationPage.documentSubmittedBanner);
		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);
		var approveBtnIsClickable = EC.elementToBeClickable(AdminetPage.approveBtn);
		var approveBtnIsInvisibility = EC.invisibilityOf(AdminetPage.approveBtn);
		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				AdminetPage.approveBtn.click();
				browser.wait(approveBtnIsInvisibility).then(function() {
					browser.sleep(2000);
					expect(true).toBe(true);
					browser.switchTo().window(handles[0]).then(function() {
						browser.sleep(2000);
						AccountDetailPage.closeKycPopup.click();
						browser.sleep(2000);
						DashboardPage.logoutLink.click();
						browser.wait(loginPageIsPresent).then(function() {
							LoginPage.userInput.sendKeys(mobileNumber);
							LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
						});	

						LoginPage.submitBtn.click();
						browser.wait(accountMenuIsClickable).then(function() {
							browser.sleep(3000);
							DashboardPage.accountMenu.click();
							browser.sleep(15000);
							expect(AccountDetailPage.kycLink.isPresent()).toBe(false);
						});
					});
				});
			});
		});	
	});

});