/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var WalletCreatePage = function() {
  this.bannerImg = element(by.css('.image__centered img'));
  this.pageTitle = element(by.css('.marketing__title h1'));
  this.pageMsg = element(by.css('.marketing__title p'));
  this.emailInput = element(by.css('input[type="email"]'));
  this.pwdInput = element(by.css('input[type="password"]'));
  this.submitBtn = element(by.css('form .section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
};

module.exports = new WalletCreatePage();
