'use strict';

describe('Suspend card page', function () {
  var SuspendCardPage = require('./suspend.po');
  var LoginPage = require('./login.po');
  var SignUpPage = require('./signup.po');
  var DashboardPage = require('./dashboard.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('./waitReady.js');

  beforeEach(function () {
    //browser.get(TestData.url);

  });

    it('setup test specs', function(){
	//removed logged in 
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should have all the elements on the page without card yet', function() {

	//Login
	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(10000);

	/*
	browser.get(TestData.url);
	LoginPage.setEmail(TestData.existingusernocard);
    LoginPage.setPassword(TestData.vCardpassword);
	expect(LoginPage.submitBtn.isEnabled()).toBe(true);
    LoginPage.submitBtn.click();
	expect(SuspendCardPage.homebannerImg.waitReady()).toBeTruthy();
	browser.sleep(2000);
	*/

	//Go to offer Page
	//expect(SuspendCardPage.getCardMenu.waitReady()).toBeTruthy();
	//SuspendCardPage.getCardMenu.click();
	browser.get(configFile.HTTP_HOST + configFile.SUSPEND_PAGE.redirectionUrl);
	browser.sleep(3000);

    expect(SuspendCardPage.homebannerImg.isPresent()).toBe(true);
	expect(SuspendCardPage.helpBtn.isPresent()).toBe(true);
	expect(SuspendCardPage.notificationBtn.isPresent()).toBe(true);
	expect(SuspendCardPage.welcomeUser.isPresent()).toBe(true);
	expect(SuspendCardPage.walletBalance.isPresent()).toBe(true);
	expect(SuspendCardPage.walletValue.isPresent()).toBe(true);
	expect(SuspendCardPage.loyaltyPoints.isPresent()).toBe(true);
	expect(SuspendCardPage.loyaltyValue.isPresent()).toBe(true);
	expect(SuspendCardPage.sidemenu.isPresent()).toBe(true);

	// Get another card section
	expect(SuspendCardPage.suspendImage.isPresent()).toBe(true);
	expect(SuspendCardPage.getCardButton.isPresent()).toBe(true);

  });

  it('should have all the elements on the page', function() {

	if (configFile.SUSPEND_PAGE.preKYC == "true"){

		browser.get(configFile.HTTP_HOST + configFile.DASHBOARD_PAGE.redirectionUrl);
		browser.sleep(5000);
		DashboardPage.popupNOtification.isPresent().then(function(result){
			if(result){
				DashboardPage.popupNOtification.click();
			}
		});

    browser.get(configFile.HTTP_HOST + configFile.SUSPEND_PAGE.redirectionUrl);
    browser.sleep(5000);
    browser.get(configFile.HTTP_HOST + configFile.DASHBOARD_PAGE.redirectionUrl);
		browser.sleep(5000);
		DashboardPage.getFirstCard();
		browser.sleep(15000);
		browser.sleep(15000);

		browser.get(configFile.HTTP_HOST + configFile.SUSPEND_PAGE.redirectionUrl);
		browser.sleep(3000);

		expect(SuspendCardPage.homebannerImg.isPresent()).toBe(true);
		expect(SuspendCardPage.helpBtn.isPresent()).toBe(true);
		expect(SuspendCardPage.notificationBtn.isPresent()).toBe(true);
		expect(SuspendCardPage.welcomeUser.isPresent()).toBe(true);
		expect(SuspendCardPage.walletBalance.isPresent()).toBe(true);
		expect(SuspendCardPage.walletValue.isPresent()).toBe(true);
		expect(SuspendCardPage.loyaltyPoints.isPresent()).toBe(true);
		expect(SuspendCardPage.loyaltyValue.isPresent()).toBe(true);
		expect(SuspendCardPage.sidemenu.isPresent()).toBe(true);

		// suspend card section
		expect(SuspendCardPage.suspendCardButton.isPresent()).toBe(true);
		expect(SuspendCardPage.cardContainer.isPresent()).toBe(true);
		expect(SuspendCardPage.cardLocked.isPresent()).toBe(false);
	}

  });

  it('should verify the popup appeared when suspend button is click', function() {

	if (configFile.SUSPEND_PAGE.preKYC == "true"){

		expect(SuspendCardPage.homebannerImg.isPresent()).toBe(true);
		expect(SuspendCardPage.helpBtn.isPresent()).toBe(true);
		expect(SuspendCardPage.notificationBtn.isPresent()).toBe(true);
		expect(SuspendCardPage.welcomeUser.isPresent()).toBe(true);
		expect(SuspendCardPage.walletBalance.isPresent()).toBe(true);
		expect(SuspendCardPage.walletValue.isPresent()).toBe(true);
		expect(SuspendCardPage.loyaltyPoints.isPresent()).toBe(true);
		expect(SuspendCardPage.loyaltyValue.isPresent()).toBe(true);
		expect(SuspendCardPage.sidemenu.isPresent()).toBe(true);

		// Get another card section
		expect(SuspendCardPage.suspendCardButton.isPresent()).toBe(true);
		expect(SuspendCardPage.cardContainer.isPresent()).toBe(true);

		SuspendCardPage.suspendCardButton.click();
		browser.sleep(3000);

		expect(SuspendCardPage.cardNumber.isPresent()).toBe(true);
		expect(SuspendCardPage.cardName.isDisplayed()).toBe(true);
		expect(SuspendCardPage.cardDate.isPresent()).toBe(true);
		expect(SuspendCardPage.detailSection.isDisplayed()).toBe(true);
	}

  });

  it('should suspend card successfully', function() {

	if (configFile.SUSPEND_PAGE.preKYC == "true"){

		expect(SuspendCardPage.homebannerImg.isPresent()).toBe(true);
		expect(SuspendCardPage.helpBtn.isPresent()).toBe(true);
		expect(SuspendCardPage.notificationBtn.isPresent()).toBe(true);
		expect(SuspendCardPage.welcomeUser.isPresent()).toBe(true);
		expect(SuspendCardPage.walletBalance.isPresent()).toBe(true);
		expect(SuspendCardPage.walletValue.isPresent()).toBe(true);
		expect(SuspendCardPage.loyaltyPoints.isPresent()).toBe(true);
		expect(SuspendCardPage.loyaltyValue.isPresent()).toBe(true);
		expect(SuspendCardPage.sidemenu.isPresent()).toBe(true);


		expect(SuspendCardPage.suspendCardButton.isPresent()).toBe(true);
		expect(SuspendCardPage.cardContainer.isPresent()).toBe(true);

		//browser.sleep(1000);
		//browser.executeScript('window.scrollTo(0,0);').then(function () {
		//SuspendCardPage.suspendCardButton.click();
		//browser.sleep(3000);
		//})


		expect(SuspendCardPage.cardNumber.isPresent()).toBe(true);
		expect(SuspendCardPage.cardName.isDisplayed()).toBe(true);
		expect(SuspendCardPage.cardDate.isPresent()).toBe(true);
		expect(SuspendCardPage.detailSection.isDisplayed()).toBe(true);

		expect(SuspendCardPage.clicktoconfirmButton.isDisplayed()).toBe(true);


		SuspendCardPage.clicktoconfirmButton.click();
		browser.sleep(10000);

		expect(SuspendCardPage.cardLocked.isPresent()).toBe(true);
		expect(SuspendCardPage.cardLocked.isDisplayed()).toBe(true);

	}


  });

});
