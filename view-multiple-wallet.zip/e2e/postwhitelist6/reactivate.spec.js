'use strict';

describe('Reactivate card page', function () {
  var SuspendCardPage = require('../suspend.po');
  var LoginPage = require('../login.po');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  var AdminetPage = require('../adminet.po');
  var NotificationPage = require('../notification.po');
  require('../waitReady.js');

  beforeEach(function () {
    //browser.get(TestData.url);

  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should sign up sucessfully and get new card', function() {

		Utility.setScreenSize();

		browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
		SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
		browser.sleep(15000);
    if (configFile.REACTIVATE_PAGE.preKYC == "true"){
		DashboardPage.popupNOtification.isPresent().then(function(result){
			if(result){
				DashboardPage.popupNOtification.click();
			}
		});
		browser.sleep(5000);
		DashboardPage.getFirstCard();
		browser.sleep(30000);
    }
  });

  it('should suspend card sucessfully', function() {
	  if (configFile.REACTIVATE_PAGE.preKYC == "true"){
		browser.get(configFile.HTTP_HOST + configFile.SUSPEND_PAGE.redirectionUrl);
		SuspendCardPage.suspendCardSucessfully();
		browser.sleep(15000);
    }else {
    browser.get(configFile.HTTP_HOST + configFile.SUSPEND_PAGE.redirectionUrl);
    browser.sleep(3000);
    expect(SuspendCardPage.homebannerImg.isPresent()).toBe(true);
    expect(SuspendCardPage.helpBtn.isPresent()).toBe(true);
    expect(SuspendCardPage.notificationBtn.isPresent()).toBe(true);
    expect(SuspendCardPage.welcomeUser.isPresent()).toBe(true);
    expect(SuspendCardPage.walletBalance.isPresent()).toBe(true);
    expect(SuspendCardPage.walletValue.isPresent()).toBe(true);
    expect(SuspendCardPage.loyaltyPoints.isPresent()).toBe(true);
    expect(SuspendCardPage.loyaltyValue.isPresent()).toBe(true);
    expect(SuspendCardPage.sidemenu.isPresent()).toBe(true);

    // Get another card section
    expect(SuspendCardPage.suspendImage.isPresent()).toBe(true);
    expect(SuspendCardPage.getCardButton.isPresent()).toBe(true);

  }
  });

  it('login to adminet', function() {
	  if (configFile.REACTIVATE_PAGE.preKYC == "true"){
		  browser.ignoreSynchronization = true;
		  browser.get(configFile.HTTP_HOST_ADMINET);
		  AdminetPage.logintoAdminet(configFile.ADMINET_PAGE.emailAccount, configFile.ADMINET_PAGE.adPassword);
	  }
  });

  it('unsuspend card', function() {
	  if (configFile.REACTIVATE_PAGE.preKYC == "true"){
		  browser.ignoreSynchronization = true;
		  AdminetPage.searchUserinCS1(newMobileSignup, "Mobile Number");
	  }
  });

  it('verify reactivation is in notification page', function() {

	  if (configFile.REACTIVATE_PAGE.preKYC == "true"){
		  browser.ignoreSynchronization = false;
		  browser.get(configFile.HTTP_HOST);
      if(configFile.SIGNUP_PAGE.emailRequired == "true"){
		    LoginPage.loginProcess(newEmailSignup, configFile.VCARD_PASSWORD);
      }else {
        LoginPage.loginProcess(newMobileSignup, configFile.VCARD_PASSWORD);
      }
		  browser.sleep(10000);
		  browser.get(configFile.HTTP_HOST + configFile.NOTIFICATION_PAGE.redirectionUrl);
		  browser.sleep(5000);
		  NotificationPage.checkNotificationIfReactivateCardVisible();
	  }

  });

});
