/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var SendCreditPage = function() {

  this.sendMenu = element(By.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[1]/side-bar/ul/li[3]/a'));
  this.amounttoTransfer = element(by.model('transfer.transferAmount'));
	this.emailField = element(by.model('transfer.email'));
	this.mobileField = element(by.model('transfer.mobile'));
	this.emailTransfer = element(by.css('label[for="email"]'));
	this.mobileTransfer = element(by.css('label[for="mobile"]'));
	this.transferButton = element(by.css('button[type="submit"]'));
	this.totalTransferAmount = element.all(by.css('.value-amount')).get(7);
  this.currency = element(by.css('.value-currency'));
	this.amountTransfer = element.all(by.css('.value-amount')).get(5);
  this.amountChargeFee = element.all(by.css('.value-amount')).get(6);
	this.transferTab = element.all(by.css('mm-tab-item')).first();
	this.historyTab = element.all(by.css('mm-tab-item')).last();
	this.statusDropdown = element(by.model('activeFilter'));
  this.errorMeassege = element(by.css('.help-block'));
  this.messageS = element(by.model('transfer.message'));
  this.progressText = element(by.css('div.detail-status h4'));


  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));

  // no topup yet
  this.topupMessage = element(by.css('.content-message--doKyc'));

  //pre kyc
  this.verifyIdentityButton = element(by.css('section.content div.content-inner .button-primary--medium'));
  this.transferButton = element(by.css('div.section-action button.button-primary--medium'));

  //post kyc
  //this.transferTab = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-tabs/v-tab[1]'));
	/*
  this.transferTab = element(by.xpath('.//*[@id="masterUI"]/div/div/div/div[2]/div[2]/section/div/section/div/section/v-tabs/v-tab[1]'));
  this.historyTab = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-tabs/v-tab[2]'));
  this.subHeader = element(by.css('.title-secondary'));

  //via email
  this.leftArrow = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-pages/v-page[1]/div/div[1]/label[4]'));
  this.rigthArrow = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-pages/v-page[1]/div/div[1]/label[2]'));
  this.amountTransferFieldEmail = element(by.model('transfer.emailAmount'));
  this.emailField = element(by.model('transfer.email'));
  this.messageFieldEmail = element(by.model('transfer.emailMessage'));
  this.transferButtonEmail = element(by.xpath('.//*[@id="transferEmail"]/div[4]/button'));
  this.amountErrorMessageEmail = element(by.xpath('.//*[@id="transferEmail"]/div[1]/div/p'));
  this.emailErrorMessageEmail = element(by.xpath('.//*[@id="transferEmail"]/div[2]/div/p'));
  this.messageErrorMessageEmail = element(by.xpath('.//*[@id="transferEmail"]/div[3]/div/p'));

  //via mobile
  this.leftArrowsms = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-pages/v-page[1]/div/div[1]/label[1]'));
  this.rigthArrowsms = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-pages/v-page[1]/div/div[1]/label[3]'));
  this.amountTransferFieldsms = element(by.model('transfer.smsAmount'));
  this.mobileNumberFieldsms = element(by.model('transfer.mobile'));
  this.messageFieldsms = element(by.model('transfer.smsMessage'));
  this.transferButtonsms = element(by.xpath('.//*[@id="transferSms"]/div[4]/button'));
  this.amountErrorMessagesms = element(by.xpath('.//*[@id="transferSms"]/div[1]/div/p'));
  this.mobileErrorMessagesms = element(by.xpath('.//*[@id="transferSms"]/div[2]/div/p'));
  this.messageErrorMessagesms = element(by.xpath('.//*[@id="transferSms"]/div[3]/div/p'));

  this.totlaValueAmount = element(by.css('.container-reciept .total span.value-amount'));
  this.amountValue = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/div/section/v-pages/v-page[1]/div/ul/li[1]/receipt-section/aside/div[1]/div[2]/p/span[2]'));
  */

  //success message
  this.sucessMessageforSendCredit = element(by.css('.content-box--success'));


  this.updatedBalanceafterSendCredit = function updatedBalance(availableBal, currentBal){
	  availableBal = parseFloat(availableBal);
	  currentBal = parseFloat(currentBal);
	  var res = availableBal - currentBal;
	  return res;
  }

};

module.exports = new SendCreditPage();
