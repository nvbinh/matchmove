/*
'use strict';

describe('Suspend card page', function () {
  var SuspendCardPage = require('./suspend.po');
  var LoginPage = require('./login.po');
  var SignUpPage = require('./signup.po');
  var DashboardPage = require('./dashboard.po');
  require('./waitReady.js');
  var newEmailSignup = TestData.randomEmailNonExisting(TestData.existinguser);
  var newMobileSignup = TestData.randommobileNonExisting('24');
  var AdminetPage = require('./adminet.po');
  var NotificationPage = require('./notification.po');
  var configFile = require('./e2e.json');

  beforeEach(function () {
    //browser.get(TestData.url);

  });
*/	/*
  it('should have all the elements on the page without card yet', function() {

	  browser.ignoreSynchronization = true;
	  browser.get(TestData.adminetURL);
	  AdminetPage.logintoAdminet(TestData.adminetEmail, TestData.adminetPassword);
	  AdminetPage.searchUserviaEmail('matchmoveexisting');

  });
  */
/*---------------------------------------------------
  it('should have all the elements on the page without card yet', function() {

	  //browser.ignoreSynchronization = true;
	  console.log(configFile.EXISTING_EMAIL);
	  console.log(configFile.VCARD_PASSWORD);
	  browser.get(TestData.url);
    browser.sleep(10000);

    /*LoginPage.loginProcess(configFile.LOGIN.ExistingEmail, configFile.LOGIN.vCardpassword);
	  browser.sleep(5000);
	  browser.get(TestData.url+'/wallet/notification');
	  browser.sleep(20000);
	  NotificationPage.checkNotificationIfReactivateCardVisible();
    */

    //Login to your MatchMove Wallet
/*--------------------------------------------------------

    element(by.cssContainingText('.ng-binding', 'Login to your MatchMove Wallet')).getText().then(function (text) {
    expect(text).toEqual('Login to your MatchMove Wallet');
    })

  });
------------------------------------------------------------
*/
//});

describe('Suspend card page', function () {

  var hotkeys = require('protractor-hotkeys');
  var configFile = require('./e2e.json');
  var openTab = require('open-new-tab');

//Database connection
var ConnectDatabase = require('./connectdb.po.js');
var connectDatabase = new ConnectDatabase();
var sql = "select code from vcard_ih.user_tokens where type = 'physical card'";

  it('should have all the elements on the page without card yet', function() {
    connectDatabase.connection.connect();
    connectDatabase.connection.query(sql, function(err, rows) {
        if (!err) {
          otpCode = rows[0].code;
          console.log('Get OTP code successfully');
          console.log(otpCode);
        }else {
          console.log(err);
        }
        connectDatabase.connection.end();
    });

/*
    var mysql = require('../node_modules/mysql');
                                            var connection = mysql.createConnection({
                                                host : "vcard-sg.cjcz2kjzqdbp.ap-southeast-1.rds.amazonaws.com",
                                                user : "vcard_ops",
                                                password : "Hi6Uc6oOt5g"
                                            });
                                            connection.connect();

                                            var optCodeQuery = "select code from vcard_ih.user_tokens where type = 'physical card'";
                                            browser.sleep(5000);
                                            connection.query(optCodeQuery, function(err, rows) {
                                                if (err) {
                                                    console.log('Could not run query');
                                                } else {
                                                    console.log('Get OTP code successfully');
                                                       otpCode = rows[0].code;
                                                       console.log(otpCode);
                                                        expect(true).toBe(true);
                                                    };
                                                })

                                            browser.sleep(2000);
                                            connection.end();

*/
  ////browser.get(configFile.HTTP_HOST);
  ////openTab("/foo");
  //browser.sleep(10000);
  //element(by.model('credentials.password')).click();
  //element(by.model('credentials.password')).sendKeys(protractor.Key.CONTROL, 't').perform();
  //browser.actions().sendKeys(protractor.Key.CONTROL +"a").perform();
  //browser.actions().keyDown(protractor.Key.CONTROL).sendKeys('a').perform();
  //browser.actions().keyDown(protractor.Key.CONTROL).sendKeys('t').perform();
  //browser.actions().keyDown(protractor.Key.CONTROL).sendKeys('t').perform();
  //hotkeys.trigger('ctrl+T');
  ////browser.sleep(5000);


  });

});
