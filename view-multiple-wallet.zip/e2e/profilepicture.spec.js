/*
*** Please config browser on maxmimum size before running this script
*/

'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var path = require('path');

describe('Profile picture ', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	browser.driver.manage().window().maximize();
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};


	it ('Sign up successfully', function() {

		browser.get(configFile.HTTP_HOST);
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber);

		console.log(mobileNumber);

		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var accountMenu = element(by.linkText('Account'));
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);

		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Click on profile image area, user is redirected to profile page', function() {

		var profileImageArea = element.all(by.css('div.profile-image')).first();
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));

		browser.sleep(2000);
		profileImageArea.click();
		//browser.wait(genderIsClickable).then(function() {
		//	expect(true).toBe(true);
		//	browser.sleep(1000);
		//});
	});
/* this step is removed since ui changed
	it ('Complete profile successfully', function() {

		browser.sleep(2000);
		browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();

		element(by.css('input[value="male"]')).click();
		AccountDetailPage.userTitle(1);

		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));

		if (configFile.SPASS_TYPE) {
				spassID.click();
		}
		else {
			passportID.click();
		}

		var randomID = Utility.autoGenerateMobile(12, 8);
		AccountDetailPage.identificationNumber.sendKeys(randomID);
		AccountDetailPage.completeProfile.click();

		browser.sleep(15000);

		if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
	      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
	      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
	      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
	      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
	      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
	    }
		AccountDetailPage.sameAddressBox.click();
		AccountDetailPage.updateAddress.click();

		var changeEmailLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeEmailLink);
		var uploadImageProfile = element(by.css('div.wrapper div.profile-image'));
		var uploadImageProfileIsVisibility = EC.visibilityOf(uploadImageProfile);

		browser.wait(uploadImageProfileIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Click upload profile image then popup is displayed', function() {

		var uploadProfileImagePopup = element(by.css('div.ngdialog-content'));
		var uploadProfileImagePopupIsVisibility = EC.visibilityOf(uploadProfileImagePopup);
		var uploadImageProfile = element(by.css('div.wrapper div.profile-image'));

		browser.sleep(2000);
		uploadImageProfile.click();
		browser.wait(uploadProfileImagePopupIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});
*/
	it ('Upload image with size > 8 MB', function() {

		var inputFile = element(by.css('input[type="file"]'));
		//var maximumSizeMessage = element(by.cssContainingText('p.ng-binding', 'less than 8 MB in size'));
		var maximumSizeMessage = element(by.css('div.msg-block__content'));
		var maximumSizeMessageIsVisibility = EC.visibilityOf(maximumSizeMessage);

		var bigSizeImage = './KYC_Image/bigsize.png';
		var bigSizeImagePath = path.resolve(__dirname, bigSizeImage);

		inputFile.sendKeys(bigSizeImagePath);
		browser.wait(maximumSizeMessageIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Upload image successfully', function() {

		//var saveBtn = element(by.css('button.button-primary--medium'));
		var saveBtn = element(by.css('button[ng-click="updateImages(uploader.flow.files)"]'));
		var saveBtnIsVisibility = EC.visibilityOf(saveBtn);
		var inputFile = element(by.css('input[type="file"]'));

		var uploadProfileImagePopup = element(by.css('div.ngdialog-content'));
		var uploadProfileImagePopupIsInvisibility = EC.invisibilityOf(uploadProfileImagePopup);

		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);

		inputFile.sendKeys(image1Path);
		browser.wait(saveBtnIsVisibility).then(function() {
			saveBtn.click();
			browser.wait(uploadProfileImagePopupIsInvisibility).then(function() {
				browser.sleep(1000);
				expect(true).toBe(true);
			});
		});
	});

	it ('Change profile image successfully', function() {

		browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
		var uploadProfileImagePopup = element(by.css('div.ngdialog-content'));
		var uploadProfileImagePopupIsVisibility = EC.visibilityOf(uploadProfileImagePopup);
		var uploadImageProfile = element(by.css('div.wrapper div.profile-image'));
		var uploadImageProfile = element.all(by.css('div.profile-image')).first();
		//var saveBtn = element(by.css('button.button-primary--medium'));
		var saveBtn = element(by.css('button[ng-click="updateImages(uploader.flow.files)"]'));
		var saveBtnIsVisibility = EC.visibilityOf(saveBtn);
		var inputFile = element(by.css('input[type="file"]'));
		var uploadProfileImagePopupIsInvisibility = EC.invisibilityOf(uploadProfileImagePopup);

		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);

		browser.sleep(3000);
		uploadImageProfile.click();
		browser.wait(uploadProfileImagePopupIsVisibility).then(function() {
			browser.sleep(2000);
			inputFile.sendKeys(image2Path);
			browser.wait(saveBtnIsVisibility).then(function() {
				saveBtn.click();
				browser.wait(uploadProfileImagePopupIsInvisibility).then(function() {
					browser.sleep(3000);
					expect(true).toBe(true);
				});
			});
		});
	});

});
