'use strict';

var VerifyMobile = function() {
  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));

  //verify mobile popup
  this.verifymobilemainPopup = element(by.css('.ngdialog-content'));
  this.verifymobileimage = element(by.css('.ngdialog-content img'));
  this.verifymobiledescription = element(by.css('.notification-popup-description'));
  this.verifymobilebutton = element(by.css('.ngdialog-content button[ng-click="openOtp()"]'));
  this.verifymobilepopupClose = element(by.css('.btnClose'));

  //otp popup
  this.otpHeader = element(by.id('ngdialog2-aria-labelledby'));
  this.otpImage = element(by.css('.section-icon img'));
  this.otpDescription = element(by.css('.section-content'));
  this.otpField = element(by.model('verification.otp'));
  this.otpResend = element(by.css('a[ng-click="resendToken()"]'));
  this.otpVerifybutton = element(by.css('form.form__centered div.action button'));

  this.otpsuccess = element(by.css('success-banner'));


  this.otpMobileDisplay = function(mob){
	  this.otpDescription.getText().then(function(text){
		var mobile = text.substr(26, 10);
		 expect(mobile).toEqual(mob);
	  });
  }

   this.getOTPMessage = function(){
	  return this.otpMessage.getText().then(function(text){
		var otp = text.substr(49, 6);
		return otp;
	  });
  }

  this.clickVerifyMobile = function(){
	this.verifymobilebutton.click();
	browser.sleep(10000);
  }

  this.processOTP = function(otp){
	this.otpField.sendKeys(otp);
	//this.otpVerifybutton.click();
	//browser.sleep(10000);
  }



};

module.exports = new VerifyMobile();
