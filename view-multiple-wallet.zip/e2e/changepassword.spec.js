'use strict';

describe('Change Password', function () {
  //var VerifyEmailPage = require('./verifyemail.po');
  var LoginPage = require('./login.po');
  var SignUpPage = require('./signup.po');
  var AccountDetailPage = require('./accountdetails.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var DashboardPage = require('./dashboard.po.js');
  var ChangePasswordPage = require('./changepassword.po');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('./waitReady.js');


  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('Sign up New user', function() {

	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(20000);
	browser.sleep(10000);
  browser.sleep(10000);
});


  it('verify successful update of personal info', function() {

	browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
	browser.sleep(2000);
	AccountDetailPage.genderDropdown(1);
	AccountDetailPage.userTitle(1);

	//AccountDetailPage.conuntryOfissue.$('[label="Singapore"]').click();
	AccountDetailPage.identityInfo(2);
	AccountDetailPage.identificationNumber.sendKeys(Utility.randomIdentityNumberGenerator('11'));
	//AccountDetailPage.birthday.clear();
	//AccountDetailPage.accountTabs.click();
        //AccountDetailPage.birthday.click();
	AccountDetailPage.birthday.sendKeys('1975-01-10');
	AccountDetailPage.completeProfile.click();
	//browser.sleep(2000);
	expect(AccountDetailPage.address1B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.nricError.isPresent()).toBe(false);
	AccountDetailPage.adressTab.click();
	browser.sleep(2000);

  });


  it('update Address', function() {

	AccountDetailPage.address1R.sendKeys('Telok');
	AccountDetailPage.address2R.sendKeys('Ayer');
	AccountDetailPage.postalR.sendKeys('321507');
  if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
    AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
  }
  if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
    AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
  }
	AccountDetailPage.sameAddressBox.click();

  expect(AccountDetailPage.updateAddress.isEnabled()).toBe(true);
  AccountDetailPage.updateAddress.click();
  browser.sleep(5000);

  });

  it('enter invalid values', function() {

    browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
  	browser.sleep(5000);

    ChangePasswordPage.editpassword.click();
    ChangePasswordPage.passField.sendKeys('mmg123456');
    expect(ChangePasswordPage.submitButton.isEnabled()).toBe(false);

    //ChangePasswordPage.passField.clear().sendKeys('Mmg@123456');
    //expect(ChangePasswordPage.submitButton.isEnabled()).toBe(false);

    ChangePasswordPage.passField.clear().sendKeys('mmmm');
    expect(ChangePasswordPage.submitButton.isEnabled()).toBe(false);

    ChangePasswordPage.passField.clear().sendKeys('skdjfiieiowijoijdowkalksmapsomapowjrjwp3map4928');
    expect(ChangePasswordPage.submitButton.isEnabled()).toBe(false);

  });

  it('Change password', function() {

    browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
  	browser.sleep(5000);
    ChangePasswordPage.editpassword.click();

    ChangePasswordPage.passField.sendKeys(configFile.RECOVER_PASSWORD_PAGE.newPassword);
    expect(ChangePasswordPage.submitButton.isEnabled()).toBe(true);

    ChangePasswordPage.submitButton.click();
    browser.sleep(3000);
    //expect(ChangePasswordPage.sucessChangeMessage.isDisplayed()).toBe(true);
    browser.sleep(5000);

  });

  it('verify in notification page', function() {

    browser.get(configFile.HTTP_HOST + configFile.NOTIFICATION_PAGE.redirectionUrl);
    browser.sleep(5000);

    expect(ChangePasswordPage.notificationRow.isDisplayed()).toBe(true);

  });

  it('Log out and login with the new password', function() {

    DashboardPage.logoutLink.isPresent().then(function(result){
  		if(result){
  			DashboardPage.logoutToApp();
  			browser.sleep(5000);
        browser.sleep(5000);
        browser.sleep(5000);
  		}
  	});

    browser.sleep(5000);
    if (configFile.VERIFY_EMAIL_ENABLE) {
    LoginPage.loginProcess(newEmailSignup, configFile.RECOVER_PASSWORD_PAGE.newPassword);
    }else{
    LoginPage.loginProcess(newMobileSignup, configFile.RECOVER_PASSWORD_PAGE.newPassword);
    }
    browser.sleep(10000);
    expect(DashboardPage.menu().isPresent()).toBe(true);

  });


});
