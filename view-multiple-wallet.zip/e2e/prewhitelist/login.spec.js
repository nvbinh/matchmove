'use strict';

describe('The Login Page', function () {
  var LoginPage;
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var DashboardPage = require('../dashboard.po.js');

  beforeEach(function () {
    browser.get(configFile.HTTP_HOST);
    LoginPage = require('../login.po');
	Utility.setScreenSize();
    browser.sleep(2000);
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });

  it('should have all the elements on the page', function() {
    expect(LoginPage.bannerImg.isPresent()).toBe(true);
    //expect(LoginPage.pageTitle.isPresent()).toBe(true);
    //expect(LoginPage.pageMsg.isPresent()).toBe(true);
    expect(LoginPage.emailInput.isPresent()).toBe(true);
    expect(LoginPage.pwdInput.isPresent()).toBe(true);
    expect(LoginPage.submitBtn.isPresent()).toBe(true);
    expect(LoginPage.signupBtn.isPresent()).toBe(true);
    expect(LoginPage.helpBtn.isPresent()).toBe(true);
	//expect(LoginPage.errorBanner.isDisplayed()).toBe(false);
  });
/*
  it('The intial state of the elements must be reset', function() {
      expect(LoginPage.emailInput.getText()).toEqual('');
      expect(LoginPage.pwdInput.getText()).toEqual('');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);
  });

  it('The input values should be correctly reflected', function() {
      LoginPage.setEmail('Jane Doe');
	  LoginPage.emailInput.getAttribute('value').then(function (value) {
	  expect(value).toEqual('Jane Doe')});

      LoginPage.setPassword('Jane Doe');
	  LoginPage.pwdInput.getAttribute('value').then(function (value) {
	  expect(value).toEqual('Jane Doe')});
  });

  it('The Login button should be disabled for invalid email', function() {
      LoginPage.setPassword('mmg123456');

      LoginPage.setEmail('plainaddress');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('#@%^%#$@#$@#.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('Joe Smith <email@domain.com>');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email.domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email@domain@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email@domain@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email.@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('あいうえお@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email@domain.com (Joe Smith)');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email@domain');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setEmail('email@-domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(false);

  });

  it('The Login button should be enabled for valid email', function() {
      LoginPage.setPassword('mmg123456');

      LoginPage.setEmail('email@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('firstname.lastname@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('email@subdomain.domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('firstname+lastname@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('email@123.123.123.123');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('1234567890@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('_______@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('email@domain.name');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('email@domain.co.jp');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setEmail('firstname-lastname@domain.com');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);
  });

  it('The Login button should switch state based on client side validity of password', function() {
      LoginPage.setEmail('email@domain.com');

      LoginPage.setPassword('mmg123456');
      expect(LoginPage.submitBtn.isEnabled()).toBe(true);

      LoginPage.setPassword('               ');
      //expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setPassword('213123  ');
      //expect(LoginPage.submitBtn.isEnabled()).toBe(false);

      LoginPage.setPassword('  213123');
      //expect(LoginPage.submitBtn.isEnabled()).toBe(false);
    });

	it('The message box directive should be triggered on wrong email', function() {
        LoginPage.setEmail('testingemail@domain.com');

        LoginPage.setPassword('mmg123456');
        expect(LoginPage.submitBtn.isEnabled()).toBe(true);

        LoginPage.submitBtn.click();

        expect(LoginPage.errorBanner.isPresent()).toBe(true);

    });
*/
	it('should Login successfully', function() {
	if(configFile.SIGNUP_PAGE.emailRequired == "true"){
        LoginPage.setEmail(configFile.EXISTING_EMAIL);
	}else{
	LoginPage.setEmail(83774627);
	}


        LoginPage.setPassword(configFile.VCARD_PASSWORD);
        expect(LoginPage.submitBtn.isEnabled()).toBe(true);

        LoginPage.submitBtn.click();
		browser.sleep(15000);
/*
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});
*/
	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			//DashboardPage.logoutToApp();
			//browser.sleep(5000);
			expect(true).toBe(true);
		}
	});


    });

});
