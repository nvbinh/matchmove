'use strict';

describe('The Sign Up Page', function () {
  var SignUpPage;
  //var RandomEmail = require('./utilities.po');
  var LoginPage = require('../login.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');

  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);

  beforeEach(function () {
    Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should have all the elements on the page', function() {
    browser.sleep(5000);
    expect(SignUpPage.bannerImg.isPresent()).toBe(true);
if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    	expect(SignUpPage.emailInput.isPresent()).toBe(true);
    }
    //expect(SignUpPage.emailInput.isPresent()).toBe(true);
    expect(SignUpPage.firstNameInput.isPresent()).toBe(true);
    expect(SignUpPage.lastNameInput.isPresent()).toBe(true);
	  expect(SignUpPage.preferredNameInput.isPresent()).toBe(true);
	  expect(SignUpPage.mobileInput.isPresent()).toBe(true);
    expect(SignUpPage.pwdInput.isPresent()).toBe(true);
    expect(SignUpPage.submitBtn.isPresent()).toBe(true);
    expect(SignUpPage.loginBtn.isPresent()).toBe(true);
    expect(SignUpPage.helpBtn.isPresent()).toBe(true);

	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
       expect(SignUpPage.tncCheckbox.isPresent()).toBe(true);
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
      expect(SignUpPage.nationality.isPresent()).toBe(true);
    }

  });

 it('The intial state of the elements must be reset', function() {

    //expect(SignUpPage.emailInput.getText()).toEqual('');
    if(configFile.SIGNUP_PAGE.emailRequired == "true"){
     expect(SignUpPage.emailInput.getText()).toEqual('');
    }
	  expect(SignUpPage.firstNameInput.getText()).toEqual('');
    expect(SignUpPage.lastNameInput.getText()).toEqual('');
	  expect(SignUpPage.preferredNameInput.getText()).toEqual('');
	  expect(SignUpPage.mobileInput.getText()).toEqual('');
    expect(SignUpPage.pwdInput.getText()).toEqual('');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		    expect(SignUpPage.tncCheckbox.isSelected()).toBe(false);
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
        expect(SignUpPage.nationality.$('option:checked').getText()).toEqual(configFile.SIGNUP_PAGE.nationalityDefault);
    }

  });

  it('The input values should be correctly reflected', function() {
    if(configFile.SIGNUP_PAGE.emailRequired == "true"){
      SignUpPage.emailInput.sendKeys(newEmailSignup);
      SignUpPage.emailInput.getAttribute('value').then(function (value) {
      expect(value).toEqual(newEmailSignup)});
    }
    //SignUpPage.emailInput.sendKeys(newEmailSignup);
    //SignUpPage.emailInput.getAttribute('value').then(function (value) {
    //expect(value).toEqual(newEmailSignup)});

	  SignUpPage.firstNameInput.sendKeys('Jane');
    SignUpPage.firstNameInput.getAttribute('value').then(function (value) {
    expect(value).toEqual('Jane')});

	  SignUpPage.lastNameInput.sendKeys('Doe');
    SignUpPage.lastNameInput.getAttribute('value').then(function (value) {
    expect(value).toEqual('Doe')});

	  SignUpPage.preferredNameInput.sendKeys('Doe');
    SignUpPage.preferredNameInput.getAttribute('value').then(function (value) {
    expect(value).toEqual('Doe')});

	  SignUpPage.mobileInput.sendKeys(configFile.MOBILE_NUMBER_SAMPLE.input);
    SignUpPage.mobileInput.getAttribute('value').then(function (value) {
	  expect(value).toEqual(configFile.MOBILE_NUMBER_SAMPLE.expected)});

    SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
    SignUpPage.pwdInput.getAttribute('value').then(function (value) {
    expect(value).toEqual(configFile.VCARD_PASSWORD)});

    if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		    expect(SignUpPage.tncCheckbox.isSelected()).toBe(false);
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
        expect(SignUpPage.nationality.$('option:checked').getText()).toEqual(configFile.SIGNUP_PAGE.nationalityDefault);
    }
  });


  it('The Create Wallet button should be disabled for invalid values', function() {

       if(configFile.SIGNUP_PAGE.emailRequired == "true"){

	SignUpPage.pwdInput.clear().sendKeys(configFile.VCARD_PASSWORD);
	  SignUpPage.firstNameInput.clear().sendKeys('Jane');
	  SignUpPage.lastNameInput.clear().sendKeys('Doe');
	  SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
	  SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');

	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		  SignUpPage.tncCheckbox.click();
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
      SignUpPage.nationality.$('[value="Indian"]').click();
    }

    SignUpPage.emailInput.sendKeys('#@%^%#$@#$@#.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('Joe Smith <email@domain.com>');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email.domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email@domain@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email@domain@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email.@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('あいうえお@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email@domain.com (Joe Smith)');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email@domain');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.emailInput.clear().sendKeys('email@-domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

  }

  });

  it('The Create Wallet button should be enabled for valid email', function() {

    if(configFile.SIGNUP_PAGE.emailRequired == "true"){

    SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
	  SignUpPage.firstNameInput.clear().sendKeys('Jane');
	  SignUpPage.lastNameInput.clear().sendKeys('Doe');
	  SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
	  SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');
	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		    SignUpPage.tncCheckbox.click();
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
      SignUpPage.nationality.$('[value="Indian"]').click();
    }

    SignUpPage.emailInput.clear().sendKeys('email@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('firstname.lastname@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('email@subdomain.domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('firstname+lastname@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('email@123.123.123.123');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('1234567890@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('email@domain-one.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('_______@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('email@domain.name');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('email@domain.co.jp');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.emailInput.clear().sendKeys('firstname-lastname@domain.com');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

  }
  });

  it('The Create Wallet button should switch state based on client side validity of password', function() {
    if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    	SignUpPage.emailInput.clear().sendKeys(newEmailSignup);
    }
	  SignUpPage.firstNameInput.clear().sendKeys('Jane');
	  SignUpPage.lastNameInput.clear().sendKeys('Doe');
	  SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
	  SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');
	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		  SignUpPage.tncCheckbox.click();
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
      SignUpPage.nationality.$('[value="Indian"]').click();
    }


    SignUpPage.pwdInput.clear().sendKeys(configFile.VCARD_PASSWORD);
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.pwdInput.clear().sendKeys('               ');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.pwdInput.clear().sendKeys('213123  ');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    SignUpPage.pwdInput.clear().sendKeys('  213123');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.pwdInput.clear().sendKeys('  asdsa  ');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.pwdInput.clear().sendKeys('  23asdsa  ');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.pwdInput.clear().sendKeys('  23@sdsa  ');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.pwdInput.clear().sendKeys('  23Asdsa  ');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

  });


  it('The Create Wallet button should switch state based on client side validity of first/last name', function() {
    SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
	 if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    	SignUpPage.emailInput.clear().sendKeys(newEmailSignup);
    }
	  SignUpPage.lastNameInput.clear().sendKeys('Doe');
	  SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
	  SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');
	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		  SignUpPage.tncCheckbox.click();
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
      SignUpPage.nationality.$('[value="Indian"]').click();
    }

    SignUpPage.firstNameInput.clear().sendKeys('Jane');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

    SignUpPage.firstNameInput.clear().sendKeys('Jane4');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.firstNameInput.clear().sendKeys('Jane');
	  expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

	  SignUpPage.lastNameInput.clear().sendKeys('Doe2');
	  expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.lastNameInput.clear().sendKeys('');
	  expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.lastNameInput.clear().sendKeys('Doe');
	  SignUpPage.firstNameInput.clear().sendKeys('');
	  expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

  });


  it('The Create Wallet button should switch state based on client side validity of mobile number', function() {

	  SignUpPage.pwdInput.clear().sendKeys(configFile.VCARD_PASSWORD);
	  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    	SignUpPage.emailInput.clear().sendKeys(newEmailSignup);
          }
	  SignUpPage.firstNameInput.clear().sendKeys('Jane');
	  SignUpPage.lastNameInput.clear().sendKeys('Doe');
	  SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');
	  if(configFile.SIGNUP_PAGE.tncEnabled == "true"){
		  SignUpPage.tncCheckbox.click();
	  }

    if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
      SignUpPage.nationality.$('[value="Indian"]').click();
    }

    SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

	  SignUpPage.mobileInput.clear().sendKeys(newMobileSignup+'33');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

	  SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);

	  SignUpPage.mobileInput.clear().sendKeys('532');
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

  });

    it('The Create Wallet button should switch state based on client side validity in checking terms and condition', function() {
		if(configFile.SIGNUP_PAGE.tncEnabled == "true"){

			SignUpPage.pwdInput.clear().sendKeys(configFile.VCARD_PASSWORD);
			if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    			SignUpPage.emailInput.clear().sendKeys(newEmailSignup);
    			}
			SignUpPage.firstNameInput.clear().sendKeys('Jane');
			SignUpPage.lastNameInput.clear().sendKeys('Doe');
			SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');
			SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);

      if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){
        SignUpPage.nationality.$('[value="Indian"]').click();
      }

			SignUpPage.tncCheckbox.click();

			expect(SignUpPage.submitBtn.isEnabled()).toBe(true);
			expect(SignUpPage.tncCheckbox.isSelected()).toBe(true);

			browser.sleep(2000);
			SignUpPage.tncCheckbox.click();

			expect(SignUpPage.submitBtn.isEnabled()).toBe(false);
			expect(SignUpPage.tncCheckbox.isSelected()).toBe(false);
		}

  });

  it('The Create Wallet button should be disabled when nationality not selected', function() {
  if(configFile.SIGNUP_PAGE.nationalityEnabled == "true"){

    SignUpPage.pwdInput.clear().sendKeys(configFile.VCARD_PASSWORD);
    if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    			SignUpPage.emailInput.clear().sendKeys(newEmailSignup);
    			}
    SignUpPage.firstNameInput.clear().sendKeys('Jane');
    SignUpPage.lastNameInput.clear().sendKeys('Doe');
    SignUpPage.preferredNameInput.clear().sendKeys('Jane Doe');
    SignUpPage.mobileInput.clear().sendKeys(newMobileSignup);
    SignUpPage.tncCheckbox.click();
    expect(SignUpPage.submitBtn.isEnabled()).toBe(false);

    browser.sleep(2000);
    SignUpPage.nationality.$('[value="Indian"]').click();
    expect(SignUpPage.submitBtn.isEnabled()).toBe(true);
  }

  });

});
