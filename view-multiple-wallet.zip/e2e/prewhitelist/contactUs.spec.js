"use strict";
var configFile = require('../e2e.json'); //
var LoginPage = require('../login.po');
var Utility = require('../utilities.po.js');
var DashboardPage = require('../dashboard.po');

describe ('Contact Us', function() {

		describe ('Is displayed', function() {

			it('setup test specs', function(){
				//removed logged in
				Utility.setScreenSize();
				browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
				browser.sleep(5000);
				DashboardPage.popupNOtification.isPresent().then(function(result){
					if(result){
						DashboardPage.popupNOtification.click();
					}
				});

				DashboardPage.logoutLink.isPresent().then(function(result){
					if(result){
					DashboardPage.logoutToApp();
					browser.sleep(5000);
					}
				});
				expect(true).toBe(true);
  			});

			it ('Should load login page', function() {
				browser.get(configFile.HTTP_HOST);
				browser.sleep(10000);
				browser.getCurrentUrl().then(function(url) {
				expect(url).toEqual(configFile.loginUrl);
				});
			});

			it ('Contact Us icon is displayed', function() {
				expect(LoginPage.contactUs().isPresent()).toBe(true);
			});
		});

		describe ('Guest', function() {

			var HelpPopUp;

			beforeEach(function() {
					browser.get(configFile.HTTP_HOST);
					HelpPopUp = LoginPage.openContactUs();
			});

			describe ('Email Address field validation', function() {

				it ('Contact Us popup is opened', function() {
					browser.sleep(500);
					expect(HelpPopUp.contactUsPopup().isPresent()).toBe(true);
				});

				it ('Support Request Email field is exist', function() {
					browser.sleep(500);
					expect(HelpPopUp.supportRequestEmail().isPresent()).toBe(true);
				});

				it ('Support Request Email field is blank', function() {
					browser.sleep(500);
					expect(HelpPopUp.supportRequestEmail().getAttribute('value')).toEqual('');
				});

				it ('Email is required', function() {
					HelpPopUp.supportRequestEmail().sendKeys('test');
					HelpPopUp.supportRequestEmail().clear();
					expect(HelpPopUp.emailRequireMessage().isPresent()).toBe(true);
				});

				it ('Email Address should be at least 5 characters', function() {
					HelpPopUp.supportRequestEmail().sendKeys('a@c');
					expect(HelpPopUp.emailMinlengthMessage().isPresent()).toBe(true);
				});

				it ('Email Address should be at max 50 characters', function() {
					HelpPopUp.supportRequestEmail().clear();
					HelpPopUp.supportRequestEmail().sendKeys('testerloc12345627ddddd2dsdsdff2536377@matchmove.com');
					expect(HelpPopUp.emailMaxlengthMessage().isPresent()).toBe(true);
				});

				it ('Email Address entered is invalid', function() {
					HelpPopUp.supportRequestEmail().clear();
					HelpPopUp.supportRequestEmail().sendKeys('testmail@');
					expect(HelpPopUp.emailInvalidMessage().isPresent()).toBe(true);
				});
			});

			describe ('Name field validation', function() {

				it ('Name field is exist', function() {
					expect(HelpPopUp.nameFields().isPresent()).toBe(true);
				});

				it ('Name is required', function() {
					HelpPopUp.nameFields().sendKeys('test');
					HelpPopUp.nameFields().clear();
					expect(HelpPopUp.nameRequireMessage().isPresent()).toBe(true);
				});

				it ('Name should be at least two characters long', function() {
					HelpPopUp.nameFields().sendKeys('a');
					expect(HelpPopUp.nameMinLengthMessage().isPresent()).toBe(true);
				});

				it ('Name should be less than 50 characters', function() {
					HelpPopUp.nameFields().clear();
					HelpPopUp.nameFields().sendKeys('more than 50 characters in this field blad blad blad blad blad');
					expect(HelpPopUp.nameMaxLengthMessage().isPresent()).toBe(true);
				});

			});

			describe ('Message validation', function() {

				it ('Massage field is exist', function() {
					expect(HelpPopUp.supportMessage().isPresent()).toBe(true);
				});

				it ('Massage is required', function() {
					HelpPopUp.supportMessage().sendKeys('abs');
					HelpPopUp.supportMessage().clear();
					expect(HelpPopUp.supportMessageRequire().isPresent()).toBe(true);
				});

				it ('The message should be atleast 10 characters long', function() {
					HelpPopUp.supportMessage().sendKeys('abcdefghi');
					expect(HelpPopUp.supportMessageMinLength().isPresent()).toBe(true);
				});

				it ('The message should be max 1000 characters', function() {
					HelpPopUp.supportMessage().sendKeys(configFile.longchars);
					expect(HelpPopUp.supportMessageMaxLength().isPresent()).toBe(true);
				});
			});


			describe ('SEND REQUEST button validation', function() {

				it ('Button is disabled when valid email - blank name - blank Message', function() {
					HelpPopUp.supportRequestEmail().sendKeys('autotester@matchmove.com');
					expect(HelpPopUp.sendRequestButton().isEnabled()).toBe(false);
				});

				it ('Button is disabled when valid email - valid name - blank Message', function() {
					HelpPopUp.supportRequestEmail().sendKeys('autotester@matchmove.com');
					HelpPopUp.nameFields().sendKeys('auto tester');
					expect(HelpPopUp.sendRequestButton().isEnabled()).toBe(false);
				});

				it ('Button is disabled when valid email - blank name - valid message', function() {
					HelpPopUp.supportRequestEmail().sendKeys('autotester@matchmove.com');
					HelpPopUp.supportMessage().sendKeys('I am doing automation');
					expect(HelpPopUp.sendRequestButton().isEnabled()).toBe(false);
				});

				it ('Button is disabled when blank email - valid name - valid message', function() {
					HelpPopUp.nameFields().sendKeys('auto tester');
					HelpPopUp.supportMessage().sendKeys('I am doing automation');
					expect(HelpPopUp.sendRequestButton().isEnabled()).toBe(false);
				});

				it ('Button is enabled when valid email - valid name - valid message', function() {
					HelpPopUp.supportRequestEmail().sendKeys('autotester@matchmove.com');
					HelpPopUp.nameFields().sendKeys('auto tester');
					HelpPopUp.supportMessage().sendKeys('I am doing automation');
					expect(HelpPopUp.sendRequestButton().isEnabled()).toBe(true);
				});

				it ('Send feedback successfully', function() {
					HelpPopUp.supportRequestEmail().sendKeys('autotester@matchmove.com');
					HelpPopUp.nameFields().sendKeys('auto tester');
					HelpPopUp.supportMessage().sendKeys('I am doing automation');
					HelpPopUp.sendRequestButton().click();
					browser.sleep(5000);
					expect(HelpPopUp.sendRequestSuccess().isPresent()).toBe(true);
				});
			});
		});


		describe ('User', function() {

			var DashboardPage;

			describe ('Exist user', function() {

				it ('Contact Us icon is displayed after login', function() {
					browser.ignoreSynchronization = true;
					jasmine.DEFAULT_TIMEOUT_INTERVAL = 30000;
					browser.get(configFile.HTTP_HOST);
					browser.sleep(5000);
					if(configFile.SIGNUP_PAGE.emailRequired == "true"){
						LoginPage.emailInput.sendKeys(configFile.existingUser.email);
					}else {
						LoginPage.emailInput.sendKeys(configFile.existingUser.mobile);
					}
					LoginPage.password().sendKeys(configFile.existingUser.password);
					var EC = protractor.ExpectedConditions;
					DashboardPage = LoginPage.clickLoginButton();
					browser.wait(EC.visibilityOf(DashboardPage.balanceBar()));
					expect(DashboardPage.contactUs().isPresent()).toBe(true);
				});
			});



			describe ('Message validation', function() {

				var HelpPopUp;

				beforeEach(function() {
					var EC = protractor.ExpectedConditions;
					browser.refresh();
					browser.wait(EC.visibilityOf(DashboardPage.balanceBar()));
					HelpPopUp = DashboardPage.openContactUs();
				});

				it ('Contact Us popup is opened', function() {
					expect(HelpPopUp.contactUsPopup().isPresent()).toBe(true);
					browser.sleep(500);
				});

				it ('Message field is present', function() {
					expect(HelpPopUp.supportMessage().isPresent()).toBe(true);
					browser.sleep(500);
				});

				it ('Message is required', function() {
					HelpPopUp.supportMessage().sendKeys('abs');
					HelpPopUp.supportMessage().clear();
					expect(HelpPopUp.supportMessageRequire().isPresent()).toBe(true);
				});

				it ('The message should be atleast 10 characters long', function() {
					HelpPopUp.supportMessage().sendKeys('abcdefghi');
					expect(HelpPopUp.supportMessageMinLength().isPresent()).toBe(true);
				});

				it ('The message should be max 1000 characters', function() {
					HelpPopUp.supportMessage().sendKeys(configFile.longchars);
					expect(HelpPopUp.supportMessageMaxLength().isPresent()).toBe(true);
				});

				it ('Send button is enabled when message is valid', function() {
					HelpPopUp.supportMessage().sendKeys('I am doing automation');
					expect(HelpPopUp.sendRequestButton().isEnabled()).toBe(true);
				});

				it ('Send message successfully', function() {
					HelpPopUp.supportMessage().sendKeys('I am doing automation');
					HelpPopUp.sendRequestButton().click();
					browser.sleep(5000);
					expect(HelpPopUp.sendRequestSuccess().isPresent()).toBe(true);
				});

			});

		});
});
