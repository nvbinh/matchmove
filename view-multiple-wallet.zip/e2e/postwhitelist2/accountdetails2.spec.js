'use strict';

describe('Account Detail page', function () {
  var VerifyEmailPage = require('../verifyemail.po');
  var LoginPage = require('../login.po');
  var ChangePasswordPage = require('../changepassword.po');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var AccountDetailPage =require('../accountdetails.po');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  var full_name = configFile.ACCOUNT_INFO.FIRST_NAME + " " + configFile.ACCOUNT_INFO.LAST_NAME;
  var mobileNumVerify = configFile.MOBILE_NUMBER_AREA_CODE + " " + newMobileSignup;
  require('../waitReady.js');


  beforeEach(function () {
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });

  it('should verify the popup for email verification is displayed', function() {

	Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(25000);
  browser.sleep(10000);

/*////////////////////////////////////////////////////////////////////////////
	expect(VerifyEmailPage.verifyEmailmainPopup.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailimage.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmaildescription.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailbutton.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailpopupClose.isPresent()).toBe(true);
//////////////////////////////////////////////////////////////////////////*/
  });


  it('verify account information in account details', function(){
    browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);

    AccountDetailPage.verifyAccountInfo(full_name, mobileNumVerify, newEmailSignup, configFile.ACCOUNTS_PAGE.mobileLen);

  });

  it('complete personal info and addresses', function(){
    AccountDetailPage.completePersonalInfo(Utility.randomIdentityNumberGenerator('AB'));
    AccountDetailPage.completeResidentialAddressInfo();
    AccountDetailPage.completeBillingAddressInfo();
    browser.sleep(10000);
  });

  it('verify all inforamtion was saved correctly', function(){

    AccountDetailPage.verifyPersonalInfo(configFile.ACCOUNTS_PAGE.personalInfovalues.title, configFile.ACCOUNTS_PAGE.personalInfovalues.gender, configFile.ACCOUNTS_PAGE.personalInfovalues.dateOfBirth, configFile.ACCOUNTS_PAGE.personalInfovalues.country);
    AccountDetailPage.adressTab.click();
    browser.sleep(5000);
    AccountDetailPage.verifyResidentialInfo(configFile.ACCOUNTS_PAGE.residentialValues.address_1, configFile.ACCOUNTS_PAGE.residentialValues.address_2, configFile.ACCOUNTS_PAGE.residentialValues.city, configFile.ACCOUNTS_PAGE.residentialValues.state, configFile.ACCOUNTS_PAGE.residentialValues.postalCode, configFile.ACCOUNTS_PAGE.residentialValues.country);
    AccountDetailPage.verifyBillingInfo(configFile.ACCOUNTS_PAGE.billingValues.address_1, configFile.ACCOUNTS_PAGE.billingValues.address_2, configFile.ACCOUNTS_PAGE.billingValues.city, configFile.ACCOUNTS_PAGE.billingValues.state, configFile.ACCOUNTS_PAGE.billingValues.postalCode, configFile.ACCOUNTS_PAGE.billingValues.country);

  });

  it('verify address 1 will accept valid values', function() {

	browser.sleep(5000);
  if (configFile.ACCOUNTS_PAGE.svgINEditAddress == "true")
  {
AccountDetailPage.updateResidentialLink.click();
  }else{
AccountDetailPage.updateResidentialLinksvg.click();
  }

  browser.sleep(5000);

	AccountDetailPage.address1R.clear().sendKeys('Telok');
	AccountDetailPage.address1R.getAttribute('value').then(function (value) {
	expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty address 1', function() {

	AccountDetailPage.address1R.clear();
	expect(AccountDetailPage.address1Rerror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when address 1 is more than prescride number of char', function() {

	AccountDetailPage.address1R.clear().sendKeys('thisaddressmorethanthirtyfi222222');
  //var e = element(by.css('p.help-block.error'));
  //var e = element(by.model('residential.address_1'));
  var EC = protractor.ExpectedConditions;
  EC.invisibilityOf(AccountDetailPage.address1Rerror2);
  //expect(e.isDisplayed()).toBe(false);
  //expect(AccountDetailPage.address1Rerror2.isDisplayed()).toBe(false);
  //expect(element(by.css('p.help-block.error')).getWebElement().isDisplayed()).toBe(false);

  AccountDetailPage.address1R.clear().sendKeys('thisaddressmorethanthirtyfi222222222222222222');
  var EC = protractor.ExpectedConditions;
  EC.visibilityOf(AccountDetailPage.address1Rerror2);

  });

  it('verify address 2 will accept valid values', function() {

	AccountDetailPage.address2R.clear().sendKeys('Telok');
	AccountDetailPage.address2R.getAttribute('value').then(function (value) {
	expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty address 2', function() {

	AccountDetailPage.address2R.clear();
	expect(AccountDetailPage.address2Rerror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when address 2 is more than prescride number of char', function() {

	AccountDetailPage.address2R.clear().sendKeys('thisaddressmorethanthirtyfi222222');
  var EC = protractor.ExpectedConditions;
  EC.invisibilityOf(AccountDetailPage.address2Rerror2);
	//expect(AccountDetailPage.address2Rerror2.isDisplayed()).toBe(false);

  AccountDetailPage.address2R.clear().sendKeys('thisaddressmorethanthirtyfi22222222222222');
  var EC = protractor.ExpectedConditions;
  EC.visibilityOf(AccountDetailPage.address2Rerror2);

  });

  it('verify postal code will accept valid values', function() {

	AccountDetailPage.postalR.clear().sendKeys('358249');
	AccountDetailPage.postalR.getAttribute('value').then(function (value) {
	expect(value).toEqual('358249')});

  });

  it('verify error messeage when postal code has less than prescride number of char', function() {

	AccountDetailPage.postalR.sendKeys('32');
	expect(AccountDetailPage.postalRerror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when postal code has more than prescride number of char', function() {

	AccountDetailPage.postalR.sendKeys('358249090980982373208764');
	expect(AccountDetailPage.postalRerror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when empty postal code', function() {

	AccountDetailPage.postalR.clear();
	expect(AccountDetailPage.postalRerror2.isDisplayed()).toBe(true);

  });


  it('verify successful update of residential address', function() {

    //change
    browser.sleep(2000);
    browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
    browser.sleep(5000);
    AccountDetailPage.adressTab.click();
    browser.sleep(2000);
    AccountDetailPage.changeResidential(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode, configFile.ACCOUNTS_PAGE.changeResidentialValues.city, configFile.ACCOUNTS_PAGE.changeResidentialValues.state);
browser.sleep(5000);
    AccountDetailPage.verifyChangedResidential(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode);

    //verify
  });


  it('verify billing address 1 will accept valid values', function() {
browser.sleep(5000);
    if (configFile.ACCOUNTS_PAGE.svgINEditAddress == "true")
    {
    AccountDetailPage.updateBillingLink.click();
    }else{
    AccountDetailPage.updateBillingLinksvg.click();
    }

  AccountDetailPage.address1B.clear().sendKeys('Telok');
  AccountDetailPage.address1B.getAttribute('value').then(function (value) {
  expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty billing address 1', function() {

  AccountDetailPage.address1B.clear();
  expect(AccountDetailPage.address1Berror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when billing address 1 is more than prescride number of char', function() {

  AccountDetailPage.address1B.sendKeys('thisaddressmorethanthirtyfi222222');
  expect(AccountDetailPage.address1Berror2.isDisplayed()).toBe(true);

  });

  it('verify billing address 2 will accept valid values', function() {

  AccountDetailPage.address2B.clear().sendKeys('Telok');
  AccountDetailPage.address2B.getAttribute('value').then(function (value) {
  expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty billing address 2', function() {

  AccountDetailPage.address2B.clear();
  expect(AccountDetailPage.address2Berror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when billing address 2 is more than prescride number of char', function() {

  AccountDetailPage.address2B.sendKeys('thisaddressmorethanthirtyfi222222');
  expect(AccountDetailPage.address2Berror2.isDisplayed()).toBe(true);

  });

  it('verify billing postal code will accept valid values', function() {

  AccountDetailPage.postalB.clear().sendKeys('358249');
  AccountDetailPage.postalB.getAttribute('value').then(function (value) {
  expect(value).toEqual('358249')});

  });

  it('verify error messeage when billing postal code has less than prescride number of char', function() {

  AccountDetailPage.postalB.sendKeys('32');
  expect(AccountDetailPage.postalBerror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when billing postal code has more than prescride number of char', function() {

  AccountDetailPage.postalB.sendKeys('358249090980982373208764');
  expect(AccountDetailPage.postalBerror2.isDisplayed()).toBe(true);

  });

  it('verify error messeage when empty postal code', function() {

  AccountDetailPage.postalB.clear();
  expect(AccountDetailPage.postalBerror2.isDisplayed()).toBe(true);

  });


  it('verify successful update of billing address', function() {

    //change
    browser.sleep(2000);
    browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
    browser.sleep(5000);
    AccountDetailPage.adressTab.click();
    browser.sleep(2000);
    AccountDetailPage.changeBilling(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode);
browser.sleep(5000);
    AccountDetailPage.verifyChangedBilling(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode);
    //verify
  });

});
