/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var AdminetPage = function() {

  this.emailfield = element(by.css('input[type="email"]'));
  this.passwordfield = element(by.css('input[type="password"]'));
  this.loginButton = element(by.id('js-login-submit'));

  this.cs1SearchBy = element(by.css('select[name="type"]'));
  this.cs1SearchTxt = element(by.css('input[type="text"]'));
  this.cs1SearchBtn = element(by.css('.btn-green'));

  this.firstSearchResult = element(by.css('div.tableHolder--main  table.footable tbody tr'));
  this.unsuspendLink = element(by.css('a[route="/product/users/cards/status/unblock"]'));
  this.cardDetailsLink = element(by.css('.tab__card-details'));
  this.unsuspendButton = element(by.css('.action-button'));
  this.confirmUnsuspend = element(by.id('magnificProductExecute'));
  this.addcommenttoUnsuspend = element(by.css('.comment--area'));
  this.addcommentbutton = element(by.id('magnificProductExecute'));


  //element(by.cssContainingText('.linkTitle', 'CS1'));
  this.menuLink = function (menu){
	  return element(by.cssContainingText('.linkTitle', menu));
  }

  this.logintoAdminet = function(email, passw){
	  //this.emailfield.sendKeys('m');
	  this.emailfield.sendKeys(email);
	  this.passwordfield.sendKeys(passw);
	  this.loginButton.click();
	  browser.sleep(15000);
  }

  this.searchUserinCS1 = function(email, value){
	  this.menuLink('CS1').click();
	  browser.sleep(5000);
	  this.cs1SearchBy.$('[value="'+value+'"]').click();
	  this.cs1SearchTxt.sendKeys(email);
	  this.cs1SearchBtn.click();
	  browser.sleep(10000);
	  browser.executeScript('window.scrollTo(0, 50);');
	  this.firstSearchResult.click();
  	  browser.sleep(5000);
	  this.unsuspendLink.click();
	  browser.sleep(5000);
	  this.cardDetailsLink.click();
	  browser.sleep(10000);
	  this.unsuspendButton.click();
	  browser.sleep(5000);
	  this.confirmUnsuspend.click();
	  browser.sleep(5000);
	  this.addcommenttoUnsuspend.sendKeys('this is a test');
	  this.addcommentbutton.click();
	  browser.sleep(15000);


  }














  this.logintoTelerivet = function(email, passw){
	  this.emailfield.sendKeys('m');
	  this.emailfield.sendKeys(email);
	  this.passwordfield.sendKeys(passw);
	  this.loginButton.click();
	  browser.sleep(5000);
  }

  this.project = element(by.cssContainingText('.nameLink', 'SG MC/Imba UAT'));
  this.messages = element(by.cssContainingText('.menu-item', 'Messages'));
  this.searchMessage = element(by.css('input[type="text"]'));
  this.actionSearch = element(by.css('.action-search'));
  this.otpMessage = element.all(by.css('.messageText'));

  this.otpMessage = element.all(by.css('.messageText')).last();//then(function(items) {


  this.goToOTPMessage = function(mobileNumber){
	  this.project.click();
	  this.messages.click();
	  this.searchMessage.sendKeys(mobileNumber);
	  this.actionSearch.click();
  }

  this.getOTPMessage = function(){
	  return this.otpMessage.getText().then(function(text){
		var otp = text.substr(49, 6);
		return otp;
	  });
  }


  this.cardselectorItemCount = function (num) {
    var dropdown = element.all(by.options('option.name for option in items track by option.id'));
	expect(dropdown.count()).toEqual(num);
  }


  this.transactions = element(by.repeater('transaction in transactions'));

  this.checkOneTransactionVisible = function(){

		element.all(by.repeater('transaction in transactions')).then(function(posts) {
		var itemImage = posts[0].element(by.className('sub-item--image'));
		var itemDesc  = posts[0].element(by.className('sub-item--description'));
		var itemBalance  = posts[0].element(by.className('sub-item--action'));

		expect(itemImage.isDisplayed()).toBe(true);
		expect(itemDesc.isDisplayed()).toBe(true);
		expect(itemBalance.isDisplayed()).toBe(true);
		})
  };


  this.checkOneDetailedTransactionVisible = function(){
	element.all(by.repeater('transaction in transactions')).then(function(posts) {
	try {
		var titleElement = posts[0].element(by.className('transaction-type'));
		expect(titleElement.isDisplayed()).toBe(true);
	}
	catch(er) {
		console.log('error occured: ' + er);
	}


	});
  }

  this.getTransationtype = function(transaction){
	element.all(by.repeater('transaction in transactions')).then(function(posts) {
    var titleElement = posts[0].element(by.className('transaction-type'));
    expect(titleElement.getText()).toEqual(transaction);
	});
  }



  this.openandLogintoTelerivet = function(){
	   var telerivetUsername = 'tester@matchmove.com';
	   var telerivetPassword = 'mmg123456';
	   var telerivetURL = 'https://telerivet.com/u/Q3CUZ6G7C6/projects';

	  browser.actions().sendKeys(protractor.Key.CONTROL +'t').perform().then(function () {
        browser.sleep(3000);
		browser.getAllWindowHandles().then(function (handles) {
            //var newWindowHandle = handles[1]; // this is your new window
            browser.switchTo().window(handles[1]);
			browser.get(telerivetURL);
			browser.sleep(10000);

			this.emailfield = element(by.id('username'));
			this.passwordfield = element(by.id('password'));
			this.loginButton = element(by.css('.btn-submit'));
			browser.sleep(10000);
			//this.logintoTelerivet(telerivetUsername, telerivetPassword);

			this.emailfield.sendKeys(telerivetUsername);
			this.passwordfield.sendKeys(telerivetPassword);
			this.loginButton.click();

        });
	  });
  }



  this.setEmail = function(email){
	  this.emailInput.clear();
	  this.emailInput.sendKeys(email);
  }

  this.setPassword = function(email){
	  this.pwdInput.clear();
	  this.pwdInput.sendKeys(email);
  }

  this.clickLogin = function(email){
	  this.loginBtn.click();
  }

  this.setScreenSize = function(){
	  browser.driver.manage().window().maximize();
	  //browser.manage().window().setSize(640, 1136);
  }

  this.actionMenu = element(by.css('a.abs-trigger'));
  this.KYCsubmissionDetails = element(by.css('a[route="/product/kyc/details"]'));
  this.generateBtn = element(by.css('button.btn-green'));
  this.searchTypeMobile = element(by.css('option[value="Mobile Number"]'));
  this.searchKeyword = element(by.css('input[name="keyword"]'));
  this.f2fVerificationBtn = element(by.css('a[data-show-class=".js-kyc-f2f-rows"]'));
  this.f2fVerificationApprovalBtn = element(by.css('a[data-message="face to face verification approved"]'));
  this.f2fVerificationRejectBtn = element(by.css('a[data-message="face to face verification rejected"]'));
  this.submitYcsBtn = element(by.css('a[data-message="submitted to ycs"]'));
  this.alreadySubmitYCS = element(by.css('a[data-tooltip="This KYC details has been Submitted for OFAC verification already."]'));
  this.requestMoreInfoBtn = element(by.css('a[data-message="information incomplete"]'));
  this.viewCardHolderDetails = element(by.css('a[route="/product/users/details"]'));
  this.userDetailsTab = element(by.css('li.tab__user-details'));

};

module.exports = new AdminetPage();
