/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var VerifyEmailPage = function() {
  
  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));
  
  this.verifyEmailmainPopup = element(by.css('.ngdialog-content'));
  this.verifyEmailimage = element(by.css('.ngdialog-content img'));
  this.verifyEmaildescription = element(by.css('.notification-popup-description'));
  this.verifyEmailbutton = element(by.css('.ngdialog-content button[ng-click="requestEmailVerification()"]'));
  this.verifyEmailpopupClose = element(by.css('.btnClose'));
  
  this.sucessPopup = element(by.css('div[class="modal-sub--status"]'));
  this.sucessPopupImg = element(by.css('section [id="ngdialog2-aria-describedby"]'));
  //this.sucessPopupHeader = element(by.css('h3[id="ngdialog2-aria-labelledby" class="ng-binding"]'));
  this.sucessPopupText = element(by.css('div.section-success h3'));
  this.sucessPopupTextdetail = element(by.css('div.section-success p'));
  
  this.resendEmailNotif = element(by.css('.modal-sub--status message-box[messagetype="success"]'));
  this.resendEmailButton = element(by.css('footer.action button.button-primary--medium'));
  this.resendClosePopup = element(by.css('.btnClose'));
  
  this.verifiedEmailEmail = element(by.model('loggedOutUser.email'));
  this.verifiedEmailPassword = element(by.model('loggedOutUser.password'));
  
  
  this.dashboardCardSection = element(by.css('section.cardContainer'));
  
  this.clickVerifyEmail = function(){
	this.verifyEmailbutton.click();
	browser.sleep(10000);
  }
  
  this.completeEmailVerificationInEmail = function(){
	this.verifyEmailbutton.click();
	browser.sleep(10000);
  }
  
};

module.exports = new VerifyEmailPage();