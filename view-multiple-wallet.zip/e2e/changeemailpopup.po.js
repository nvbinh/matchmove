/**
 * This file uses the Page Object pattern to define change email popup
 */

'use strict';

var ChangeEmailPopup = function() {

  this.changeEmailPopup = element(by.css('.ngdialog-content'));
  this.changeEmailBtn =element(by.css('button.button-primary--large'));
  this.emailInput = element(by.model('email'));
  this.warningMessage = element(by.css('p[ng-show="createForm.email.$invalid && !createForm.email.$pristine"]'));
  this.messageBox = element.all(by.css('message-box[messageicon="mcw-common-alert"]')).first();
  this.sendNotify = element(by.css('section.modal-content'));
};

module.exports = new ChangeEmailPopup();