/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var configFile = require('./e2e.json');

var SignUpPage = function() {

  this.bannerImg = element(by.css('.image__centered img'));
  //this.pageTitle = element(by.css('.marketing__title h1'));
  //this.pageMsg = element(by.css('.marketing__title p'));
  this.emailInput = element(by.model('user.email'));
  this.firstNameInput = element(by.model('user.first_name'));
  this.lastNameInput = element(by.model('user.last_name'));
  this.preferredNameInput = element(by.model('user.preferred_name'));
  this.mobileInput = element(by.model('user.mobile'));
  this.pwdInput = element(by.model('user.password'));
  this.tncCheckbox = element(by.model('user.tnc'));
  this.submitBtn = element(by.css('form .section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.errorBanner = element(by.css('.msg-banner'));
  this.nationality = element(by.model('user.user_type'));

  this.signupSucess = function(emailAdd, fName, lName, pName, mobileNum, passWord, tncEnabled, nationalityEnabled){
	if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    		this.emailInput.sendKeys(emailAdd);
  	}
  	
  	this.firstNameInput.sendKeys(fName);
  	this.lastNameInput.sendKeys(lName);
  	this.preferredNameInput.sendKeys(pName);
  	this.mobileInput.sendKeys(mobileNum);
  	this.pwdInput.sendKeys(passWord);
	console.log(mobileNum);
    if (nationalityEnabled == "true"){
  		this.nationality.$('[value="Indian"]').click();
  	}
  	if (tncEnabled == "true"){
  		this.tncCheckbox.click();
  	}
  	this.submitBtn.click();
  	browser.sleep(10000);
  }


};

module.exports = new SignUpPage();
