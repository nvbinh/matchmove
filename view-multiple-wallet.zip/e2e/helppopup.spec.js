'use strict';

describe('The Help popup', function () {
  var HelpPopUp;
  var LoginPage = require('./login.po');
  var Utility = require('./utilities.po.js');
  var configFile = require('./e2e.json');
  var DashboardPage = require('./dashboard.po');
  var HelpPopUp = require('./helppopup.po');

  beforeEach(function () {
    browser.get(configFile.HTTP_HOST);
	  Utility.setScreenSize();
    
	  HelpPopUp.popupButton.click();
  });

  it('setup test specs', function(){
	//removed logged in 
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should have all the elements on the popup for feedback', function() {
    //feedback section
	expect(HelpPopUp.popupButton.isPresent()).toBe(true);
	//expect(HelpPopUp.feedbackTab.isPresent()).toBe(true);
	expect(HelpPopUp.feedback.isPresent()).toBe(true);
	expect(HelpPopUp.needHelp.isPresent()).toBe(true);
	//expect(HelpPopUp.subHeader.isPresent()).toBe(true);
	expect(HelpPopUp.emailField.isPresent()).toBe(true);
	expect(HelpPopUp.nameField.isPresent()).toBe(true);
	expect(HelpPopUp.messageField.isPresent()).toBe(true);
	expect(HelpPopUp.sendButton.isPresent()).toBe(true);

	
	if(configFile.HELPPOPUP_PAGE.isSVG == "true"){
		expect(HelpPopUp.faqTabsvg.isPresent()).toBe(true);
	}else{
		expect(HelpPopUp.faqTab.isPresent()).toBe(true);
	}
	expect(HelpPopUp.faqHeader.isPresent()).toBe(true);
	expect(HelpPopUp.closePopup.isPresent()).toBe(true);
  });

  it('The intial state of the elements must be reset', function(){
	expect(HelpPopUp.emailField.getText()).toEqual('');
	expect(HelpPopUp.nameField.getText()).toEqual('');
	expect(HelpPopUp.messageField.getText()).toEqual('');
	expect(HelpPopUp.sendButton.isEnabled()).toBe(false);
  });

  it('The input values should be correctly reflected', function(){
	//email
	HelpPopUp.setEmail('testermike@matchmove.com');
    HelpPopUp.emailField.getAttribute('value').then(function (value) {
    expect(value).toEqual('testermike@matchmove.com')});

	//name
	HelpPopUp.setName('mike');
    HelpPopUp.nameField.getAttribute('value').then(function (value) {
    expect(value).toEqual('mike')});

	//message
	HelpPopUp.setMessage('this is a test');
    HelpPopUp.messageField.getAttribute('value').then(function (value) {
    expect(value).toEqual('this is a test')});
  });

  it('should enable send request button when valid value entered', function(){

	HelpPopUp.setEmail('testermike@matchmove.com');
	HelpPopUp.setName('mike');
	HelpPopUp.setMessage('this is a test');
	expect(HelpPopUp.sendButton.isEnabled()).toBe(true);
  });


  it('The Send Request button should switch state based on client side validity of email', function(){

  	HelpPopUp.setName('mike');
  	HelpPopUp.setMessage('this is a test');


	  HelpPopUp.setEmail('#@%^%#$@#$@#.com');
    expect(HelpPopUp.sendButton.isEnabled()).toBe(false);

    HelpPopUp.setEmail('@domain.com');
    expect(HelpPopUp.sendButton.isEnabled()).toBe(false);

  	HelpPopUp.setEmail('testermike@matchmove.com');
  	expect(HelpPopUp.sendButton.isEnabled()).toBe(true);

    HelpPopUp.setEmail('Joe Smith <email@domain.com>');
    expect(HelpPopUp.sendButton.isEnabled()).toBe(false);

  });


  it('should show the faq tab when faq is click', function(){
  browser.sleep(2000);
	if(configFile.HELPPOPUP_PAGE.isSVG == "true"){
		HelpPopUp.faqTabsvg.click();
	}else{
		HelpPopUp.faqTab.click();
	}
	
	expect(HelpPopUp.faqHeader.isPresent()).toBe(true);

  });

  it('should send email to customer service', function(){

	HelpPopUp.setEmail('testermike@matchmove.com');
	HelpPopUp.setName('mike');
	HelpPopUp.setMessage('this is a test');
	HelpPopUp.clickSendRequestButton();
	browser.sleep(5000);

  });

});
