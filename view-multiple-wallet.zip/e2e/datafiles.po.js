'use strict';

var DataFilePage = function() {

	this.maxPreKycAmount = 500;
	this.kycApprovalPoint = 100;
	this.firstTopupPoint = 100;
	this.firstTopupAmount = 50;
	this.preKYCmaxCards = 5;
	this.postKYCmaxCards = 10;

};

module.exports = new DataFilePage();