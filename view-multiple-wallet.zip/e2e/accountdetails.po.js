/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var AccountDetailPage = function() {


  //var configFile = require('./protractor-config-files/e2e.json');

  var configFile = require('./e2e.json');


  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));

  this.warningBox = element(by.css('.content-box--warning'));
  //this.accountTabs = element(by.css('v-tabs[active="detailsTabs.active"]'));
  //this.accountTabs = element(by.css('v-tab.subttitle-icon'));
  this.accountTabs = element(by.css('mm-tab-item.mm-tab'));

  this.adressTab = element.all(by.css('mm-tab-item.mm-tab')).last();

  this.birthday = element(by.model('info.birthday'));
  this.identificationNumber = element(by.model('info.identification.number'));
  this.conuntryOfissue = element(by.model('info.countryofissue'));
  this.completeProfile = element(by.css('button[ng-click="completeAccountProfile(info)"]'));

  //address res
  this.address1R = element(by.model('residential.address_1'));
  this.address1Rerror = element(by.css('div[ng-messages="forms.updateAddress.Residential_address_1.$error"]'));
  //this.address1Rerror2 = element(by.css('div[ng-messages="residentialAddress.address_1.$error"]'));
  this.address1Rerror2 = element(by.css('p.help-block.error'));//.getWebElement();
  //this.address2R = element(by.model('residential.address_2'));
  this.address2R = element(by.model('residential.address_2'));
  this.address2Rerror = element(by.css('div[ng-messages="forms.updateAddress.Residential_address_2.$error"'));
  this.address2Rerror2 = element(by.css('div[ng-messages="residentialAddress.address_2.$error"]'));
  //this.city = element(by.model('res.city'));
  this.city = element(by.model('residential.city'));
  this.state = element(by.model('residential.state'));
  this.postalR = element(by.model('residential.zipcode'));
  this.postalRerror = element(by.css('div[ng-messages="forms.updateAddress.Residential_zipcode.$error"]'));
  this.postalRerror2 = element(by.css('div[ng-messages="residentialAddress.zipcode.$error"]'));
  this.updateResidentialLinksvg = element(by.css('a[ng-click="addressResidential.showStaticView = !addressResidential.showStaticView"]'));
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
  this.updateResidentialLink = element.all(by.css('.icon-edit')).get(4);}
  else{
  this.updateResidentialLink = element.all(by.css('.icon-edit')).get(3);
  }
  this.updateResidentialButton = element(by.css('.button-primary--medium'));

  //address billing
  this.address1B = element(by.model('billing.address_1'));
  this.address1Berror = element(by.css('div[ng-messages="forms.updateAddress.Billing_address_1.$error"]'));
  this.address1Berror2 = element(by.css('div[ng-messages="billingAddress.address_1.$error"]'));
  this.address2B  = element(by.model('billing.address_2'));
  this.address2Berror = element(by.css('div[ng-messages="forms.updateAddress.Billing_address_2.$error"]'));
  this.address2Berror2 = element(by.css('div[ng-messages="billingAddress.address_2.$error"]'));
  this.cityB = element(by.model('bill.city'));
  this.stateB = element(by.model('bill.state'));
  this.countryB = element(by.model('billing.country'));
  this.postalB = element(by.model('billing.zipcode'));
  this.postalBerror = element(by.css('div[ng-messages="forms.updateAddress.Billing_zipcode.$error"]'));
  this.postalBerror2 = element(by.css('div[ng-messages="billingAddress.zipcode.$error"]'));
  this.updateBillingLinksvg = element(by.css('a[ng-click="addressBilling.showStaticView = !addressBilling.showStaticView"]'));
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
  this.updateBillingLink = element.all(by.css('.icon-edit')).get(5);}
  else{
  this.updateBillingLink = element.all(by.css('.icon-edit')).get(4);
  }
  this.updateBillingButton = element(by.css('.button-primary--medium'));

  this.sameAddressBox = element(by.model('details.hideBillingInfo'));
  this.updateAddress = element(by.css('button[ng-click="completeAddressInformation()"]'));

  this.gender = element.all(by.css('.section-radio')).all(by.tagName('input')).last();
  this.userTitle = element.all(by.css('.section-radio')).all(by.model('info.title')).last();
  this.identityInfolast = element.all(by.css('.section-radio')).all(by.model('info.identification.type')).last();

  this.dobError = element(by.css('.help-block'));
  this.nricError = element(by.css('message-box[messagetext="NRIC Invalid"]'));
  //this.nricError = element(by.xpath('.//*[@id="updateProfile"]/ul[2]/li[2]/message-box[2]/aside/aside/p'));

  this.updatedInfosuccess = element(by.css('message-box[messagetext="Profile successfully updated"]'));



  //this.Subheader = element(by.css('.item-title'));
  //this.fullName = element(by.css('.label-title'));

  //check the number of fields available in the page
  this.detailsSection = function (num, num2){
	  var subheader = element.all(by.css('.item-title'));
	  expect(subheader.count()).toBe(num);


	  //var accountdetails = element.all(by.css('.label-title'));
	  //expect(accountdetails.count()).toBe(num2);

	  var accountdetails = element.all(by.css('.section-info'));
	  expect(accountdetails.count()).toBe(num2);

  };

  //select a gender radio button
  this.genderDropdown = function(num){
	element.all(by.css('.section-radio')).all(by.tagName('input')).get(num).click();
  }

  //select a title
  this.userTitle = function(num){
	element.all(by.css('.section-radio')).all(by.model('info.title')).get(num).click();
  }

  //select a identity
  this.identityInfo = function(num){
	element.all(by.css('.section-radio')).all(by.model('info.identification.type')).get(num).click();
  }

  this.countminiDashboard = function(num){
	  var checklist = element.all(by.css('.text-small--success'));
	  expect(checklist.count()).toBe(num);
  }

  this.completeDetails = function(idNum){
  	this.genderDropdown(1);
  	this.userTitle(1);
  	//this.conuntryOfissue.$('[label="Singapore"]').click();
  	this.identityInfo(3);
  	this.identificationNumber.sendKeys(idNum);
 // 	this.birthday.clear();
  //	this.accountTabs.click();
  	this.birthday.sendKeys('1975-01-10');
  	this.completeProfile.click();
  	browser.sleep(5000);

    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
      this.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
      this.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
      this.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
      this.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
      this.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
    }

    if (configFile.ACCOUNTS_PAGE.billingEnabled.address_1 == "true"){
      this.address1B.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.address_1);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.address_2 == "true"){
      this.address2B.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.address_2);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.city == "true"){
      this.cityB.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.city);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.state == "true"){
      this.stateB.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.state);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.postalCode == "true"){
      this.postalB.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.postalCode);
    }

    this.updateAddress.click();
    browser.sleep(10000);




/*
this.genderDropdown(1);
  	this.userTitle(1);
  	this.birthday.clear();
  	this.accountTabs.click();
  	this.birthday.sendKeys('1975-01-10');
  	//this.conuntryOfissue.$('[label="Singapore"]').click();
  	this.identityInfo(3);
  	this.identificationNumber.sendKeys(idNum);
  	this.completeProfile.click();
  	browser.sleep(5000);

  	this.address1R.sendKeys('Telok');
  	this.address2R.sendKeys('Ayer');
  	this.postalR.sendKeys('321507');
  	this.sameAddressBox.click();
  	this.updateAddress.click();
  	browser.sleep(10000);*/
  }

  this.completeAllDetails = function(idNum){
  	this.genderDropdown(1);
  	this.userTitle(1);
  	//this.conuntryOfissue.$('[label="Singapore"]').click();
  	this.identityInfo(2);
  	this.identificationNumber.sendKeys(idNum);
	//this.birthday.clear();
  	//this.accountTabs.click();
  	this.birthday.sendKeys('1975-01-10');
  	this.completeProfile.click();
  	browser.sleep(5000);

  	this.address1R.sendKeys('Telok');
  	this.address2R.sendKeys('Ayer');
  	this.postalR.sendKeys('321507');
  	//this.sameAddressBox.click();
  	//this.updateAddress.click();
  	//browser.sleep(10000);

    this.address1B.sendKeys('Telok Billing');
    this.address2B.sendKeys('Ayer Billing');
    this.countryB.$('[label="Singapore"]').click();
    this.postalB.sendKeys('472645');
    this.updateAddress.click();
    browser.sleep(10000);
  }

  this.completePersonalInfo = function(idNum){
  	this.genderDropdown(1);
  	this.userTitle(1);
  	//this.conuntryOfissue.$('[label="Singapore"]').click();
  	this.identityInfo(2);
  	this.identificationNumber.sendKeys(idNum);
  	//this.birthday.clear();
  	//this.accountTabs.click();
  	this.birthday.sendKeys('1975-01-10');
  	this.completeProfile.click();
  	browser.sleep(5000);
  }

  this.completeResidentialAddressInfo = function(){

    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
      this.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
      this.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
      this.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
      this.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
      this.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
    }

  }

  this.completeBillingAddressInfo = function(){

    if (configFile.ACCOUNTS_PAGE.billingEnabled.address_1 == "true"){
      this.address1B.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.address_1);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.address_2 == "true"){
      this.address2B.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.address_2);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.city == "true"){
      this.cityB.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.city);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.state == "true"){
      this.stateB.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.state);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.postalCode == "true"){
      this.postalB.sendKeys(configFile.ACCOUNTS_PAGE.billingValues.postalCode);
    }

    this.updateAddress.click();
    browser.sleep(10000);
  }

  this.changeResidential = function(add1Param, add2Param, postalParam, cityParam, stateParam){


    if (configFile.ACCOUNTS_PAGE.svgINEditAddress == "true")
    {
	this.updateResidentialLink.click();
    }else{
	this.updateResidentialLinksvg.click();
    }
    browser.sleep(5000);
    this.address1R.clear();
    this.address2R.clear();
    this.postalR.clear();
    this.address1R.sendKeys(add1Param);
    this.address2R.sendKeys(add2Param);
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
      this.city.clear();
      this.city.sendKeys(cityParam);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
      this.state.clear();
      this.state.sendKeys(stateParam);
    }
    this.postalR.sendKeys(postalParam);
    this.updateResidentialButton.click();
    browser.sleep(5000);

  }

  this.changeBilling = function(add1Param, add2Param, postalParam){


    if (configFile.ACCOUNTS_PAGE.svgINEditAddress == "true")
    {
	this.updateBillingLink.click();
    }else{
	this.updateBillingLinksvg.click();
    }
    browser.sleep(5000);
    this.address1B.clear();
    this.address2B.clear();
    this.postalB.clear();
    this.address1B.sendKeys(add1Param);
    this.address2B.sendKeys(add2Param);
    this.postalB.sendKeys(postalParam);
    if (configFile.ACCOUNTS_PAGE.billingEnabled.city == "true"){
      this.cityB.clear();
      this.cityB.sendKeys(cityParam);
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.state == "true"){
      this.stateB.clear();
      this.stateB.sendKeys(stateParam);
    }
    this.updateBillingButton.click();
    browser.sleep(5000);

  }

  this.changeBillingSameAsResidential = function(add1Param, add2Param, postalParam){

    this.adressTab.click();
    this.sameAddressBox.click();
    browser.sleep(10000);

  }

  this.verifyChangedResidential = function(add1Param, add2Param, postalParam){

    if (configFile.ACCOUNTS_PAGE.svgINEditAddress == "true")
    {
	this.updateResidentialLink.click();
    }else{
	this.updateResidentialLinksvg.click();
    }
    this.address1R.getAttribute('value').then(function (value) {
    expect(value).toEqual(add1Param)});

    this.address2R.getAttribute('value').then(function (value) {
    expect(value).toEqual(add2Param)});

    this.postalR.getAttribute('value').then(function (value) {
    expect(value).toEqual(postalParam)});
    this.updateResidentialButton.click();

  }

  this.verifyChangedBilling = function(add1Param, add2Param, postalParam){

    if (configFile.ACCOUNTS_PAGE.svgINEditAddress == "true")
    {
	this.updateBillingLink.click();
    }else{
	this.updateBillingLinksvg.click();
    }
    this.address1B.getAttribute('value').then(function (value) {
    expect(value).toEqual(add1Param)});

    this.address2B.getAttribute('value').then(function (value) {
    expect(value).toEqual(add2Param)});

    this.postalB.getAttribute('value').then(function (value) {
    expect(value).toEqual(postalParam)});
  }


  this.verifyAccountInfo = function(Fname, mob, emailAdd, len){

    // fullName
    //element(by.cssContainingText('.ng-binding', Fname)).getText().then(function (text) {
    //  expect(text).toEqual(Fname);
    //});
    //mobile
    element(by.cssContainingText('.ng-binding', mob)).getText().then(function (text) {
	var x = text.substr(text.length - len);
	var y = mob.substr(mob.length - len);
	expect(x).toEqual(y);
    });
    //email
    if (configFile.SIGNUP_PAGE.emailRequired == "true"){
    var emailTxt = element(by.cssContainingText('.ng-binding', emailAdd)).getText().then(function (text) {
      expect(text).toEqual(emailAdd);
    });
    }
  }

  this.verifyPersonalInfo = function(title, gender, bday, contryIssue){

    element(by.cssContainingText('.ng-binding', title)).getText().then(function (text) {
      expect(text).toEqual(title);
    });
    element(by.cssContainingText('.ng-binding', gender)).getText().then(function (text) {
      expect(text).toEqual(gender);
    });
    element(by.cssContainingText('.ng-binding', bday)).getText().then(function (text) {
      expect(text).toEqual(bday);
    });
    element(by.cssContainingText('.ng-binding', contryIssue)).getText().then(function (text) {
      expect(text).toEqual(contryIssue);
    });
  }

  this.verifyResidentialInfo = function(address1, address2, city, state, postal, contryIssue){

    element(by.cssContainingText('.ng-binding', address1)).getText().then(function (text) {
      expect(text).toEqual(address1);
    });
    element(by.cssContainingText('.ng-binding', address2)).getText().then(function (text) {
      expect(text).toEqual(address2);
    });
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
      element(by.cssContainingText('.ng-binding', city)).getText().then(function (text) {
        expect(text).toEqual(city);
      });
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
      element(by.cssContainingText('.ng-binding', state)).getText().then(function (text) {
        expect(text).toEqual(state);
      });
    }
    element(by.cssContainingText('.ng-binding', postal)).getText().then(function (text) {
      expect(text).toEqual(postal);
    });
    //element(by.cssContainingText('.ng-binding', contryIssue)).getText().then(function (text) {
    //  expect(text).toEqual(contryIssue);
    //});
  }

  this.verifyBillingInfo = function(address1, address2, city, state, postal, contryIssue){

    element(by.cssContainingText('.ng-binding', address1)).getText().then(function (text) {
      expect(text).toEqual(address1);
    });
    element(by.cssContainingText('.ng-binding', address2)).getText().then(function (text) {
      expect(text).toEqual(address2);
    });
    if (configFile.ACCOUNTS_PAGE.billingEnabled.city == "true"){
      element(by.cssContainingText('.ng-binding', city)).getText().then(function (text) {
        expect(text).toEqual(city);
      });
    }
    if (configFile.ACCOUNTS_PAGE.billingEnabled.state == "true"){
      element(by.cssContainingText('.ng-binding', state)).getText().then(function (text) {
        expect(text).toEqual(state);
      });
    }
    element(by.cssContainingText('.ng-binding', postal)).getText().then(function (text) {
      expect(text).toEqual(postal);
    });
    if (configFile.ACCOUNTS_PAGE.billingEnabled.country == "true"){
      element(by.model('billing.country')).$('[label="'+contryIssue+'"]').getAttribute('selected').then (function (selected){
        expect(selected).toBe(true);
    });
    }
  }

  this.logoutLink = element(by.css('a[ng-click="logout()"]'));
  this.changeEmailLink = element(by.css('a[ng-dialog="app/components/emailChange/partials/emailChange.html"]'));
  this.changeMobilelLink = element(by.css('a[ng-dialog="app/components/mobileChange/partials/mobileChange.html"]'));

};

module.exports = new AccountDetailPage();
