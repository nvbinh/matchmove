/*
***** Please provide post-kyc account in SGMC config file before runnning this script
*/
'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');

describe('Remittance', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;
	var sendAmount = 0;


	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Login with post-KYC account', function() {

		browser.get(configFile.HTTP_HOST);

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(configFile.POST_KYC_ACCOUNT.MOBILE_NUMBER);
			LoginPage.pwdInput.sendKeys(configFile.POST_KYC_ACCOUNT.PASSWORD);
		});

		LoginPage.submitBtn.click();
		var remitMenu = element(by.linkText('Remit'));
		var remitMenuIsClickable = EC.elementToBeClickable(remitMenu);
		browser.wait(remitMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(2000);
		});
	});

	it ('Access Remittance page and do topup if user has no balance', function() {

		var remittanceTitleIsVisibily = EC.visibilityOf(RemitPage.remittanceTitle);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var chooseCountryIsVisibility = EC.visibilityOf(RemitPage.chooseCountry);

		RemitPage.remitMenu.click();
		browser.wait(remittanceTitleIsVisibily).then(function() {
			RemitPage.topupNowBtn.isPresent().then(function(result) {
				if (result) {
					RemitPage.topupNowBtn.click();
					browser.wait(providerEasypayIsClickable).then(function() {
						TopupPage.providerEasypay.click();
						browser.wait(topupBtnIsClickable).then(function() {
							TopupPage.amountCustom.click();
							customAmount = 100;
							TopupPage.amountCustomText.sendKeys(customAmount);
							TopupPage.topupBtn.click();
						});
					});

					browser.wait(windowCount(2), 60000);
					browser.getAllWindowHandles().then(function(handles) {
						var newWindowHandle = handles[1];
						browser.switchTo().window(newWindowHandle).then(function() {
							browser.wait(cancelBtnIsClickable).then(function() {
								EasyGateway.visaChannel.click();
								browser.sleep(2000);
								EasyGateway.creditCardNum.sendKeys('4111111111111111');
								EasyGateway.expMonth.click();
								EasyGateway.expYear.click();
								EasyGateway.creditCardCvv2.sendKeys('989');
								EasyGateway.creditCardName.sendKeys('auto tester');
								EasyGateway.submitBtn.click();
							});
						});
					});

					var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
					browser.wait(transactionSuccessfulIsVisibility).then(function() {//
						browser.getAllWindowHandles().then(function(handles) {
							browser.driver.close().then(function () {
								browser.switchTo().window(handles[0]).then(function() {
									browser.sleep(90000); //waiting 90 seconds for balance to be updated
									browser.refresh();
		    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
									browser.wait(walletBalanceIsPresence).then(function() {
										TopupPage.walletBalance.getInnerHtml().then(function(balance) {
											balanceAfter = balance;
											var amountIncrese = balanceAfter - balanceBefore;
											expect(amountIncrese).toEqual(customAmount);
										});
									});
								});
							});
						});
					});

					RemitPage.remitMenu.click();
				}

				browser.wait(chooseCountryIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});

	});

	it ('select country = PH then Mobile Money Transfer and Select Network dropdown are displayed ', function() {

		RemitPage.selectPhilippines.click();
		browser.sleep(1000);

		RemitPage.mobileMoneyTransfer.isPresent().then(function(result) {
			expect(result).toBe(true);
		});

		RemitPage.selectNetwork.isPresent().then(function(result) {
			expect(result).toBe(true);
		});

	});

	it ('select network = GCash, enter amount = 100 then receipt will be displayed', function() {

		var receiptIsVisibility = EC.visibilityOf(RemitPage.receipt);

		RemitPage.gCash.click();
		browser.sleep(500);
		sendAmount = 100;
		RemitPage.inputAmount.sendKeys(sendAmount);
		browser.wait(receiptIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});


	it ('Send mount was calculated correctly', function() {

		RemitPage.getExchangeRate.getText().then(function(text) {
			var splitTextBySpace = text.split(" ");
			var rate = parseFloat(splitTextBySpace.pop()); //get rate by taking last element
			console.log(rate);
			var sendAmountInSGDCalculated = sendAmount / rate * 100 + 1;
			sendAmountInSGDCalculated = Math.trunc(sendAmountInSGDCalculated) / 100
			RemitPage.getSendAmount.getText().then(function(text) {
				var sendAmountInSGD = parseFloat(text);
				expect(sendAmountInSGDCalculated).toEqual(sendAmountInSGD);
				browser.sleep(2000);
			});
		});
	});

	it ('Click Countinue then Receiver details page is displayed and Continue button is disabled as default', function() {

		var mobileIntIsVisibility = EC.visibilityOf(RemitPage.mobileInp);

		RemitPage.continueBtn.click();
		browser.wait(mobileIntIsVisibility).then(function() {
			expect(RemitPage.continueBtn.isEnabled()).toBe(false);
			browser.sleep(1000);
		});
	});

	it ('Inline validation message is showing when input invalid mobile number netword', function() {

		RemitPage.mobileInp.sendKeys(configFile.REMIT_MOBILE_NUMBER.SMART_MONEY);
		browser.sleep(1000);
		expect(RemitPage.inlineMessage.isPresent()).toBe(true);
	});

	it ('Compplete all fields for  Receiver details except Reason for Remittance and Continue button is disabled', function() {

		RemitPage.mobileInp.clear();
		RemitPage.mobileInp.sendKeys('+');
		RemitPage.mobileInp.sendKeys(configFile.REMIT_MOBILE_NUMBER.GCASH);
		browser.sleep(1000);
		RemitPage.firstName.sendKeys('auto firstname');
		RemitPage.lastName.sendKeys('auto lastname');
		RemitPage.DOB.sendKeys('1990-01-01');
		RemitPage.nationalityFilipino.click();
		RemitPage.address1.sendKeys('25 ADB avenue');
		RemitPage.address2.sendKeys('Ortigas');
		RemitPage.city.sendKeys('Makati');
		RemitPage.state.sendKeys('Manila')
		RemitPage.zipCode.sendKeys(123456);
		browser.sleep(1000);
		expect(RemitPage.continueBtn.isEnabled()).toBe(false);
		browser.sleep(500);

	});

	it ('Complete all fields and Continue button is Enabled', function() {

		RemitPage.reasonForRemit.get(1).click();
		browser.sleep(1000);
		//expect(RemitPage.continueBtn.isEnabled()).toBe(true);
		var continueBtnIsClickable = EC.elementToBeClickable(RemitPage.continueBtn);
		browser.wait(continueBtnIsClickable).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Click Continue and Confirm successfully', function() {

		var confirmationBtnIsClickable = EC.elementToBeClickable(RemitPage.confirmationBtn);
		var successMessageIsPresence = EC.presenceOf(RemitPage.successMessage);

		RemitPage.continueBtn.click();
		browser.wait(confirmationBtnIsClickable).then(function() {
			RemitPage.confirmationBtn.click();
			browser.wait(successMessageIsPresence).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});
		});

	});

	it ('Remit again via Smart Money and enter an invalid send amount', function() {

		var chooseCountryIsVisibility = EC.visibilityOf(RemitPage.chooseCountry);
		var invalidFormatMessageIsPresence = EC.presenceOf(RemitPage.invalidFormatMessage);

		RemitPage.remitAgain.click();
		browser.wait(chooseCountryIsVisibility).then(function() {
			RemitPage.selectPhilippines.click();
			browser.sleep(500);
			RemitPage.smartMoney.click();
			browser.sleep(500);
			RemitPage.inputAmount.sendKeys(100.5);
			browser.wait(invalidFormatMessageIsPresence).then(function() {
				expect(true).toBe(true);
			});
		});

		RemitPage.inputAmount.clear();
		RemitPage.inputAmount.sendKeys(0);
		browser.wait(invalidFormatMessageIsPresence).then(function() {
				expect(true).toBe(true);
		});

		RemitPage.inputAmount.clear();
		RemitPage.inputAmount.sendKeys('-150');
		browser.wait(invalidFormatMessageIsPresence).then(function() {
				expect(true).toBe(true);
		});


	});

	it ('Enter send amount less than minimum', function() {

		var minMessageIsPresence = EC.presenceOf(RemitPage.minMessage);

		RemitPage.inputAmount.clear();
		RemitPage.inputAmount.sendKeys(49);
		browser.wait(minMessageIsPresence).then(function() {
			expect(true).toBe(true);
		});

		RemitPage.inputAmount.clear();
		RemitPage.inputAmount.sendKeys(1);
		browser.wait(minMessageIsPresence).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Enter valid amount and remit successfully', function() {

		var continueBtnIsClickable = EC.elementToBeClickable(RemitPage.continueBtn);
		var mobileIntIsVisibility = EC.visibilityOf(RemitPage.mobileInp);
		var confirmationBtnIsClickable = EC.elementToBeClickable(RemitPage.confirmationBtn);
		var successMessageIsPresence = EC.presenceOf(RemitPage.successMessage);

		RemitPage.inputAmount.clear();
		RemitPage.inputAmount.sendKeys(100);
		browser.wait(continueBtnIsClickable).then(function() {
			RemitPage.continueBtn.click();
		});

		browser.wait(mobileIntIsVisibility).then(function() {
			RemitPage.mobileInp.sendKeys('+');
			RemitPage.mobileInp.sendKeys(configFile.REMIT_MOBILE_NUMBER.SMART_MONEY);
			browser.sleep(1000);
			RemitPage.firstName.sendKeys('auto firstname');
			RemitPage.lastName.sendKeys('auto lastname');
			RemitPage.reasonForRemit.get(1).click();
			RemitPage.DOB.sendKeys('1990-01-01');
			RemitPage.nationalityFilipino.click();
			RemitPage.address1.sendKeys('25 ADB avenue');
			RemitPage.address2.sendKeys('Ortigas');
			RemitPage.city.sendKeys('Makati');
			RemitPage.state.sendKeys('Manila')
			RemitPage.zipCode.sendKeys(123456);
			expect(true).toBe(true);
			browser.sleep(1000);
		});

		browser.wait(continueBtnIsClickable).then(function() {
			RemitPage.continueBtn.click();
		});

		browser.wait(confirmationBtnIsClickable).then(function() {
			RemitPage.confirmationBtn.click();
			browser.wait(successMessageIsPresence).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});
		});
	});
});
