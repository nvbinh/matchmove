/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var LoginPage = function() {

  //this.offerMenu = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[1]/side-bar/ul/li[6]/a/label'));
  this.offerMenu = element(by.css('a[href="/wallet/offers/list"]'));


  //offer main page
  this.pageTitle = element(by.css('.title-header h2'));
  //this.titleIcon = element(by.css('.title-icon use'));
  this.titleIcon = element(by.css('.title-icon'));
  this.offerList = element(by.repeater('offer in offers'));

  //offer detail page
  this.subHeader = element(by.css('.title-secondary'));
  this.offerDetails = element(by.css('.offer-details'));
  this.offerInfo = element(by.css('.offer-info'));
  this.offerDescription = element(by.css('.offer-description'));

  //master page
  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));

};

module.exports = new LoginPage();
