/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var HelpPopUp = function() {

  var configFile = require('./e2e.json');

  this.popupButton = element(by.css('a[ng-dialog="app/components/help/partials/help.html"]'))
  //Feedback
  //this.feedbackTab = element(by.css('v-tab span.mcw-common-contact'));
  this.feedbackTab = element.all(by.css('.icon-32')).first();
  this.feedback = element(by.id('ngdialog1-aria-describedby'));
  this.needHelp = element(by.css('div.content-message--callcenter')).element(by.tagName('h4'));
  this.emailField = element(by.model('supportRequest.email'));
  this.nameField = element(by.model('supportRequest.name'));
  this.messageField = element(by.model('supportRequest.content'));
  this.sendButton = element(by.css('button[ng-click="submitForm()"]'));

  //FAQ

  this.faqTab = element(by.css('v-tab span.mcw-common-help'));
  this.faqTabsvg = element.all(by.css('.icon-32')).last();

  this.faqHeader = element(by.css('.content-faq h2'));

  this.closePopup = element(by.css('.ngdialog-close'));


  this.setEmail = function(email){
	  this.emailField.clear();
	  this.emailField.sendKeys(email);
  };

  this.setName = function(name){
	  this.nameField.clear();
	  this.nameField.sendKeys(name);
  };

  this.setMessage = function(message){
	  this.messageField.clear();
	  this.messageField.sendKeys(message);
  };

  this.clickSendRequestButton = function(){
	  expect(this.sendButton.isEnabled()).toBe(true);
  };

  /*
  this.bannerImg = element(by.css('.image__centered img'));
  //this.pageTitle = element(by.css('.marketing__title h1'));
  //this.pageMsg = element(by.css('.marketing__title p'));
  this.emailInput = element(by.model('user.email'));
  this.firstNameInput = element(by.model('user.first_name'));
  this.lastNameInput = element(by.model('user.last_name'));
  this.mobileInput = element(by.model('user.mobile'));
  this.pwdInput = element(by.model('user.password'));
  this.submitBtn = element(by.css('form .section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.errorBanner = element(by.css('.msg-banner'));
  //this.faqHeader = element(by.cssContainingText('.ng-binding', 'Frequently Asked Questions'));
  */


this.contactUsPopup = function() {
    return element(by.css('.ngdialog-content'));
  };

  this.supportRequestEmail = function() {
    return element(by.model('supportRequest.email'));
  };

  this.emailRequireMessage = function() {
    return element(by.css('div[ng-messages="supportForm.email.$error"]')).element(by.css('.help-block[ng-message="required"]'));
  };

  this.emailMinlengthMessage = function() {
    return element(by.css('div[ng-messages="supportForm.email.$error"]')).element(by.css('.help-block[ng-message="minlength"]'));
  };

  this.emailMaxlengthMessage = function() {
    return element(by.css('div[ng-messages="supportForm.email.$error"]')).element(by.css('.help-block[ng-message="maxlength"]'));
  };

  this.emailInvalidMessage = function() {
    return element(by.css('div[ng-messages="supportForm.email.$error"]')).element(by.css('.help-block[ng-message="pattern,email"]'));
  };

  this.nameFields = function() {
    return element(by.model('supportRequest.name'));
  };

  this.nameRequireMessage = function() {
    return element(by.css('div[ng-messages="supportForm.name.$error"]')).element(by.css('.help-block[ng-message="required"]'));
  };

  this.nameMinLengthMessage = function() {
    return element(by.css('div[ng-messages="supportForm.name.$error"]')).element(by.css('.help-block[ng-message="minlength"]'));
  };


  this.nameMaxLengthMessage = function() {
    return element(by.css('div[ng-messages="supportForm.name.$error"]')).element(by.css('.help-block[ng-message="maxlength"]'));
  };

  this.supportMessage = function() {
    return element(by.model('supportRequest.content'));
  };

  this.supportMessageRequire = function() {
    return element(by.css('div[ng-messages="supportForm.content.$error"]')).element(by.css('.help-block[ng-message="required"]'));
  };

  this.supportMessageMinLength = function() {
    return element(by.css('div[ng-messages="supportForm.content.$error"]')).element(by.css('.help-block[ng-message="minlength"]'));
  };

  this.supportMessageMaxLength = function() {
    return element(by.css('div[ng-messages="supportForm.content.$error"]')).element(by.css('.help-block[ng-message="maxlength"]'));
  };

  this.sendRequestButton = function() {
    return element(by.css('button[ng-click="submitForm()"]'));
  };

  this.sendRequestSuccess = function() {
    //return element(by.css('div.section-success #ngdialog1-aria-labelledby'));
    return element(by.css('div[ng-if="feedbackSubmitted"] #ngdialog1-aria-labelledby'));

  };

  this.closePopups = function() {
    return element(by.css('div.ngdialog-content div.ngdialog-close'));
  };


};


module.exports = new HelpPopUp();
