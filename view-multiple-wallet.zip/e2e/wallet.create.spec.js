'use strict';
/*
describe('The main view', function () {
  var WalletCreatePage;

  beforeEach(function () {
    browser.get('http://localhost:3000/index.html/#/wallet/create');
    WalletCreatePage = require('./wallet.create.po');
  });

  it('should have all the elements on the page', function() {
    // expect(WalletCreatePage.bannerImg.isPresent()).toBe(true);
    // expect(WalletCreatePage.pageTitle.isPresent()).toBe(true);
    // expect(WalletCreatePage.pageMsg.isPresent()).toBe(true);
    // expect(WalletCreatePage.emailInput.isPresent()).toBe(true);
    // expect(WalletCreatePage.pwdInput.isPresent()).toBe(true);
    // expect(WalletCreatePage.submitBtn.isPresent()).toBe(true);
  });

});
