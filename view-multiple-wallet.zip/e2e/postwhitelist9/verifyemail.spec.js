'use strict';

describe('Verify email', function () {
  var VerifyEmailPage = require('../verifyemail.po');
  var LoginPage = require('../login.po');
  var ChangePasswordPage = require('../changepassword.po');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var DashboardPage = require('../dashboard.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('../waitReady.js');


  beforeEach(function () {
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should verify the popup for email verification is displayed', function() {

	Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(10000);

	expect(VerifyEmailPage.verifyEmailmainPopup.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailimage.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmaildescription.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailbutton.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailpopupClose.isPresent()).toBe(true);
  });

   it('successfully verify email', function() {

	browser.sleep(5000);

	//click verify email
    VerifyEmailPage.verifyEmailbutton.click();
	browser.sleep(15000);

	//verify sucess popup present in dom
	expect(VerifyEmailPage.sucessPopup.isPresent()).toBe(true);
	//expect(VerifyEmailPage.sucessPopupHeader.isPresent()).toBe(true);
	//expect(VerifyEmailPage.sucessPopupImg.isPresent()).toBe(true);
	expect(VerifyEmailPage.sucessPopupText.isPresent()).toBe(true);
	expect(VerifyEmailPage.sucessPopupTextdetail.isPresent()).toBe(true);

	//verify sucess popup displays
	expect(VerifyEmailPage.sucessPopup.isDisplayed()).toBe(true);
	//expect(VerifyEmailPage.sucessPopupHeader.isDisplayed()).toBe(true);
	//expect(VerifyEmailPage.sucessPopupImg.isDisplayed()).toBe(true);
	expect(VerifyEmailPage.sucessPopupText.isDisplayed()).toBe(true);
	expect(VerifyEmailPage.sucessPopupTextdetail.isDisplayed()).toBe(true);

	browser.sleep(15000);

  });


  it('Go to gmail and verify email was reiceved', function() {

	browser.ignoreSynchronization = true;
    browser.get('https://gmail.com');

	var emailField = element(by.id('Email'));
	var nextButton = element(by.id('next'));
	var passwordField = element(by.id('Passwd'));
	var signInButton = element(by.id('signIn'));

	//var emailSubject = element(by.id(':2x'));
	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
	//var recoverPasswordButton = element(by.css('target=_blank'));
	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	var persistentCookie = element(by.css('#PersistentCookie'));

	browser.sleep(10000);

	//expect(emailField.isPresent()).toBe(true);
	//expect(nextButton.isPresent()).toBe(true);
	emailField.isDisplayed().then(function(result){
		if(result){
			emailField.sendKeys(configFile.EXISTING_EMAIL);
			nextButton.click();
		}
		else{
		}
	});

	browser.sleep(3000);

	passwordField.isPresent().then(function(result){
		if(result){
			persistentCookie.isPresent().then(function(present){
				if(present){
					persistentCookie.isSelected().then(function(select){
						if(select){
							persistentCookie.click();
						}
					});
				}
			passwordField.sendKeys(configFile.GMAIL_PASSWORD);
			signInButton.click();

			});
		}
		else{
		}
	});

	browser.sleep(5000);

	expect(emailSubject.waitReady()).toBeTruthy();
	emailSubject.click();

	browser.sleep(5000);

	expect(recoverPasswordButton.waitReady()).toBeTruthy();
	recoverPasswordButton.click();

	browser.sleep(10000);

	browser.getAllWindowHandles().then(function (handles) {
	  var secondWindowHandle = handles[1];
	  var firstWindowHandle = handles[0];

	  browser.switchTo().window(firstWindowHandle)
	  .then(function () {
	    browser.sleep(2000);
	    element(by.css('.gb_8a')).click();
	    browser.sleep(2000);
	    element(by.css('#gb_71')).click();
	    browser.close();
	  })
	  .then(function () {
        browser.ignoreSynchronization = false;
        browser.switchTo().window(secondWindowHandle)
	  })
	  .then(function () {

		browser.sleep(12000);
		expect(LoginPage.emailInput.isPresent()).toBe(true);
		expect(LoginPage.pwdInput.isPresent()).toBe(true);

        /* expect(ChangePasswordPage.passwordField.isPresent()).toBe(true);
	    expect(ChangePasswordPage.confirmPasswordField.isPresent()).toBe(true);
	    expect(ChangePasswordPage.submitBtn.isPresent()).toBe(true);

		ChangePasswordPage.passwordField.sendKeys(TestData.vCardpassword);
		ChangePasswordPage.confirmPasswordField.sendKeys(TestData.vCardpassword);
		ChangePasswordPage.submitBtn.click();

		browser.sleep(10000);

		expect(LoginPage.emailInput.waitReady()).toBeTruthy();
		expect(LoginPage.emailInput.isPresent()).toBe(true); */

	  });
	});
  });


   it('verify verification email will fail when the email is already verified/expired', function() {

	browser.ignoreSynchronization = true;
    browser.get('https://gmail.com');

	var emailField = element(by.id('Email'));
	var nextButton = element(by.id('next'));
	var passwordField = element(by.id('Passwd'));
	var signInButton = element(by.id('signIn'));

	//var emailSubject = element(by.id(':2x'));
	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
	//var recoverPasswordButton = element(by.css('target=_blank'));
	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	var persistentCookie = element(by.css('#PersistentCookie'));

	//browser.sleep(120000);

	//expect(emailField.isPresent()).toBe(true);
	//expect(nextButton.isPresent()).toBe(true);

	emailField.isPresent().then(function(result){
		if(result){
			emailField.sendKeys(configFile.EXISTING_EMAIL);
			nextButton.click();
		}
		else{
		}
	});

	browser.sleep(3000);

	passwordField.isPresent().then(function(result){
		if(result){
			persistentCookie.isPresent().then(function(present){
				if(present){
					persistentCookie.isSelected().then(function(select){
						if(select){
							persistentCookie.click();
						}
					});
				}
			passwordField.sendKeys(configFile.GMAIL_PASSWORD);
			signInButton.click();

			});
		}
		else{
		}
	});

	expect(emailSubject.waitReady()).toBeTruthy();
	emailSubject.click();

	browser.sleep(5000);

	expect(recoverPasswordButton.waitReady()).toBeTruthy();
	recoverPasswordButton.click();

	browser.sleep(10000);

	browser.getAllWindowHandles().then(function (handles) {
	  var secondWindowHandle = handles[1];
	  var firstWindowHandle = handles[0];

	  browser.switchTo().window(firstWindowHandle)
	  .then(function () {
	    browser.sleep(2000);
	    element(by.css('.gb_8a')).click();
	    browser.sleep(2000);
	    element(by.css('#gb_71')).click();
	    browser.sleep(10000);
	    browser.close();
	  })
	  .then(function () {
        browser.ignoreSynchronization = false;
        browser.switchTo().window(secondWindowHandle)
	  })
	  .then(function () {
		browser.sleep(12000);

		expect(VerifyEmailPage.verifiedEmailEmail.isPresent()).toBe(true);
		expect(VerifyEmailPage.verifiedEmailPassword.isPresent()).toBe(true);

        /* expect(ChangePasswordPage.passwordField.isPresent()).toBe(true);
	    expect(ChangePasswordPage.confirmPasswordField.isPresent()).toBe(true);
	    expect(ChangePasswordPage.submitBtn.isPresent()).toBe(true);

		ChangePasswordPage.passwordField.sendKeys(TestData.vCardpassword);
		ChangePasswordPage.confirmPasswordField.sendKeys(TestData.vCardpassword);
		ChangePasswordPage.submitBtn.click();

		browser.sleep(10000);

		expect(LoginPage.emailInput.waitReady()).toBeTruthy();
		expect(LoginPage.emailInput.isPresent()).toBe(true); */

	  });
	});
  });

});
