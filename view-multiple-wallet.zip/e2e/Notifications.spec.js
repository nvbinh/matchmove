'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./protractor-config-files/SGMCconfig.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var KycValidationPage = require('./kycvalidation.po.js');
var AdminetPage = require('./adminet.po.js');
var TransferClaimPage = require('./transferClaim.po.js');
var NotificationPage = require('./notification.po.js');

describe('Notifications', function() {

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};	

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;

	var mobileNumber1 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var mobileNumber2 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);

	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;

	it ('Submit Document successfully', function() {

		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var genderIsClickable = EC.elementToBeClickable(AccountDetailPage.genderMale);
		var randomID = Utility.autoGenerateMobile(12, 8);
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);
		var kycLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.kycLink);
		var uploadImageIsVisibility = EC.visibilityOf(KycValidationPage.uploadImage);
		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);
		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);
		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);
		var image4 = './KYC_Image/image4.png';
		var image4Path = path.resolve(__dirname, image4);
		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var KYCsubmissionDetailsIsVisibility = EC.visibilityOf(AdminetPage.KYCsubmissionDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationRequiredBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fVerificationRequiredBanner);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var alreadySubmitYCSIsPresence = EC.presenceOf(AdminetPage.alreadySubmitYCS);	
		var approveBtnIsClickable = EC.elementToBeClickable(AdminetPage.approveBtn);
		var approveBtnIsInvisibility = EC.invisibilityOf(AdminetPage.approveBtn);
		
		browser.get(configFile.HTTP_HOST);
		LoginPage.signupBtn.click();
		browser.sleep(5000);
		SignUpPage.firstNameInput.sendKeys('match');
		SignUpPage.lastNameInput.sendKeys('move');
		SignUpPage.preferredNameInput.sendKeys('user');
		SignUpPage.mobileInput.sendKeys(mobileNumber1);
		console.log(mobileNumber1);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()		
		SignUpPage.submitBtn.click();
		
		browser.wait(accountMenuIsClickable).then(function() {
			
			browser.sleep(3000);
			DashboardPage.accountMenu.click();
			browser.wait(genderIsClickable).then(function() {
				browser.sleep(2000);
				browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
			});
			AccountDetailPage.genderMale.click();
			AccountDetailPage.userTitle(1);
			if (configFile.SPASS_TYPE) {
					AccountDetailPage.spassID.click();
			}
			else {
				AccountDetailPage.passportID.click();
			}
			AccountDetailPage.identificationNumber.sendKeys(randomID);
			AccountDetailPage.completeProfile.click();
			browser.sleep(15000);
			if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
		      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
		      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
		      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
		      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
		      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
		    }
			AccountDetailPage.sameAddressBox.click();
			AccountDetailPage.updateAddress.click();
			browser.sleep(5000);
			browser.wait(kycLinkIsClickable).then(function() {
				browser.sleep(4000);
				AccountDetailPage.kycLink.click();
				browser.wait(uploadDocumentsBtnIsClickable).then(function() {
					browser.sleep(2000);
					KycValidationPage.uploadDocumentsBtn.click();
					browser.wait(uploadImageIsVisibility).then(function() {
						browser.sleep(2000);
						KycValidationPage.inputFile.sendKeys(image1Path);
						KycValidationPage.inputFile.sendKeys(image2Path);
						KycValidationPage.inputFile.sendKeys(image3Path);
						KycValidationPage.inputFile.sendKeys(image4Path);
						browser.sleep(4000);
						KycValidationPage.submitDocumentBtn.click();
						browser.wait(KYCprogressIsPresence).then(function() {					
							browser.sleep(10000);
							expect(true).toBe(true);
						});	
					});
				});
			});						
		});
	});

	it('Identity Verification submitted', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var identityVerificationNotificationIsPresence = EC.presenceOf(NotificationPage.identityVerificationNotification);
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);  	
			
		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(1000);
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			browser.sleep(1000);
			LoginPage.submitBtn.click();

			browser.wait(topupMenuIsClickable).then(function() {
				browser.sleep(10000);
				DashboardPage.notificationBell.click();
				browser.sleep(2000);
				DashboardPage.goToNotification.click();
				browser.wait(identityVerificationNotificationIsPresence).then(function() {
					browser.sleep(10000);
					expect(true).toBe(true);	
				});
			});
		});	
	});

	it ('Topup successfully', function() {

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);
		var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);

		browser.sleep(3000);
		browser.wait(topupMenuIsClickable).then(function() {
			browser.sleep(2000);
			DashboardPage.topupMenu.click();
			browser.wait(providerEasypayImageIsVisibility).then(function() {
				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
					var balanceText = balance.replace(",", "");				
						balanceBefore = parseFloat(balanceText);
				});		
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 500;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(2), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[1];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
							EasyGateway.visaChannel.click();
							browser.sleep(2000);
							EasyGateway.creditCardNum.sendKeys('4111111111111111');
							EasyGateway.expMonth.click();
							EasyGateway.expYear.click();
							EasyGateway.creditCardCvv2.sendKeys('989');
							EasyGateway.creditCardName.sendKeys('auto tester');
							EasyGateway.submitBtn.click();				
						});
					});
				});

				browser.wait(transactionSuccessfulIsVisibility).then(function() {
					browser.getAllWindowHandles().then(function(handles) {
						browser.driver.close().then(function () {
							browser.switchTo().window(handles[0]).then(function() {
								browser.sleep(90000); //waiting 90 seconds for balance to be updated
								browser.refresh();
	    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
								browser.wait(walletBalanceIsPresence).then(function() {
									TopupPage.walletBalance.getInnerHtml().then(function(balance) {
										balanceAfter = balance;
										var amountIncrese = balanceAfter - balanceBefore;
										expect(amountIncrese).toEqual(customAmount);		
									});				
								});
							});
						});
					});
				});
			});	
		});

	});

	it ('Send successfully', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);

		browser.sleep(1000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				///
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber2);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(1);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Send successfully again', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);

		browser.sleep(1000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				///
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber2);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(2);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Money Transfer notification', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var moneyTransferNotificationIsPresence = EC.presenceOf(NotificationPage.moneyTransferNotification); 
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);	
			
		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(1000);
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			browser.sleep(1000);
			LoginPage.submitBtn.click();

			browser.wait(sendMenuIsClickable).then(function() {
				browser.sleep(10000);
				DashboardPage.notificationBell.click();
				browser.sleep(2000);
				DashboardPage.goToNotification.click();
				browser.wait(moneyTransferNotificationIsPresence).then(function() {
					browser.sleep(90000);
					expect(true).toBe(true);	
				});
			});
		});	

	});

	it ('Cancel transfer successfully', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);	
		var historyTabIsClickable = EC.elementToBeClickable(TransferClaimPage.historyTab);
		var statusFilterIsVisibility = EC.visibilityOf(TransferClaimPage.statusFilter);
		var cancelTransferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.cancelTransferBtn);
		var cancelBtnIsInvisible = EC.invisibilityOf(TransferClaimPage.cancelTransferBtn);
		var cancelSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.cancelSuccessMessage);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(120000);
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		LoginPage.submitBtn.click();

		browser.wait(sendMenuIsClickable).then(function() {
			browser.sleep(120000);
			DashboardPage.logoutLink.click();
			browser.wait(loginPageIsPresent).then(function() {
				browser.sleep(10000);
				LoginPage.userInput.sendKeys(mobileNumber1);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});	
			LoginPage.submitBtn.click();
			browser.wait(sendMenuIsClickable).then(function() {
				 browser.sleep(1000);
				DashboardPage.sendMenu.click();
				browser.wait(historyTabIsClickable).then(function() {
					browser.sleep(1000);
					TransferClaimPage.historyTab.click();
					browser.wait(statusFilterIsVisibility).then(function() {
						browser.sleep(1000);
						TransferClaimPage.activeStatus.click();
						browser.wait(cancelTransferBtnIsClickable).then(function() {
							browser.sleep(5000);
							TransferClaimPage.cancelTransferBtn.click();
							browser.wait(cancelBtnIsInvisible).then(function() {
								expect(true).toBe(true);
								browser.sleep(2000);
							});
						});
					});
				});
			});
		});
	});

	it ('Cancel notification', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var cancelNotificationIsPresence = EC.presenceOf(NotificationPage.cancelNotification);
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);	
			
		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(1000);
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		LoginPage.submitBtn.click();
		browser.sleep(10000);

		browser.wait(sendMenuIsClickable).then(function() {
			browser.sleep(90000);
			DashboardPage.logoutLink.click();
			browser.wait(loginPageIsPresent).then(function() {
				browser.sleep(1000);
				LoginPage.userInput.sendKeys(mobileNumber1);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				browser.sleep(1000);
				LoginPage.submitBtn.click();
				browser.wait(sendMenuIsClickable).then(function() {
					browser.sleep(10000);
					DashboardPage.notificationBell.click();
					browser.sleep(2000);
					DashboardPage.goToNotification.click();
					browser.wait(cancelNotificationIsPresence).then(function() {
						browser.sleep(3000);
						expect(true).toBe(true);	
					});
				});
			});	
		});
	});

});