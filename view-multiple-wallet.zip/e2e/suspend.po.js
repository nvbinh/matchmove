/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var SuspendCardPage = function() {
	
  this.suspendMenu = element(By.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[1]/side-bar/ul/li[7]/a'))
  

  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));
  
  //suspend card without card
  this.suspendImage = element(by.css('.content-message--nocard img'));
  this.getCardButton = element(by.css('a.button-primary--medium'));
  
  //suspendCard
  this.suspendCardButton = element(by.css('div.cardDescription aside.section-marketing a.button-warning--medium'));
  //this.suspendCardButton = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[2]/div/div[2]/div[2]/section/div/section/div/ul/li/div[2]/aside/a'));
  this.cardLocked = element(by.css('div.actionContainer a'));
  this.cardContainer = element(by.css('.cardContainer'));
  
  //suspend popup
  this.cardNumber = element(by.model('card.number'));	
  this.cardName = element(by.model('card.holder.name'));
  this.cardDate = element(by.model('card.date.expiry'));
  this.detailSection = element(by.css('footer.action'));
  this.clicktoconfirmButton = element(by.css('footer.action button.button-primary--medium'));
  
  this.suspendCardSucessfully = function(){
	this.suspendCardButton.click();  
	browser.sleep(5000);
	this.clicktoconfirmButton.click();
	browser.sleep(10000);
  }
  
  
};

module.exports = new SuspendCardPage();

