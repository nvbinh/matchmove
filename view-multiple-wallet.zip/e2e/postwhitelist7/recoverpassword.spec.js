'use strict';

describe('Recover password', function () {
  var RecoverPasswordPage = require('../recoverpassword.po');
  var ChangePasswordPage = require('../changepassword.po');
  var LoginPage = require('../login.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');
  var TelerivetPage = require('../telerivet.po');
  var VerifyMobile = require('../verifymobile.po');

  var ConnectDatabase = require('../connectdb.po.js');
  var connectDatabase = new ConnectDatabase();
  var sql = "select code from vcard_ih.user_tokens where type = 'password recovery' order by id desc";

  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  var otpCode = "";
  var xx = "";
  require('../waitReady.js');


  /*beforeEach(function () {
    browser.get(configFile.HTTP_HOST + configFile.RECOVER_PASSWORD_PAGE.redirectionUrl);
	  Utility.setScreenSize();
  });*/

  it('setup test specs', function(){
	//removed logged in
	//browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should sign up successfully', function() {
	Utility.setScreenSize();
    browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	  SignUpPage.signupSucess(newEmailSignup, Utility.randomFirstName(configFile.ACCOUNT_INFO.FIRST_NAME), configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	  browser.sleep(10000);
browser.sleep(10000);
browser.sleep(10000);
    browser.get(configFile.HTTP_HOST + configFile.OFFER_PAGE.redirectionUrl);
	  browser.sleep(10000);
    DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	  browser.sleep(10000);

  });

   it('should have all the elements on the page', function() {

	    browser.get(configFile.HTTP_HOST + configFile.RECOVER_PASSWORD_PAGE.redirectionUrl);
      expect(RecoverPasswordPage.bannerImg.isPresent()).toBe(true);
      expect(RecoverPasswordPage.emailInput.isPresent()).toBe(true);
      expect(RecoverPasswordPage.submitBtn.isPresent()).toBe(true);
      expect(RecoverPasswordPage.loginBtn.isPresent()).toBe(true);
      expect(RecoverPasswordPage.signupBtn.isPresent()).toBe(true);
      expect(RecoverPasswordPage.helpBtn.isPresent()).toBe(true);
  });



  it('The intial state of the elements must be reset', function() {
    expect(RecoverPasswordPage.emailInput.getText()).toEqual('');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  });


  it('The input values should be correctly reflected', function() {
    if(configFile.SIGNUP_PAGE.emailRequired == "true"){
      RecoverPasswordPage.emailInput.sendKeys(newEmailSignup);
      RecoverPasswordPage.emailInput.getAttribute('value').then(function (value) {
      expect(value).toEqual(newEmailSignup)});
    }else {
      RecoverPasswordPage.emailInput.sendKeys(newMobileSignup);
      RecoverPasswordPage.emailInput.getAttribute('value').then(function (value) {
      expect(value).toEqual(newMobileSignup)});
    }
  });


  it('The Submit button should be disabled for invalid values', function() {
    //empty email
	RecoverPasswordPage.emailInput.clear();
  	RecoverPasswordPage.emailInput.sendKeys('');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  	RecoverPasswordPage.emailInput.clear();

	// min lenght
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
  	RecoverPasswordPage.emailInput.sendKeys('q');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  	RecoverPasswordPage.emailInput.clear();
  }else {
    RecoverPasswordPage.emailInput.sendKeys('99');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  	RecoverPasswordPage.emailInput.clear();
  }

	// invalid format
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    RecoverPasswordPage.emailInput.sendKeys('@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();
  }else {
    RecoverPasswordPage.emailInput.sendKeys('837746 648');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
    RecoverPasswordPage.emailInput.clear();
  }

	// incomplete
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    RecoverPasswordPage.emailInput.sendKeys('JoeSmithEmailAddress');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();
  }else {
    RecoverPasswordPage.emailInput.sendKeys('847jkj');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
    RecoverPasswordPage.emailInput.clear();
  }
	//invalid
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    RecoverPasswordPage.emailInput.sendKeys('email@domain@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@-domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();
  }
  });


  it('Error message appears for non existing email data input', function() {
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    RecoverPasswordPage.emailInput.sendKeys('firstname.lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.submitBtn.click();
	  expect(RecoverPasswordPage.bannerImg.isPresent()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();
  }else {
    RecoverPasswordPage.emailInput.sendKeys('66666661');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.submitBtn.click();
	  expect(RecoverPasswordPage.bannerImg.isPresent()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();
  }
  });


  it('The Submit button should be enabled for valid email', function() {
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    RecoverPasswordPage.emailInput.sendKeys('firstname.lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@subdomain.domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('firstname+lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@123.123.123.123');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('1234567890@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain-one.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('_______@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain.name');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain.co.jp');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('firstname-lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();
  }
  else {
    RecoverPasswordPage.emailInput.sendKeys('88385896');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('98897357');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('67495839');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();
  }
  });


  it('Successfully Recover Password', function() {

  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    RecoverPasswordPage.emailInput.sendKeys(newEmailSignup);
    RecoverPasswordPage.submitBtn.click();

	//expect(RecoverPasswordPage.successIcon.isPresent()).toBe(true);
  	expect(RecoverPasswordPage.successMessage.isPresent()).toBe(true);
  	expect(RecoverPasswordPage.resendLink.isPresent()).toBe(true);
  }else {
    RecoverPasswordPage.emailInput.sendKeys(newMobileSignup);
    RecoverPasswordPage.submitBtn.click();

	//expect(RecoverPasswordPage.successIcon.isPresent()).toBe(true);
  	expect(RecoverPasswordPage.successMessage.isPresent()).toBe(true);
  	expect(RecoverPasswordPage.resendLink.isPresent()).toBe(true);
  }

  });

  it('Go to gmail and verify email was reiceved', function() {

  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
	   browser.ignoreSynchronization = true;
     browser.get('https://gmail.com');

  	var emailField = element(by.id('Email'));
  	var nextButton = element(by.id('next'));
  	var passwordField = element(by.id('Passwd'));
  	var signInButton = element(by.id('signIn'));

  	//var emailSubject = element(by.id(':2x'));
  	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
  	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
  	//var recoverPasswordButton = element(by.css('target=_blank'));
  	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
  	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	var persistentCookie = element(by.css('#PersistentCookie'));

  	//browser.sleep(120000);

	emailField.isDisplayed().then(function(result){
		if(result){
			emailField.sendKeys(configFile.EXISTING_EMAIL);
			nextButton.click();
		}
		else{
		}
	});

	browser.sleep(3000);

	passwordField.isPresent().then(function(result){
		if(result){
			persistentCookie.isPresent().then(function(present){
				if(present){
					persistentCookie.isSelected().then(function(select){
						if(select){
							persistentCookie.click();
						}
					});
				}
			passwordField.sendKeys(configFile.GMAIL_PASSWORD);
			signInButton.click();

			});
		}
		else{
		}
	});


  	browser.sleep(5000);

  	expect(emailSubject.waitReady()).toBeTruthy();
  	emailSubject.click();

  	browser.sleep(5000);
  }
	})

	it('verify email and change password', function() {
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
	var emailField = element(by.id('Email'));
  	var nextButton = element(by.id('next'));
  	var passwordField = element(by.id('Passwd'));
  	var signInButton = element(by.id('signIn'));

  	//var emailSubject = element(by.id(':2x'));
  	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
  	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
  	//var recoverPasswordButton = element(by.css('target=_blank'));
  	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
  	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));

  	expect(recoverPasswordButton.waitReady()).toBeTruthy();
  	recoverPasswordButton.click();

  	browser.sleep(15000);

  	browser.getAllWindowHandles().then(function (handles) {
  	  var secondWindowHandle = handles[1];
  	  var firstWindowHandle = handles[0];

  	  browser.switchTo().window(firstWindowHandle)
  	  .then(function () {
	    browser.sleep(2000);
	    //element(by.css('.gb_3a')).click();
	    element(by.css('.gb_8a')).click();
	    //browser.sleep(2000);
	    //element(by.css('#gb_71')).click();
	    //browser.sleep(10000);
  	    //browser.close();
  	  })
  	  .then(function () {
          browser.ignoreSynchronization = false;
          browser.switchTo().window(secondWindowHandle)
  	  })
  	  .then(function () {
          expect(ChangePasswordPage.passwordField.isPresent()).toBe(true);
  	    expect(ChangePasswordPage.confirmPasswordField.isPresent()).toBe(true);
  	    expect(ChangePasswordPage.submitBtn.isPresent()).toBe(true);

  		ChangePasswordPage.passwordField.sendKeys(configFile.RECOVER_PASSWORD_PAGE.newPassword);
  		ChangePasswordPage.confirmPasswordField.sendKeys(configFile.RECOVER_PASSWORD_PAGE.newPassword);
  		ChangePasswordPage.submitBtn.click();

  		browser.sleep(10000);

//  		RecoverPasswordPage.errorMessage.isPresent().then(function (isVisible){
//  			if (isVisible) {
//  				expect(RecoverPasswordPage.errorMessage.isDisplayed()).toBe(false);
//  			}


//		});

	  });
	});
  }
  });
/*
  it ('should open new tab', function(){
  if(configFile.SIGNUP_PAGE.emailRequired == "false"){
  if (configFile.VERIFY_MOBILE.OTPonTelerivet == "true"){
    Utility.OpenNewTab();
    Utility.chooseActiveTab(1);
    browser.ignoreSynchronization = true;
    browser.get(configFile.HTTP_HOST_TELERIVET);
  }else {
      expect(true).toBe(true);
  }
  }

  });

  it ('login to telerivet', function(){
    if(configFile.SIGNUP_PAGE.emailRequired == "false"){
    if (configFile.VERIFY_MOBILE.OTPonTelerivet == "true"){
      TelerivetPage.logintoTelerivet(configFile.TELERIVET_USERNAME, configFile.TELERIVET_PASSWORD);
    	TelerivetPage.goToOTPMessage(newMobileSignup);
    	x = TelerivetPage.getOTPMessage();
      console.log(x);
    	//Utility.closeSelectedBrowser(1);
    	browser.sleep(10000);
    }else {
        expect(true).toBe(true);
    }
  }

  });

  it('get telerivet OTP', function() {
if(configFile.SIGNUP_PAGE.emailRequired == "false"){
	browser.ignoreSynchronization = false;
	Utility.chooseActiveTab(0);
	VerifyMobile.processOTP(x);
  RecoverPasswordPage.newPassword.sendKeys(configFile.RECOVER_PASSWORD_PAGE.newPassword);
	VerifyMobile.otpVerifybutton.click();
	//browser.sleep(2000);
  //expect(VerifyMobile.otpsuccess.waitReady()).toBeTruthy();
	//expect(VerifyMobile.otpsuccess.isDisplayed()).toBe(true);
}

  });
*/

it('change the password', function() {
  if(configFile.SIGNUP_PAGE.emailRequired == "false"){
  var EC = protractor.ExpectedConditions;
  browser.wait(EC.visibilityOf(VerifyMobile.otpField),10000);
  browser.wait(EC.visibilityOf(RecoverPasswordPage.newPassword),10000);
  browser.sleep(5000);

  //enter wrong otp
  VerifyMobile.otpField.sendKeys('11111');

  //enter wrong password
  RecoverPasswordPage.newPassword.sendKeys("    7");
  var EC = protractor.ExpectedConditions;
  browser.wait(EC.visibilityOf(element(by.css('p.help-block.error'))), 10000);
}
});

it('get opt from db', function() {
  browser.sleep(5000);
if(configFile.SIGNUP_PAGE.emailRequired == "false"){
  connectDatabase.connection.connect();
  connectDatabase.connection.query(sql, function(err, rows) {
      if (!err) {
        otpCode = rows[0].code;
        console.log('Get OTP code successfully');
        console.log(otpCode);
      }else {
        console.log(err);
      }
  connectDatabase.connection.end();

  });
}

console.log(xx);
});

it('change the password', function() {
  if(configFile.SIGNUP_PAGE.emailRequired == "false"){
  var EC = protractor.ExpectedConditions;
  browser.wait(EC.visibilityOf(VerifyMobile.otpField),10000);
  browser.wait(EC.visibilityOf(RecoverPasswordPage.newPassword),10000);
  browser.sleep(2000);
  console.log(otpCode + 'this is the otp to put on the otf field');
  xx='30';
  console.log(xx);
  VerifyMobile.otpField.clear().sendKeys(otpCode);
  RecoverPasswordPage.newPassword.clear().sendKeys(configFile.RECOVER_PASSWORD_PAGE.newPassword);
  VerifyMobile.otpVerifybutton.click();
  browser.sleep(10000);
}
});

   it('login with the new password', function() {
     xx="66";
     console.log(xx);
    browser.sleep(10000);
	browser.get(configFile.HTTP_HOST);
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
	LoginPage.loginProcess(newEmailSignup, configFile.RECOVER_PASSWORD_PAGE.newPassword);
}else {
  LoginPage.loginProcess(newMobileSignup, configFile.RECOVER_PASSWORD_PAGE.newPassword);
}
	browser.sleep(10000);
	expect(DashboardPage.menu().isPresent()).toBe(true);

  });

});
