/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';
require ('./helppopup.po.js');
require('./dashboard.po.js');
var configFile = require('./e2e.json');

var LoginPage = function() {

  this.mobileField = element(by.css('input#mobile'));
  this.amountField = element(by.css('input#amount'));
  this.sendBtn = element(by.css('button#intra'));
  this.sendEOD = element(by.css('a[target="_blank"]'));


  this.bannerImg = element(by.css('.image__centered img'));
  this.pageTitle = element(by.css('.marketing__title h1'));
  this.pageMsg = element(by.css('.marketing__title p'));
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    this.emailInput = element(by.model('credentials.email'));
  }else{
    this.emailInput = element(by.model('credentials.username'));
  };
  this.pwdInput = element(by.css('input[type="password"]'));
  this.submitBtn = element(by.css('form .section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  //this.errorBanner = element(by.css('.error-banner'));
  this.errorBanner = element(by.css('display-errors[messageicon="mcw-common-alert"]'));



  this.setEmail = function(email){
	  this.emailInput.clear();
	  this.emailInput.sendKeys(email);
  }

  this.setPassword = function(email){
	  this.pwdInput.clear();
	  this.pwdInput.sendKeys(email);
  }

  this.clickLogin = function(email){
	  this.submitBtn.click();
  }

  this.loginProcess = function(emailadd, passWord){
	  this.setEmail(emailadd);
	  this.setPassword(passWord);
	  this.clickLogin();
  }

    //
  this.contactUs = function() {
    return element(by.css('a[ng-dialog="app/components/help/partials/help.html"]'));
  };

  this.openContactUs = function() {
    this.contactUs().click();
    return require('./helppopup.po.js');
  };

  this.emailAddress = function() {
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    return element(by.model('credentials.email'));
  }else{
    return element(by.model('credentials.username'));
  }
  };

  this.password = function() {
    return element(by.model('credentials.password'));
  };

  this.loginButton = function() {
    return element(by.css('button[ng-disabled="loginForm.$invalid"]'));
  };

  this.clickLoginButton = function() {
    this.loginButton().click();
    return require('./dashboard.po.js');
  };

  this.signupButton = element(by.css('a[href="/auth/create/"]'));
};

module.exports = new LoginPage();
