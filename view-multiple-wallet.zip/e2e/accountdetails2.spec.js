'use strict';

describe('Account Detail page', function () {
  var VerifyEmailPage = require('./verifyemail.po');
  var LoginPage = require('./login.po');
  var ChangePasswordPage = require('./changepassword.po');
  var SignUpPage = require('./signup.po');
  var DashboardPage = require('./dashboard.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var AccountDetailPage =require('./accountdetails.po');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  var full_name = configFile.ACCOUNT_INFO.FIRST_NAME + " " + configFile.ACCOUNT_INFO.LAST_NAME;
  var mobileNumVerify = configFile.MOBILE_NUMBER_AREA_CODE + " " + newMobileSignup;
  require('./waitReady.js');


  beforeEach(function () {
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });

  it('should verify the popup for email verification is displayed', function() {

	Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(25000);

	expect(VerifyEmailPage.verifyEmailmainPopup.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailimage.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmaildescription.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailbutton.isPresent()).toBe(true);
    expect(VerifyEmailPage.verifyEmailpopupClose.isPresent()).toBe(true);
  });


  it('verify account information in account details', function(){
    browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);

    AccountDetailPage.verifyAccountInfo(full_name, mobileNumVerify, newEmailSignup);

  });

  it('complete personal info and addresses', function(){
    AccountDetailPage.completePersonalInfo(Utility.randomIdentityNumberGenerator('M'));
    AccountDetailPage.completeResidentialAddressInfo();
    AccountDetailPage.completeBillingAddressInfo();
    browser.sleep(10000);
  });

  it('verify all inforamtion was saved correctly', function(){

    AccountDetailPage.verifyPersonalInfo(configFile.ACCOUNTS_PAGE.personalInfovalues.title, configFile.ACCOUNTS_PAGE.personalInfovalues.gender, configFile.ACCOUNTS_PAGE.personalInfovalues.dateOfBirth, configFile.ACCOUNTS_PAGE.personalInfovalues.country);
    AccountDetailPage.adressTab.click();
    browser.sleep(5000);
    AccountDetailPage.verifyResidentialInfo(configFile.ACCOUNTS_PAGE.residentialValues.address_1, configFile.ACCOUNTS_PAGE.residentialValues.address_2, configFile.ACCOUNTS_PAGE.residentialValues.city, configFile.ACCOUNTS_PAGE.residentialValues.state, configFile.ACCOUNTS_PAGE.residentialValues.postalCode, configFile.ACCOUNTS_PAGE.residentialValues.country);
    AccountDetailPage.verifyBillingInfo(configFile.ACCOUNTS_PAGE.billingValues.address_1, configFile.ACCOUNTS_PAGE.billingValues.address_2, configFile.ACCOUNTS_PAGE.billingValues.city, configFile.ACCOUNTS_PAGE.billingValues.state, configFile.ACCOUNTS_PAGE.billingValues.postalCode, configFile.ACCOUNTS_PAGE.billingValues.country);

  });


  it('verify successful update of residential address', function() {

    //change
    AccountDetailPage.changeResidential(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode, configFile.ACCOUNTS_PAGE.changeResidentialValues.city, configFile.ACCOUNTS_PAGE.changeResidentialValues.state);
    AccountDetailPage.verifyChangedResidential(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode);

    //verify
  });

  it('verify successful update of billing address', function() {

    //change
    AccountDetailPage.changeBilling(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode);
    AccountDetailPage.verifyChangedBilling(configFile.ACCOUNTS_PAGE.changeResidentialValues.address_1, configFile.ACCOUNTS_PAGE.changeResidentialValues.address_2, configFile.ACCOUNTS_PAGE.changeResidentialValues.postalCode);
    //verify
  });

});
