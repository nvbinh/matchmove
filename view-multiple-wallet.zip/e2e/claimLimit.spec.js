'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./protractor-config-files/SGMCconfig.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var KycValidationPage = require('./kycvalidation.po.js');
var AdminetPage = require('./adminet.po.js');
var TransferClaimPage = require('./transferClaim.po.js');
var DataFilePage = require('./datafiles.po.js');

describe('', function() {

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};	

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;

	var mobileNumber1 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var mobileNumber2 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var mobileNumber3 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var mobileNumber4 = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);


	it ('Create Post_KYC account successfully', function() {

		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		var genderIsClickable = EC.elementToBeClickable(AccountDetailPage.genderMale);
		var randomID = Utility.autoGenerateMobile(12, 8);
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);
		var kycLinkIsClickable = EC.elementToBeClickable(kycLink);
		var uploadImageIsVisibility = EC.visibilityOf(KycValidationPage.uploadImage);
		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);
		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);
		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);
		var image4 = './KYC_Image/image4.png';
		var image4Path = path.resolve(__dirname, image4);
		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var KYCsubmissionDetailsIsVisibility = EC.visibilityOf(AdminetPage.KYCsubmissionDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationRequiredBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fVerificationRequiredBanner);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var alreadySubmitYCSIsPresence = EC.presenceOf(AdminetPage.alreadySubmitYCS);	
		var approveBtnIsClickable = EC.elementToBeClickable(AdminetPage.approveBtn);
		var approveBtnIsInvisibility = EC.invisibilityOf(AdminetPage.approveBtn);
		
		///

		browser.get(configFile.HTTP_HOST);
		LoginPage.signupBtn.click();
		browser.sleep(5000);
		//SignUpPage.emailInput.sendKeys(emailAddress);
		SignUpPage.firstNameInput.sendKeys('match');
		SignUpPage.lastNameInput.sendKeys('move');
		SignUpPage.preferredNameInput.sendKeys('user');
		SignUpPage.mobileInput.sendKeys(mobileNumber1);
		console.log(mobileNumber1);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()		
		SignUpPage.submitBtn.click();
		
		browser.wait(accountMenuIsClickable).then(function() {
			
			browser.sleep(3000);
			browser.actions().keyDown(protractor.Key.COMMAND).click(DashboardPage.accountMenu).keyUp(protractor.Key.COMMAND).perform();
			DashboardPage.accountMenu.click();
			browser.wait(genderIsClickable).then(function() {
				browser.sleep(2000);
				browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
			});
			AccountDetailPage.genderMale.click();
			AccountDetailPage.userTitle(1);
			if (configFile.SPASS_TYPE) {
					AccountDetailPage.spassID.click();
			}
			else {
				AccountDetailPage.passportID.click();
			}
			AccountDetailPage.identificationNumber.sendKeys(randomID);
			AccountDetailPage.completeProfile.click();
			browser.sleep(15000);
			if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
		      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
		      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
		      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
		      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
		      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
		    }
			AccountDetailPage.sameAddressBox.click();
			AccountDetailPage.updateAddress.click();
			browser.sleep(5000);
			browser.wait(kycLinkIsClickable).then(function() {
				browser.sleep(4000);
				AccountDetailPage.kycLink.click();
				browser.wait(uploadDocumentsBtnIsClickable).then(function() {
					browser.sleep(2000);
					KycValidationPage.uploadDocumentsBtn.click();
					browser.wait(uploadImageIsVisibility).then(function() {
						browser.sleep(2000);
						KycValidationPage.inputFile.sendKeys(image1Path);
						KycValidationPage.inputFile.sendKeys(image2Path);
						KycValidationPage.inputFile.sendKeys(image3Path);
						KycValidationPage.inputFile.sendKeys(image4Path);
						browser.sleep(4000);
						KycValidationPage.submitDocumentBtn.click();
						browser.wait(KYCprogressIsPresence).then(function() {						
							browser.getAllWindowHandles().then(function(handles) {
								var newWindowHandle = handles[1];
								browser.switchTo().window(newWindowHandle).then(function() {
									browser.get(configFile.HTTP_HOST_ADMINET);
									AdminetPage.emailfield.sendKeys(configFile.ADMINET_ACCOUNT.EMAIL);
									AdminetPage.passwordfield.sendKeys(configFile.ADMINET_ACCOUNT.PASSWORD);
									AdminetPage.loginButton.click();
									browser.wait(actionMenuIsClickable).then(function() {
										AdminetPage.actionMenu.click();
										browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
											browser.sleep(3000);
											AdminetPage.KYCsubmissionDetails.click();
										});
										
										browser.wait(generateBtnIsClickable).then(function() {
											AdminetPage.searchTypeMobile.click();
											AdminetPage.searchKeyword.sendKeys(mobileNumber1);
											AdminetPage.generateBtn.click();
											browser.wait(actionMenuIsClickable).then(function() {
												AdminetPage.actionMenu.click();
												browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
													browser.sleep(3000);
													AdminetPage.KYCsubmissionDetails.click();
												});
												browser.wait(f2fVerificationBtnIsClickable).then(function() {
													AdminetPage.f2fVerificationBtn.click();
													browser.wait(f2fVerificationApprovalBtnIsClickable).then(function() {
														browser.sleep(1000);
														AdminetPage.f2fVerificationApprovalBtn.click();
														browser.wait(approveBtnIsClickable).then(function() {
															browser.sleep(1000);
															AdminetPage.approveBtn.click();
															browser.wait(approveBtnIsInvisibility).then(function() {
																browser.sleep(20000);
																expect(true).toBe(true);
															});
														});	
													});							
												});
											});			
										});				
									});
								});
							});	

						});	
					});
				});
			});						
		});
	});

	it ('Create 1st pre-kyc and topup with max amount successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);
		var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);

		browser.sleep(3000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(2000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					browser.sleep(15000);
					LoginPage.signupBtn.click();
					browser.sleep(5000);
					SignUpPage.firstNameInput.sendKeys('Match');
					SignUpPage.lastNameInput.sendKeys('Move');
					SignUpPage.preferredNameInput.sendKeys('User');
					SignUpPage.mobileInput.sendKeys(mobileNumber2);
					console.log(mobileNumber2);
					if (configFile.SIGNUP_PAGE.nationalityEnabled) {
						SignUpPage.nationality.$('[value="Indian"]').click();
					};
					SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
					SignUpPage.tncCheckbox.click()		
					SignUpPage.submitBtn.click();

					var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);		
					browser.wait(topupMenuIsClickable).then(function() {
						browser.sleep(2000);
						DashboardPage.topupMenu.click();
						browser.wait(providerEasypayImageIsVisibility).then(function() {
							TopupPage.walletBalance.getInnerHtml().then(function(balance) {
								var balanceText = balance.replace(",", "");				
									configFile.WALLET_BALANCE.balanceBefore = parseFloat(balanceText);
							});		
							TopupPage.providerEasypay.click();
							browser.wait(topupBtnIsClickable).then(function() {
								TopupPage.amountCustom.click();
								configFile.TOPUP.customAmount = DataFilePage.maxPreKycAmount;
								TopupPage.amountCustomText.sendKeys(configFile.TOPUP.customAmount);
								TopupPage.topupBtn.click();
							});
							browser.wait(windowCount(3), 60000);
							browser.getAllWindowHandles().then(function(handles) {
								var newWindowHandle = handles[2];
								browser.switchTo().window(newWindowHandle).then(function() {
									browser.wait(cancelBtnIsClickable).then(function() {
										browser.sleep(2000);
										EasyGateway.visaChannel.click();
										browser.sleep(2000);
										EasyGateway.creditCardNum.sendKeys('4111111111111111');
										EasyGateway.expMonth.click();
										EasyGateway.expYear.click();
										EasyGateway.creditCardCvv2.sendKeys('989');
										EasyGateway.creditCardName.sendKeys('auto tester');
										EasyGateway.submitBtn.click();				
									});
								});
							});

							browser.wait(transactionSuccessfulIsVisibility).then(function() {
								browser.getAllWindowHandles().then(function(handles) {
									browser.driver.close().then(function () {
										browser.switchTo().window(handles[0]).then(function() {
											browser.sleep(90000); //waiting 90 seconds for balance to be updated
											browser.refresh();
				    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
											browser.wait(walletBalanceIsPresence).then(function() {
												TopupPage.walletBalance.getInnerHtml().then(function(balance) {
													configFile.WALLET_BALANCE.balanceAfter = balance;
													var amountIncrese = configFile.WALLET_BALANCE.balanceAfter - configFile.WALLET_BALANCE.balanceBefore;
													expect(amountIncrese).toEqual(configFile.TOPUP.customAmount);		
												});				
											});
										});
									});
								});
							});
						});	
					});	

				});	
			});
		});
		
	});

	it ('Send 1 SGD to Post_KYC account successfully', function() {

		///
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(1);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Send 10 SGD to Post_KYC account successfully', function() {

		///
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		browser.sleep(1000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				///
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(10);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
				///
			});
		});	
	});

	it ('Send 489 SGD to Post_KYC account successfully', function() {

		///
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		browser.sleep(1000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				///
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(489);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Create 2nd pre-kyc and topup with max amount successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(2000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					browser.sleep(2000);
					LoginPage.signupBtn.click();
					browser.sleep(20000);
					SignUpPage.firstNameInput.sendKeys('Match');
					SignUpPage.lastNameInput.sendKeys('Move');
					SignUpPage.preferredNameInput.sendKeys('User');
					SignUpPage.mobileInput.sendKeys(mobileNumber3);
					console.log(mobileNumber3);
					if (configFile.SIGNUP_PAGE.nationalityEnabled) {
						SignUpPage.nationality.$('[value="Indian"]').click();
					};
					SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
					SignUpPage.tncCheckbox.click()		
					SignUpPage.submitBtn.click();

					var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);		
					browser.wait(topupMenuIsClickable).then(function() {
						browser.sleep(2000);
						var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
						var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
						var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
						var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);
						var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);

						browser.sleep(2000);
						DashboardPage.topupMenu.click();
						browser.wait(providerEasypayImageIsVisibility).then(function() {
							TopupPage.walletBalance.getInnerHtml().then(function(balance) {
								var balanceText = balance.replace(",", "");				
									configFile.WALLET_BALANCE.balanceBefore = parseFloat(balanceText);
							});		
							TopupPage.providerEasypay.click();
							browser.wait(topupBtnIsClickable).then(function() {
								TopupPage.amountCustom.click();
								configFile.TOPUP.customAmount = DataFilePage.maxPreKycAmount;
								TopupPage.amountCustomText.sendKeys(configFile.TOPUP.customAmount);
								TopupPage.topupBtn.click();
							});
							browser.wait(windowCount(3), 60000);
							browser.getAllWindowHandles().then(function(handles) {
								var newWindowHandle = handles[2];
								browser.switchTo().window(newWindowHandle).then(function() {
									browser.wait(cancelBtnIsClickable).then(function() {
										EasyGateway.visaChannel.click();
										browser.sleep(2000);
										EasyGateway.creditCardNum.sendKeys('4111111111111111');
										EasyGateway.expMonth.click();
										EasyGateway.expYear.click();
										EasyGateway.creditCardCvv2.sendKeys('989');
										EasyGateway.creditCardName.sendKeys('auto tester');
										EasyGateway.submitBtn.click();				
									});
								});
							});

							browser.wait(transactionSuccessfulIsVisibility).then(function() {
								browser.getAllWindowHandles().then(function(handles) {
									browser.driver.close().then(function () {
										browser.switchTo().window(handles[0]).then(function() {
											browser.sleep(90000); //waiting 90 seconds for balance to be updated
											browser.refresh();
				    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
											browser.wait(walletBalanceIsPresence).then(function() {
												TopupPage.walletBalance.getInnerHtml().then(function(balance) {
													configFile.WALLET_BALANCE.balanceAfter = balance;
													var amountIncrese = balanceAfter - configFile.WALLET_BALANCE.balanceBefore;
													expect(amountIncrese).toEqual(configFile.TOPUP.customAmount);		
												});				
											});
										});
									});
								});
							});
						});	
					});	
				});	
			});
		});
	});

	it ('Send 200 SGD to Post_KYC account successfully', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);
				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(200);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Send 299 SGD to Post_KYC account successfully', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);
				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(299);
				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Send 1 SGD to Post_KYC account successfully', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
		var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);
				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(1);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});
	
	it ('Create 3rd pre-kyc and topup with max amount successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);
		var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(2000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					browser.sleep(2000);
					LoginPage.signupBtn.click();
					browser.sleep(20000);
					SignUpPage.firstNameInput.sendKeys('Match');
					SignUpPage.lastNameInput.sendKeys('Move');
					SignUpPage.preferredNameInput.sendKeys('User');
					SignUpPage.mobileInput.sendKeys(mobileNumber4);
					console.log(mobileNumber4);
					if (configFile.SIGNUP_PAGE.nationalityEnabled) {
						SignUpPage.nationality.$('[value="Indian"]').click();
					};
					SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
					SignUpPage.tncCheckbox.click()		
					SignUpPage.submitBtn.click();

					var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);		
					browser.wait(topupMenuIsClickable).then(function() {
						browser.sleep(4000);
						DashboardPage.topupMenu.click();
						browser.wait(providerEasypayImageIsVisibility).then(function() {
							TopupPage.walletBalance.getInnerHtml().then(function(balance) {
								var balanceText = balance.replace(",", "");				
									configFile.WALLET_BALANCE.balanceBefore = parseFloat(balanceText);
							});		
							TopupPage.providerEasypay.click();
							browser.wait(topupBtnIsClickable).then(function() {
								TopupPage.amountCustom.click();
								configFile.TOPUP.customAmount = DataFilePage.maxPreKycAmount;
								TopupPage.amountCustomText.sendKeys(configFile.TOPUP.customAmount);
								TopupPage.topupBtn.click();
							});
							browser.wait(windowCount(3), 60000);
							browser.getAllWindowHandles().then(function(handles) {
								var newWindowHandle = handles[2];
								browser.switchTo().window(newWindowHandle).then(function() {
									browser.wait(cancelBtnIsClickable).then(function() {
										EasyGateway.visaChannel.click();
										browser.sleep(2000);
										EasyGateway.creditCardNum.sendKeys('4111111111111111');
										EasyGateway.expMonth.click();
										EasyGateway.expYear.click();
										EasyGateway.creditCardCvv2.sendKeys('989');
										EasyGateway.creditCardName.sendKeys('auto tester');
										EasyGateway.submitBtn.click();				
									});
								});
							});

							browser.wait(transactionSuccessfulIsVisibility).then(function() {
								browser.getAllWindowHandles().then(function(handles) {
									browser.driver.close().then(function () {
										browser.switchTo().window(handles[0]).then(function() {
											browser.sleep(90000); //waiting 90 seconds for balance to be updated
											browser.refresh();
				    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
											browser.wait(walletBalanceIsPresence).then(function() {
												TopupPage.walletBalance.getInnerHtml().then(function(balance) {
													configFile.WALLET_BALANCE.balanceAfter = balance;
													var amountIncrese = configFile.WALLET_BALANCE.balanceAfter - configFile.WALLET_BALANCE.balanceBefore;
													expect(amountIncrese).toEqual(configFile.TOPUP.customAmount);		
												});				
											});
										});
									});
								});
							});
						});	
					});	
				});	
			});
		});
	});
	

	it ('Send 1 SGD to Post_KYC account successfully', function() {

		///
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				///
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(1);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
				///
			});
		});	
	});

	it ('Send 1 SGD to Post_KYC account successfully again', function() {

		///
		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(1);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});

	it ('Send 1 SGD to Post_KYC account successfully again', function() {

		var sendMenuIsClickable = EC.elementToBeClickable(DashboardPage.sendMenu);
		var sendAmountIsVisibility = EC.visibilityOf(TransferClaimPage.sendAmount);
		browser.sleep(10000);
		browser.wait(sendMenuIsClickable).then(function() {			
			DashboardPage.sendMenu.click();
			browser.wait(sendAmountIsVisibility).then(function() {
				browser.sleep(1000);
				TransferClaimPage.mobileMode.click();
				browser.sleep(1000);
				TransferClaimPage.mobileTransferInput.sendKeys(mobileNumber1);

				var transferBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.transferBtn);
				var printReceiptLinkIsClickable = EC.elementToBeClickable(TransferClaimPage.printReceiptLink);

				browser.sleep(1000);
				TransferClaimPage.messageInput.clear();
				TransferClaimPage.messageInput.sendKeys('This is the transfer done via automation script');
				TransferClaimPage.amountTransfer.clear();
				TransferClaimPage.amountTransfer.sendKeys(1);

				browser.wait(transferBtnIsClickable).then(function() {
					TransferClaimPage.transferBtn.click();
					browser.wait(printReceiptLinkIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(90000);
					});
				});
			});
		});	
	});	

	it ('Claim first transaction successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);
		
		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});		
		LoginPage.submitBtn.click();

		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(claimSuccessMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(2000);
				});
			});
		});
	});

	it ('Claim 2nd transaction successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		
		LoginPage.submitBtn.click();
		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(claimSuccessMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});
	});

	it ('Claim 3rd transaction successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		
		LoginPage.submitBtn.click();
		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(claimSuccessMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});
	});

	it ('Claim 4th transaction successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		
		LoginPage.submitBtn.click();
		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(claimSuccessMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});
	});

	it ('Claim 5th transaction successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});		
		LoginPage.submitBtn.click();

		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.refresh();

			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(claimSuccessMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});
	});

	it ('Claim 6th transaction successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast.claimBtn);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		
		LoginPage.submitBtn.click();
		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(claimSuccessMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(1000);
				});
			});
		});
	});

	it ('Claim 7th transaction - reach limit message ', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var claimMenuIsClickable = EC.elementToBeClickable(DashboardPage.claimMenu);
		var reachLimitMessageIsVisibility = EC.visibilityOf(TransferClaimPage.reachLimitMessage);
		var claimBtnIsClickable = EC.elementToBeClickable(TransferClaimPage.claimBtnLast);
		var claimSuccessMessageIsVisibility = EC.visibilityOf(TransferClaimPage.claimSuccessMessage);

		browser.sleep(2000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber1);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	
		
		LoginPage.submitBtn.click();
		browser.wait(claimMenuIsClickable).then(function() {
			browser.sleep(30000);
			DashboardPage.claimMenu.click();
			browser.sleep(30000);
			browser.wait(claimBtnIsClickable).then(function() {
				browser.sleep(5000);
				TransferClaimPage.claimBtnLast.click();
				browser.wait(reachLimitMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(500);
				});
			});
		});
	});

});