'use strict';

describe('Verify email 2', function () {
  var VerifyEmailPage = require('../verifyemail.po');
  var LoginPage = require('../login.po');
  var SignUpPage = require('../signup.po');
  var ChangePasswordPage = require('../changepassword.po');
  require('../waitReady.js');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var DashboardPage = require('../dashboard.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);


  beforeEach(function () {
  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });



  it('sign up', function() {

	Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(10000);
	browser.sleep(15000);
  });
	/*
	browser.get(TestData.url + '/wallet/create/');
	browser.sleep(5000);
	SignUpPage.emailInput.sendKeys(newEmailSignup);
	SignUpPage.firstNameInput.sendKeys('mike');
    SignUpPage.lastNameInput.sendKeys('x');
	SignUpPage.preferredNameInput.sendKeys('mikex');
	SignUpPage.mobileInput.sendKeys(TestData.randommobileNonExisting('24'));
    SignUpPage.pwdInput.sendKeys(TestData.vCardpassword);
    SignUpPage.submitBtn.click();
	browser.sleep(10000);
	*/

	it('resend email', function() {
	//click verify email
    	VerifyEmailPage.verifyEmailbutton.click();
	browser.sleep(15000);
	browser.sleep(10000);

	//verify sucess popup present in dom
	expect(VerifyEmailPage.sucessPopup.isPresent()).toBe(true);
	expect(VerifyEmailPage.sucessPopupText.isPresent()).toBe(true);
	expect(VerifyEmailPage.sucessPopupTextdetail.isPresent()).toBe(true);

	//verify sucess popup displays
	expect(VerifyEmailPage.sucessPopup.isDisplayed()).toBe(true);
	expect(VerifyEmailPage.sucessPopupText.isDisplayed()).toBe(true);
	expect(VerifyEmailPage.sucessPopupTextdetail.isDisplayed()).toBe(true);


	//click resend button
	expect(VerifyEmailPage.resendEmailButton.isPresent()).toBe(true);
	expect(VerifyEmailPage.resendClosePopup.isPresent()).toBe(true);

	VerifyEmailPage.resendEmailButton.click();

	browser.sleep(3000);

	expect(VerifyEmailPage.resendEmailNotif.isPresent()).toBe(true);
	});

	it('go to email and verify email', function() {
	browser.ignoreSynchronization = true;
    browser.get('https://gmail.com');
	browser.sleep(10000);

	var emailField = element(by.id('Email'));
	var nextButton = element(by.id('next'));
	var passwordField = element(by.id('Passwd'));
	var signInButton = element(by.id('signIn'));

	//var emailSubject = element(by.id(':2x'));
	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
	//var recoverPasswordButton = element(by.css('target=_blank'));
	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	var persistentCookie = element(by.css('#PersistentCookie'));

	//browser.sleep(120000);

	emailField.isDisplayed().then(function(result){
		if(result){
			emailField.sendKeys(configFile.EXISTING_EMAIL);
			nextButton.click();
		}
		else{
		}
	});

	browser.sleep(3000);

	passwordField.isPresent().then(function(result){
		if(result){
			persistentCookie.isPresent().then(function(present){
				if(present){
					persistentCookie.isSelected().then(function(select){
						if(select){
							persistentCookie.click();
						}
					});
				}
			passwordField.sendKeys(configFile.GMAIL_PASSWORD);
			signInButton.click();

			});
		}
		else{
		}
	});

	browser.sleep(5000);

	expect(emailSubject.waitReady()).toBeTruthy();
	emailSubject.click();

	browser.sleep(5000);


	expect(recoverPasswordButton.waitReady()).toBeTruthy();
	recoverPasswordButton.click();

	browser.sleep(10000);

	browser.getAllWindowHandles().then(function (handles) {
	  var secondWindowHandle = handles[1];
	  var firstWindowHandle = handles[0];

	  browser.switchTo().window(firstWindowHandle)
	  .then(function () {
	    browser.sleep(2000);
	    element(by.css('.gb_8a')).click();
	    browser.sleep(2000);
	    element(by.css('#gb_71')).click();
	    browser.close();
	  })
	  .then(function () {
        browser.ignoreSynchronization = false;
        browser.switchTo().window(secondWindowHandle)
	  })
	  .then(function () {
		browser.sleep(12000);
		expect(LoginPage.emailInput.isPresent()).toBe(true);
		expect(LoginPage.pwdInput.isPresent()).toBe(true);
	  });

	});
  });



});
