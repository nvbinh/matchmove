'use strict';
var configFile = require('./e2e.json');
var TopupPage = function() {

	//Easypay
	this.providerEasypayImage = element(by.css('img[src="https://vcard-assets.s3.amazonaws.com/payments/Easypay2.png"]'));
	this.minValue = element.all(by.css('a[href="/wallet/topup/enter/Easypay2"] div.detail-topup ul.info-topup--details li p span.value-amount')).first();
	this.maxValue = element.all(by.css('a[href="/wallet/topup/enter/Easypay2"] div.detail-topup ul.info-topup--details li p span.value-amount')).last();
	this.feePercent = element(by.css('a[href="/wallet/topup/enter/Easypay2"] div.detail-topup ul>li:nth-child(5)'));
	this.providerEasypay = element(by.css('a[href="/wallet/topup/enter/Easypay2"]'));

	//Razor
	this.providerRazorImage = element(by.css('img[src="https://vcard-assets.s3.amazonaws.com/payments/Razorpay.png"]'));
	this.minValueOfRazor = element.all(by.css('a[href="/wallet/topup/enter/Razorpay"] div.detail-topup ul.info-topup--details li p span.value-amount')).first();
	this.maxValueOfRazor = element.all(by.css('a[href="/wallet/topup/enter/Razorpay"] div.detail-topup ul.info-topup--details li p span.value-amount')).last();
	this.feePercentOfRazor = element(by.css('a[href="/wallet/topup/enter/Razorpay"] div.detail-topup ul>li:nth-child(5)'));
	this.providerRazorpay = element(by.css('a[href="/wallet/topup/enter/Razorpay"]'));




	this.topupBtn = element(by.cssContainingText('button', 'Top up'));
	this.amountCustom = element(by.css('input#amount-custom'));
	this.amountCustomText = element(by.css('input#amount-custom-text'));
	this.minWarningMessage = element(by.css('div[ng-messages="forms.topupEnter.customAmount.$error"] p[ng-message="min"]'));
	this.emptyWarningMessage = element(by.css('div[ng-messages="forms.topupEnter.customAmount.$error"] p[ng-message="fieldEmpty"]'));
	this.numberOnlyWarningMessage = element(by.css('div[ng-messages="forms.topupEnter.customAmount.$error"] p[ng-message="number"]'));
	this.maxWarningMessage = element(by.css('div[ng-messages="forms.topupEnter.customAmount.$error"] p[ng-message="max"]'));
	this.pre_definded_amount_10 = element(by.css('input#amount-10'));
	this.pre_definded_amount_500 = element(by.css('input#amount-500'));
	this.pre_definded_amount_1000 = element(by.css('input#amount-1000'));
	this.pre_definded_amount_5000 = element(by.css('input#amount-5000'));
	this.pre_definded_amount_10000 = element(by.css('input#amount-10000'));


	this.getFeeChargeAmount = function() {
		var feeCharge = element.all(by.css('div.detail-section p.value span.value-amount')).last();
		feeCharge.getInnerHtml().then(function(text) {
			return text;
		});
	};

	this.walletBalance = element.all(by.css('div[ng-if="widgetDataLoaded"] p.value-amount')).first();
	this.progressText = element(by.css('div.detail-status h4'));
	this.printReceipt = element(by.css('div.section-action a[onclick="window.print()"]'));
	this.printWindow = element(by.css('div#main-container'));
	this.cancelPrint = element.all(by.css('div.button-strip button.cancel')).first();
};

module.exports = new TopupPage();
