'use strict';
var configFile = require('./e2e.json');
//var configFile = require('./protractor-config-files/MUTHOOTconfig.json');
//var configFile = require('./protractor-config-files/PAYASIAconfig.json');
//var configFile = require('./protractor-config-files/centrum.json');

var GmailPage = function() {
	this.emailInput = element(by.id('Email'));
	this.nextBtn = element(by.id('next'));
	this.passwordInput = element(by.id('Passwd'));
	this.signInBtn = element(by.id('signIn'));
	this.verifyEmail = element(by.css('table tbody tr td a'));
	this.verifyAuthenEmail = element.all(by.cssContainingText('table tbody tr td a', configFile.VERIFY_EMAIL_TEXT.AuthenticationEmail));
	this.verifyChangeEmail = element.all(by.cssContainingText('table tbody tr td a', configFile.VERIFY_EMAIL_TEXT.ChangeEmail));

	this.expandEmail = element(by.css('div.ajR[data-tooltip="Show trimmed content"]'));
	this.expandEmails = element.all(by.css('div.ajR[data-tooltip="Show trimmed content"]'));

};

module.exports = new GmailPage();
