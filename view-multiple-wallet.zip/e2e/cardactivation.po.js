/*
*** for SGMC 
*/

'use strict';

var CardActivationPage = function() {
	this.purchaseACard = element(by.css('mm-tab-item:nth-child(2)'));
	this.orderACardBtn = element.all(by.cssContainingText('button.button-primary--medium', 'Order a Card')).first();
	this.orderCardPopup = element(by.css('div.ngdialog-content'));
	this.cancelBtn = element(by.css('button.button-secondary--medium'));
	this.orderCardBtn = element.all(by.css('button.button-primary--medium')).last();
	this.newCardOrderNotAllow = element(by.css('div.content-message--new-card-order-not-allowed'));
	this.activateACard = element(by.css('mm-tab-item:nth-child(3)'));
	this.activateCardOrderBtn = element(by.buttonText('Activate card order'));
	this.activateCardPopup = element.all(by.css('div.ngdialog-content')).first();
	this.cardNumberMode = element(by.css('v-tab[ng-if="cardNumberMode"]'));
	this.proxyNumberMode = element(by.css('v-tab[ng-if="proxyNumberMode"]'));
	this.proxyInp = element.all(by.model('cardNumber')).first();
	this.digitAllowMessage = element(by.cssContainingText('div.section-input p', 'digits allowed'));
	this.proxyNumberIsRequired = element(by.cssContainingText('div.section-input p', 'proxy number is required'));
	this.submitBtn = element.all(by.css('button[type="submit"]')).first();
	this.errorMessage = element.all(by.cssContainingText('div.msg-block__content', 'We encountered an unexpected error')).first();
	this.alreadyActivatedMessage = element.all(by.cssContainingText('div.msg-block__content', 'already activated')).first();
	this.otpInput = element(by.model('verification.otp'));
	this.verifyOtpBtn = element(by.css('button.button-primary--large'));
	this.resendLink = element(by.css('a[ng-click="resendToken()"]'));
	this.invalidOtpMessage = element(by.cssContainingText('div.msg-block__content p.ng-binding', 'OTP is Invalid'));

};

module.exports = new CardActivationPage();