'use strict'
var TopupPage = require('./topup.po.js');
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
//var configFile = require('./protractor-config-files/MUTHOOTconfig.json');
//var configFile = require('./protractor-config-files/PAYASIAconfig.json');
//var configFile = require('./protractor-config-files/centrum.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var RazorPopup = require('./razorpopup.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');

describe('Verify Notification', function() {
	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);

	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Sign up successfully', function() {
		browser.get(configFile.HTTP_HOST);
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		console.log(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click();
		SignUpPage.submitBtn.click();

		if (configFile.VERIFY_EMAIL_ENABLE){
			var verifyEmailClickable = EC.elementToBeClickable(VerifyEmailPage.verifyEmailbutton);
			browser.wait(verifyEmailClickable).then(function() {
				browser.sleep(1000);
				VerifyEmailPage.verifyEmailbutton.click();
				browser.sleep(5000);
				expect(VerifyEmailPage.resendEmailButton.isPresent()).toBe(true);
			});

			browser.sleep(30000); //waiting for verify email was sent to Gmail
			browser.get(configFile.GMAIL);

			var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.Authentication)).first();
			var emailIsClickable = EC.elementToBeClickable(emailSubjects);
			var expandIsPresence = EC.presenceOf(GmailPage.expandEmail);

			GmailPage.emailInput.sendKeys(configFile.G_EMAIL);
			GmailPage.nextBtn.click();

			browser.sleep(1000);
			GmailPage.passwordInput.sendKeys(configFile.G_PASSWORD);
			GmailPage.signInBtn.click();
			browser.wait(emailIsClickable).then(function() {
				emailSubjects.click();
			});

			browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {

				GmailPage.expandEmail.isPresent().then(function(result) {
					if(result) {
					GmailPage.expandEmails.count().then(function(count) {
						if (count >= 1) {
							GmailPage.expandEmails.last().click();
							}
						});
					}

				});
			});

			browser.sleep(1000);
					GmailPage.verifyAuthenEmail.count().then(function(count) {
				if (count > 1) {
					GmailPage.verifyAuthenEmail.last().click();
				}
				else {
					GmailPage.verifyAuthenEmail.first().click();
			}
		});

		browser.sleep(1000);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				expect(browser.getCurrentUrl()).toContain(configFile.HTTP_HOST);
			});
		});
		var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified email'));
		var verifyEmailSuccessIsVisibility = EC.visibilityOf(verifyEmailSuccess);
		browser.wait(verifyEmailSuccessIsVisibility).then(function() {

			var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);

			browser.wait(loginPageIsPresent).then(function() {
				LoginPage.emailInput.sendKeys(emailAddress);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});

			LoginPage.submitBtn.click();
		});

		}

		else {
			var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
			browser.wait(topupMenuIsClickable).then(function() {
				expect(true).toBe(true);
			});
		}
	});

	it ('Wallet Creation Notification', function() {

		browser.sleep(1000);
		var notificationBellIsClickable = EC.elementToBeClickable(DashboardPage.notificationBell);
		//var walletCreationNotification = element(by.cssContainingText('div.box-title span', 'Wallet Creation'));
		var walletCreationNotification = element.all(by.css('use[data-ng-href="#mcw-notification-_ACT_CARD_WALLET_CREATE"')).first();
		//var walletCreationNotificationIsVisible = EC.visibilityOf(walletCreationNotification);

		browser.wait(notificationBellIsClickable).then(function() {
			DashboardPage.notificationBell.click();
			browser.sleep(1000);
			DashboardPage.goToNotification.click();
		});

		expect(walletCreationNotification.isPresent()).toBe(true);
		//browser.wait(EC.visibilityOf(walletCreationNotification), 5000).then(function() {
		//	expect(true).toBe(true);
		//});
	});

	it ('Email Verification Success', function() {
		if (configFile.VERIFY_EMAIL_ENABLE){
			var emailVerificationNotification = element(by.cssContainingText('div.box-title span', 'Email Verification Success'));
			expect(emailVerificationNotification.isPresent()).toBe(true);
		}
		else {
			expect(true).toBe(true);
		}
	});

	it ('Logout and Login to check Account Login notification', function() {
		var logoutLink = element(by.css('a[ng-click="logout()"]'));
		var notificationBellIsClickable = EC.elementToBeClickable(DashboardPage.notificationBell);
		logoutLink.click();


		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		browser.wait(loginPageIsPresent).then(function() {
			if (configFile.VERIFY_EMAIL_ENABLE){
				LoginPage.emailInput.sendKeys(emailAddress);
			}else{
				LoginPage.emailInput.sendKeys(mobileNumber);
			}
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);

		});

		LoginPage.submitBtn.click();

		if (configFile.VERIFY_EMAIL_ENABLE) {
			browser.wait(notificationBellIsClickable).then(function() {
				browser.sleep(1000);
			});
		}

		if (configFile.VERIFY_MOBILE_ENABLE) {
			var verifyMobileIsClickable = EC.elementToBeClickable(VerifyMobile.verifymobilebutton)
			browser.wait(verifyMobileIsClickable).then(function() {
				browser.sleep(500);
				VerifyMobile.verifymobilepopupClose.click();
			})
		}


		var accountLoginNotification = element.all(by.css('use[data-ng-href="#mcw-notification-_ACT_LOGGED_IN"]')).first();
		var accountLoginNotificationIsPresence = EC.presenceOf(accountLoginNotification);

		browser.wait(notificationBellIsClickable).then(function() {
			DashboardPage.notificationBell.click();
			browser.sleep(1000);
			DashboardPage.goToNotification.click();
		});

		//DashboardPage.notificationBell.click();
		//browser.sleep(1000);
		//DashboardPage.goToNotification.click();
		expect(accountLoginNotification.isPresent()).toBe(true);
		//browser.wait(accountLoginNotificationIsPresence).then(function() {
		//		browser.sleep(1000);
		//		expect(true).toBe(true);
		//});
	});

	it ('Account Details', function() {

		var accountMenu = element(by.linkText('Account'));
		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));
		var notificationBellIsClickable = EC.elementToBeClickable(DashboardPage.notificationBell);

		browser.wait(accountMenuIsClickable).then(function() {
			accountMenu.click();
		});


		browser.wait(genderIsClickable).then(function() {
			browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
		});

		element(by.css('input[value="male"]')).click();
		AccountDetailPage.userTitle(1);
		//
		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));

		if (configFile.SPASS_TYPE) {
				spassID.click();
		}
		else {
			passportID.click();
		}

		var randomID = Utility.autoGenerateMobile(12, 8);
		AccountDetailPage.identificationNumber.sendKeys(randomID);
		AccountDetailPage.completeProfile.click();

		browser.sleep(15000);

		if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
	      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
	      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
	      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
	      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
	      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
	    }
		AccountDetailPage.sameAddressBox.click();
		AccountDetailPage.updateAddress.click();

		var changeEmailLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.wait(changeEmailLinkIsClickable).then(function() {
			browser.sleep(1000);
			//var accountDetailsNotification = element.all(by.cssContainingText('div.box-title span', 'Account Details')).last();
			var accountDetailsNotification = element.all(by.css('use[data-ng-href="#mcw-notification-_ACT_USER_UPDATE"]')).first();
			var accountDetailsNotificationIsVisible = EC.visibilityOf(accountDetailsNotification);

			browser.wait(notificationBellIsClickable).then(function() {
				DashboardPage.notificationBell.click();
				browser.sleep(1000);
				DashboardPage.goToNotification.click();
			});
			//DashboardPage.notificationBell.click();
			//browser.sleep(1000);
			//DashboardPage.goToNotification.click();

			expect(accountDetailsNotification.isPresent()).toBe(true);

			//browser.wait(accountDetailsNotificationIsVisible).then(function() {
			//	browser.sleep(1000);
			//	expect(true).toBe(true);
			//});
		});
	});

	it ('Card Creation', function() {
		var homePage = element.all(by.cssContainingText('label.ng-binding', 'My Cards')).last();
		var loadCardIsClickable = EC.elementToBeClickable(LoadUnloadPage.loadCardLink);
		var getFirstCardbuttonIsClickable = EC.elementToBeClickable(DashboardPage.getFirstCardbutton);
		var cardCreationNotification = element.all(by.cssContainingText('div.box-title span', 'Card Creation')).last();
		var cardCreationNotificationIsVisible = EC.visibilityOf(cardCreationNotification);
		var verifyMobilePopupIsPresent = EC.presenceOf(VerifyMobile.verifymobilemainPopup);

		//homePage.click();
		browser.get(configFile.HTTP_HOST + configFile.DASHBOARD_PAGE.redirectionUrl);
		browser.wait(verifyMobilePopupIsPresent).then(function() {
			browser.sleep(500);
			VerifyMobile.verifymobilepopupClose.click();
		});

		browser.sleep(1000);

		browser.wait(getFirstCardbuttonIsClickable).then(function() {
			DashboardPage.getFirstCardbutton.click();
			browser.wait(loadCardIsClickable).then(function() {
				DashboardPage.notificationBell.click();
				browser.sleep(1000);
				DashboardPage.goToNotification.click();
				browser.wait(cardCreationNotificationIsVisible).then(function() {
					browser.sleep(1000);
					expect(true).toBe(true);
				})
			})
		});
	});

	it ('Topup Success Notification', function() {

		browser.sleep(2000);

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

		var providerRazorpayIsClickable = EC.elementToBeClickable(TopupPage.providerRazorpay);
		var paymentPopupIsPresence = EC.presenceOf(RazorPopup.paymentPopup);
		var successBtnIsPresence = EC.presenceOf(RazorPopup.successBtn);
		var cardPaymentMethodIsPresence = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);
		var payBtnIsClickable = EC.elementToBeClickable(RazorPopup.payBtn);

		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
		});

		browser.wait(EC.or(providerEasypayIsClickable, providerRazorpayIsClickable)).then(function() {
			TopupPage.providerEasypay.isPresent().then(function(result) {
			if (result) {

				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
					var balanceText = balance.replace(",", "");
					balanceBefore = parseFloat(balanceText);
				});
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 100;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(2), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[1];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
							EasyGateway.visaChannel.click();
							browser.sleep(2000);
							EasyGateway.creditCardNum.sendKeys('4111111111111111');
							EasyGateway.expMonth.click();
							EasyGateway.expYear.click();
							EasyGateway.creditCardCvv2.sendKeys('989');
							EasyGateway.creditCardName.sendKeys('auto tester');
							EasyGateway.submitBtn.click();
						});
					});
				});

				var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
				browser.wait(transactionSuccessfulIsVisibility).then(function() {
					browser.getAllWindowHandles().then(function(handles) {
						browser.driver.close().then(function () {
							browser.switchTo().window(handles[0]).then(function() {
								browser.sleep(90000); //waiting 90 seconds for balance to be updated
								browser.refresh();
	    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
								browser.wait(walletBalanceIsPresence).then(function() {
									TopupPage.walletBalance.getInnerHtml().then(function(balance) {
										balanceAfter = balance;
										var amountIncrese = balanceAfter - balanceBefore;
										expect(amountIncrese).toEqual(customAmount);
									});
								});
							});
						});
					});
				});

				var topupNotification = element(by.css('li.item-notification.notify-group--Easypay2.notification-Easypay2'));
				var topupNotificationIsPresence = EC.presenceOf(topupNotification);

				DashboardPage.notificationBell.click();
				browser.sleep(1000);
				DashboardPage.goToNotification.click();
				browser.wait(topupNotificationIsPresence).then(function() {
					browser.sleep(1000);
					expect(true).toBe(true);
				});
			}

			else {

				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceBefore = parseFloat(balanceText);
				});

				TopupPage.providerRazorpay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					topupAmount = 100;
					TopupPage.amountCustomText.sendKeys(topupAmount);
					TopupPage.topupBtn.click();
				});
				browser.sleep(15000);
				browser.switchTo().frame(0);
				browser.sleep(2000);
				RazorPopup.cardPaymentMethod.click();
				browser.wait(payBtnIsClickable).then(function() {
					RazorPopup.cardNumber.sendKeys(4111111111111111);
					RazorPopup.cardExpiry.sendKeys(1117);
					RazorPopup.cardCvv.sendKeys(989);
				});

				RazorPopup.payBtn.click();
				browser.wait(windowCount(3), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[2];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.sleep(15000);
						RazorPopup.successBtn.click();
						browser.wait(windowCount(2), 60000);
					});

					browser.switchTo().window(handles[1]).then(function() {
						var progressTextIsInvisibility = EC.invisibilityOf(TopupPage.progressText);
						browser.sleep(10000);
						expect(TopupPage.progressText.isPresent()).toBe(false);
					});
				});

				browser.sleep(90000); //waiting for 90s to see if balance is updated
				var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
				browser.refresh();
				browser.wait(walletBalanceIsPresence).then(function() {
					TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceAfter = parseFloat(balanceText);
						var amountIncrese = balanceAfter - balanceBefore;
						expect(amountIncrese).toEqual(topupAmount);
					});
				});


				var walletTopupNotification = element.all(by.cssContainingText('div.box-title span', 'Wallet Topup')).last();
				var walletTopupNotificationIsVisible = EC.visibilityOf(walletTopupNotification);
				DashboardPage.notificationBell.click();
				browser.sleep(1000);
				DashboardPage.goToNotification.click();
				browser.wait(walletTopupNotificationIsVisible).then(function() {
					browser.sleep(1000);
					expect(true).toBe(true);
				});

			}
			});
		});

	});

	it ('Topup failure (Muthoot, centrum)', function() {

		if (configFile.VERIFY_EMAIL_ENABLE) {
			expect(true).toBe(true);
		}

		else {
			var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
			var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
			var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
			var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

			browser.wait(topupMenuIsClickable).then(function() {
				DashboardPage.topupMenu.click();
			});

			TopupPage.providerEasypay.isPresent().then(function(result) {
				TopupPage.walletBalance.getInnerHtml().then(function(balance) {
					var balanceText = balance.replace(",", "");
					balanceBefore = parseFloat(balanceText);
				});
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 100;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(2), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[1];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
								EasyGateway.cancelBtn.click();
							});
						});
					browser.driver.close().then(function () {
						browser.switchTo().window(handles[0]).then(function() {
							var topupFailedNotification = element.all(by.cssContainingText('div.box-title span', 'Your topup was unsuccessful')).last();
							var topupFailedNotificationIsPresence = EC.presenceOf(topupFailedNotification);
							DashboardPage.notificationBell.click();
							browser.sleep(1000);
							DashboardPage.goToNotification.click();
							browser.wait(topupFailedNotificationIsPresence).then(function() {
								browser.sleep(1000);
								expect(true).toBe(true);
							});
						})
					});
				});
			});
		}
	});

});
