'use strict';

describe('Complete details', function () {
  //var VerifyEmailPage = require('./verifyemail.po');
  //var LoginPage = require('./login.po');
  var SignUpPage = require('../signup.po');
  var AccountDetailPage = require('../accountdetails.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var DashboardPage = require('../dashboard.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('../waitReady.js');

/*
  beforeEach(function () {
    //browser.get(TestData.url);
  });

  /*
    it('should signup successfully', function() {

	LoginPage.setScreenSize();

	browser.get(TestData.url);
	browser.sleep(5000);


	LoginPage.setEmail('matchmoveexistinguser+exemail@gmail.com');
    LoginPage.setPassword(TestData.vCardpassword);
	expect(LoginPage.submitBtn.isEnabled()).toBe(true);

    LoginPage.submitBtn.click();

	browser.sleep(5000);

	browser.get(TestData.url + '/#/wallet/details/list');
	browser.sleep(2000);

	AccountDetailPage.detailsSection(4, 10);
	//var subheader = element.all(by.css('.item-title'))
	//expect(subheader.count()).toBe(2);

	AccountDetailPage.genderDropdown(1);

	AccountDetailPage.userTitle(1);

	AccountDetailPage.identityInfo(0);

	browser.sleep(5000);



  });
  */

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('Sign up New user', function() {

	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(20000);
	browser.sleep(10000);
});

it('Verify all elements are displayed', function() {

	browser.sleep(5000);
  browser.sleep(5000);
  browser.sleep(5000);
	browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
	browser.sleep(2000);

	//make sure all fields are available
	AccountDetailPage.detailsSection(configFile.ACCOUNTS_PAGE.titleItem, configFile.ACCOUNTS_PAGE.section);

	expect(AccountDetailPage.accountTabs.isPresent()).toBe(true);
	expect(AccountDetailPage.adressTab.isPresent()).toBe(true);

	//AccountDetailPage.countminiDashboard(3);

	expect(AccountDetailPage.birthday.isPresent()).toBe(true);
	expect(AccountDetailPage.identificationNumber.isPresent()).toBe(true);
	expect(AccountDetailPage.conuntryOfissue.isPresent()).toBe(true);
	expect(AccountDetailPage.completeProfile.isPresent()).toBe(true);

	AccountDetailPage.adressTab.click();

	expect(AccountDetailPage.address1R.isPresent()).toBe(true);
	expect(AccountDetailPage.address2R.isPresent()).toBe(true);
	expect(AccountDetailPage.postalR.isPresent()).toBe(true);
	expect(AccountDetailPage.address1B.isPresent()).toBe(true);
	expect(AccountDetailPage.address2B.isPresent()).toBe(true);
	expect(AccountDetailPage.countryB.isPresent()).toBe(true);
	expect(AccountDetailPage.postalB.isPresent()).toBe(true);
	expect(AccountDetailPage.sameAddressBox.isPresent()).toBe(true);
	expect(AccountDetailPage.updateAddress.isPresent()).toBe(true);

  });

  it('verify age most be above 18', function() {
  if (configFile.ACCOUNTS_PAGE.min_age == "18"){
  	browser.sleep(2000);
  	//make sure all fields are available
  	AccountDetailPage.accountTabs.click();
    AccountDetailPage.birthday.sendKeys('2016-01-10');
  	expect(AccountDetailPage.dobError.isPresent()).toBe(true);
  	//AccountDetailPage.birthday.sendKeys(protractor.Key.BACK_SPACE);
  	AccountDetailPage.birthday.clear();
  	AccountDetailPage.accountTabs.click();
  	AccountDetailPage.birthday.sendKeys('1975-01-10');
  	AccountDetailPage.accountTabs.click();
  	expect(AccountDetailPage.dobError.isDisplayed()).toBe(false);
  }
  });

  it('verify invalid NRIC', function() {
    if (configFile.ACCOUNTS_PAGE.nricUsed == "true"){
    	browser.sleep(2000);
    	AccountDetailPage.genderDropdown(1);
    	AccountDetailPage.userTitle(1);
    	//AccountDetailPage.conuntryOfissue.$('[label="Singapore"]').click();
    	AccountDetailPage.identityInfo(0);
    	AccountDetailPage.identificationNumber.sendKeys(Utility.randomIdentityNumberGenerator('AB'));
    	AccountDetailPage.completeProfile.click();
    	browser.sleep(700);
    	expect(AccountDetailPage.nricError.isPresent()).toBe(true);

    	//efdc87bae426b8f893b491cf703a827a
    }
  });

  it('verify successful update of personal info', function() {

	browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
	browser.sleep(2000);
	AccountDetailPage.genderDropdown(1);
	AccountDetailPage.userTitle(1);

	//AccountDetailPage.conuntryOfissue.$('[label="Singapore"]').click();
	AccountDetailPage.identityInfo(2);
	AccountDetailPage.identificationNumber.sendKeys(Utility.randomIdentityNumberGenerator('11'));
	//AccountDetailPage.birthday.clear();
	//AccountDetailPage.accountTabs.click();
        //AccountDetailPage.birthday.click();
	AccountDetailPage.birthday.sendKeys('1975-01-10');
	AccountDetailPage.completeProfile.click();
	//browser.sleep(2000);
	expect(AccountDetailPage.address1B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.nricError.isPresent()).toBe(false);
	AccountDetailPage.adressTab.click();
	browser.sleep(2000);

  });
  /*
  it('verify details are correctly updated in the profile mini dashboard', function() {

	AccountDetailPage.countminiDashboard(7);

  });
  */

  it('verify address 1 will accept valid values', function() {

	browser.sleep(5000);
	AccountDetailPage.address1R.sendKeys('Telok');
	AccountDetailPage.address1R.getAttribute('value').then(function (value) {
	expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty address 1', function() {

	AccountDetailPage.address1R.clear();
	expect(AccountDetailPage.address1Rerror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when address 1 is more than prescride number of char', function() {

	AccountDetailPage.address1R.sendKeys('thisaddressmorethanthirtyfivecharacters');
	expect(AccountDetailPage.address1Rerror.isDisplayed()).toBe(true);

  });

  it('verify address 2 will accept valid values', function() {

	AccountDetailPage.address2R.sendKeys('Telok');
	AccountDetailPage.address2R.getAttribute('value').then(function (value) {
	expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty address 2', function() {

	AccountDetailPage.address2R.clear();
	expect(AccountDetailPage.address2Rerror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when address 2 is more than prescride number of char', function() {

	AccountDetailPage.address2R.sendKeys('thisaddressmorethanthirtyfivecharacters');
	expect(AccountDetailPage.address2Rerror.isDisplayed()).toBe(true);

  });

  it('verify postal code will accept valid values', function() {

	AccountDetailPage.postalR.sendKeys('358249');
	AccountDetailPage.postalR.getAttribute('value').then(function (value) {
	expect(value).toEqual('358249')});

  });

  it('verify error messeage when postal code has less than prescride number of char', function() {

	AccountDetailPage.postalR.sendKeys('32');
	expect(AccountDetailPage.postalRerror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when postal code has more than prescride number of char', function() {

	AccountDetailPage.postalR.sendKeys('358249090980982373208764');
	expect(AccountDetailPage.postalRerror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when empty postal code', function() {

	AccountDetailPage.postalR.clear();
	expect(AccountDetailPage.postalRerror.isDisplayed()).toBe(true);

  });

  it('verify billing address is same as the residential address', function() {

	//click checkbox and verify billing address is removed
  if(configFile.ACCOUNTS_PAGE.sameWithResRemovedFields == "false"){
	AccountDetailPage.sameAddressBox.click();
	expect(AccountDetailPage.address1B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.address2B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.countryB.isDisplayed()).toBe(true);
	expect(AccountDetailPage.postalB.isDisplayed()).toBe(true);
}else {
  AccountDetailPage.sameAddressBox.click();
	expect(AccountDetailPage.address1B.isDisplayed()).toBe(false);
	expect(AccountDetailPage.address2B.isDisplayed()).toBe(false);
	expect(AccountDetailPage.countryB.isDisplayed()).toBe(false);
	expect(AccountDetailPage.postalB.isDisplayed()).toBe(false);
}

  });

  it('verify billing address is displayed when checkbox is not tick', function() {

	//click checkbox and verify billing address is removed
	AccountDetailPage.sameAddressBox.click();
	expect(AccountDetailPage.address1B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.address2B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.countryB.isDisplayed()).toBe(true);
	expect(AccountDetailPage.postalB.isDisplayed()).toBe(true);

  });

  it('verify billing address 1 will accept valid values', function() {

	AccountDetailPage.address1B.sendKeys('Telok');
	AccountDetailPage.address1B.getAttribute('value').then(function (value) {
	expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty billing address 1', function() {

	AccountDetailPage.address1B.clear();
	expect(AccountDetailPage.address1Berror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when billing address 1 is more than prescride number of char', function() {

	AccountDetailPage.address1B.sendKeys('thisaddressmorethanthirtyfivecharacters');
	expect(AccountDetailPage.address1Berror.isDisplayed()).toBe(true);

  });

  it('verify billing address 2 will accept valid values', function() {

	AccountDetailPage.address2B.sendKeys('Telok');
	AccountDetailPage.address2B.getAttribute('value').then(function (value) {
	expect(value).toEqual('Telok')});
  });

  it('verify error messeage when empty billing address 2', function() {

	AccountDetailPage.address2B.clear();
	expect(AccountDetailPage.address2Berror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when billing address 2 is more than prescride number of char', function() {

	AccountDetailPage.address2B.sendKeys('thisaddressmorethanthirtyfivecharacters');
	expect(AccountDetailPage.address2Berror.isDisplayed()).toBe(true);

  });

  it('verify billing postal code will accept valid values', function() {

	AccountDetailPage.postalB.sendKeys('358249');
	AccountDetailPage.postalB.getAttribute('value').then(function (value) {
	expect(value).toEqual('358249')});

  });

  it('verify error messeage when billing postal code has less than prescride number of char', function() {

	AccountDetailPage.postalB.sendKeys('32');
	expect(AccountDetailPage.postalBerror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when billing postal code has more than prescride number of char', function() {

	AccountDetailPage.postalB.sendKeys('358249090980982373208764');
	expect(AccountDetailPage.postalBerror.isDisplayed()).toBe(true);

  });

  it('verify error messeage when empty postal code', function() {

	AccountDetailPage.postalB.clear();
	expect(AccountDetailPage.postalBerror.isDisplayed()).toBe(true);

  });



  it('verify details are correctly updated in the profile mini dashboard after successful update', function() {

	//browser.get(TestData.url + '/wallet/create/');
	//SignUpPage.signupSucess(newEmailSignup, 'auto', 'script', 'autosrcipt cards', newMobileSignup, TestData.vCardpassword);
	//browser.sleep(10000);
	/*
	browser.get(TestData.url + '/#/wallet/details/list');
	browser.sleep(2000);
	AccountDetailPage.genderDropdown(1);
	AccountDetailPage.userTitle(1);
	AccountDetailPage.birthday.clear();
	AccountDetailPage.accountTabs.click();
	AccountDetailPage.birthday.sendKeys('1975-01-10');
	AccountDetailPage.conuntryOfissue.$('[label="Singapore"]').click();
	AccountDetailPage.identityInfo(1);
	AccountDetailPage.identificationNumber.sendKeys(TestData.randomIdentityNumberGenerator('M'));
	AccountDetailPage.completeProfile.click();
	browser.sleep(1000);
	expect(AccountDetailPage.address1B.isDisplayed()).toBe(true);
	expect(AccountDetailPage.nricError.isPresent()).toBe(false);
	*/

	AccountDetailPage.address1R.clear();
	AccountDetailPage.address2R.clear();
	AccountDetailPage.postalR.clear();


	AccountDetailPage.address1R.sendKeys('Telok');
	AccountDetailPage.address2R.sendKeys('Ayer');
	AccountDetailPage.postalR.sendKeys('321507');
  if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
    AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
    AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
  }
	AccountDetailPage.sameAddressBox.click();

  expect(AccountDetailPage.updateAddress.isEnabled()).toBe(true);
  AccountDetailPage.updateAddress.click();
  browser.sleep(5000);

	AccountDetailPage.countminiDashboard(0);


  });


});
