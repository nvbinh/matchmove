'use strict';

describe('Recover password', function () {
  var RecoverPasswordPage = require('./recoverpassword.po');
  var ChangePasswordPage = require('./changepassword.po');
  var LoginPage = require('./login.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var SignUpPage = require('./signup.po');
  var DashboardPage = require('./dashboard.po');

  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('./waitReady.js');


  /*beforeEach(function () {
    browser.get(configFile.HTTP_HOST + configFile.RECOVER_PASSWORD_PAGE.redirectionUrl);
	  Utility.setScreenSize();
  });*/

  it('setup test specs', function(){
	//removed logged in 
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should sign up successfully', function() {
	Utility.setScreenSize();
    browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	  SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	  browser.sleep(10000);
    browser.get(configFile.HTTP_HOST + configFile.OFFER_PAGE.redirectionUrl);
	  browser.sleep(10000);
    DashboardPage.logoutToApp();
	  browser.sleep(10000);

  });

   it('should have all the elements on the page', function() {

	    browser.get(configFile.HTTP_HOST + configFile.RECOVER_PASSWORD_PAGE.redirectionUrl);
      expect(RecoverPasswordPage.bannerImg.isPresent()).toBe(true);
      expect(RecoverPasswordPage.emailInput.isPresent()).toBe(true);
      expect(RecoverPasswordPage.submitBtn.isPresent()).toBe(true);
      expect(RecoverPasswordPage.loginBtn.isPresent()).toBe(true);
      expect(RecoverPasswordPage.signupBtn.isPresent()).toBe(true);
      expect(RecoverPasswordPage.helpBtn.isPresent()).toBe(true);
  });



  it('The intial state of the elements must be reset', function() {
    expect(RecoverPasswordPage.emailInput.getText()).toEqual('');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  });


  it('The input values should be correctly reflected', function() {
    RecoverPasswordPage.emailInput.sendKeys(newEmailSignup);
    RecoverPasswordPage.emailInput.getAttribute('value').then(function (value) {
    expect(value).toEqual(newEmailSignup)});
  });


  it('The Submit button should be disabled for invalid values', function() {
    //empty email
	RecoverPasswordPage.emailInput.clear();
  	RecoverPasswordPage.emailInput.sendKeys('');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  	RecoverPasswordPage.emailInput.clear();

	// min lenght
  	RecoverPasswordPage.emailInput.sendKeys('q');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
  	RecoverPasswordPage.emailInput.clear();

	// invalid format
    RecoverPasswordPage.emailInput.sendKeys('@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();

	// incomplete
    RecoverPasswordPage.emailInput.sendKeys('JoeSmithEmailAddress');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();

	//invalid
    RecoverPasswordPage.emailInput.sendKeys('email@domain@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@-domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(false);
	  RecoverPasswordPage.emailInput.clear();
  });


  it('Error message appears for non existing email data input', function() {

    RecoverPasswordPage.emailInput.sendKeys('firstname.lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.submitBtn.click();
	  expect(RecoverPasswordPage.bannerImg.isPresent()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();
  });


  it('The Submit button should be enabled for valid email', function() {

    RecoverPasswordPage.emailInput.sendKeys('firstname.lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@subdomain.domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('firstname+lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@123.123.123.123');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('1234567890@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain-one.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('_______@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain.name');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('email@domain.co.jp');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();

    RecoverPasswordPage.emailInput.sendKeys('firstname-lastname@domain.com');
    expect(RecoverPasswordPage.submitBtn.isEnabled()).toBe(true);
	  RecoverPasswordPage.emailInput.clear();
  });


  it('Successfully Recover Password', function() {
    RecoverPasswordPage.emailInput.sendKeys(newEmailSignup);
    RecoverPasswordPage.submitBtn.click();

	//expect(RecoverPasswordPage.successIcon.isPresent()).toBe(true);
  	expect(RecoverPasswordPage.successMessage.isPresent()).toBe(true);
  	expect(RecoverPasswordPage.resendLink.isPresent()).toBe(true);

  });

  it('Go to gmail and verify email was reiceved', function() {

	   browser.ignoreSynchronization = true;
     browser.get('https://gmail.com');

  	var emailField = element(by.id('Email'));
  	var nextButton = element(by.id('next'));
  	var passwordField = element(by.id('Passwd'));
  	var signInButton = element(by.id('signIn'));

  	//var emailSubject = element(by.id(':2x'));
  	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
  	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
  	//var recoverPasswordButton = element(by.css('target=_blank'));
  	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
  	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	var persistentCookie = element(by.css('#PersistentCookie'));

  	//browser.sleep(120000);

	emailField.isDisplayed().then(function(result){
		if(result){
			emailField.sendKeys(configFile.EXISTING_EMAIL);
			nextButton.click();
		}
		else{
		}
	});

	browser.sleep(3000);

	passwordField.isPresent().then(function(result){
		if(result){
			persistentCookie.isPresent().then(function(present){
				if(present){
					persistentCookie.isSelected().then(function(select){
						if(select){
							persistentCookie.click();
						}
					});
				}
			passwordField.sendKeys(configFile.GMAIL_PASSWORD);
			signInButton.click();

			});
		}
		else{
		}
	});	


  	browser.sleep(5000);

  	expect(emailSubject.waitReady()).toBeTruthy();
  	emailSubject.click();

  	browser.sleep(5000);
	})

	it('verify email and change password', function() {

	var emailField = element(by.id('Email'));
  	var nextButton = element(by.id('next'));
  	var passwordField = element(by.id('Passwd'));
  	var signInButton = element(by.id('signIn'));

  	//var emailSubject = element(by.id(':2x'));
  	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
  	//var emailSubject = element(by.css('tr.zA td.xY div.y6 span'));
  	//var recoverPasswordButton = element(by.css('target=_blank'));
  	//var recoverPasswordButton = element(by.css('a[href^="http"]'));
  	var recoverPasswordButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));

  	expect(recoverPasswordButton.waitReady()).toBeTruthy();
  	recoverPasswordButton.click();

  	browser.sleep(5000);

  	browser.getAllWindowHandles().then(function (handles) {
  	  var secondWindowHandle = handles[1];
  	  var firstWindowHandle = handles[0];

  	  browser.switchTo().window(firstWindowHandle)
  	  .then(function () {
	    browser.sleep(2000);
	    element(by.css('.gb_3a')).click();
	    browser.sleep(2000);
	    element(by.css('#gb_71')).click();
	    browser.sleep(10000);
  	    browser.close();
  	  })
  	  .then(function () {
          browser.ignoreSynchronization = false;
          browser.switchTo().window(secondWindowHandle)
  	  })
  	  .then(function () {
          expect(ChangePasswordPage.passwordField.isPresent()).toBe(true);
  	    expect(ChangePasswordPage.confirmPasswordField.isPresent()).toBe(true);
  	    expect(ChangePasswordPage.submitBtn.isPresent()).toBe(true);

  		ChangePasswordPage.passwordField.sendKeys(configFile.VCARD_PASSWORD);
  		ChangePasswordPage.confirmPasswordField.sendKeys(configFile.VCARD_PASSWORD);
  		ChangePasswordPage.submitBtn.click();

  		browser.sleep(10000);

  		RecoverPasswordPage.errorMessage.isPresent().then(function (isVisible){
  			if (isVisible) {
  				expect(RecoverPasswordPage.errorMessage.isDisplayed()).toBe(false);
  			}


		});

	  });
	});
  });
});
