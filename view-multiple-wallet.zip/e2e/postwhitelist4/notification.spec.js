'use strict';

describe('Notification page', function () {
  var NotificationPage = require('../notification.po');
  var SignUpPage = require('../signup.po');
  var LoginPage = require('../login.po');
  var DashboardPage = require('../dashboard.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('../waitReady.js');

  beforeEach(function () {
    //browser.get(TestData.url);

  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });



  it('signup', function() {

	//Login
	Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(20000);

	/*
	browser.get(TestData.url);
	LoginPage.setEmail(TestData.existingusernocard);
    LoginPage.setPassword(TestData.vCardpassword);
	expect(LoginPage.submitBtn.isEnabled()).toBe(true);
    LoginPage.submitBtn.click();
	expect(NotificationPage.homebannerImg.waitReady()).toBeTruthy();
	browser.sleep(2000);
	*/

	//check dashboard notificationBtn
	//expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);



  });


  it('should have notification icon in the dashboard in every page of the app', function() {

	//check topup
	browser.sleep(20000);
	browser.sleep(20000);
	browser.get(configFile.HTTP_HOST + configFile.TOPUP_PAGE.redirectionUrl);
	browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);

	//check send
	browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);

  	//check claim
	browser.get(configFile.HTTP_HOST + configFile.CLAIM_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);

	//check history
	browser.get(configFile.HTTP_HOST + configFile.HISTORY_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);
  });
	it('should have notification icon in the dashboard in every page of the app', function() {
	//check offers
	browser.get(configFile.HTTP_HOST + configFile.OFFER_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);

	//check suspend
	browser.get(configFile.HTTP_HOST + configFile.SUSPEND_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);

	//check account
	browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);

	//check get card
	browser.get(configFile.HTTP_HOST + configFile.GET_ANOTHER_CARD_PAGE.redirectionUrl);
browser.sleep(10000);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   expect(NotificationPage.notificationBtnWithLanguage.isDisplayed()).toBe(true);
	}else{
	   expect(NotificationPage.notificationBtn.isDisplayed()).toBe(true);
	}
	browser.sleep(2000);
  });


  it('should have dropdown appeared when notification icon is click', function() {
	browser.get(configFile.HTTP_HOST + configFile.DASHBOARD_PAGE.redirectionUrl);
	if (configFile.NOTIFICATION_PAGE.withLanguage == "true"){
	   NotificationPage.notificationBtnWithLanguage.click();
	}else{
	   NotificationPage.notificationBtn.click();
	}
	expect(NotificationPage.notifDropdown.waitReady()).toBeTruthy();

	expect(NotificationPage.notifDropdown.isDisplayed()).toBe(true);

  });

  it('should have all the elements in the notification tab page', function() {
	browser.get(configFile.HTTP_HOST + configFile.NOTIFICATION_PAGE.redirectionUrl);

	expect(NotificationPage.header.isDisplayed()).toBe(true);
	expect(NotificationPage.headericon.isDisplayed()).toBe(true);
	expect(NotificationPage.notifTab.isDisplayed()).toBe(true);
	expect(NotificationPage.newsTab.isDisplayed()).toBe(true);
	expect(NotificationPage.activityDetailslink.isPresent()).toBe(true);
	NotificationPage.activityDetailslink.click();
	browser.sleep(1000);
	expect(NotificationPage.activityDetails.isDisplayed()).toBe(true);

  });

  it('should have all the elements in the news tab page', function() {
	NotificationPage.newsTab.click();
	browser.sleep(2000);

	if (configFile.NOTIFICATION_PAGE.newsItem == "true"){
		expect(NotificationPage.header.isDisplayed()).toBe(true);
		expect(NotificationPage.headericon.isDisplayed()).toBe(true);
		expect(NotificationPage.notifTab.isDisplayed()).toBe(true);
		expect(NotificationPage.newsTab.isDisplayed()).toBe(true);
		//expect(NotificationPage.newsItemImage.isPresent()).toBe(true);
	}

	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutToApp();
	browser.sleep(5000);


  });

});
