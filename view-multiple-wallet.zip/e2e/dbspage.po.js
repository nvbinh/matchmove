/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';
require ('./helppopup.po.js');
require('./dashboard.po.js');
var configFile = require('./e2e.json');

var DBSPOSB = function() {

  this.topupMenu = element.all(by.repeater('method in methods')).get(configFile.DBS_POSB_PAGE.topupageRow);
  this.topupMenuiBanking = element.all(by.repeater('method in methods')).get(configFile.DBS_IBANKING_PAGE.topupageRow);
  this.locationNotAvailable = element(by.css('aside.error-banner'));
  this.atmTab = element.all(by.css('v-tab.subttitle-icon')).first();
  this.internetTab = element.all(by.css('v-tab.subttitle-icon')).get(1);
  this.mobileTab = element.all(by.css('v-tab.subttitle-icon')).last();

  this.imobileTab = element.all(by.css('v-tab.subttitle-icon')).first();
  this.iinternetTab = element.all(by.css('v-tab.subttitle-icon')).last();

  this.get_Atm_number_of_slides = function(){
    this.numberofslides = element.all(by.css('div div.navigation label[ng-repeat="slide in atmdata"]')).count();
    expect(this.numberofslides).toEqual(configFile.DBS_POSB_PAGE.atmSlide);
  };

  this.get_internet_number_of_slides = function(){
    this.numberofslides = element.all(by.css('div div.navigation label[ng-repeat="slide in appdata"]')).count();
    expect(this.numberofslides).toEqual(configFile.DBS_POSB_PAGE.internetSlide);
  };

  this.get_mobile_number_of_slides = function(){
    this.numberofslides = element.all(by.css('div div.navigation label[ng-repeat="slide in ibankingdata"]')).count();
    expect(this.numberofslides).toEqual(configFile.DBS_POSB_PAGE.mobileAppSlide);
  };

  this.get_Iinternet_number_of_slides = function(){
    this.numberofslides = element.all(by.css('div div.navigation label[ng-repeat="slide in ibankingdata"]')).count();
    expect(this.numberofslides).toEqual(configFile.DBS_IBANKING_PAGE.internetSlide);
  };

  this.get_Imobile_number_of_slides = function(){
    this.numberofslides = element.all(by.css('div div.navigation label[ng-repeat="slide in appdata"]')).count();
    expect(this.numberofslides).toEqual(configFile.DBS_IBANKING_PAGE.mobileAppSlide);
  };

  this.checkATMcontentslide = function(){
    for(var ctr = 0; ctr < configFile.DBS_POSB_PAGE.atmSlide; ctr++ ){
      element.all(by.css('div div.navigation label[ng-repeat="slide in atmdata"]')).get(ctr).click();
      browser.sleep(2000);
      var slideIMG = element.all(by.css('ul li.section-guide div.media-image img')).get(ctr);
      var slideHEAD = element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr);

      expect(element.all(by.css('ul li.section-guide div.media-image img')).get(ctr).isDisplayed()).toBe(true);
      expect(element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr).isDisplayed()).toBe(true);

      var strTO = ctr + 1;
      var str = strTO.toString();

      expect(element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr).getText()).toEqual(str);

      //element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr).getText().then(function(text1) {
          //var header  expect(parseFloat(text1)).toEqual(ctr+1);
      //    var header = parseFloat(text1);
      //});

      //expect(header).toEqual(ctr+1);
      //expect(slideHEAD).toBe(true);

      //var header = parseFloat(ctr);

      //expect(slideHEAD).toEqual(header);

    }
  };

  this.checkInternetcontentslide = function(){
    for(var ctr = 0; ctr < configFile.DBS_POSB_PAGE.internetSlide; ctr++ ){
      element.all(by.css('div div.navigation label[ng-repeat="slide in appdata"]')).get(ctr).click();
      browser.sleep(2000);
      var slideIMG = element.all(by.css('ul li.section-guide div.media-image img')).get(ctr);
      var slideHEAD = element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr);

      expect(element.all(by.css('div[ng-if="appHasData"] div.csslider ul li.section-guide div.media-image img')).get(ctr).isDisplayed()).toBe(true);
      expect(element.all(by.css('div[ng-if="appHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).isDisplayed()).toBe(true);

      var strTO = ctr + 1;
      var str = strTO.toString();

      expect(element.all(by.css('div[ng-if="appHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).getText()).toEqual(str);

    }
  };

  this.checkMobilecontentslide = function(){
    for(var ctr = 0; ctr < configFile.DBS_POSB_PAGE.mobileAppSlide; ctr++ ){
      element.all(by.css('div div.navigation label[ng-repeat="slide in ibankingdata"]')).get(ctr).click();
      browser.sleep(2000);
      var slideIMG = element.all(by.css('ul li.section-guide div.media-image img')).get(ctr);
      var slideHEAD = element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr);

      expect(element.all(by.css('div[ng-if="ibankingHasData"] div.csslider ul li.section-guide div.media-image img')).get(ctr).isDisplayed()).toBe(true);
      expect(element.all(by.css('div[ng-if="ibankingHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).isDisplayed()).toBe(true);

      var strTO = ctr + 1;
      var str = strTO.toString();

      expect(element.all(by.css('div[ng-if="ibankingHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).getText()).toEqual(str);

    }
  };


  this.checkiInternetcontentslide = function(){
    for(var ctr = 0; ctr < configFile.DBS_IBANKING_PAGE.internetSlide; ctr++ ){
      element.all(by.css('div div.navigation label[ng-repeat="slide in ibankingdata"]')).get(ctr).click();
      browser.sleep(2000);
      var slideIMG = element.all(by.css('ul li.section-guide div.media-image img')).get(ctr);
      var slideHEAD = element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr);

      expect(element.all(by.css('div[ng-if="ibankingHasData"] div.csslider ul li.section-guide div.media-image img')).get(ctr).isDisplayed()).toBe(true);
      expect(element.all(by.css('div[ng-if="ibankingHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).isDisplayed()).toBe(true);

      var strTO = ctr + 1;
      var str = strTO.toString();

      expect(element.all(by.css('div[ng-if="ibankingHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).getText()).toEqual(str);

    }
  };

  this.checkiMobilecontentslide = function(){
    for(var ctr = 0; ctr < configFile.DBS_IBANKING_PAGE.mobileAppSlide; ctr++ ){
      element.all(by.css('div div.navigation label[ng-repeat="slide in appdata"]')).get(ctr).click();
      browser.sleep(2000);
      var slideIMG = element.all(by.css('ul li.section-guide div.media-image img')).get(ctr);
      var slideHEAD = element.all(by.css('ul li.section-guide div.media-content h1')).get(ctr);

      expect(element.all(by.css('div[ng-if="appHasData"] div.csslider ul li.section-guide div.media-image img')).get(ctr).isDisplayed()).toBe(true);
      expect(element.all(by.css('div[ng-if="appHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).isDisplayed()).toBe(true);

      var strTO = ctr + 1;
      var str = strTO.toString();

      expect(element.all(by.css('div[ng-if="appHasData"] div.csslider ul li.section-guide div.media-content h1')).get(ctr).getText()).toEqual(str);

    }
  };


  this.check_DBS_POSB_inTopupPage = function(){
		element.all(by.repeater('method in methods')).then(function(posts) {
		var itemImage = posts[configFile.DBS_POSB_PAGE.topupageRow].element(by.css('div.img-topup img'));
		var itemTitle  = posts[configFile.DBS_POSB_PAGE.topupageRow].element(by.css('div.detail-topup h3'));
		var minP  = posts[configFile.DBS_POSB_PAGE.topupageRow].all(by.css('a div ul li p')).get(0);
    var min = element(by.css('span.value-amount'));
    var maxP  = posts[configFile.DBS_POSB_PAGE.topupageRow].all(by.css('a div ul li p')).get(1);
    var max = element(by.css('span.value-amount'));

		expect(itemImage.isDisplayed()).toBe(true);
		expect(itemTitle.isDisplayed()).toBe(true);
		expect(minP.element(min.locator()).getText()).toEqual(configFile.DBS_POSB_PAGE.minimum);
		expect(maxP.element(max.locator()).getText()).toEqual(configFile.DBS_POSB_PAGE.maximumPre);

		})
  };


  this.check_DBS_iBanking_inTopupPage = function(){
    element.all(by.repeater('method in methods')).then(function(posts) {
    var itemImage = posts[configFile.DBS_IBANKING_PAGE.topupageRow].element(by.css('div.img-topup img'));
    var itemTitle  = posts[configFile.DBS_IBANKING_PAGE.topupageRow].element(by.css('div.detail-topup h3'));
    var minP  = posts[configFile.DBS_IBANKING_PAGE.topupageRow].all(by.css('a div ul li p')).get(0);
    var min = element(by.css('span.value-amount'));
    var maxP  = posts[configFile.DBS_IBANKING_PAGE.topupageRow].all(by.css('a div ul li p')).get(1);
    var max = element(by.css('span.value-amount'));

    expect(itemImage.isDisplayed()).toBe(true);
    expect(itemTitle.isDisplayed()).toBe(true);
    expect(minP.element(min.locator()).getText()).toEqual(configFile.DBS_IBANKING_PAGE.minimum);
    expect(maxP.element(max.locator()).getText()).toEqual(configFile.DBS_IBANKING_PAGE.maximumPre);

    })
  };


};

module.exports = new DBSPOSB();
