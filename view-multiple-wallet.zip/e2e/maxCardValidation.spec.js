'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./protractor-config-files/SGMCconfig.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var KycValidationPage = require('./kycvalidation.po.js');
var AdminetPage = require('./adminet.po.js');
var DataFilePage = require('./datafiles.po.js');

describe('Max Cards Validation', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;

	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var getAnotherCardMenu = element(by.linkText('Get Another Card'));
	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;
	var otpCode = '';

	var signupBtnIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
	var getVirtualCard = element.all(by.buttonText('Get Card')).first();
	var getVirtualCardIsClickable = EC.elementToBeClickable(getVirtualCard);
	var getCardSuccessMessage = element.all(by.cssContainingText('div.msg-block__content', 'Your new card was successfully created. Kindly visit dashboard to see your new card')).first();
	var getCardSuccessMessageIsVisibility = EC.visibilityOf(getCardSuccessMessage);
	var loadCardLink = element.all(by.css('a[ng-click="loadCard($event, card.id, $index)"]')).first();
	var loadCardIsClickable = EC.elementToBeClickable(loadCardLink);
	var numberOfCards = element.all(by.css('div.navigation div label'));

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};	

	it ('Create Pre_KYC account successfully', function() {

		browser.get(configFile.HTTP_HOST);
		browser.wait(signupBtnIsClickable).then(function() {
			browser.sleep(1000);
			LoginPage.signupBtn.click();
		});

		browser.sleep(5000);
		SignUpPage.firstNameInput.sendKeys('Match');
		SignUpPage.lastNameInput.sendKeys('Move');
		SignUpPage.preferredNameInput.sendKeys('User');
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		console.log(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()		
		SignUpPage.submitBtn.click();

		var getAnotherCardMenuIsClickable = EC.elementToBeClickable(DashboardPage.getAnotherCardMenu);		
		browser.wait(getAnotherCardMenuIsClickable).then(function() {
			expect(true).toBe(true);
		});		
	});

	it ('Access Get Another Card page - get 1st card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});


	it ('Verify user can get 5 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		for (var i = 0; i < DataFilePage.preKYCmaxCards - 1; ++i) {
			browser.sleep(30000);
			DashboardPage.logoutLink.click();
			browser.wait(loginPageIsPresent).then(function() {
				browser.sleep(20000);
				LoginPage.userInput.sendKeys(mobileNumber);
				LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});	
			LoginPage.submitBtn.click();
			browser.wait(loadCardIsClickable).then(function() {
				expect(true).toBe(true);
				browser.sleep(20000);
				DashboardPage.getAnotherCardMenu.click();
				browser.wait(getVirtualCardIsClickable).then(function() {
					browser.sleep(5000);
					getVirtualCard.click();
					browser.wait(getCardSuccessMessageIsVisibility).then(function() {
						expect(true).toBe(true);
						browser.sleep(20000);
						console.log('Get card successfully');
					});
				});
			});					
		};
	});	

	it ('Logout and login page and see that user has 5 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(30000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(DataFilePage.preKYCmaxCards);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - User is required to do KYC before getting more card', function() {

		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);
		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(uploadDocumentsBtnIsClickable).then(function() {
				expect(true).toBe(true);
				browser.sleep(2000);
		});
	});

	it ('Complete profile, upload document and approve via Adminet', function() {

		var completeProfileLinkIsClickable = EC.elementToBeClickable(KycValidationPage.completeProfileLink);
		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));
		var randomID = Utility.autoGenerateMobile(12, 8);
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));
		var kycLink = element(by.css('a[ng-dialog="app/components/doKyc/partials/doKyc.html"]'));
		var kycLinkIsClickable = EC.elementToBeClickable(kycLink);
		var uploadImageIsVisibility = EC.visibilityOf(KycValidationPage.uploadImage);
		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);
		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);
		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);
		var image4 = './KYC_Image/image4.png';
		var image4Path = path.resolve(__dirname, image4);
		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var KYCsubmissionDetailsIsVisibility = EC.visibilityOf(AdminetPage.KYCsubmissionDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationRequiredBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fVerificationRequiredBanner);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var alreadySubmitYCSIsPresence = EC.presenceOf(AdminetPage.alreadySubmitYCS);
		var approveBtnIsClickable = EC.elementToBeClickable(AdminetPage.approveBtn);
		var approveBtnIsInvisibility = EC.invisibilityOf(AdminetPage.approveBtn);

		browser.sleep(2000);
		KycValidationPage.uploadDocumentsBtn.click();
		browser.sleep(1000);
		browser.wait(completeProfileLinkIsClickable).then(function() {
			browser.sleep(1000);
			KycValidationPage.completeProfileLink.click();
			///
			browser.sleep(3000);
			browser.actions().keyDown(protractor.Key.COMMAND).click(DashboardPage.accountMenu).keyUp(protractor.Key.COMMAND).perform();
			browser.wait(genderIsClickable).then(function() {
				browser.sleep(2000);
				browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
			});
			element(by.css('input[value="male"]')).click();
			AccountDetailPage.userTitle(1);
			if (configFile.SPASS_TYPE) {
					spassID.click();
			}
			else {
				passportID.click();
			}
			AccountDetailPage.identificationNumber.sendKeys(randomID);
			AccountDetailPage.completeProfile.click();
			browser.sleep(15000);
			if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
		      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
		      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
		      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
		      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
		      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
		    }
			AccountDetailPage.sameAddressBox.click();
			AccountDetailPage.updateAddress.click();
			browser.sleep(5000);
			browser.wait(kycLinkIsClickable).then(function() {
				browser.sleep(4000);
				kycLink.click();
				browser.wait(uploadDocumentsBtnIsClickable).then(function() {
					browser.sleep(2000);
					KycValidationPage.uploadDocumentsBtn.click();
					browser.wait(uploadImageIsVisibility).then(function() {
						browser.sleep(2000);
						KycValidationPage.inputFile.sendKeys(image1Path);
						KycValidationPage.inputFile.sendKeys(image2Path);
						KycValidationPage.inputFile.sendKeys(image3Path);
						KycValidationPage.inputFile.sendKeys(image4Path);
						browser.sleep(4000);
						KycValidationPage.submitDocumentBtn.click();
						browser.wait(KYCprogressIsPresence).then(function() {						
							browser.getAllWindowHandles().then(function(handles) {
								var newWindowHandle = handles[1];
								browser.switchTo().window(newWindowHandle).then(function() {
									browser.get(configFile.HTTP_HOST_ADMINET);
									AdminetPage.emailfield.sendKeys(configFile.ADMINET_ACCOUNT.EMAIL);
									AdminetPage.passwordfield.sendKeys(configFile.ADMINET_ACCOUNT.PASSWORD);
									AdminetPage.loginButton.click();
									browser.wait(actionMenuIsClickable).then(function() {
										browser.sleep(3000);
										AdminetPage.actionMenu.click();
										browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
											browser.sleep(3000);
											AdminetPage.KYCsubmissionDetails.click();
										});
										
										browser.wait(generateBtnIsClickable).then(function() {
											AdminetPage.searchTypeMobile.click();
											AdminetPage.searchKeyword.sendKeys(mobileNumber);
											AdminetPage.generateBtn.click();
											browser.wait(actionMenuIsClickable).then(function() {
												AdminetPage.actionMenu.click();
												browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
													browser.sleep(3000);
													AdminetPage.KYCsubmissionDetails.click();
												});
												browser.wait(f2fVerificationBtnIsClickable).then(function() {
													browser.sleep(1000);
													AdminetPage.f2fVerificationBtn.click();
													browser.wait(f2fVerificationApprovalBtnIsClickable).then(function() {
														browser.sleep(1000);
														AdminetPage.f2fVerificationApprovalBtn.click();
														browser.wait(approveBtnIsClickable).then(function() {
															browser.sleep(1000);
															AdminetPage.approveBtn.click();
															browser.wait(approveBtnIsInvisibility).then(function() {
																browser.sleep(20000);
																expect(true).toBe(true);
															});
														});	
													});							
												});
											});			
										});				
									});
								});
							});	
						});
					});
				});
			});				
		});
	});

	it ('Verify user can get max cards when KYCed', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(3000);
				for (var i = 0; i < DataFilePage.postKYCmaxCards - DataFilePage.preKYCmaxCards; ++i) {
					browser.sleep(30000);
					DashboardPage.logoutLink.click();
					browser.wait(loginPageIsPresent).then(function() {
						browser.sleep(20000);
						LoginPage.userInput.sendKeys(mobileNumber);
						LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
					});	
					LoginPage.submitBtn.click();
					browser.wait(loadCardIsClickable).then(function() {
						expect(true).toBe(true);
						browser.sleep(20000);
						DashboardPage.getAnotherCardMenu.click();
						browser.wait(getVirtualCardIsClickable).then(function() {
							browser.sleep(5000);
							getVirtualCard.click();
							browser.wait(getCardSuccessMessageIsVisibility).then(function() {
								expect(true).toBe(true);
								browser.sleep(20000);
								console.log('Get card successfully');
							});
						});
					});					
				};
			});
		});
	});	

	it ('Logout and login page and see that user has 10 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(30000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(DataFilePage.postKYCmaxCards);
				browser.sleep(2000);
			});
		});
	});



/*
	it ('Logout and login and see that card was created', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(2000);
		});
	});

	it ('Access Get Another Card page again - get 2nd card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login page and see that user has 2 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(2);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 3rd card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 3 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			numberOfCards.count().then(function(count) {
				browser.sleep(3000);
				console.log(count);
				expect(count).toEqual(3);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 4th card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 4 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(4);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 5th card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 5 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();
		
		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(5);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - User is required to do KYC before getting more card', function() {

		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);
		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(uploadDocumentsBtnIsClickable).then(function() {
				expect(true).toBe(true);
				browser.sleep(2000);
		});
	});

	it ('Complete profile, upload document and approve via Adminet', function() {

		var completeProfileLinkIsClickable = EC.elementToBeClickable(KycValidationPage.completeProfileLink);
		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));
		var randomID = Utility.autoGenerateMobile(12, 8);
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));
		var kycLink = element(by.css('a[ng-dialog="app/components/doKyc/partials/doKyc.html"]'));
		var kycLinkIsClickable = EC.elementToBeClickable(kycLink);
		var uploadImageIsVisibility = EC.visibilityOf(KycValidationPage.uploadImage);
		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);
		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);
		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);
		var image4 = './KYC_Image/image4.png';
		var image4Path = path.resolve(__dirname, image4);
		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var KYCsubmissionDetailsIsVisibility = EC.visibilityOf(AdminetPage.KYCsubmissionDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationRequiredBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fVerificationRequiredBanner);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var alreadySubmitYCSIsPresence = EC.presenceOf(AdminetPage.alreadySubmitYCS);
		var approveBtnIsClickable = EC.elementToBeClickable(AdminetPage.approveBtn);
		var approveBtnIsInvisibility = EC.invisibilityOf(AdminetPage.approveBtn);

		browser.sleep(2000);
		KycValidationPage.uploadDocumentsBtn.click();
		browser.sleep(1000);
		browser.wait(completeProfileLinkIsClickable).then(function() {
			browser.sleep(1000);
			KycValidationPage.completeProfileLink.click();
			///
			browser.sleep(3000);
			browser.actions().keyDown(protractor.Key.COMMAND).click(DashboardPage.accountMenu).keyUp(protractor.Key.COMMAND).perform();
			browser.wait(genderIsClickable).then(function() {
				browser.sleep(2000);
				browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
			});
			element(by.css('input[value="male"]')).click();
			AccountDetailPage.userTitle(1);
			if (configFile.SPASS_TYPE) {
					spassID.click();
			}
			else {
				passportID.click();
			}
			AccountDetailPage.identificationNumber.sendKeys(randomID);
			AccountDetailPage.completeProfile.click();
			browser.sleep(15000);
			if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
		      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
		      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
		      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
		      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
		    }
		    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
		      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
		    }
			AccountDetailPage.sameAddressBox.click();
			AccountDetailPage.updateAddress.click();
			browser.sleep(5000);
			browser.wait(kycLinkIsClickable).then(function() {
				browser.sleep(4000);
				kycLink.click();
				browser.wait(uploadDocumentsBtnIsClickable).then(function() {
					browser.sleep(2000);
					KycValidationPage.uploadDocumentsBtn.click();
					browser.wait(uploadImageIsVisibility).then(function() {
						browser.sleep(2000);
						KycValidationPage.inputFile.sendKeys(image1Path);
						KycValidationPage.inputFile.sendKeys(image2Path);
						KycValidationPage.inputFile.sendKeys(image3Path);
						KycValidationPage.inputFile.sendKeys(image4Path);
						browser.sleep(4000);
						KycValidationPage.submitDocumentBtn.click();
						browser.wait(KYCprogressIsPresence).then(function() {						
							browser.getAllWindowHandles().then(function(handles) {
								var newWindowHandle = handles[1];
								browser.switchTo().window(newWindowHandle).then(function() {
									browser.get(configFile.HTTP_HOST_ADMINET);
									AdminetPage.emailfield.sendKeys(configFile.ADMINET_ACCOUNT.EMAIL);
									AdminetPage.passwordfield.sendKeys(configFile.ADMINET_ACCOUNT.PASSWORD);
									AdminetPage.loginButton.click();
									browser.wait(actionMenuIsClickable).then(function() {
										AdminetPage.actionMenu.click();
										browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
											browser.sleep(3000);
											AdminetPage.KYCsubmissionDetails.click();
										});
										
										browser.wait(generateBtnIsClickable).then(function() {
											AdminetPage.searchTypeMobile.click();
											AdminetPage.searchKeyword.sendKeys(mobileNumber);
											AdminetPage.generateBtn.click();
											browser.wait(actionMenuIsClickable).then(function() {
												AdminetPage.actionMenu.click();
												browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
													browser.sleep(3000);
													AdminetPage.KYCsubmissionDetails.click();
												});
												browser.wait(f2fVerificationBtnIsClickable).then(function() {
													browser.sleep(1000);
													AdminetPage.f2fVerificationBtn.click();
													browser.wait(f2fVerificationApprovalBtnIsClickable).then(function() {
														browser.sleep(1000);
														AdminetPage.f2fVerificationApprovalBtn.click();
														browser.wait(approveBtnIsClickable).then(function() {
															browser.sleep(1000);
															AdminetPage.approveBtn.click();
															browser.wait(approveBtnIsInvisibility).then(function() {
																browser.sleep(20000);
																expect(true).toBe(true);
															});
														});	
													});							
												});
											});			
										});				
									});
								});
							});	
						});
					});
				});
			});				
		});

	});
	
	it ('Logout and login then get 6th card successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var getAnotherCardMenuIsClickable = EC.elementToBeClickable(DashboardPage.getAnotherCardMenu);		

		browser.sleep(2000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(2000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					LoginPage.userInput.sendKeys(mobileNumber);
					LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				});	

				LoginPage.submitBtn.click();
				browser.wait(getAnotherCardMenuIsClickable).then(function() {
					browser.sleep(2000);
					DashboardPage.getAnotherCardMenu.click();
					browser.wait(getVirtualCardIsClickable).then(function() {
						browser.sleep(2000);
						getVirtualCard.click();
						browser.wait(getCardSuccessMessageIsVisibility).then(function() {
							expect(true).toBe(true);
							browser.sleep(500);
						});
					});
				});	
			})
		});
	});

	it ('Logout and login and see that user has 6 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);

		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(6);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 7th card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 7 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(7);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 8th card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 8 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(8);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 9th card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 9 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(9);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - get 10th card successfully', function() {

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(getVirtualCardIsClickable).then(function() {
			browser.sleep(2000);
			getVirtualCard.click();
			browser.wait(getCardSuccessMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
			});
		});
	});

	it ('Logout and login and see that user has 10 cards', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		
		browser.sleep(20000);
		DashboardPage.logoutLink.click();
		browser.wait(loginPageIsPresent).then(function() {
			browser.sleep(5000);
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});	

		LoginPage.submitBtn.click();

		browser.wait(loadCardIsClickable).then(function() {
			browser.sleep(3000);
			numberOfCards.count().then(function(count) {
				console.log(count);
				expect(count).toEqual(10);
				browser.sleep(2000);
			});
		});
	});

	it ('Access Get Another Card page again - Showing Wow , You have too many cards', function() {

		var manyCardsMessage = element(by.cssContainingText('h4', 'You have too many cards'));
		var manyCardsMessageIsVisibility = EC.visibilityOf(manyCardsMessage);

		browser.sleep(2000);
		DashboardPage.getAnotherCardMenu.click();
		browser.wait(manyCardsMessageIsVisibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(500);
		});
	});
*/
});