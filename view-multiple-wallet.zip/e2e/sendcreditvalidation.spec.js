'use strict';

describe('Send Credit Validation', function () {
  var SendCreditPage = require('./sendcredit.po');
  var LoginPage = require('./login.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var SignUpPage = require('./signup.po');
  var DashboardPage = require('./dashboard.po');
  var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var RazorPopup = require('./razorpopup.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var TopupPage = require('./topup.po.js');
  var y = '';
  var EC = protractor.ExpectedConditions;

  var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;

  //var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  //var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);

  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('./waitReady.js');

  function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};


  /*beforeEach(function () {
    browser.get(configFile.HTTP_HOST + configFile.RECOVER_PASSWORD_PAGE.redirectionUrl);
	  Utility.setScreenSize();
  });*/

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('should sign up successfully', function() {
	Utility.setScreenSize();
    browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	  SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	  browser.sleep(10000);

    DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
			browser.sleep(5000);
		}
	});
	  browser.sleep(10000);

  });


   it('should have all the elements on the page when there is no topup made yet', function() {

	    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
      if(configFile.TOPUP_PAGE.preKYC == "true"){
          browser.sleep(3000);
          expect(SendCreditPage.topupMessage.isDisplayed()).toBe(true);
      }

  });



  it ('Topup Success Notification', function() {

    browser.sleep(2000);
    browser.ignoreSynchronization = true;

    var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
    var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
    var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
    var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

    var providerRazorpayIsClickable = EC.elementToBeClickable(TopupPage.providerRazorpay);
    var paymentPopupIsPresence = EC.presenceOf(RazorPopup.paymentPopup);
    var successBtnIsPresence = EC.presenceOf(RazorPopup.successBtn);
    var cardPaymentMethodIsPresence = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);
    var payBtnIsClickable = EC.elementToBeClickable(RazorPopup.payBtn);

    browser.wait(topupMenuIsClickable).then(function() {
      DashboardPage.topupMenu.click();
    });

    browser.wait(EC.or(providerEasypayIsClickable, providerRazorpayIsClickable)).then(function() {
      TopupPage.providerEasypay.isPresent().then(function(result) {
      if (result) {

        TopupPage.walletBalance.getInnerHtml().then(function(balance) {
          var balanceText = balance.replace(",", "");
          balanceBefore = parseFloat(balanceText);
        });
        TopupPage.providerEasypay.click();
        browser.wait(topupBtnIsClickable).then(function() {
          TopupPage.amountCustom.click();
          customAmount = 100;
          TopupPage.amountCustomText.sendKeys(customAmount);
          TopupPage.topupBtn.click();
        });
        browser.wait(windowCount(2), 60000);
        browser.getAllWindowHandles().then(function(handles) {
          var newWindowHandle = handles[1];
          browser.switchTo().window(newWindowHandle).then(function() {
            browser.wait(cancelBtnIsClickable).then(function() {
              EasyGateway.visaChannel.click();
              browser.sleep(2000);
              EasyGateway.creditCardNum.sendKeys('4111111111111111');
              EasyGateway.expMonth.click();
              EasyGateway.expYear.click();
              EasyGateway.creditCardCvv2.sendKeys('989');
              EasyGateway.creditCardName.sendKeys('auto tester');
              EasyGateway.submitBtn.click();
            });
          });
        });

        var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
        browser.wait(transactionSuccessfulIsVisibility).then(function() {
          browser.getAllWindowHandles().then(function(handles) {
            browser.driver.close().then(function () {
              browser.switchTo().window(handles[0]).then(function() {
                browser.sleep(90000); //waiting 90 seconds for balance to be updated
                browser.refresh();
                  var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
                browser.wait(walletBalanceIsPresence).then(function() {
                  TopupPage.walletBalance.getInnerHtml().then(function(balance) {
                    balanceAfter = balance;
                    var amountIncrese = balanceAfter - balanceBefore;
                    expect(amountIncrese).toEqual(customAmount);
                  });
                });
              });
            });
          });
        });

        var topupNotification = element(by.css('li.item-notification.notify-group--Easypay2.notification-Easypay2'));
        var topupNotificationIsPresence = EC.presenceOf(topupNotification);

        DashboardPage.notificationBell.click();
        browser.sleep(1000);
        DashboardPage.goToNotification.click();
        browser.wait(topupNotificationIsPresence).then(function() {
          browser.sleep(1000);
          expect(true).toBe(true);
        });
      }

      else {

        TopupPage.walletBalance.getInnerHtml().then(function(balance) {
            var balanceText = balance.replace(",", "");
            balanceBefore = parseFloat(balanceText);
        });

        TopupPage.providerRazorpay.click();
        browser.wait(topupBtnIsClickable).then(function() {
          TopupPage.amountCustom.click();
          topupAmount = 100;
          TopupPage.amountCustomText.sendKeys(topupAmount);
          TopupPage.topupBtn.click();
        });
        browser.sleep(15000);
        browser.switchTo().frame(0);
        browser.sleep(2000);
        RazorPopup.cardPaymentMethod.click();
        browser.wait(payBtnIsClickable).then(function() {
          RazorPopup.cardNumber.sendKeys(4111111111111111);
          RazorPopup.cardExpiry.sendKeys(1117);
          RazorPopup.cardCvv.sendKeys(989);
        });

        RazorPopup.payBtn.click();
        browser.sleep(10000);
        browser.wait(windowCount(2), 60000);
        browser.getAllWindowHandles().then(function(handles) {
          var newWindowHandle = handles[1];
          browser.switchTo().window(newWindowHandle).then(function() {
            browser.sleep(15000);
            RazorPopup.successBtn.click();
            browser.wait(windowCount(1), 60000);
          });

          browser.switchTo().window(handles[0]).then(function() {
            var progressTextIsInvisibility = EC.invisibilityOf(TopupPage.progressText);
            browser.sleep(10000);
            expect(TopupPage.progressText.isPresent()).toBe(false);
          });
        });

        browser.sleep(90000); //waiting for 90s to see if balance is updated
        var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
        browser.refresh();
        browser.wait(walletBalanceIsPresence).then(function() {
          TopupPage.walletBalance.getInnerHtml().then(function(balance) {
            var balanceText = balance.replace(",", "");
            balanceAfter = parseFloat(balanceText);
            var amountIncrese = balanceAfter - balanceBefore;
            expect(amountIncrese).toEqual(topupAmount);
          });
        });


        var walletTopupNotification = element.all(by.cssContainingText('div.box-title span', 'Wallet Topup')).last();
        var walletTopupNotificationIsVisible = EC.visibilityOf(walletTopupNotification);
        DashboardPage.notificationBell.click();
        browser.sleep(1000);
        DashboardPage.goToNotification.click();
        browser.wait(walletTopupNotificationIsVisible).then(function() {
          browser.sleep(1000);
          expect(true).toBe(true);
        });

      }
      });
    });

  });

 it('should have all the elements on the page (page access)', function() {

    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    if(configFile.TOPUP_PAGE.preKYC == "true"){
        browser.sleep(10000);


        //SendCreditPage.amountTransfer.getAttribute('value').then(function (value) {
        //expect(value).toEqual('1.00')});
        //SendCreditPage.amountTransfer.getAttribute('value').toEqual('1.00');


        expect(SendCreditPage.amountTransfer.isDisplayed()).toBe(true);
        expect(SendCreditPage.emailTransfer.isDisplayed()).toBe(true);
        expect(SendCreditPage.mobileTransfer.isDisplayed()).toBe(true);
        //expect(SendCreditPage.emailField.isPresent()).toBe(true);
        //expect(SendCreditPage.mobileField.isPresent()).toBe(true);
        expect(SendCreditPage.transferButton.isDisplayed()).toBe(true);
        expect(SendCreditPage.totalTransferAmount.isDisplayed()).toBe(true);
        expect(SendCreditPage.amountChargeFee.isDisplayed()).toBe(true);
        expect(SendCreditPage.currency.isDisplayed()).toBe(true);
        expect(SendCreditPage.amountTransfer.isDisplayed()).toBe(true);
        expect(SendCreditPage.transferTab.isDisplayed()).toBe(true);
      	expect(SendCreditPage.historyTab.isDisplayed()).toBe(true);
        //expect(SendCreditPage.statusDropdown.isPresent()).toBe(true);
        //default amount = 1
        expect(element(by.model('transfer.transferAmount')).getAttribute('value')).toEqual('1');
    }

});


  it('Email Field Validation', function() {

    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    if(configFile.TOPUP_PAGE.preKYC == "true"){
        browser.sleep(10000);

    SendCreditPage.emailTransfer.click();
    //Email Address = own email address
    SendCreditPage.emailField.sendKeys(newEmailSignup);
    //SendCreditPage.emailField.sendKeys('matchmoveexistinguser+488274@gmail.com');
    SendCreditPage.emailField.click();
    //SendCreditPage.transferButton.click();
    browser.sleep(2000);
    //expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //Email Address = empty
    SendCreditPage.emailField.clear();
    SendCreditPage.emailField.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //Email Address < minimum character (6)
    SendCreditPage.emailField.clear().sendKeys('terkt');
    SendCreditPage.emailField.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //Email Address = invalid format
    SendCreditPage.emailField.clear().sendKeys('thisisnotacorrectemailformat');
    SendCreditPage.emailField.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);
  }
  });

  it('Mobile Field Validation', function() {

    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    if(configFile.TOPUP_PAGE.preKYC == "true"){
        browser.sleep(10000);
    SendCreditPage.mobileTransfer.click();
    //Mobile Number = own mobile number
    SendCreditPage.mobileField.sendKeys(newMobileSignup);
    //SendCreditPage.mobileField.sendKeys('9488857375');
    SendCreditPage.transferTab.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //Mobile Number = empty
    SendCreditPage.mobileField.clear();
    SendCreditPage.mobileField.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //Mobile Number < minimum character (8)
    SendCreditPage.mobileField.clear().sendKeys('4523');
    SendCreditPage.mobileField.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //Mobile Number = invalid format (with alphabetic, special or space)
    SendCreditPage.mobileField.clear().sendKeys('4 afs 5 d23');
    SendCreditPage.mobileField.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);
  }

  });


  it('Message Field Validation', function() {
    //Message > maximum characters (160)
    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    if(configFile.TOPUP_PAGE.preKYC == "true"){
        browser.sleep(10000);
    SendCreditPage.emailTransfer.click();
    //Email Address = own email address
    //SendCreditPage.emailField.sendKeys(newEmailSignup);
    SendCreditPage.emailField.sendKeys('matchmoveexistinguser+488274@gmail.com');
    for (var x = 1; x < 160; x++){
      var y = y + 'y';
    }
    //SendCreditPage.messageS.sendKeys('4 afs 5skskmalskalskdaklwndaoiwdnoaiwnoin d23');
    SendCreditPage.messageS.sendKeys(y);
    SendCreditPage.transferTab.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);
    }

  });

  it('Amount Field Validation', function() {

    var transferEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);

    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    if(configFile.TOPUP_PAGE.preKYC == "true"){
        browser.sleep(10000);

    //amount = empty
    SendCreditPage.amounttoTransfer.sendKeys(protractor.Key.BACK_SPACE);
    SendCreditPage.transferTab.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //amount min < 1
    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    browser.sleep(5000);
    SendCreditPage.amounttoTransfer.sendKeys(protractor.Key.BACK_SPACE);
    SendCreditPage.amounttoTransfer.sendKeys(0.01);
    SendCreditPage.transferTab.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //amount max > 999
    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    browser.sleep(5000);
    SendCreditPage.amounttoTransfer.sendKeys(protractor.Key.BACK_SPACE);
    SendCreditPage.amounttoTransfer.sendKeys(configFile.SEND_PAGE.max);
    SendCreditPage.transferTab.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //amount > available balance
    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    browser.sleep(5000);
    SendCreditPage.amounttoTransfer.sendKeys(protractor.Key.BACK_SPACE);
    SendCreditPage.amounttoTransfer.clear().sendKeys(configFile.SEND_PAGE.morethan);
    SendCreditPage.transferTab.click();
    browser.sleep(2000);
    expect(SendCreditPage.errorMeassege.isDisplayed()).toBe(true);

    //amount with decimal
    browser.get(configFile.HTTP_HOST + configFile.SEND_PAGE.redirectionUrl);
    browser.sleep(5000);
    SendCreditPage.amounttoTransfer.sendKeys(protractor.Key.BACK_SPACE);
    SendCreditPage.amounttoTransfer.clear().sendKeys(32.15);
    SendCreditPage.emailTransfer.click();
    SendCreditPage.emailField.sendKeys(transferEmailSignup);
    SendCreditPage.transferButton.click();
    browser.sleep(10000);
    expect(SendCreditPage.progressText.isDisplayed()).toBe(true);

  }
});


});
