'use strict';

describe('DBS iBanking Topup', function () {
  //var VerifyEmailPage = require('./verifyemail.po');
  var LoginPage = require('./login.po');
  var SignUpPage = require('./signup.po');
  var AccountDetailPage = require('./accountdetails.po');
  var configFile = require('./e2e.json');
  var Utility = require('./utilities.po.js');
  var DashboardPage = require('./dashboard.po.js');
  var ChangePasswordPage = require('./changepassword.po');
  var DBSPOSB = require('./dbspage.po');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('./waitReady.js');


  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  it('Sign up New user', function() {

	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(20000);
	browser.sleep(10000);
});

  it('verify slide number', function() {

  browser.get(configFile.HTTP_HOST + configFile.TOPUP_PAGE.redirectionUrl);
  DBSPOSB.check_DBS_iBanking_inTopupPage();
  DBSPOSB.topupMenuiBanking.click();
  browser.sleep(5000);
  DBSPOSB.get_Imobile_number_of_slides();
  DBSPOSB.iinternetTab.click();
  browser.sleep(2000);
  DBSPOSB.get_Iinternet_number_of_slides();

  });

  it('verify mobile slide content', function() {

    DBSPOSB.imobileTab.click();
    DBSPOSB.checkiMobilecontentslide();

  });

  it('verify internet slide content', function() {

    DBSPOSB.iinternetTab.click();
    DBSPOSB.checkiInternetcontentslide();

  });

});
