'use strict';
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');

//var configFile = require('./protractor-config-files/SGMCconfig.json');
//var configFile = require('./protractor-config-files/MUTHOOTconfig.json');
var configFile = require('./protractor-config-files/PAYASIAconfig.json');
//var configFile = require('./protractor-config-files/centrum.json');

var LoginPage = require('./login.po.js');
//var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobilePage = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var ChangeEmailPopup = require('./changeemailpopup.po.js');

describe('Change Email', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var firstEmail = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var SecondEmail; 
	var thirdEmail;
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	
	it ('sign up and click Verify Email popup', function() {
		
		browser.get(configFile.HTTP_HOST);
		//LoginPage.signupBtn.click();
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(5000);
		SignUpPage.emailInput.sendKeys(firstEmail);
		SignUpPage.firstNameInput.sendKeys('loc');
		SignUpPage.lastNameInput.sendKeys('loc');
		SignUpPage.preferredNameInput.sendKeys('loc');
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		}
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		
		SignUpPage.submitBtn.click();

		var verifyEmailClickable = EC.elementToBeClickable(VerifyEmailPage.verifyEmailbutton);
		browser.wait(verifyEmailClickable).then(function() {
			browser.sleep(1000);
			VerifyEmailPage.verifyEmailbutton.click();	
			browser.sleep(5000);		
			expect(VerifyEmailPage.resendEmailButton.isPresent()).toBe(true);
		}); 
	}); 
	

	it ('open gmail and check verify email', function() {

		browser.sleep(60000); //waiting for change email was sent to Gmail
		browser.get(configFile.GMAIL);

		var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.Authentication)).first();
		var emailIsClickable = EC.elementToBeClickable(emailSubjects);

		var expandEmail = element(by.css('div.ajR[data-tooltip="Show trimmed content"]'));
		var expandIsPresence = EC.presenceOf(expandEmail);

		GmailPage.emailInput.sendKeys(configFile.G_EMAIL);
		browser.sleep(1000);
		GmailPage.nextBtn.click();

		browser.sleep(1000);
		GmailPage.passwordInput.sendKeys(configFile.G_PASSWORD);
		GmailPage.signInBtn.click();
		browser.wait(emailIsClickable).then(function() {
			emailSubjects.click();
		});

		browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {

			expandEmail.isPresent().then(function(result) {
				if(result) {
				GmailPage.expandEmails.count().then(function(count) {
					if (count >= 1) {
						GmailPage.expandEmails.last().click();
						}
					});
				}
					
			});
		});

		browser.sleep(1000);
		expect(GmailPage.verifyEmail.isPresent()).toBe(true);
	});

	it ('Click and Verify Email successfully', function() {

		GmailPage.verifyAuthenEmail.count().then(function(count) {
				if (count > 1) {
					GmailPage.verifyAuthenEmail.last().click();
				}
				else {
					GmailPage.verifyAuthenEmail.first().click();
			}
		});	

		browser.sleep(1000);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				expect(browser.getCurrentUrl()).toContain(configFile.HTTP_HOST);
			});
		});
		//var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified email'));
		var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified'));
		var verifyEmailSuccessIsVisibility = EC.visibilityOf(verifyEmailSuccess);
		browser.wait(verifyEmailSuccessIsVisibility).then(function() {
			expect(true).toBe(true);
		});
		
	});


	it ('complete account detail', function() {

		//browser.get(configFile.HTTP_HOST);

		var accountMenu = element(by.linkText('Account'));
		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));
		var verifyMobilePopupIsPresent = EC.presenceOf(VerifyMobilePage.verifymobilemainPopup);

		browser.wait(loginPageIsPresent).then(function() {

			LoginPage.emailInput.sendKeys(firstEmail);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			});

			LoginPage.submitBtn.click();

			browser.wait(verifyMobilePopupIsPresent).then(function() {
				browser.sleep(1000);
				VerifyMobilePage.verifymobilepopupClose.click();
				browser.sleep(2000);
				accountMenu.click();
			});
				

			browser.wait(genderIsClickable).then(function() {
				browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
			});

			element(by.css('input[value="male"]')).click();

			AccountDetailPage.userTitle(1);

			//
			var spassID = element(by.css('input[value="spass"]'));
			var passportID = element(by.css('input[value="passport"]'));

			if (configFile.SPASS_TYPE) {
					spassID.click();
			}
			else {
				passportID.click();
			}
			
			var randomID = Utility.autoGenerateMobile(12, 8);

			//element(by.css('input[value="spass"]')).click();
			AccountDetailPage.identificationNumber.sendKeys(randomID);
			AccountDetailPage.completeProfile.click();
			
				browser.sleep(10000);
				//AccountDetailPage.completeResidentialAddressInfo();
	if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
    }
    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
    }
				AccountDetailPage.sameAddressBox.click();
				AccountDetailPage.updateAddress.click();

			var changeEmailLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeEmailLink);

			browser.wait(changeEmailLinkIsClickable).then(function() {
				browser.sleep(1000);
				AccountDetailPage.changeEmailLink.click();
			});			

			expect(ChangeEmailPopup.changeEmailPopup.isPresent()).toBe(true);
		
	});


	it ('Change Email button is disable', function() {
		expect(ChangeEmailPopup.changeEmailBtn.isEnabled()).toBe(false);
	});

	it ('Invalid Email', function() {
		ChangeEmailPopup.emailInput.sendKeys('invalidEmail@sdd');
		expect(ChangeEmailPopup.warningMessage.isDisplayed()).toBe(true);
	});

	it ('Exist Email', function() {
		var messageBoxIsVisibility = EC.visibilityOf(ChangeEmailPopup.messageBox);
		ChangeEmailPopup.emailInput.clear();
		ChangeEmailPopup.emailInput.sendKeys(firstEmail);
		ChangeEmailPopup.changeEmailBtn.click();
		browser.wait(messageBoxIsVisibility).then(function() {
			expect(true).toBe(true);
		});	
		browser.sleep(500);
	});
	

	it ('Enter an valid email then click Change Email', function() {
		SecondEmail = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
		var sendNotifyIsVisibility = EC.visibilityOf(ChangeEmailPopup.sendNotify);
		ChangeEmailPopup.emailInput.clear();
		ChangeEmailPopup.emailInput.sendKeys(SecondEmail);
		ChangeEmailPopup.changeEmailBtn.click();
		browser.wait(sendNotifyIsVisibility).then(function() {
			expect(true).toBe(true);
		});


	});

	it ('Open Gmail and check if Change Email was sent to user', function() {
		browser.sleep(60000) //waiting for email ...
		var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.changeEmail)).first();
		var emailIsClickable = EC.elementToBeClickable(emailSubjects);

		var expandEmail = element(by.css('div.ajR[data-tooltip="Show trimmed content"]'));
		var expandEmail = element(by.css('div.ajR[data-tooltip="Show trimmed content"]'));
		var expandIsPresence = EC.presenceOf(expandEmail);
		var expandIsClickable = EC.elementToBeClickable(expandEmail);

		browser.getAllWindowHandles().then(function (handles) {
        var newWindowHandle = handles[0];      
        	browser.switchTo().window(newWindowHandle).then(function () { 
        		browser.get('https://mail.google.com/mail/#inbox');
        	});
        });

		browser.wait(emailIsClickable).then(function() {		
			emailSubjects.click();
			browser.sleep(10000);
		});
		
		browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {
			expandEmail.isPresent().then(function(result) {
				if(result) {
				GmailPage.expandEmails.count().then(function(count) {
					if (count >= 1) {
						GmailPage.expandEmails.last().click();
						}
					});
				}
					
			});
		});

		browser.sleep(1000);
		expect(GmailPage.verifyEmail.isPresent()).toBe(true);
	});

	it ('Click Verify Email', function() {

		browser.sleep(5000);
		GmailPage.verifyChangeEmail.count().then(function(count) {
				if (count > 1) {
					GmailPage.verifyChangeEmail.last().click();
				}
				else {
					GmailPage.verifyChangeEmail.first().click();
				}
		});	

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[2];
				browser.switchTo().window(newWindowHandle).then(function() {
					expect(browser.getCurrentUrl()).toContain(configFile.HTTP_HOST);
				});
		});
		var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified'));
		var verifyEmailSuccessIsPresence = EC.presenceOf(verifyEmailSuccess);
		browser.wait(verifyEmailSuccessIsPresence).then(function() {
			expect(true).toBe(true);
		});
	});
	
	it ('Try to login by old email address', function() {
		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var warningMessage = element(by.css('display-errors.ng-isolate-scope'));
		var warningMessageIsVisibility = EC.visibilityOf(warningMessage);

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.emailInput.sendKeys(firstEmail);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		browser.wait(warningMessageIsVisibility).then(function() {
			browser.sleep(500);
			expect(true).toBe(true);
		});
	});
	
	it ('Login by new Email Address', function() {
		browser.sleep(3000);
		LoginPage.emailInput.clear();
		LoginPage.emailInput.sendKeys(SecondEmail);
		browser.sleep(1000);
		LoginPage.submitBtn.click();
		var verifyMobilePopupIsPresent = EC.presenceOf(VerifyMobilePage.verifymobilemainPopup);

		browser.wait(verifyMobilePopupIsPresent).then(function() {
			browser.sleep(500);
			VerifyMobilePage.verifymobilepopupClose.click();
			expect(true).toBe(true);
		});

	});

	it ('New email was updated in Account page', function() {
		var accountMenu = element(by.linkText('Account'));
		browser.sleep(2000);
		accountMenu.click();
		
		var newEmailInfo = element(by.cssContainingText('div.section-info p.ng-binding', SecondEmail));
		var newEmailInfoIsVisibility = EC.visibilityOf(newEmailInfo);
 		browser.wait(newEmailInfoIsVisibility).then(function() {
 			expect(true).toBe(true);
		});
	});

	it ('Check Notification page', function() {

		var notificationBell = element(by.css('a.link-nav[ng-click="readAllNotification()"]'));
		var goToNotification = element(by.css('a[ng-click="goToNotification()"]'));
		var changeEmailNotification = element(by.cssContainingText('p.ng-binding', 'You successfully changed'));
		var changeEmailNotificationIsPresence = EC.presenceOf(changeEmailNotification);

		notificationBell.click();
		browser.sleep(1000);
		goToNotification.click();
		browser.wait(changeEmailNotificationIsPresence).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	
	it ('Test Resend Email', function() {
    
		thirdEmail = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
		browser.sleep(5000);

		var accountMenu = element(by.linkText('Account'));
		accountMenu.click();

		var changeEmailLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeEmailLink);

		browser.wait(changeEmailLinkIsClickable).then(function() {
			AccountDetailPage.changeEmailLink.click();
		});

		var sendNotify = element(by.css('section.modal-content'));
		var sendNotifyIsVisibility = EC.visibilityOf(sendNotify);
		var resendEmailBtn = element(by.css('button.button-primary--medium'));
		browser.sleep(2000);

		ChangeEmailPopup.emailInput.sendKeys(thirdEmail);
		ChangeEmailPopup.changeEmailBtn.click();
		browser.wait(sendNotifyIsVisibility).then(function() {
			expect(true).toBe(true);
		});

		browser.sleep(90000); //waiting for change email to be sent to user	


		var expandEmail = element(by.css('div.ajR[data-tooltip="Show trimmed content"]'));
		var expandIsPresence = EC.presenceOf(expandEmail);

		browser.getAllWindowHandles().then(function (handles) {      
        	browser.switchTo().window(handles[0]).then(function () { 
        		browser.refresh();
        		browser.wait(emailIsPresent).then(function() {
        			browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {
						expandEmail.isPresent().then(function(result) {
							if(result) {
								GmailPage.expandEmails.count().then(function(count) {
									if (count >= 1) {
										GmailPage.expandEmails.last().click();
									}
								});
							}
					
						});
					});
        		
        		});
        	});
        		//switch back to Vcard and click Resend
        		browser.switchTo().window(handles[2]).then(function() {
 					resendEmailBtn.click();
 				});       	
        });	

		var resendSuccessMessage = element(by.css('message-box[messagetype="success"]'));
		var resendSuccessMessageIsPresence = EC.presenceOf(resendSuccessMessage);
		browser.wait(resendSuccessMessageIsPresence).then(function() {			
			expect(true).toBe(true);
			browser.sleep(2000);
		});

	});

	it ('Validation failed by using invalid email', function() {

		browser.sleep(10000); //wait for change email popup tobe closed
		AccountDetailPage.logoutLink.click();

		//Back to Gmail, click Verify on old email
	
		browser.getAllWindowHandles().then(function (handles) {
        var newWindowHandle = handles[0];      
        	browser.switchTo().window(newWindowHandle).then(function () {       	
        		GmailPage.verifyChangeEmail.first().click();						
			});
 		});

		//Handle new window open when clicked Verify Email
		browser.sleep(1000);

		browser.getAllWindowHandles().then(function (handles) {
		var newWindowHandle = handles[3];
		    browser.switchTo().window(newWindowHandle).then(function () {       	
        		var emailField = element(by.model('loggedOutUser.email'));
        		var emailFieldIsVisibility = EC.visibilityOf(emailField);
        		var passwordField = element(by.model('loggedOutUser.password'));
        		var verifyEmailBtn = element(by.css('button.button-primary--large'));

        		//var emailFieldIsVisibility = EC.visibilityOf(emailField);

        		var verificationFailed = element(by.css('div[ng-if="validationEmailErrorTrue"]'));       			
        		var verificationFailedIsVisibility = EC.visibilityOf(verificationFailed);

        		browser.wait(emailFieldIsVisibility).then(function() {
        			emailField.sendKeys(SecondEmail);
        			passwordField.sendKeys(configFile.VCARD_PASSWORD)
        			verifyEmailBtn.click();
        			browser.wait(verificationFailedIsVisibility).then(function() {      			
        				expect(true).toBe(true);
        				browser.sleep(500);
        			});
        		});
			});
 		});	

	});

	it ('Can not verify by using new email address', function() {

		element(by.css('a.link[ng-click="redirectionLink()"]')).click();
		browser.sleep(5000);

		browser.getAllWindowHandles().then(function (handles) {
        var newWindowHandle = handles[0];      
        	browser.switchTo().window(newWindowHandle).then(function () {
        		browser.refresh();
        		browser.wait(emailIsPresent).then(function() {
        			GmailPage.expandEmails.first().click();
        		});
        		browser.sleep(1000);     	
        		GmailPage.verifyChangeEmail.first().click();						
			});
 		});

		//Handle new window open when clicked Verify Email
		browser.sleep(1000);

		browser.getAllWindowHandles().then(function (handles) {
		var newWindowHandle = handles[4];
		    browser.switchTo().window(newWindowHandle).then(function () {       	
        		var emailField = element(by.model('loggedOutUser.email'));
        		var passwordField = element(by.model('loggedOutUser.password'));
        		var verifyEmailBtn = element(by.css('button.button-primary--large'));
        		var errorMessage = element(by.css('[messagetype="error"]'));

        		var emailFieldIsVisibility = EC.visibilityOf(emailField);	
        		var errorMessageIsPresence = EC.presenceOf(errorMessage);

        		browser.wait(emailFieldIsVisibility).then(function() {
        			emailField.sendKeys(thirdEmail);
        			passwordField.sendKeys(configFile.VCARD_PASSWORD);
        			verifyEmailBtn.click();
        		});

        		browser.wait(errorMessageIsPresence).then(function() {    			
        			expect(true).toBe(true);
        			browser.sleep(1000);
        		});

			});
 		});	

	});

	it ('Verify Email successfully', function() {
		var emailField = element(by.model('loggedOutUser.email'));
        var passwordField = element(by.model('loggedOutUser.password'));
        var verifyEmailBtn = element(by.css('button.button-primary--large'));
        var errorMessage = element(by.css('[messagetype="error"]'));
        var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified'));
		var verifyEmailSuccessIsPresence = EC.presenceOf(verifyEmailSuccess)

        var emailFieldIsVisibility = EC.visibilityOf(emailField);	
        var errorMessageIsPresence = EC.presenceOf(errorMessage);
        
        browser.refresh();

        browser.wait(emailFieldIsVisibility).then(function() {
        	//Input existing account
        	emailField.sendKeys(SecondEmail);
        	passwordField.sendKeys(configFile.VCARD_PASSWORD);
        	verifyEmailBtn.click();
        });

        browser.wait(verifyEmailSuccessIsPresence).then(function() {
			expect(true).toBe(true);
		});
	});  
});


