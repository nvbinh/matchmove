'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');

describe('Topup via Wirecard/ EasyPay2', function() {
	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;


	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('sign up and click Verify Email popup', function() {

		browser.get(configFile.HTTP_HOST);
		LoginPage.signupBtn.click();
		browser.sleep(5000);
		//SignUpPage.emailInput.sendKeys(emailAddress);
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click();
		SignUpPage.submitBtn.click();

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		browser.wait(topupMenuIsClickable).then(function() {
			expect(true).toBe(true);
		});
		/*
		var verifyMobileIsClickable = EC.elementToBeClickable(VerifyMobile.verifymobilebutton)
		browser.wait(verifyMobileIsClickable).then(function() {
			VerifyMobile.verifymobilepopupClose.click();
			expect(true).toBe(true);
		})
		*/
		/*
		var verifyEmailClickable = EC.elementToBeClickable(VerifyEmailPage.verifyEmailbutton);
		browser.wait(verifyEmailClickable).then(function() {
			browser.sleep(1000);
			VerifyEmailPage.verifyEmailbutton.click();
			browser.sleep(5000);
			expect(VerifyEmailPage.resendEmailButton.isPresent()).toBe(true);
		});
		*/
	});
/*
	it ('open gmail and check verify email', function() {

		browser.sleep(30000); //waiting for verify email was sent to Gmail
		browser.get(configFile.GMAIL);

		var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.Authentication)).first();
		var emailIsClickable = EC.elementToBeClickable(emailSubjects);
		var expandIsPresence = EC.presenceOf(GmailPage.expandEmail);

		GmailPage.emailInput.sendKeys(configFile.G_EMAIL);
		GmailPage.nextBtn.click();

		browser.sleep(1000);
		GmailPage.passwordInput.sendKeys(configFile.G_PASSWORD);
		GmailPage.signInBtn.click();
		browser.wait(emailIsClickable).then(function() {
			emailSubjects.click();
		});

		browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {

			GmailPage.expandEmail.isPresent().then(function(result) {
				if(result) {
				GmailPage.expandEmails.count().then(function(count) {
					if (count >= 1) {
						GmailPage.expandEmails.last().click();
						}
					});
				}

			});
		});

		browser.sleep(1000);
		expect(GmailPage.verifyEmail.isPresent()).toBe(true);
	});

	it ('Click and Verify Email successfully', function() {

		GmailPage.verifyAuthenEmail.count().then(function(count) {
				if (count > 1) {
					GmailPage.verifyAuthenEmail.last().click();
				}
				else {
					GmailPage.verifyAuthenEmail.first().click();
			}
		});

		browser.sleep(1000);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				expect(browser.getCurrentUrl()).toContain(configFile.HTTP_HOST);
			});
		});
		var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified email'));
		var verifyEmailSuccessIsVisibility = EC.visibilityOf(verifyEmailSuccess);
		browser.wait(verifyEmailSuccessIsVisibility).then(function() {
			expect(true).toBe(true);
		});
	});
*/
	it ('access Topup page and check if EasyPay channel is displayed', function() {
		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);

		/*
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.emailInput.sendKeys(emailAddress);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();
		*/

		browser.sleep(2000);

		//browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
		//});

		browser.wait(providerEasypayImageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Get min value', function() {

		TopupPage.minValue.getInnerHtml().then(function(min) {
			var getMinValue = parseFloat(min);
			expect(getMinValue).toEqual(configFile.PRE_KYC_TOPUP_LIMIT.min);
		});

	});

	it ('Get max value', function() {

		TopupPage.maxValue.getInnerHtml().then(function(max) {
			var getMaxValue = parseFloat(max);
			expect(getMaxValue).toEqual(configFile.PRE_KYC_TOPUP_LIMIT.max);
		});

	});

	it ('Get fee charge', function() {

   		TopupPage.feePercent.getText().then(function (fee) {
        	var feeText = fee.split(":");
        	var feecharge = parseFloat(feeText[1]);
        	expect(feecharge).toEqual(configFile.PRE_KYC_TOPUP_LIMIT.fee);
    	});
	});


	it ('select EasyPay channel and check current URL include topup/enter/Easypay2', function() {

		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);

		browser.wait(providerEasypayIsClickable).then(function() {
			TopupPage.providerEasypay.click();
		});

		browser.wait(topupBtnIsClickable).then(function() {
			browser.getCurrentUrl().then(function(url) {
				expect(url).toEqual(configFile.TOPUP_EASY_PAGE.url);
			});
		});
	});


	it ('Topup button is disable when topup amount less than min amount', function() {

		TopupPage.amountCustom.click();
		TopupPage.amountCustomText.sendKeys(1);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(0.112);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(0);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(9);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(9.99);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(-11);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);

	});

	it ('warning massage is displayed when topup amount greater than max amount', function() {

		var maxWarningMessageIsPresence = EC.presenceOf(TopupPage.maxWarningMessage);
		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(501);
		TopupPage.topupBtn.click();
		browser.wait(maxWarningMessageIsPresence).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Topup with predefind amount = 10', function() {

		//browser.refresh();
		var providerEasypayImageIsVisibility = EC.visibilityOf(TopupPage.providerEasypayImage);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);

		DashboardPage.topupMenu.click();

		browser.wait(providerEasypayImageIsVisibility).then(function() {
			browser.wait(providerEasypayIsClickable).then(function() {
				TopupPage.providerEasypay.click();
			});
		});



		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		browser.wait(topupBtnIsClickable).then(function() {
			//expect(TopupPage.pre_definded_amount_10.isSelected()).toBe(true);
		});

		TopupPage.pre_definded_amount_10.getAttribute('value').then(function(amount) {
			topupAmount = parseFloat(amount);
		});

		var feeAmount = TopupPage.getFeeChargeAmount();

		TopupPage.walletBalance.getInnerHtml().then(function(balance) {
			balanceBefore = balance;
		});

		expect(true).toBe(true);
	});


	it ('click Topup button and Easy payment gateway is opened ', function() {

		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		TopupPage.topupBtn.click();

		//browser.wait(windowCount(3), 60000);
		browser.wait(windowCount(2), 60000);
		browser.getAllWindowHandles().then(function(handles) {
			//var newWindowHandle = handles[2];
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.wait(cancelBtnIsClickable).then(function() {
					expect(browser.getCurrentUrl()).toContain(configFile.EASE_PAGE_URL);
				});
			});
		});
	});

	it ('select Visa and Visa payment is displayed', function() {
		EasyGateway.visaChannel.click();
		browser.sleep(2000);
		expect(EasyGateway.visaLogo.isDisplayed()).toBe(true);
	});

	it ('Input valid Visa card detail and click Submit', function() {

		EasyGateway.creditCardNum.sendKeys('4111111111111111');
		EasyGateway.expMonth.click();
		EasyGateway.expYear.click();
		EasyGateway.creditCardCvv2.sendKeys('989');
		EasyGateway.creditCardName.sendKeys('auto tester');
		EasyGateway.submitBtn.click();

		var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
		browser.wait(transactionSuccessfulIsVisibility).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Back to Vcard and see that transaction status is success', function() {
		var progressTextIsInvisibility = EC.invisibilityOf(TopupPage.progressText);

		browser.getAllWindowHandles().then(function(handles) {
			browser.driver.close().then(function () {
				//browser.switchTo().window(handles[1]).then(function() {
				browser.switchTo().window(handles[0]).then(function() {
					browser.wait(progressTextIsInvisibility).then(function() {
						expect(true).toBe(true);
					});
				});
			});
		});
	});

	it ('Checking Print Receipt feature', function() {
		TopupPage.printReceipt.click();
		browser.sleep(2000);
		browser.getAllWindowHandles().then(function (handles) {
        	//var newWindowHandle = handles[2];
        	var newWindowHandle = handles[1];
        	browser.switchTo().window(newWindowHandle).then(function () {
            	expect(TopupPage.printWindow.isPresent()).toBe(true);
            	browser.sleep(2000);
                TopupPage.cancelPrint.click();
        	});

        	//browser.switchTo().window(handles[1]).then(function() {
        	browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(120000); //waiting for 2 mins to see if balance is updated
        	});
    	});

	});

	it ('balance was updated', function() {
		var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
		browser.refresh();
		browser.wait(walletBalanceIsPresence).then(function() {
			TopupPage.walletBalance.getInnerHtml().then(function(balance) {
				balanceAfter = balance;
				var amountIncrese = balanceAfter - balanceBefore;
				expect(amountIncrese).toEqual(topupAmount);
			});
		});

	});

	it ('Check transaction history', function() {
		var historyMenu = element(by.linkText('History'));

		var topupTransaction = element(by.cssContainingText('span.transaction-description', 'Topup via Easypay2'));
		var topupTransactionIsPresence = EC.presenceOf(topupTransaction);

		historyMenu.click();
		browser.wait(topupTransactionIsPresence).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Check Notification page', function() {
		var notificationBell = element(by.css('a.link-nav[ng-click="readAllNotification()"]'));
		var goToNotification = element(by.css('a[ng-click="goToNotification()"]'));
		var topupNotification = element(by.css('li.item-notification.notify-group--Easypay2.notification-Easypay2'));
		var topupNotificationIsPresence = EC.presenceOf(topupNotification);

		notificationBell.click();
		browser.sleep(1000);
		goToNotification.click();
		browser.wait(topupNotificationIsPresence).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});
/*
	it ('Check topup email was sent to user', function() {

		var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.topupEmail)).first();
		var emailIsClickable = EC.elementToBeClickable(emailSubjects);
		var expandIsPresence = EC.presenceOf(GmailPage.expandEmail);

		browser.sleep(10000); //waiting for change email was sent to Gmail
		//
		browser.get(configFile.GMAIL);
		GmailPage.emailInput.sendKeys(configFile.G_EMAIL);
		GmailPage.nextBtn.click();

		browser.sleep(1000);
		GmailPage.passwordInput.sendKeys(configFile.G_PASSWORD);
		GmailPage.signInBtn.click();
		browser.wait(emailIsClickable).then(function() {
			emailSubjects.click();
		});
		//

		/*
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.get('https://mail.google.com/mail/#inbox');
				browser.wait(emailIsClickable).then(function() {
					emailSubjects.click();
				});
			});
		});
		*/
/*
		browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {
			GmailPage.expandEmail.isPresent().then(function(result) {
				if(result) {
				GmailPage.expandEmails.count().then(function(count) {
					if (count >= 1) {
						GmailPage.expandEmails.last().click();
						}
					});
				}
			});
		});

		browser.sleep(1000);
		expect(true).toBe(true);
	});
*/
	it ('Top up with custom amount', function() {
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		//
		//var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		//
		/*
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[1]).then(function() {
				browser.refresh();
			});
		});
		*/
		/*
		//
		browser.get(configFile.HTTP_HOST);

		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.emailInput.sendKeys(emailAddress);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();


		var verifyMobileIsClickable = EC.elementToBeClickable(VerifyMobile.verifymobilebutton)
		browser.wait(verifyMobileIsClickable).then(function() {
			VerifyMobile.verifymobilepopupClose.click();
		})
		*/
		//
		browser.sleep(1000);
		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
			browser.wait(providerEasypayIsClickable).then(function() {
				balanceBefore = balanceAfter;
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 25;
					TopupPage.amountCustomText.sendKeys(customAmount);
					browser.sleep(1000);
					browser.wait(topupBtnIsClickable).then(function() {
						TopupPage.topupBtn.click();
					});
				});
			});
		});


		//browser.wait(windowCount(3), 60000);
		browser.wait(windowCount(2), 60000);
		browser.getAllWindowHandles().then(function(handles) {
			//var newWindowHandle = handles[2];
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.wait(cancelBtnIsClickable).then(function() {
					EasyGateway.visaChannel.click();
					browser.sleep(2000);
					EasyGateway.creditCardNum.sendKeys('4111111111111111');
					EasyGateway.expMonth.click();
					EasyGateway.expYear.click();
					EasyGateway.creditCardCvv2.sendKeys('989');
					EasyGateway.creditCardName.sendKeys('auto tester');
					EasyGateway.submitBtn.click();
				});
			});
		});

		var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
		browser.wait(transactionSuccessfulIsVisibility).then(function() {
			expect(true).toBe(true);
			/*
			browser.getAllWindowHandles().then(function(handles) {
				browser.driver.close().then(function () {
					//browser.switchTo().window(handles[1]).then(function() {
					browser.switchTo().window(handles[0]).then(function() {
						browser.sleep(60000); //waiting 60 seconds for balance to be updated
						browser.refresh();
		    			var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
						browser.wait(walletBalanceIsPresence).then(function() {
							TopupPage.walletBalance.getInnerHtml().then(function(balance) {
								balanceAfter = balance;
								var amountIncrese = balanceAfter - balanceBefore;
								expect(amountIncrese).toEqual(customAmount);
							});
						});
					});
				});
			});
			*/
		});
	});
});
