/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var Testdata = function() {
  
  //this.url = 'https://sg-uat-54.mmvpay.com';
  this.url = 'https://sg-uat-35.mmvpay.com';
  
  this.newuser = 'matchmovenewuser@gmail.com';
  this.existingusernocard = 'matchmoveexistinguser+plstc2@gmail.com';
  this.existinguser = 'matchmoveexistinguser@gmail.com';
  this.mobilenumber = '32151532';
  this.vCardpassword = 'mmg123456$Q';
  
  this.sendexistingemail = 'matchmovenewuser@gmail.com';
  this.sendexistingmobile = '32153215';
  
  this.telerivetUsername = 'tester@matchmove.com';
  this.telerivetPassword = 'mmg123456';
  
  
  this.amountSend1 = '1';
  
  this.randomEmailNonExisting = function randomEmail(newEmail){
	  var d = new Date();
	  var t = d.getTime();
	  
	  var e = newEmail.split('@');
	  var res = e[0] + '+' + t + '@' + e[1];
	  return res;
  }
  
  this.randommobileNonExisting = function randomEmail(first2Digit){
	  
	  var res = "";
	  for (var q = 0; q < 6; q++){
	    res = res + Math.floor((Math.random() * 10));
	  }
	  res = first2Digit + res
	  return res;
  }
  
  
};

module.exports = new Testdata();

//console.log(TestData.randomEmailNonExisting('email@yopmail.com')); 
  