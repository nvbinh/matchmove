'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var AdminetPage = require('./adminet.po.js');
var KycValidationPage = require('./kycvalidation.po.js');


describe('Change Mobile Number', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);

	var newMobileNumber = 0;
	var otpCode = 0;


	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Sign up new account successfully', function() {

		browser.get(configFile.HTTP_HOST);
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber);

		console.log(mobileNumber);

		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var accountMenu = element(by.linkText('Account'));
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);

		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Complete Account Details successfully', function() {

		var accountMenu = element(by.linkText('Account'));
		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));

		browser.wait(accountMenuIsClickable).then(function() {
			accountMenu.click();
			browser.sleep(5000);
			browser.actions().keyDown(protractor.Key.COMMAND).click(accountMenu).keyUp(protractor.Key.COMMAND).perform();
		});

		browser.wait(genderIsClickable).then(function() {
			browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
		});

		element(by.css('input[value="male"]')).click();
		AccountDetailPage.userTitle(1);
		//
		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));

		if (configFile.SPASS_TYPE) {
				spassID.click();
		}
		else {
			passportID.click();
		}

		var randomID = Utility.autoGenerateMobile(12, 8);
		AccountDetailPage.identificationNumber.sendKeys(randomID);
		AccountDetailPage.completeProfile.click();

		browser.sleep(15000);

		if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
	      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
	      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
	    }
 	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
	      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
	      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
	      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
	    }
		AccountDetailPage.sameAddressBox.click();
		AccountDetailPage.updateAddress.click();
		browser.sleep(3000);
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.wait(changeMobilelLinkIsClickable).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Click change mobile number link then popup is displayed - Change button is disabled', function() {

		var changeMobilePopup = element(by.css('div.ngdialog-content'));
		var changeMobilePopupIsVisibility = EC.visibilityOf(changeMobilePopup);
		var changeMobileNumberBtn = element.all(by.css('button.button-primary--medium')).first();

		browser.sleep(1000);
		AccountDetailPage.changeMobilelLink.click();
		browser.wait(changeMobilePopupIsVisibility).then(function() {
			browser.sleep(3000);
			expect(true).toBe(true);
			expect(changeMobileNumberBtn.isEnabled()).toBe(false);
		});
	});

	it ('Enter an valid mobile number, Change button is enabled', function() {

		newMobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
		console.log(newMobileNumber);
		var mobileNumberInput = element(by.model('user.mobile'));
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));
		var changeMobileNumberBtnIsClickable = EC.elementToBeClickable(changeMobileNumberBtn);

		browser.sleep(1000);
		mobileNumberInput.sendKeys(newMobileNumber);
		browser.wait(changeMobileNumberBtnIsClickable).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Click Change Mobile Number button then user is required to input OTP code', function() {

		var otpInput = element(by.model('user.otpValue'));
		var otpInputIsVisibility = EC.visibilityOf(otpInput);
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));

		browser.sleep(1000);
		changeMobileNumberBtn.click();
		browser.wait(otpInputIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Open Telerivet and get OTP', function() {

		var loginBtnIsClickable = EC.elementToBeClickable(TelerivetPage.loginButton);
		var otpMessage = element(by.partialLinkText(newMobileNumber));
		var otpMessageIsVisibility = EC.visibilityOf(otpMessage);
		var latestMessage = element.all(by.css('span.convContent')).last();

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.get(configFile.TELERIVET_SGMC_URL);
				browser.wait(loginBtnIsClickable).then(function() {
					TelerivetPage.emailfield.sendKeys(configFile.TELERIVET_USERNAME);
					TelerivetPage.passwordfield.sendKeys(configFile.TELERIVET_PASSWORD);
					TelerivetPage.loginButton.click();
					browser.wait(otpMessageIsVisibility).then(function() {
						otpMessage.click();
						expect(true).toBe(true);
						browser.sleep(4000);
					});
				});
			});
		});

		browser.sleep(4000);
		latestMessage.getText().then(function(text) {
			var slitMessage = text.split(" ");
			otpCode = slitMessage[19].replace(",", "");
			console.log('OTP: ' + otpCode);
		});

	});

	it ('Enter OTP code and click Verify button', function() {

		var otpInput = element(by.model('user.otpValue'));
		var verifyOtpBtn = element.all(by.css('button.button-primary--medium')).last();
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				otpInput.sendKeys(otpCode);
				browser.sleep(1000);
				verifyOtpBtn.click();
				browser.wait(changeMobilelLinkIsClickable).then(function() {
					browser.sleep(1000);
					expect(true).toBe(true);
				});
			});
		});
	});

	it ('New mobile number is saved', function() {

		var newMobileNumberValue = element(by.cssContainingText('p.ng-binding', newMobileNumber));

		browser.sleep(10000);
		expect(newMobileNumberValue.isDisplayed()).toBe(true);

	});

	it ('Open Adminet and view card holder details, new mobile number was updated', function() {

		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var viewCardHolderDetailsIsVisibility = EC.visibilityOf(AdminetPage.viewCardHolderDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var userDetailsTabIsClickable = EC.elementToBeClickable(AdminetPage.userDetailsTab);
		var newMobileNumberValue = element.all(by.cssContainingText('div.box p', newMobileNumber)).first();
		var newMobileNumberValueIsVisibility = EC.visibilityOf(newMobileNumberValue);

		browser.sleep(2000);
		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.get(configFile.HTTP_HOST_ADMINET);
				AdminetPage.emailfield.sendKeys(configFile.ADMINET_ACCOUNT.EMAIL);
				AdminetPage.passwordfield.sendKeys(configFile.ADMINET_ACCOUNT.PASSWORD);
				AdminetPage.loginButton.click();
				browser.wait(actionMenuIsClickable).then(function() {
					AdminetPage.actionMenu.click();
					browser.wait(viewCardHolderDetailsIsVisibility).then(function() {
						browser.sleep(3000);
						AdminetPage.viewCardHolderDetails.click();
						browser.wait(generateBtnIsClickable).then(function() {
							AdminetPage.searchTypeMobile.click();
							AdminetPage.searchKeyword.sendKeys(newMobileNumber);
							AdminetPage.generateBtn.click();
							browser.wait(userDetailsTabIsClickable).then(function() {
								AdminetPage.userDetailsTab.click();
								browser.wait(newMobileNumberValueIsVisibility).then(function() {
									browser.sleep(1000);
									expect(true).toBe(true);
								});
							});
						});
					});
				});
			});
		});
	});

	it ('Logout and login by new mobile number and check notification', function() {

		var changeMobileNumberNotification = element.all(by.cssContainingText('p.ng-binding', 'You have successfully changed your mobile number.')).first();
		var changeMobileNumberNotificationIsPresense = EC.presenceOf(changeMobileNumberNotification);
		var verifyIdentityBtnIsClickable = EC.elementToBeClickable(KycValidationPage.verifyIdentityBtn);
		var closePopup = element(by.css('a.btnClose'));
		var closePopupIsClickable = EC.elementToBeClickable(closePopup);
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var notificationBellIsClickable = EC.elementToBeClickable(DashboardPage.notificationBell);
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);
		var accountMenu = element(by.linkText('Account'));
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(1000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					LoginPage.userInput.sendKeys(newMobileNumber);
					LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				});
				LoginPage.submitBtn.click();
				browser.wait(closePopupIsClickable).then(function() {
					closePopup.click();
					browser.sleep(5000)
					DashboardPage.notificationBell.click();
					browser.sleep(5000);
					DashboardPage.goToNotification.click();
					browser.wait(changeMobileNumberNotificationIsPresense).then(function() {
						browser.sleep(1000);
						expect(true).toBe(true);
					});
				});
			});
		});

	});

});
