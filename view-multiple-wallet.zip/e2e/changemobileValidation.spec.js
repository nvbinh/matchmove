'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var AdminetPage = require('./adminet.po.js');
var KycValidationPage = require('./kycvalidation.po.js');


describe('Change Mobile Number Validation', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);

	var newMobileNumber = 0;
	var otpCode = 0;


	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(5000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
	});

	it ('Sign up new account successfully', function() {

		browser.get(configFile.HTTP_HOST);
		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});
		browser.sleep(2000);
		if (configFile.VERIFY_EMAIL_ENABLE) {
			SignUpPage.emailInput.sendKeys(emailAddress);
		}
		SignUpPage.firstNameInput.sendKeys('loc');
		SignUpPage.lastNameInput.sendKeys('loc');
		SignUpPage.preferredNameInput.sendKeys('loc');
		SignUpPage.mobileInput.sendKeys(mobileNumber);

		console.log(mobileNumber);

		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var accountMenu = element(by.linkText('Account'));
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);

		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

/*
	it('Sign up New user', function() {

	Utility.setScreenSize();

	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(20000);
	browser.sleep(10000);
});
*/

	it ('Complete Account Details successfully', function() {

		var accountMenu = element(by.linkText('Account'));
		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);
		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));

		browser.wait(accountMenuIsClickable).then(function() {
			accountMenu.click();
			browser.sleep(5000);
			browser.actions().keyDown(protractor.Key.COMMAND).click(accountMenu).keyUp(protractor.Key.COMMAND).perform();
		});

		browser.wait(genderIsClickable).then(function() {
			browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
		});

		element(by.css('input[value="male"]')).click();
		AccountDetailPage.userTitle(1);
		//
		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));

		if (configFile.SPASS_TYPE) {
				spassID.click();
		}
		else {
			passportID.click();
		}

		var randomID = Utility.autoGenerateMobile(12, 8);
		AccountDetailPage.identificationNumber.sendKeys(randomID);
		AccountDetailPage.completeProfile.click();

		browser.sleep(15000);

		if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
	      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
	      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
	    }
 	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
	      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
	      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
	      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
	    }
		AccountDetailPage.sameAddressBox.click();
		AccountDetailPage.updateAddress.click();
		browser.sleep(3000);
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.wait(changeMobilelLinkIsClickable).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Click change mobile number link then popup is displayed - Change button is disabled', function() {

		var changeMobilePopup = element(by.css('div.ngdialog-content'));
		var changeMobilePopupIsVisibility = EC.visibilityOf(changeMobilePopup);
		var changeMobileNumberBtn = element.all(by.css('button.button-primary--medium')).first();

		browser.sleep(1000);
		AccountDetailPage.changeMobilelLink.click();
		browser.wait(changeMobilePopupIsVisibility).then(function() {
			browser.sleep(3000);
			expect(true).toBe(true);
			expect(changeMobileNumberBtn.isEnabled()).toBe(false);
		});
	});


	it ('Enter invalid mobile - mobile number less than 8', function() {

		newMobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
		console.log(newMobileNumber);
		var mobileNumberInput = element(by.model('user.mobile'));
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));
		var changeMobileNumberBtnIsClickable = EC.elementToBeClickable(changeMobileNumberBtn);

		browser.sleep(1000);
		mobileNumberInput.clear().sendKeys('6755769');
		expect(changeMobileNumberBtn.isEnabled()).toBe(false)

	});

	it ('Enter invalid mobile - mobile number more than 8', function() {

		newMobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
		console.log(newMobileNumber);
		var mobileNumberInput = element(by.model('user.mobile'));
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));
		var changeMobileNumberBtnIsClickable = EC.elementToBeClickable(changeMobileNumberBtn);

		browser.sleep(1000);
		mobileNumberInput.clear().sendKeys('675576989');
		expect(changeMobileNumberBtn.isEnabled()).toBe(false)

	});

	it ('Enter invalid mobile - special characters', function() {

		newMobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
		console.log(newMobileNumber);
		var mobileNumberInput = element(by.model('user.mobile'));
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));
		var changeMobileNumberBtnIsClickable = EC.elementToBeClickable(changeMobileNumberBtn);

		browser.sleep(1000);
		mobileNumberInput.clear().sendKeys('675576989');
		expect(changeMobileNumberBtn.isEnabled()).toBe(false)

	});

	it ('Enter an valid mobile number, Change button is enabled', function() {

		newMobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
		console.log(newMobileNumber);
		var mobileNumberInput = element(by.model('user.mobile'));
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));
		var changeMobileNumberBtnIsClickable = EC.elementToBeClickable(changeMobileNumberBtn);

		browser.sleep(1000);
		mobileNumberInput.clear().sendKeys(newMobileNumber);
		browser.wait(changeMobileNumberBtnIsClickable).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('Click Change Mobile Number button then user is required to input OTP code', function() {

		var otpInput = element(by.model('user.otpValue'));
		var otpInputIsVisibility = EC.visibilityOf(otpInput);
		var changeMobileNumberBtn = element(by.css('button.button-primary--medium'));

		browser.sleep(1000);
		changeMobileNumberBtn.click();
		browser.wait(otpInputIsVisibility).then(function() {
			browser.sleep(1000);
			expect(true).toBe(true);
		});
	});

	it ('OTP code - less than 6 and more than 6 digits', function() {

		var otpInput = element(by.model('user.otpValue'));
		var verifyOtpBtn = element.all(by.css('button.button-primary--medium')).last();
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				otpInput.clear().sendKeys('57673');
				browser.sleep(1000);
				expect(verifyOtpBtn.isEnabled()).toBe(false);

				otpInput.clear().sendKeys('57673485');
				browser.sleep(1000);
				expect(verifyOtpBtn.isEnabled()).toBe(false);
			});
		});
	});

	it ('OTP code - invalid', function() {

		var otpInput = element(by.model('user.otpValue'));
		var verifyOtpBtn = element.all(by.css('button.button-primary--medium')).last();
		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				otpInput.clear().sendKeys('000100');
				browser.sleep(1000);
				verifyOtpBtn.click();
				browser.sleep(10000);
				expect(verifyOtpBtn.isDisplayed()).toBe(true);
			});
		});
	});

});
