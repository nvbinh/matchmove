/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var GetAnotherCardPage = function() {

  this.getCardMenu = element(By.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[1]/side-bar/ul/li[9]/a'))

  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));

  //pre kyc
  this.verifyIdentityButton = element(by.css('.button-primary--medium.ng-binding'));
  this.transferButton = element(by.css('div.section-action button.button-primary--medium'));

  //post kyc
  //get card tab
  this.getFreecardTab = element.all(by.css('mm-tab-item.mm-tab')).first();
  //this.getFreecardTab = element(by.xpath('.//*[@id="masterUI"]/div/div/div/div/div/*/v-tab[1]/h3'));
  //this.getFreecardTab = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[2]/div/div[2]/div[2]/section/div/section/div/v-tabs/v-tab[1]/h3'));
  this.cardimage = element(by.css('.cardContainer.card-get__new'));
  this.getcardDescription = element(by.css('aside.cardloading-container'));
  this.getCardButton = element(by.css('.button-primary--medium.ng-binding'));
  this.cardDescription = element(by.css('.cardDescription'));

  //purchase card tab
  this.purchaseAcard = element.all(by.css('mm-tab-item.mm-tab')).get(1);
  //this.purchaseCardImage = element(by.css('.content-message--comingsoon.ng-scope>img'));
  this.purchaseCardImage = element(by.css('.cardContainer.card-get__new'));
  this.purchaseCardDescription = element(by.css('.cardloading-container'));
  this.purchaseCardContent = element(by.css('.cardDescription'));
	this.orderButton = element(by.css('button[ng-hide="getNewCardLoading"]'));

  //this.purchaseCardContent = element(by.css('li[ng-repeat="card in PhysicalCards"] .cardDescription'));

  //activate card
  this.activateCard = element.all(by.css('mm-tab-item.mm-tab')).last();
  //this.navigation = element(by.css('.navigation.ng-scope>div'));
  this.stepImage = element(by.css('.media-image>img'));
  this.stepDescription = element.all(by.css('div.sub-item--description')).last();
	this.activateButton = element(by.css('button[ng-hide="PurchasedCardLoading"]'));

	this.leftarrow1 = element(by.repeater('card in virtualCardList'));
	this.rightarrow1 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[2]'));

	/*
  this.leftarrow1 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[7]'));
  this.rightarrow1 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[2]'));
  this.leftarrow2 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[1]'));
  this.rightarrow2 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[3]'));
  this.leftarrow3 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[2]'));
  this.rightarrow3 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[4]'));
  this.leftarrow4 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[3]'));
  this.rightarrow4 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[5]'));
  this.leftarrow5 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[4]'));
  this.rightarrow5 = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[2]/section/div/section/v-pages/v-page[3]/div/div[1]/label[6]'));
*/



};

module.exports = new GetAnotherCardPage();
