/*
***** Please provide new proxy number in SGMCconfig.json (PROXY_NUMBER) before running this script
*/
'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js')

describe('Activate Card', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;
	var sendAmount = 0;
	var otpCode = '';


	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Signup new account successfully and complete account details', function() {

		var signupBtnIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.get(configFile.HTTP_HOST);
		browser.wait(signupBtnIsClickable).then(function() {
			LoginPage.signupBtn.click();
			browser.sleep(5000);
			SignUpPage.firstNameInput.sendKeys(Utility.randomFirstName(configFile.ACCOUNT_INFO.FIRST_NAME));
			SignUpPage.lastNameInput.sendKeys('loc');
			SignUpPage.preferredNameInput.sendKeys('loc');
			SignUpPage.mobileInput.sendKeys(mobileNumber);
			console.log("Mobile number: " + mobileNumber);
			if (configFile.SIGNUP_PAGE.nationalityEnabled) {
				SignUpPage.nationality.$('[value="Indian"]').click();
			};
			SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
			SignUpPage.tncCheckbox.click()	;
			SignUpPage.submitBtn.click();
		});

		var accountMenu = element(by.linkText('Account'));

		var accountMenuIsClickable = EC.elementToBeClickable(accountMenu);
		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
		});

	});

	it ('Access Get Another Card page', function() {

		var getAnotherCardMenu = element(by.linkText('Get Another Card'));
		var getAnotherCardMenuIsClickable = EC.elementToBeClickable(getAnotherCardMenu);
		var purchaseACardIsPresence = EC.presenceOf(CardActivationPage.purchaseACard);

		browser.wait(getAnotherCardMenuIsClickable).then(function() {
			getAnotherCardMenu.click();
			browser.wait(purchaseACardIsPresence).then(function() {
				expect(true).toBe(true);
				browser.actions().keyDown(protractor.Key.COMMAND).click(getAnotherCardMenu).keyUp(protractor.Key.COMMAND).perform();
				browser.sleep(3000);
			});
		});
	});

	it ('Click Purchase a card', function() {

		CardActivationPage.purchaseACard.click();
		browser.sleep(2000);
		expect(CardActivationPage.orderACardBtn.isPresent()).toBe(true);
	});

	it ('Click Order a Card button', function() {

		var orderCardPopupIsPresence = EC.presenceOf(CardActivationPage.orderCardPopup);
		CardActivationPage.orderACardBtn.click();
		browser.wait(orderCardPopupIsPresence).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ('Cancel Order Card successfully', function() {

		var cancelSuccessMessage = element(by.cssContainingText('p.ng-binding', 'You declined the card order'));
		var cancelSuccessMessageIspresence = EC.presenceOf(cancelSuccessMessage);

		CardActivationPage.cancelBtn.click();
		browser.wait(cancelSuccessMessageIspresence).then(function() {
			expect(true).toBe(true);
			browser.sleep(500);
		});

	});

	it ('Click Order Card button', function() {

		var orderCardPopupIsPresence = EC.presenceOf(CardActivationPage.orderCardPopup);
		var newCardOrderNotAllowIsPresence = EC.presenceOf(CardActivationPage.newCardOrderNotAllow);

		browser.sleep(1000);
		CardActivationPage.orderACardBtn.click();
		browser.wait(orderCardPopupIsPresence).then(function() {
			browser.sleep(1000);
			CardActivationPage.orderCardBtn.click();
			browser.wait(newCardOrderNotAllowIsPresence).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});
		});
	});

	it ('Activate a Card', function() {

		var activateACardIsClickable = EC.elementToBeClickable(CardActivationPage.activateACard);
		var activateCardPopupIsVisibility = EC.visibilityOf(CardActivationPage.activateCardPopup);
		var cardNumberModeIsClickable = EC.elementToBeClickable(CardActivationPage.cardNumberMode);
		var proxyNumberModeIsClickable = EC.elementToBeClickable(CardActivationPage.proxyNumberMode);

		browser.refresh();
		browser.wait(activateACardIsClickable).then(function() {
			CardActivationPage.activateACard.click();
			browser.sleep(1000);
			CardActivationPage.activateCardOrderBtn.click();
			browser.wait(activateCardPopupIsVisibility).then(function() {
				browser.wait(cardNumberModeIsClickable).then(function() {
					CardActivationPage.cardNumberMode.click();
					browser.wait(proxyNumberModeIsClickable).then(function() {
						CardActivationPage.proxyNumberMode.click();
						expect(true).toBe(true);
						browser.sleep(2000);
					});
				});
			});
		});
	});

	it ('12 digits are allowed', function() {

		var digitAllowMessageIsVisibility = EC.visibilityOf(CardActivationPage.digitAllowMessage);
		CardActivationPage.proxyInp.click();
		CardActivationPage.proxyInp.sendKeys(123456789);
		browser.wait(digitAllowMessageIsVisibility).then(function() {
			expect(CardActivationPage.digitAllowMessage.isDisplayed()).toBe(true);

			CardActivationPage.proxyInp.clear();
			CardActivationPage.proxyInp.sendKeys('abcdefghiklm');
			browser.sleep(1000);
			expect(CardActivationPage.digitAllowMessage.isDisplayed()).toBe(true);

			CardActivationPage.proxyInp.clear();
			CardActivationPage.proxyInp.sendKeys(1234567890123);
			browser.sleep(1000);
			expect(CardActivationPage.digitAllowMessage.isDisplayed()).toBe(true);
		});
	});

	it ('Proxy number is required', function() {

		CardActivationPage.proxyInp.clear();
		browser.sleep(1000);
		expect(CardActivationPage.proxyNumberIsRequired.isDisplayed()).toBe(true);

	});

	it ('Enter an invalid proxy number but correct format then Submit button is enabled', function() {

		CardActivationPage.proxyInp.sendKeys(123456789012);
		browser.sleep(1000);
		expect(CardActivationPage.submitBtn.isEnabled()).toBe(true);
	});

	it ('Click Submit button then error message is displayed', function() {

		var errorMessageIsVisibility = EC.visibilityOf(CardActivationPage.errorMessage);

		CardActivationPage.submitBtn.click();
		browser.wait(errorMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(500);
		});
	});

	it ('Using number already activated', function() {

		var alreadyActivatedMessageIsVisibility = EC.visibilityOf(CardActivationPage.alreadyActivatedMessage);

		CardActivationPage.proxyInp.clear();
		CardActivationPage.proxyInp.sendKeys(configFile.PROXY_NUMBER.ACTIVATED);
		CardActivationPage.submitBtn.click();
		browser.wait(alreadyActivatedMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(500);
		});
	});

	it ('Using valid proxy number then verify OTP is displayed', function() {

		var otpInputIsVisibility = EC.visibilityOf(CardActivationPage.otpInput);

		CardActivationPage.proxyInp.clear();
		CardActivationPage.proxyInp.sendKeys(configFile.PROXY_NUMBER.NEW);

		CardActivationPage.submitBtn.click();
		browser.wait(otpInputIsVisibility).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Verify OTP button is disabled as default or when user enter an invalid OTP format', function() {

		CardActivationPage.otpInput.sendKeys(12345);
		expect(CardActivationPage.verifyOtpBtn.isEnabled()).toBe(false);

		CardActivationPage.otpInput.clear();
		CardActivationPage.otpInput.sendKeys(1234567);
		expect(CardActivationPage.verifyOtpBtn.isEnabled()).toBe(false);
	});

	it ('OTP is invalid', function() {

		var invalidOtpMessageIsVisibility = EC.visibilityOf(CardActivationPage.invalidOtpMessage);

		CardActivationPage.otpInput.clear();
		CardActivationPage.otpInput.sendKeys(123456);

		CardActivationPage.verifyOtpBtn.click();
		browser.wait(invalidOtpMessageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(3000);
		});
	});

	it ('Open Telerivet and get OTP', function() {

		var loginBtnIsClickable = EC.elementToBeClickable(TelerivetPage.loginButton);
		var otpMessage = element(by.partialLinkText(mobileNumber));
		var otpMessageIsVisibility = EC.visibilityOf(otpMessage);
		var latestMessage = element.all(by.css('span.convContent')).last();

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.get(configFile.TELERIVET_SGMC_URL);
				browser.wait(loginBtnIsClickable).then(function() {
					TelerivetPage.emailfield.sendKeys(configFile.TELERIVET_USERNAME);
					TelerivetPage.passwordfield.sendKeys(configFile.TELERIVET_PASSWORD);
					TelerivetPage.loginButton.click();
					browser.wait(otpMessageIsVisibility).then(function() {
						otpMessage.click();
						expect(true).toBe(true);
						browser.sleep(4000);
					});
				});
			});
		});

		browser.sleep(4000);
		latestMessage.getText().then(function(text) {
			var slitMessage = text.split(" ");
			otpCode = slitMessage[10].replace(".", "");
		});

	});

	it ('Enter valid OTP and click Verify', function() {

		var purchaseACardIsPresence = EC.presenceOf(CardActivationPage.purchaseACard);

		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				CardActivationPage.otpInput.clear();
				browser.sleep(1000);
				CardActivationPage.otpInput.sendKeys(otpCode);
				CardActivationPage.verifyOtpBtn.click();
				browser.wait(purchaseACardIsPresence).then(function() {
					expect(true).toBe(true);
					browser.sleep(10000);
				});
			});
		});
	});

	it ('Physical card is present', function() {

		DashboardPage.logoutLink.click();
		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.userInput.sendKeys(mobileNumber);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();

		var getAnotherCardMenu = element(by.linkText('Get Another Card'));
		var getAnotherCardMenuIsClickable = EC.elementToBeClickable(getAnotherCardMenu);
		browser.wait(getAnotherCardMenuIsClickable).then(function() {
			var physicalCard = element(by.cssContainingText('div.cardDescription h4', 'Physical'));
			var physicalCardIsVsibility = EC.visibilityOf(physicalCard);
			browser.wait(physicalCardIsVsibility).then(function() {
				expect(true).toBe(true);
				browser.sleep(1000);
			});
		});
	});

	it ('Get CVC sucessfully', function() {
		var getCVC = element(by.css('a.button-security'));
		var cvcCode = element(by.css('span.cvv'));
		var cvcCodeIsVisibility = EC.visibilityOf(cvcCode);

		getCVC.click();
		browser.wait(cvcCodeIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});

	});

});
