'use strict';

var Utility = function() {

  //this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  require('./waitReady.js');
  var configFile = require('./e2e.json');

  this.setScreenSize = function(){
	  browser.driver.manage().window().maximize();
	  //browser.manage().window().setSize(640, 1136);
  }

  this.randomEmailNonExisting = function randomEmail(newEmail){
	  var d = new Date();
	  var t = d.getTime();

	  var e = newEmail.split('@');
	  var res = e[0] + '+' + t + '@' + e[1];
	  return res;
  }

  this.randomFirstName = function randomEmail(fname){

    var textw = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    for( var i=0; i < 5; i++ )
        textw += possible.charAt(Math.floor(Math.random() * possible.length));

    //return text;

    var res = fname + textw
    return res;
  }

  this.randommobileNonExisting = function randomEmail(first2Digit, len){

	  var res = "";

	  if (configFile.MOBILE_RANDOM == "true"){
		  for (var q = 0; q < len; q++){
		    res = res + Math.floor((Math.random() * 10));
		  }
		  res = first2Digit + res
		  return res;
	  }
	  else{
	  	var res = first2Digit + len;
    		return res;
	  }


  }

  this.OpenNewTab = function(){
	  browser.actions().sendKeys(protractor.Key.CONTROL +'t').perform()/*.then(function () {
        browser.sleep(3000);
		browser.getAllWindowHandles().then(function (handles) {
            var newWindowHandle = handles[1]; // this is your new window
            browser.switchTo().window(newWindowHandle)
        });
	  });*/
  }

  this.goToGmailandOpenTheLastestEmail = function(emailOpen, passWord){
	browser.ignoreSynchronization = true;
    browser.get('https://gmail.com');
	browser.sleep(10000);

	var emailField = element(by.css('input[type="email"]'));
	var nextButton = element(by.css('input[type="submit"]'));
	var passwordField = element(by.css('input[type="password"]'));
	var signInButton = element(by.css('input[value="Sign in"]'));

	var emailSubject = element(by.css('tr.zA td.xY div.xS div.xT div.y6 span'));
	var persistentCookie = element(by.css('#PersistentCookie'));

	browser.sleep(10000);

	//expect(emailField.isPresent()).toBe(true);
	//expect(nextButton.isPresent()).toBe(true);

	emailField.isPresent().then(function(result){
		if(result){
			emailField.sendKeys(configFile.EXISTING_EMAIL);
			nextButton.click();
		}
		else{
		}
	});

	browser.sleep(3000);

	passwordField.isPresent().then(function(result){
		if(result){
			persistentCookie.isPresent().then(function(present){
				if(present){
					persistentCookie.isSelected().then(function(select){
						if(select){
							persistentCookie.click();
						}
					});
				}
			passwordField.sendKeys(configFile.GMAIL_PASSWORD);
			signInButton.click();

			});
		}
		else{
		}
	});


	browser.sleep(15000);

	//expect(emailSubject.waitReady()).toBeTruthy();
	emailSubject.click();

	browser.sleep(10000);
  }

  this.clickButtonfromEmail = function(objClick){
	  objClick.click();
  }

  this.closeSelectedBrowser = function(windowIndex){
	  browser.getAllWindowHandles().then(function (handles) {
	    browser.switchTo().window(handles[windowIndex]).then(function() {
	      browser.close();
	    })
	  })
  }

  this.chooseActiveTab = function(windowIndex){
	  browser.getAllWindowHandles().then(function (handles) {
	    browser.switchTo().window(handles[windowIndex])
	  })
  }

  this.getString = function(obj, start, len){
	  //return obj.getText().then(function(text){
		var stringResult = obj.substr(start, len);
		return stringResult;

  }

  this.randomIdentityNumberGenerator = function randomNumber(charac){
	  var res = "";
	  for (var q = 0; q < 6; q++){
	    res = res + Math.floor((Math.random() * 10));
	  }
	  res = charac + res;
	  return res;
  }


	this.autoGenerateEmail = function(local_part, domain_part) {
		var randVal = Date.now();
		var autoGenerateEmail = local_part + randVal + domain_part;
		return autoGenerateEmail;
	};

	this.autoGenerateMobile = function(prefix_2digits, length) {
		var autoGenerateMobile = "";
		for (var i = 0; i < (length - 2); i++) {
			autoGenerateMobile += Math.floor(Math.random() *10);
		}
		return prefix_2digits + autoGenerateMobile;
	};

};

module.exports = new Utility();
