/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var ChangePasswordPage = function() {
  this.bannerImg = element(by.css('.image__centered img'));
  this.pageTitle = element(by.css('.marketing__title h1'));
  this.passwordField = element(by.model('password'));
  this.confirmPasswordField = element(by.model('rePassword'));
  //this.submitBtn = element(by.css('div.content-main form.form__centered div.section-action button'));
  this.submitBtn = element(by.css('form.form__centered div.section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.errorBanner = element(by.css('form .msg-banner .error-banner .mwc-common-alert'));
  this.successMessage = element(by.css('form .msg-banner .success-banner .mwc-common-alert p'));

  //from account details
  this.editpassword = element.all(by.css('div label a svg')).get(1);

  //change password popup
  this.popupHeader = element(by.css('.modal-title'));
  this.passField = element(by.model('password'));
  this.comsatPassword = element(by.css('.comsat--btn'));
  this.submitButton = element(by.css('button[type="submit"]'));
  this.sucessChangeMessage = element(by.css('.success-banner'));

  //notification
  this.notificationRow = element.all(by.css('.notify-group--UsersAuthenticationsPassword')).first();
  this.notificationIcon = element.all(by.css('use[data-ng-href="#mcw-notification-_ACT_CHANGE_PASSWORD_SUCCESS"]')).first();






};

module.exports = new ChangePasswordPage();
