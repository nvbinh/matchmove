/*
*** Please provide new proxy number to accquire physical card before running this script.
*/

'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobile = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var LoadUnloadPage = require('./loadunloadpopup.po.js');
var RemitPage = require('./remittance.po.js');
var CardActivationPage = require('./cardactivation.po.js');
var TelerivetPage = require('./telerivet.po.js');
var path = require('path');
var KycValidationPage = require('./kycvalidation.po.js');
var AdminetPage = require('./adminet.po.js');

describe('Topup validation - topup/load/unload', function() {

	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;

	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var getAnotherCardMenu = element(by.linkText('Get Another Card'));
	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;
	var otpCode = '';

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Signup successfully', function() {
		browser.get(configFile.HTTP_HOST);
		LoginPage.signupBtn.click();
		browser.sleep(5000);
		//SignUpPage.emailInput.sendKeys(emailAddress);
		SignUpPage.firstNameInput.sendKeys(configFile.ACCOUNT_INFO.FIRST_NAME);
		SignUpPage.lastNameInput.sendKeys(configFile.ACCOUNT_INFO.LAST_NAME);
		SignUpPage.preferredNameInput.sendKeys(configFile.ACCOUNT_INFO.PREFERRED_NAME);
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		console.log(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var accountMenuIsClickable = EC.elementToBeClickable(DashboardPage.accountMenu);
		browser.wait(accountMenuIsClickable).then(function() {
			expect(true).toBe(true);
		});
	});

	it ('Pre-KYC can not topup with amount = 999', function() {

		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var maxWarningMessageIsVisibility = EC.visibilityOf(TopupPage.maxWarningMessage);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);

		browser.sleep(3000);
		DashboardPage.topupMenu.click();

		browser.wait(providerEasypayIsClickable).then(function() {
		browser.sleep(2000);
		TopupPage.providerEasypay.click();
			browser.wait(topupBtnIsClickable).then(function() {
				TopupPage.amountCustom.click();
				customAmount = 999;
				TopupPage.amountCustomText.sendKeys(customAmount);
				browser.wait(maxWarningMessageIsVisibility).then(function() {
					expect(true).toBe(true);
					browser.sleep(2000);
				});
			});
		});
	});

	it ('Complete profile successfully', function() {

		var genderIsClickable = EC.elementToBeClickable(element(by.css('input[value="male"]')));

		browser.sleep(3000);

		browser.actions().keyDown(protractor.Key.COMMAND).click(DashboardPage.accountMenu).keyUp(protractor.Key.COMMAND).perform();
		DashboardPage.accountMenu.click();


		browser.wait(genderIsClickable).then(function() {
			browser.sleep(2000);
			browser.driver.actions().mouseDown(AccountDetailPage.birthday).click().sendKeys("1975-01-10").perform();
		});

		element(by.css('input[value="male"]')).click();
		AccountDetailPage.userTitle(1);
		//
		var spassID = element(by.css('input[value="spass"]'));
		var passportID = element(by.css('input[value="passport"]'));

		if (configFile.SPASS_TYPE) {
				spassID.click();
		}
		else {
			passportID.click();
		}

		var randomID = Utility.autoGenerateMobile(12, 8);
		AccountDetailPage.identificationNumber.sendKeys(randomID);
		AccountDetailPage.completeProfile.click();

		browser.sleep(15000);

		if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_1 == "true"){
	      AccountDetailPage.address1R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_1);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.address_2 == "true"){
	      AccountDetailPage.address2R.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.address_2);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.city == "true"){
	      AccountDetailPage.city.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.city);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.state == "true"){
	      AccountDetailPage.state.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.state);
	    }
	    if (configFile.ACCOUNTS_PAGE.residentialEnabled.postalCode == "true"){
	      AccountDetailPage.postalR.sendKeys(configFile.ACCOUNTS_PAGE.residentialValues.postalCode);
	    }
		AccountDetailPage.sameAddressBox.click();
		AccountDetailPage.updateAddress.click();
		browser.sleep(3000);

		var changeMobilelLinkIsClickable = EC.elementToBeClickable(AccountDetailPage.changeMobilelLink);

		browser.wait(changeMobilelLinkIsClickable).then(function() {
			browser.sleep(2000);
			expect(true).toBe(true);
		});
	});

	it ('Click KYC link then user is redirected upload images page', function() {

		var kycLink = element(by.css('a[ng-dialog="app/components/doKyc/partials/doKyc.html"]'));
		var uploadImageIsVisibility = EC.visibilityOf(KycValidationPage.uploadImage);
		var uploadDocumentsBtnIsClickable = EC.elementToBeClickable(KycValidationPage.uploadDocumentsBtn);

		browser.sleep(2000);
		kycLink.click();
		browser.wait(uploadDocumentsBtnIsClickable).then(function() {
			browser.sleep(2000);
			KycValidationPage.uploadDocumentsBtn.click();
			browser.wait(uploadImageIsVisibility).then(function() {
				expect(true).toBe(true);
			});
		});
	});

	it ('Upload KYC document successfully', function() {

		var image1 = './KYC_Image/image1.png';
		var image1Path = path.resolve(__dirname, image1);
		var image2 = './KYC_Image/image2.png';
		var image2Path = path.resolve(__dirname, image2);
		var image3 = './KYC_Image/image3.png';
		var image3Path = path.resolve(__dirname, image3);
		var image4 = './KYC_Image/image4.png';
		var image4Path = path.resolve(__dirname, image4);

		var KYCprogressIsPresence = EC.presenceOf(KycValidationPage.KYCprogress);

		browser.sleep(2000);
		KycValidationPage.inputFile.sendKeys(image1Path);
		KycValidationPage.inputFile.sendKeys(image2Path);
		KycValidationPage.inputFile.sendKeys(image3Path);
		KycValidationPage.inputFile.sendKeys(image4Path);
		browser.sleep(4000);

		KycValidationPage.submitDocumentBtn.click();
		browser.wait(KYCprogressIsPresence).then(function() {
			expect(true).toBe(true);
		});
	})

	it ('Do approve KYC in Adminet', function() {

		var actionMenuIsClickable = EC.elementToBeClickable(AdminetPage.actionMenu);
		var KYCsubmissionDetailsIsVisibility = EC.visibilityOf(AdminetPage.KYCsubmissionDetails);
		var generateBtnIsClickable = EC.elementToBeClickable(AdminetPage.generateBtn);
		var f2fVerificationBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationBtn);
		var f2fVerificationRequiredBannerIsVisibility = EC.visibilityOf(KycValidationPage.f2fVerificationRequiredBanner);
		var f2fVerificationApprovalBtnIsClickable = EC.elementToBeClickable(AdminetPage.f2fVerificationApprovalBtn);
		var submitYcsBtnIsClickable = EC.elementToBeClickable(AdminetPage.submitYcsBtn);
		var alreadySubmitYCSIsPresence = EC.presenceOf(AdminetPage.alreadySubmitYCS);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.get(configFile.HTTP_HOST_ADMINET);
				AdminetPage.emailfield.sendKeys(configFile.ADMINET_ACCOUNT.EMAIL);
				AdminetPage.passwordfield.sendKeys(configFile.ADMINET_ACCOUNT.PASSWORD);
				AdminetPage.loginButton.click();
				browser.wait(actionMenuIsClickable).then(function() {
					AdminetPage.actionMenu.click();
					browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
						browser.sleep(3000);
						AdminetPage.KYCsubmissionDetails.click();
					});

					browser.wait(generateBtnIsClickable).then(function() {
						AdminetPage.searchTypeMobile.click();
						AdminetPage.searchKeyword.sendKeys(mobileNumber);
						AdminetPage.generateBtn.click();
						browser.wait(actionMenuIsClickable).then(function() {
							AdminetPage.actionMenu.click();
							browser.wait(KYCsubmissionDetailsIsVisibility).then(function() {
								browser.sleep(3000);
								AdminetPage.KYCsubmissionDetails.click();
							});
							browser.wait(f2fVerificationBtnIsClickable).then(function() {
								AdminetPage.f2fVerificationBtn.click();
								browser.wait(f2fVerificationApprovalBtnIsClickable).then(function() {
									AdminetPage.f2fVerificationApprovalBtn.click();
									browser.wait(submitYcsBtnIsClickable).then(function() {
										AdminetPage.submitYcsBtn.click();
										browser.wait(alreadySubmitYCSIsPresence).then(function() {
											expect(true).toBe(true);
											browser.sleep(2000);
										});
									});
								});
							});
						});
					});
				});
			});
		});
	})

	it ('Connect to database and mannually approve KYC successfully', function() {

		var mysql = require('/usr/local/lib/node_modules/mysql');
	    var connection = mysql.createConnection({
	        host : configFile.DB_INFO.HOST,
	        user : configFile.DB_INFO.USERNAME,
	        password : configFile.DB_INFO.PASSWORD
	    });
	    connection.connect();

	    var kycApproveQuery = "update sg_mc_uat.kyc set status = 'approved', for_processor_verification = 'submitted to ycs', date_processed = CURRENT_TIMESTAMP() where user_id = (select id from sg_mc_uat.users where username like '%" + mobileNumber + "%');";

        browser.sleep(5000);
		connection.query(kycApproveQuery, function(err, rows) {
		    if (err) {
		        console.log('Could not run query');
		    } else {
		    	console.log('Approve KYC successfully');
		   		expect(true).toBe(true);
		    }
		});
		browser.sleep(2000);
		connection.end();

	});

	it ('Logout and login and tupup 999 first successfully', function() {

		var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

		browser.sleep(1000);
		browser.getAllWindowHandles().then(function(handles) {
			browser.switchTo().window(handles[0]).then(function() {
				browser.sleep(2000);
				DashboardPage.logoutLink.click();
				browser.wait(loginPageIsPresent).then(function() {
					LoginPage.userInput.sendKeys(mobileNumber);
					LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
				});

				LoginPage.submitBtn.click();
				browser.wait(topupMenuIsClickable).then(function() {
					DashboardPage.topupMenu.click();
					TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceBefore = parseFloat(balanceText);
					});

					browser.wait(providerEasypayIsClickable).then(function() {
						browser.sleep(2000);
						TopupPage.providerEasypay.click();
						browser.wait(topupBtnIsClickable).then(function() {
							TopupPage.amountCustom.click();
							customAmount = 999;
							TopupPage.amountCustomText.sendKeys(customAmount);
							TopupPage.topupBtn.click();
						});
						browser.wait(windowCount(3), 60000);
						browser.getAllWindowHandles().then(function(handles) {
							var newWindowHandle = handles[2];
							browser.switchTo().window(newWindowHandle).then(function() {
								browser.wait(cancelBtnIsClickable).then(function() {
									EasyGateway.visaChannel.click();
									browser.sleep(2000);
									EasyGateway.creditCardNum.sendKeys('4111111111111111');
									EasyGateway.expMonth.click();
									EasyGateway.expYear.click();
									EasyGateway.creditCardCvv2.sendKeys('989');
									EasyGateway.creditCardName.sendKeys('auto tester');
									EasyGateway.submitBtn.click();
								});
							});
						});

						var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
						browser.wait(transactionSuccessfulIsVisibility).then(function() {//
							browser.getAllWindowHandles().then(function(handles) {
								browser.driver.close().then(function () {
									browser.switchTo().window(handles[0]).then(function() {
										browser.sleep(90000); //waiting 90 seconds for balance to be updated
										browser.refresh();
			    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
										browser.wait(walletBalanceIsPresence).then(function() {
											TopupPage.walletBalance.getInnerHtml().then(function(balance) {
												balanceAfter = balance;
												var amountIncrese = balanceAfter - balanceBefore;
												expect(amountIncrese).toEqual(customAmount);
											});
										});
									});
								});
							});
						});
					});
				});
			})
		});
	})

	it ('Topup 999 again - You have exceeded the maximum value of topup', function() {

		//var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var exceededBalanceMessage = element(by.cssContainingText('div.msg-block__content p', 'You have exceeded the maximum value of topup'));
		var exceededBalanceMessageIsVisibility = EC.visibilityOf(exceededBalanceMessage);

		browser.sleep(2000);
		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();

			browser.wait(providerEasypayIsClickable).then(function() {
				browser.sleep(2000);
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 999;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
					browser.wait(exceededBalanceMessageIsVisibility).then(function() {
						expect(true).toBe(true);
						browser.sleep(1000);
					});
				});
			});
		});
	});

	it ('Get 1st virtual card and load 999 successfully', function() {

		var getFirstCardbuttonIsClickable = EC.elementToBeClickable(DashboardPage.getFirstCardbutton);
		var loadSuccessMessageIsPresence = EC.presenceOf(LoadUnloadPage.loadSuccessMessage);
		var loadCardIsClickable = EC.elementToBeClickable(LoadUnloadPage.loadCardLink);
		var closeLoadPopup = element(by.css('div.ngdialog-close'));

		browser.sleep(10000);
		DashboardPage.myWalletMenu.click();
		browser.wait(getFirstCardbuttonIsClickable).then(function() {
			browser.sleep(1000);
			DashboardPage.getFirstCardbutton.click();
			browser.wait(loadCardIsClickable).then(function() {
				LoadUnloadPage.loadCardLink.click();
				browser.sleep(5000);
				LoadUnloadPage.inputLoadAmount.clear();
				browser.sleep(1000);
				LoadUnloadPage.inputLoadAmount.sendKeys(999);
				browser.sleep(1000);
				LoadUnloadPage.loadUnloadCardBtn.click();
				browser.wait(loadSuccessMessageIsPresence).then(function() {
					browser.sleep(5000);
					expect(true).toBe(true);
				});
			});
		});
	});

	it ('Unload 999 successfully', function() {

		var unloadCardLinkIsVisibility = EC.visibilityOf(LoadUnloadPage.unloadCardLink);
		var unloadSuccessMessageIsPresence = EC.presenceOf(LoadUnloadPage.unloadSuccessMessage);

		browser.sleep(3000);
		browser.wait(unloadCardLinkIsVisibility).then(function() {
			browser.sleep(2000);
			LoadUnloadPage.unloadCardLink.click();
			browser.sleep(5000);
			LoadUnloadPage.inputUnloadAmount.clear();
			LoadUnloadPage.inputUnloadAmount.sendKeys(999);
			LoadUnloadPage.loadUnloadCardBtn.click();
			browser.wait(unloadSuccessMessageIsPresence).then(function() {
				browser.sleep(5000);
				expect(true).toBe(true);
			});
		});
	});

	it ('Load 999 again successfully', function() {

		var loadCardIsClickable = EC.elementToBeClickable(LoadUnloadPage.loadCardLink);
		var loadSuccessMessageIsPresence = EC.presenceOf(LoadUnloadPage.loadSuccessMessage);

		browser.sleep(2000);
		browser.wait(loadCardIsClickable).then(function() {
			LoadUnloadPage.loadCardLink.click();
			browser.sleep(5000);
			LoadUnloadPage.inputLoadAmount.clear();
			browser.sleep(1000);
			LoadUnloadPage.inputLoadAmount.sendKeys(999);
			browser.sleep(1000);
			LoadUnloadPage.loadUnloadCardBtn.click();
			browser.wait(loadSuccessMessageIsPresence).then(function() {
				browser.sleep(5000);
				expect(true).toBe(true);
			});
		});
	});

	it ('Topup 999 again - Successfully', function() {

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

		browser.sleep(1000);
		browser.wait(topupMenuIsClickable).then(function() {

			DashboardPage.topupMenu.click();
			TopupPage.walletBalance.getInnerHtml().then(function(balance) {
				var balanceText = balance.replace(",", "");
				balanceBefore = parseFloat(balanceText);
			});

			browser.wait(providerEasypayIsClickable).then(function() {
				browser.sleep(2000);
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 999;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(3), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[2];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
							EasyGateway.visaChannel.click();
							browser.sleep(2000);
							EasyGateway.creditCardNum.sendKeys('4111111111111111');
							EasyGateway.expMonth.click();
							EasyGateway.expYear.click();
							EasyGateway.creditCardCvv2.sendKeys('989');
							EasyGateway.creditCardName.sendKeys('auto tester');
							EasyGateway.submitBtn.click();
						});
					});
				});

				var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
				browser.wait(transactionSuccessfulIsVisibility).then(function() {
					browser.getAllWindowHandles().then(function(handles) {
						browser.driver.close().then(function () {
							browser.switchTo().window(handles[0]).then(function() {
								browser.sleep(90000); //waiting 90 seconds for balance to be updated
								browser.refresh();
	    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
								browser.wait(walletBalanceIsPresence).then(function() {
									TopupPage.walletBalance.getInnerHtml().then(function(balance) {
										var balanceText = balance.replace(",", "");
										balanceAfter = parseFloat(balanceText);
										var amountIncrese = balanceAfter - balanceBefore;
										expect(amountIncrese).toEqual(customAmount);
									});
								});
							});
						});
					});
				});
			});
		});
	});

	it ('Activate physical card successfully', function() {

		var getAnotherCardMenu = element(by.linkText('Get Another Card'));
		var getAnotherCardMenuIsClickable = EC.elementToBeClickable(getAnotherCardMenu);
		var purchaseACardIsPresence = EC.presenceOf(CardActivationPage.purchaseACard);
		var orderCardPopupIsPresence = EC.presenceOf(CardActivationPage.orderCardPopup);
		var activateCardPopupIsVisibility = EC.visibilityOf(CardActivationPage.activateCardPopup);
		var cardNumberModeIsClickable = EC.elementToBeClickable(CardActivationPage.cardNumberMode);
		var proxyNumberModeIsClickable = EC.elementToBeClickable(CardActivationPage.proxyNumberMode);
		var activateACardIsClickable = EC.elementToBeClickable(CardActivationPage.activateACard);
		var otpInputIsVisibility = EC.visibilityOf(CardActivationPage.otpInput);
		var loginBtnIsClickable = EC.elementToBeClickable(TelerivetPage.loginButton);
		var otpMessage = element(by.partialLinkText());
		var otpMessageIsVisibility = EC.visibilityOf(otpMessage);
		var latestMessage = element.all(by.css('span.convContent')).last();
		var purchaseACardIsPresence = EC.presenceOf(CardActivationPage.purchaseACard);

		browser.sleep(2000);
		browser.wait(getAnotherCardMenuIsClickable).then(function() {
			getAnotherCardMenu.click();
			browser.wait(purchaseACardIsPresence).then(function() {
				browser.sleep(3000);
				CardActivationPage.purchaseACard.click();
				browser.sleep(2000);
				CardActivationPage.orderACardBtn.click();
				browser.wait(orderCardPopupIsPresence).then(function() {
					browser.sleep(1000);
					CardActivationPage.orderCardBtn.click();
					browser.sleep(10000);
					browser.refresh();
					browser.wait(activateACardIsClickable).then(function() {
						browser.sleep(2000);
						CardActivationPage.activateACard.click();
						browser.sleep(1000);
						CardActivationPage.activateCardOrderBtn.click();
						browser.wait(activateCardPopupIsVisibility).then(function() {
							browser.wait(cardNumberModeIsClickable).then(function() {
								CardActivationPage.cardNumberMode.click();
								browser.wait(proxyNumberModeIsClickable).then(function() {
									CardActivationPage.proxyNumberMode.click();
									browser.sleep(2000);
									CardActivationPage.proxyInp.clear();
									CardActivationPage.proxyInp.sendKeys(configFile.PROXY_NUMBER.NEW);
									CardActivationPage.submitBtn.click();
									browser.wait(otpInputIsVisibility).then(function() {
										var mysql = require('/usr/local/lib/node_modules/mysql');
									    var connection = mysql.createConnection({
									        host : configFile.DB_INFO.HOST,
									        user : configFile.DB_INFO.USERNAME,
									        password : configFile.DB_INFO.PASSWORD
									    });
									    connection.connect();

									    var optCodeQuery = "select code from vcard_ih.user_tokens where type = 'physical card' and email like '%" + mobileNumber +"%'";
									    browser.sleep(5000);
										connection.query(optCodeQuery, function(err, rows) {
										    if (err) {
										        console.log('Could not run query');
										    } else {
										    	console.log('Get OTP code successfully');
										   		otpCode = rows[0].code;
										   		browser.sleep(1000);
										   		CardActivationPage.otpInput.clear();
												browser.sleep(1000);
												CardActivationPage.otpInput.sendKeys(otpCode);
												CardActivationPage.verifyOtpBtn.click();
												browser.wait(purchaseACardIsPresence).then(function() {
													browser.sleep(10000);
													expect(true).toBe(true);
												});
										    }
										});
										browser.sleep(2000);
										connection.end();
									});
								});
							});
						});
					});
				});
			});
		});

	});

	it ('Topup 999 again - You have exceeded the maximum value of topup', function() {

		//var loginPageIsPresent = EC.presenceOf(LoginPage.userInput);
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var exceededBalanceMessage = element(by.cssContainingText('div.msg-block__content p', 'You have exceeded the maximum value of topup'));
		var exceededBalanceMessageIsVisibility = EC.visibilityOf(exceededBalanceMessage);


		//browser.get(configFile.HTTP_HOST);
		//browser.wait(loginPageIsPresent).then(function() {
		//	LoginPage.userInput.sendKeys(31031510);
		//	LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		//});
		//LoginPage.submitBtn.click();


		browser.sleep(2000);
		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
			browser.wait(providerEasypayIsClickable).then(function() {
				browser.sleep(2000);
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 999;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
					browser.wait(exceededBalanceMessageIsVisibility).then(function() {
						expect(true).toBe(true);
						browser.sleep(1000);
					});
				});
			});
		});
	});

	it ('Load 999 to physical card successfully', function() {

		var nextArrow = element(by.css('div.navigation label[for="slides_2"]'));
		var nextArrowIsClickable = EC.elementToBeClickable(nextArrow);
		var loadSuccessMessageIsPresence = EC.presenceOf(LoadUnloadPage.loadSuccessMessage);
		var loadPhysicalCardLink = element.all(by.css('a[ng-click="loadCard($event, card.id, $index)"]')).last();

		browser.sleep(2000);
		DashboardPage.myWalletMenu.click();

		//Remove when run E2E
		//browser.actions().keyDown(protractor.Key.COMMAND).click(DashboardPage.accountMenu).keyUp(protractor.Key.COMMAND).perform();

		browser.wait(nextArrowIsClickable).then(function() {
			browser.sleep(2000);
			nextArrow.click();
			browser.sleep(2000);
			loadPhysicalCardLink.click();
			browser.sleep(5000);
			LoadUnloadPage.inputLoadAmount.clear();
			browser.sleep(1000);
			LoadUnloadPage.inputLoadAmount.sendKeys(999);
			browser.sleep(1000);
			LoadUnloadPage.loadUnloadCardBtn.click();
			browser.wait(loadSuccessMessageIsPresence).then(function() {
				browser.sleep(5000);
				expect(true).toBe(true);
			});
		});
	});

	it ('Topup 999 again - Successfully', function() {

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);

		browser.sleep(1000);
		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
			TopupPage.walletBalance.getInnerHtml().then(function(balance) {
				var balanceText = balance.replace(",", "");
				balanceBefore = parseFloat(balanceText);
			});

			browser.wait(providerEasypayIsClickable).then(function() {
				browser.sleep(2000);
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 999;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
				});
				browser.wait(windowCount(3), 60000);
				browser.getAllWindowHandles().then(function(handles) {
					var newWindowHandle = handles[2];
					browser.switchTo().window(newWindowHandle).then(function() {
						browser.wait(cancelBtnIsClickable).then(function() {
							EasyGateway.visaChannel.click();
							browser.sleep(2000);
							EasyGateway.creditCardNum.sendKeys('4111111111111111');
							EasyGateway.expMonth.click();
							EasyGateway.expYear.click();
							EasyGateway.creditCardCvv2.sendKeys('989');
							EasyGateway.creditCardName.sendKeys('auto tester');
							EasyGateway.submitBtn.click();
						});
					});
				});

				var transactionSuccessfulIsVisibility = EC.visibilityOf(EasyGateway.transactionSuccessful);
				browser.wait(transactionSuccessfulIsVisibility).then(function() {
					browser.getAllWindowHandles().then(function(handles) {
						browser.driver.close().then(function () {
							browser.switchTo().window(handles[0]).then(function() {
								browser.sleep(90000); //waiting 90 seconds for balance to be updated
								browser.refresh();
	    						var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
								browser.wait(walletBalanceIsPresence).then(function() {
									TopupPage.walletBalance.getInnerHtml().then(function(balance) {
										var balanceText = balance.replace(",", "");
										balanceAfter = parseFloat(balanceText);
										var amountIncrese = balanceAfter - balanceBefore;
										expect(amountIncrese).toEqual(customAmount);
									});
								});
							});
						});
					});
				});
			});
		});
	});

	it ('Topup 999 again - You have exceeded the maximum value of topup', function() {

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerEasypayIsClickable = EC.elementToBeClickable(TopupPage.providerEasypay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);
		var cancelBtnIsClickable = EC.elementToBeClickable(EasyGateway.cancelBtn);
		var exceededBalanceMessage = element(by.cssContainingText('div.msg-block__content p', 'You have exceeded the maximum value of topup'));
		var exceededBalanceMessageIsVisibility = EC.visibilityOf(exceededBalanceMessage);

		browser.sleep(2000);
		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
			browser.wait(providerEasypayIsClickable).then(function() {
				browser.sleep(2000);
				TopupPage.providerEasypay.click();
				browser.wait(topupBtnIsClickable).then(function() {
					TopupPage.amountCustom.click();
					customAmount = 999;
					TopupPage.amountCustomText.sendKeys(customAmount);
					TopupPage.topupBtn.click();
					browser.wait(exceededBalanceMessageIsVisibility).then(function() {
						expect(true).toBe(true);
						browser.sleep(1000);
					});
				});
			});
		});
	});
});
