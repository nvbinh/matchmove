'use strict'
var TopupPage = require('./topup.po.js')
var SignUpPage = require ('./signup.po.js');
var Utility = require('./utilities.po.js');
//var configFile = require('./protractor-config-files/MUTHOOTconfig.json');
//var configFile = require('./protractor-config-files/PAYASIAconfig.json'); //not applicable onPayAsia
var configFile = require('./e2e.json');
var LoginPage = require('./login.po.js');
var SignUpPage = require('./signup.po.js');
var VerifyEmailPage = require('./verifyemail.po.js');
var VerifyMobilePage = require('./verifymobile.po.js');
var DashboardPage = require('./dashboard.po.js');
var AccountDetailPage = require('./accountdetails.po.js');
var GmailPage = require('./gmail.po.js');
var EasyGateway = require('./easygateway.po.js');
var RazorPopup = require('./razorpopup.po.js');

describe('Topup via Razor', function() {
	var EC = protractor.ExpectedConditions;
	browser.ignoreSynchronization = true;
	var emailIsPresent = EC.presenceOf(GmailPage.verifyEmail);
	var emailAddress = Utility.autoGenerateEmail(configFile.EMAIL_GENERATE.local_part, configFile.EMAIL_GENERATE.domain_part);
	var mobileNumber = Utility.autoGenerateMobile(configFile.MOBILE_PREFIX_2DIGITS, configFile.MOBILE_LENGTH);
	var balanceBefore = 0;
	var balanceAfter = 0;
	var topupAmount = 0;
	var customAmount = 0;

	function windowCount (count) {
    	return function () {
        	return browser.getAllWindowHandles().then(function (handles) {
            	return handles.length === count;
        	});
    	};
	};

	it ('Pre_KYC - Sign up with Indian check if Razor channel is displayed', function() {

		browser.get(configFile.HTTP_HOST);

		var signupButtonIsClickable = EC.elementToBeClickable(LoginPage.signupBtn);
		browser.wait(signupButtonIsClickable).then(function() {;
			LoginPage.signupBtn.click();
		});

		browser.sleep(3000);

		SignUpPage.emailInput.sendKeys(emailAddress);
		SignUpPage.firstNameInput.sendKeys('loc');
		SignUpPage.lastNameInput.sendKeys('loc');
		SignUpPage.preferredNameInput.sendKeys('loc');
		SignUpPage.mobileInput.sendKeys(mobileNumber);
		if (configFile.SIGNUP_PAGE.nationalityEnabled) {
			SignUpPage.nationality.$('[value="Indian"]').click();
		};
		SignUpPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		SignUpPage.tncCheckbox.click()
		SignUpPage.submitBtn.click();

		var verifyEmailClickable = EC.elementToBeClickable(VerifyEmailPage.verifyEmailbutton);
		browser.wait(verifyEmailClickable).then(function() {
			browser.sleep(1000);
			VerifyEmailPage.verifyEmailbutton.click();
			browser.sleep(5000);
			expect(VerifyEmailPage.resendEmailButton.isPresent()).toBe(true);
		});

		browser.sleep(30000); //waiting for verify email was sent to Gmail
		browser.get(configFile.GMAIL);

		var emailSubjects = element.all(by.cssContainingText('.y6 span', configFile.EMAILS.Authentication)).first();
		var emailIsClickable = EC.elementToBeClickable(emailSubjects);
		var expandIsPresence = EC.presenceOf(GmailPage.expandEmail);

		GmailPage.emailInput.sendKeys(configFile.G_EMAIL);
		GmailPage.nextBtn.click();

		browser.sleep(1000);
		GmailPage.passwordInput.sendKeys(configFile.G_PASSWORD);
		GmailPage.signInBtn.click();
		browser.wait(emailIsClickable).then(function() {
			emailSubjects.click();
		});

		browser.wait(EC.or(expandIsPresence, emailIsPresent)).then(function() {

			GmailPage.expandEmail.isPresent().then(function(result) {
				if(result) {
				GmailPage.expandEmails.count().then(function(count) {
					if (count >= 1) {
						GmailPage.expandEmails.last().click();
						}
					});
				}

			});
		});

		browser.sleep(1000);
		expect(GmailPage.verifyEmail.isPresent()).toBe(true);

		GmailPage.verifyAuthenEmail.count().then(function(count) {
				if (count > 1) {
					GmailPage.verifyAuthenEmail.last().click();
				}
				else {
					GmailPage.verifyAuthenEmail.first().click();
			}
		});

		browser.sleep(1000);

		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[1];
			browser.switchTo().window(newWindowHandle).then(function() {
				expect(browser.getCurrentUrl()).toContain(configFile.HTTP_HOST);
			});
		});
		var verifyEmailSuccess = element(by.cssContainingText('h2.ng-binding', 'Successfully verified email'));
		var verifyEmailSuccessIsVisibility = EC.visibilityOf(verifyEmailSuccess);
		browser.wait(verifyEmailSuccessIsVisibility).then(function() {
			expect(true).toBe(true);
		});

		var loginPageIsPresent = EC.presenceOf(LoginPage.emailInput);
		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var providerRazorImageIsVisibility = EC.visibilityOf(TopupPage.providerRazorImage);


		browser.wait(loginPageIsPresent).then(function() {
			LoginPage.emailInput.sendKeys(emailAddress);
			LoginPage.pwdInput.sendKeys(configFile.VCARD_PASSWORD);
		});

		LoginPage.submitBtn.click();

		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
		});

		browser.wait(providerRazorImageIsVisibility).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ("Verify if min topup amount is equal 1", function() {
		TopupPage.minValueOfRazor.getInnerHtml().then(function(min) {
			var getMinValue = parseFloat(min);
			expect(getMinValue).toEqual(configFile.PRE_KYC_TOPUP_LIMIT.INDIA.min);
		});
	});

	it ('Verify if max topup amount is equal 10000', function() {
		TopupPage.maxValueOfRazor.getInnerHtml().then(function(maxText) {
			var max = maxText.replace(",", "");
			var getMaxValue = parseFloat(max);
			expect(getMaxValue).toEqual(configFile.PRE_KYC_TOPUP_LIMIT.INDIA.max);
		});
	});

	it ('Verify if fee percent is equal 2.5', function() {
   		TopupPage.feePercentOfRazor.getText().then(function (fee) {
        	var feeText = fee.split(":");
        	var feePercent = parseFloat(feeText[1]);
        	expect(feePercent).toEqual(configFile.PRE_KYC_TOPUP_LIMIT.INDIA.feePercent);
    	});
	});

	it ('select Razor channel and check current URL include topup/enter/Razorpay', function() {

		var providerRazorpayIsClickable = EC.elementToBeClickable(TopupPage.providerRazorpay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);

		browser.wait(providerRazorpayIsClickable).then(function() {
			TopupPage.providerRazorpay.click();
		});

		browser.wait(topupBtnIsClickable).then(function() {
			browser.getCurrentUrl().then(function(url) {
				expect(url).toEqual(configFile.TOPUP_RAZOR_PAGE.url);
			});
		});
	});

	it ('Default topup amount is INR 500', function() {

		TopupPage.pre_definded_amount_500.getAttribute('value').then(function(amount) {
			topupAmount = parseFloat(amount);
		});

		expect(TopupPage.pre_definded_amount_500.isSelected()).toBe(true);
	});

	it ('Verify Total Amount, Amount, Fees Charged values are calculated correctly', function() {
		var totalAmount = element.all(by.css('div.total p.value span.value-amount')).first();

		TopupPage.pre_definded_amount_500.getAttribute('value').then(function(amount) {
			topupAmount = parseFloat(amount);
			var feeChargedCalculation = (topupAmount * configFile.PRE_KYC_TOPUP_LIMIT.INDIA.feePercent / 100);
			var totalAmountCalculation = topupAmount + feeChargedCalculation;
			totalAmount.getInnerHtml().then(function(value) {
				var getTotalAmount = parseFloat(value);
				expect(getTotalAmount).toEqual(totalAmountCalculation);
			});

			var values = element.all(by.css("aside.container-reciept div.details div.detail-section p.value span.value-amount"));

			values.get(0).getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getAmount = parseFloat(valueText);
				expect(getAmount).toEqual(topupAmount);
			});

			values.get(1).getInnerHtml().then(function(value) {
				var feeCharged = parseFloat(value);
				expect(feeCharged).toEqual(feeChargedCalculation);
			});
		});
	});


	it ('Verify Total Amount, Amount, Fees Charged values when selected amount = 1000', function() {
		var totalAmount = element.all(by.css('div.total p.value span.value-amount')).first();
		TopupPage.pre_definded_amount_1000.click();
		browser.sleep(1000);

		TopupPage.pre_definded_amount_1000.getAttribute('value').then(function(amount) {
			topupAmount = parseFloat(amount);
			var feeChargedCalculation = (topupAmount * configFile.PRE_KYC_TOPUP_LIMIT.INDIA.feePercent / 100);
			var totalAmountCalculation = topupAmount + feeChargedCalculation;
			totalAmount.getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getTotalAmount = parseFloat(valueText);
				expect(getTotalAmount).toEqual(totalAmountCalculation);
			});

			var values = element.all(by.css("aside.container-reciept div.details div.detail-section p.value span.value-amount"));

			values.get(0).getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getAmount = parseFloat(valueText);
				expect(getAmount).toEqual(topupAmount);
			});

			values.get(1).getInnerHtml().then(function(value) {
				var feeCharged = parseFloat(value);
				expect(feeCharged).toEqual(feeChargedCalculation);
			});
		});
	});

	it ('Verify Total Amount, Amount, Fees Charged values when selected amount = 5000', function() {
		var totalAmount = element.all(by.css('div.total p.value span.value-amount')).first();
		TopupPage.pre_definded_amount_5000.click();
		browser.sleep(1000);

		TopupPage.pre_definded_amount_5000.getAttribute('value').then(function(amount) {
			topupAmount = parseFloat(amount);
			var feeChargedCalculation = (topupAmount * configFile.PRE_KYC_TOPUP_LIMIT.INDIA.feePercent / 100);
			var totalAmountCalculation = topupAmount + feeChargedCalculation;
			totalAmount.getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getTotalAmount = parseFloat(valueText);
				expect(getTotalAmount).toEqual(totalAmountCalculation);
			});

			var values = element.all(by.css("aside.container-reciept div.details div.detail-section p.value span.value-amount"));

			values.get(0).getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getAmount = parseFloat(valueText);
				expect(getAmount).toEqual(topupAmount);
			});

			values.get(1).getInnerHtml().then(function(value) {
				var feeCharged = parseFloat(value);
				expect(feeCharged).toEqual(feeChargedCalculation);
			});
		});
	});

	it ('Verify Total Amount, Amount, Fees Charged values when selected amount = 10000', function() {
		var totalAmount = element.all(by.css('div.total p.value span.value-amount')).first();
		TopupPage.pre_definded_amount_10000.click();
		browser.sleep(1000);

		TopupPage.pre_definded_amount_10000.getAttribute('value').then(function(amount) {
			topupAmount = parseFloat(amount);
			var feeChargedCalculation = (topupAmount * configFile.PRE_KYC_TOPUP_LIMIT.INDIA.feePercent / 100);
			var totalAmountCalculation = topupAmount + feeChargedCalculation;
			totalAmount.getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getTotalAmount = parseFloat(valueText);
				expect(getTotalAmount).toEqual(totalAmountCalculation);
			});

			var values = element.all(by.css("aside.container-reciept div.details div.detail-section p.value span.value-amount"));

			values.get(0).getInnerHtml().then(function(value) {
				var valueText = value.replace(",", "");
				var getAmount = parseFloat(valueText);
				expect(getAmount).toEqual(topupAmount);
			});

			values.get(1).getInnerHtml().then(function(value) {
				var feeCharged = parseFloat(value);
				expect(feeCharged).toEqual(feeChargedCalculation);
			});
		});
	});

	it ('Verify Topup button is disable when selected CustomAmount option and left the input is empty', function() {
		TopupPage.amountCustom.click();
		expect(TopupPage.topupBtn.isEnabled()).toBe(false);
	});

	it ('Topup with amount less than minimum amount', function() {
		TopupPage.amountCustomText.sendKeys(0);
		browser.sleep(500);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(0.99);
		browser.sleep(500);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(-10);
		browser.sleep(500);
		expect(TopupPage.minWarningMessage.isPresent()).toBe(true);
	});

	it ('Topup with amount greater than maximum amount', function() {

		TopupPage.amountCustomText.clear();
		TopupPage.amountCustomText.sendKeys(10001);
		browser.sleep(2000);
		//expect(TopupPage.topupBtn.isEnabled()).toBe(false);
		var exceedAmountWarning = element(by.cssContainingText('div.msg-block__content p', 'You have exceeded'))
		var exceedAmountWarningIsPresence = EC.presenceOf(exceedAmountWarning);
		TopupPage.topupBtn.isEnabled().then(function(result) {
			if(result){
				TopupPage.topupBtn.click();
				browser.wait(exceedAmountWarningIsPresence).then(function() {
					expect(true).toBe(true);
				});
			}
			else {
				expect(true).toBe(true);
			}
		});
	});

	it ('Toup with amount = 100 Successfully', function() {

		var paymentPopupIsPresence = EC.presenceOf(RazorPopup.paymentPopup);
		var successBtnIsPresence = EC.presenceOf(RazorPopup.successBtn);
		var cardPaymentMethodIsPresence = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);
		var payBtnIsClickable = EC.elementToBeClickable(RazorPopup.payBtn);

		TopupPage.walletBalance.getInnerHtml().then(function(balance) {
			var balanceText = balance.replace(",", "");
			balanceBefore = parseFloat(balanceText);
		});

		TopupPage.amountCustomText.clear();
		topupAmount = 100;
		TopupPage.amountCustomText.sendKeys(topupAmount);
		TopupPage.topupBtn.click();

		browser.sleep(15000);
		browser.switchTo().frame(0);
		browser.sleep(2000);
		RazorPopup.cardPaymentMethod.click();
		browser.wait(payBtnIsClickable).then(function() {
			RazorPopup.cardNumber.sendKeys(4111111111111111);
			RazorPopup.cardExpiry.sendKeys(1117);
			RazorPopup.cardCvv.sendKeys(989);
		});

		RazorPopup.payBtn.click();
		browser.wait(windowCount(3), 60000);
		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[2];
			browser.switchTo().window(newWindowHandle).then(function() {
				browser.sleep(15000);
				RazorPopup.successBtn.click();
				browser.wait(windowCount(2), 60000);
			});

			browser.switchTo().window(handles[1]).then(function() {
				var progressTextIsInvisibility = EC.invisibilityOf(TopupPage.progressText);
				browser.sleep(10000);
				expect(TopupPage.progressText.isPresent()).toBe(false);
			});
		});
	});

	it ('Checking Print Receipt feature', function() {
		TopupPage.printReceipt.click();
		browser.sleep(2000);
		browser.getAllWindowHandles().then(function (handles) {
        	var newWindowHandle = handles[2];
        	browser.switchTo().window(newWindowHandle).then(function () {
            	expect(TopupPage.printWindow.isPresent()).toBe(true);
            	browser.sleep(2000);
                TopupPage.cancelPrint.click();
        	});

        	browser.switchTo().window(handles[1]).then(function() {
				browser.sleep(120000); //waiting for 2 mins to see if balance is updated
        	});
    	});
	});

	it ('balance was updated', function() {
		var walletBalanceIsPresence = EC.presenceOf(TopupPage.walletBalance);
		browser.refresh();
		browser.wait(walletBalanceIsPresence).then(function() {
			TopupPage.walletBalance.getInnerHtml().then(function(balance) {
				var balanceText = balance.replace(",", "");

				balanceAfter = parseFloat(balanceText);
				var amountIncrese = balanceAfter - balanceBefore;
				expect(amountIncrese).toEqual(topupAmount);
			});
		});

	});

	it ('Check transaction history', function() {
		var historyMenu = element(by.linkText('History'));

		var topupTransaction = element(by.cssContainingText('span.transaction-description', 'Topup via Razorpay'));
		var topupTransactionIsPresence = EC.presenceOf(topupTransaction);

		historyMenu.click();
		browser.wait(topupTransactionIsPresence).then(function() {
			expect(true).toBe(true);
			browser.sleep(1000);
		});
	});

	it ("Topup failure and balance isn't updated", function() {

		var topupMenuIsClickable = EC.elementToBeClickable(DashboardPage.topupMenu);
		var paymentPopupIsPresence = EC.presenceOf(RazorPopup.paymentPopup);
		var successBtnIsPresence = EC.presenceOf(RazorPopup.successBtn);
		var failureBtnIsPrecense = EC.presenceOf(RazorPopup.failureBtn);
		var cardPaymentMethodIsClickable = EC.elementToBeClickable(RazorPopup.cardPaymentMethod);
		var payBtnIsClickable = EC.elementToBeClickable(RazorPopup.payBtn);
		var providerRazorpayIsClickable = EC.elementToBeClickable(TopupPage.providerRazorpay);
		var topupBtnIsClickable = EC.elementToBeClickable(TopupPage.topupBtn);

		browser.wait(topupMenuIsClickable).then(function() {
			DashboardPage.topupMenu.click();
		});

		browser.wait(providerRazorpayIsClickable).then(function() {
			TopupPage.providerRazorpay.click();
		});

		TopupPage.walletBalance.getInnerHtml().then(function(balance) {
			var balanceText = balance.replace(",", "");
			balanceBefore = parseFloat(balanceText);
		});

		browser.wait(topupBtnIsClickable).then(function() {
			TopupPage.amountCustom.click();
			TopupPage.amountCustomText.clear();
			topupAmount = 100;
			TopupPage.amountCustomText.sendKeys(topupAmount);
			TopupPage.topupBtn.click();
		});

		browser.sleep(15000);
		browser.switchTo().frame(1);
		//browser.sleep(5000);
		browser.wait(cardPaymentMethodIsClickable).then(function() {
			RazorPopup.cardPaymentMethod.click();
		});

		browser.wait(payBtnIsClickable).then(function() {
			RazorPopup.cardNumber.sendKeys(4111111111111111);
			RazorPopup.cardExpiry.sendKeys(1117);
			RazorPopup.cardCvv.sendKeys(989);
		});

		RazorPopup.payBtn.click();
		browser.wait(windowCount(3), 60000);
		browser.getAllWindowHandles().then(function(handles) {
			var newWindowHandle = handles[2];
			browser.switchTo().window(newWindowHandle).then(function() {
			browser.sleep(15000);
			RazorPopup.failureBtn.click();
			browser.sleep(3000);
			browser.switchTo().window(handles[1]).then(function() {
				browser.switchTo().frame(1);
					var retryBtn = element(by.css('button#fd-hide'));
					retryBtn.click();
					var closePaymentPopup = element(by.css('div#modal-close'));
					browser.sleep(2000);
					closePaymentPopup.click();
				});

				browser.switchTo().window(handles[1]).then(function() {
					browser.sleep(30000); //waiting for 30 seconds to see that balance isn't updated
						TopupPage.walletBalance.getInnerHtml().then(function(balance) {
						var balanceText = balance.replace(",", "");
						balanceAfter = parseFloat(balanceText);
						var amountIncrese = balanceAfter - balanceBefore;
						expect(amountIncrese).toEqual(0);
					});
				});
			});
		});
	});
});
