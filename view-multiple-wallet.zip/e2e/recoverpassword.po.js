/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';
var configFile = require('./e2e.json');
var RecoverPasswordPage = function() {
  this.bannerImg = element(by.css('.image__centered img'));
  this.pageTitle = element(by.css('.marketing__title h1'));
  if(configFile.SIGNUP_PAGE.emailRequired == "true"){
    this.emailInput = element(by.model('email'));
  }else{
    this.emailInput = element(by.model('payload.mobile'));
  }
  this.submitBtn = element(by.css('form div.section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.errorBanner = element(by.css('form .msg-banner .error-banner .mwc-common-alert'));
  this.newPassword = element(by.model('verification.password'));



  this.successIcon = element(by.css('.mcw-common-congratulations'));
  this.successMessage = element(by.css('.marketing__title h1'));
  this.resendLink = element(by.css('p.ng-binding a.link'));

  this.errorMessage = element(by.css('[messagetype="error"]'));




};

module.exports = new RecoverPasswordPage();
