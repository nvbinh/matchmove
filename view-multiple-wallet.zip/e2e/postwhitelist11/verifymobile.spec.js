'use strict';

describe('Verify mobile', function () {
  var LoginPage = require('../login.po');
  var TelerivetPage = require('../telerivet.po');
  var VerifyEmailPage = require('../verifyemail.po');
  var VerifyMobile = require('../verifymobile.po');
  var AccountDetailPage = require('../accountdetails.po');
  var SignUpPage = require('../signup.po');
  var DashboardPage = require('../dashboard.po');
  var configFile = require('../e2e.json');
  var Utility = require('../utilities.po.js');
  var newEmailSignup = Utility.randomEmailNonExisting(configFile.EXISTING_EMAIL);
  var newMobileSignup = Utility.randommobileNonExisting(configFile.MOBILE_NUMBER_FIRST_2_DIGIT, configFile.MOBILE_NUMBER_LENGTH);
  require('../waitReady.js');
  var x;
  //var verifyEmailButton

  beforeEach(function () {


  });

  it('setup test specs', function(){
	//removed logged in
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	browser.sleep(15000);
	DashboardPage.popupNOtification.isPresent().then(function(result){
		if(result){
			DashboardPage.popupNOtification.click();
		}
	});

	DashboardPage.logoutLink.isPresent().then(function(result){
		if(result){
			DashboardPage.logoutToApp();
			browser.sleep(5000);
		}
	});
	expect(true).toBe(true);
  });


  /* it('should have all the elements on the page', function() {
	LoginPage.setScreenSize();
	browser.get(TestData.url + '/wallet/create/');
	SignUpPage.signupSucess(newEmailSignup, 'auto', 'script', 'autosrcipt cards', newMobileSignup, TestData.vCardpassword);
	browser.sleep(10000);
	VerifyEmailPage.clickVerifyEmail();

	Utility.goToGmailandOpenTheLastestEmail(TestData.existinguser, TestData.emailPassword);
	var verifyEmailButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	Utility.clickButtonfromEmail(verifyEmailButton);
	Utility.closeSelectedBrowser(0);
	browser.sleep(10000);
	browser.ignoreSynchronization = false;
	browser.get(TestData.url);
	LoginPage.loginProcess(newEmailSignup, TestData.vCardpassword);
  }); */

  it('sign up and verify email', function() {
	Utility.setScreenSize();
	browser.get(configFile.HTTP_HOST + configFile.SIGNUP_PAGE.redirectionUrl);
	SignUpPage.signupSucess(newEmailSignup, configFile.ACCOUNT_INFO.FIRST_NAME, configFile.ACCOUNT_INFO.LAST_NAME, configFile.ACCOUNT_INFO.PREFERRED_NAME, newMobileSignup, configFile.VCARD_PASSWORD, configFile.SIGNUP_PAGE.tncEnabled, configFile.SIGNUP_PAGE.nationalityEnabled);
	browser.sleep(15000);
	VerifyEmailPage.clickVerifyEmail();
	browser.sleep(10000);
  });

  it('go to gmail and verify email', function() {

	Utility.goToGmailandOpenTheLastestEmail(configFile.EXISTING_EMAIL, configFile.GMAIL_PASSWORD);
	var verifyEmailButton = element(by.css('table tbody tr td table tbody tr td table tbody tr td table tbody tr td a'));
	Utility.clickButtonfromEmail(verifyEmailButton);
	browser.sleep(10000);
	
  });

  it('login again to the newly created user', function() {

	Utility.closeSelectedBrowser(0);
	browser.sleep(10000);	
	Utility.chooseActiveTab(0);
	browser.ignoreSynchronization = false;
	browser.get(configFile.HTTP_HOST);
	LoginPage.loginProcess(newEmailSignup, configFile.VCARD_PASSWORD);
	browser.sleep(10000);

  });

  it('complete details', function() {

	browser.get(configFile.HTTP_HOST + configFile.ACCOUNTS_PAGE.redirectionUrl);
	browser.sleep(5000);
	AccountDetailPage.completeDetails(Utility.randomIdentityNumberGenerator('AB'));
	browser.sleep(5000);
	browser.get(configFile.HTTP_HOST + configFile.DASHBOARD_PAGE.redirectionUrl);
	browser.sleep(5000);

  });


  it('should have all the elements on the verify mobile popup', function() {

	browser.sleep(10000);
	expect(VerifyMobile.verifymobilemainPopup.isPresent()).toBe(true);
    expect(VerifyMobile.verifymobileimage.isPresent()).toBe(true);
    expect(VerifyMobile.verifymobiledescription.isPresent()).toBe(true);
    expect(VerifyMobile.verifymobilebutton.isPresent()).toBe(true);
    expect(VerifyMobile.verifymobilepopupClose.isPresent()).toBe(true);

	expect(VerifyMobile.verifymobilemainPopup.isDisplayed()).toBe(true);
    expect(VerifyMobile.verifymobileimage.isDisplayed()).toBe(true);
    expect(VerifyMobile.verifymobiledescription.isDisplayed()).toBe(true);
    expect(VerifyMobile.verifymobilebutton.isDisplayed()).toBe(true);
    expect(VerifyMobile.verifymobilepopupClose.isDisplayed()).toBe(true);

	VerifyMobile.clickVerifyMobile();
	browser.sleep(10000);

	expect(VerifyMobile.otpHeader.isPresent()).toBe(true);
    expect(VerifyMobile.otpImage.isPresent()).toBe(true);
    expect(VerifyMobile.otpDescription.isPresent()).toBe(true);
    expect(VerifyMobile.otpField.isPresent()).toBe(true);
    expect(VerifyMobile.otpResend.isPresent()).toBe(true);
	expect(VerifyMobile.otpVerifybutton.isPresent()).toBe(true);

	expect(VerifyMobile.otpHeader.isDisplayed()).toBe(true);
    expect(VerifyMobile.otpImage.isDisplayed()).toBe(true);
    expect(VerifyMobile.otpDescription.isDisplayed()).toBe(true);
    expect(VerifyMobile.otpField.isDisplayed()).toBe(true);
    expect(VerifyMobile.otpResend.isDisplayed()).toBe(true);
	expect(VerifyMobile.otpVerifybutton.isDisplayed()).toBe(true);

  });

  it ('should open new tab', function(){
  if (configFile.VERIFY_MOBILE.OTPonTelerivet == "true"){
    Utility.OpenNewTab();
    Utility.chooseActiveTab(1);
    browser.ignoreSynchronization = true;
    browser.get(configFile.HTTP_HOST_TELERIVET);
  }else {
      expect(true).toBe(true);
  }

  });

  it ('login to telerivet', function(){
    if (configFile.VERIFY_MOBILE.OTPonTelerivet == "true"){
      TelerivetPage.logintoTelerivet(configFile.TELERIVET_USERNAME, configFile.TELERIVET_PASSWORD);
    	TelerivetPage.goToOTPMessage(newMobileSignup);
    	x = TelerivetPage.getOTPMessage();
    	Utility.closeSelectedBrowser(1);
    	browser.sleep(10000);
    }else {
        expect(true).toBe(true);
    }

  });

  it('should have all the elements on the page6', function() {

	browser.ignoreSynchronization = false;
	Utility.chooseActiveTab(0);
	VerifyMobile.processOTP(x);
	VerifyMobile.otpVerifybutton.click();
	browser.sleep(10000);
	expect(VerifyMobile.otpsuccess.isDisplayed()).toBe(true);


  });
  /*
  it('should have all the elements on the page5', function() {



	//TelerivetPage.openandLogintoTelerivet();
	//Utility.chooseActiveTab(1);


	var a = element(by.id('username'));
	var b = element(by.id('password'));
	var c = element(by.css('.btn-submit'));




	expect(a.isDisplayed()).toBe(true);

	a.sendKeys(TestData.telerivetUsername);
	b.sendKeys(TestData.telerivetPassword);
	c.click();

	//TelerivetPage.logintoTelerivet(TestData.telerivetUsername, TestData.telerivetPassword);
	//TelerivetPage.goToOTPMessage('1461221986');

	//x = TelerivetPage.getOTPMessage();

	//Utility.closeSelectedBrowser(1);
	browser.sleep(10000);


  });
  */
  /*
  it('should have all the elements on the page6', function() {

	//browser.ignoreSynchronization = false;
	//Utility.chooseActiveTab(0);
	//VerifyMobile.processOTP(x);

  });

   */




});
