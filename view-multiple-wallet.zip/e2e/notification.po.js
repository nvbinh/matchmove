/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */

'use strict';

var NotificationPage = function() {

  this.suspendMenu = element(By.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[2]/div[1]/side-bar/ul/li[7]/a'))


  this.homebannerImg = element(by.css('div.header-main nav.navbar a img'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.notificationBtn = element(by.css('.link-nav'));
  this.notificationBtnWithLanguage = element.all(by.css('.link-nav')).last();
  this.welcomeUser = element(by.css('.user'));
  this.walletBalance = element(by.css('.main-item'));
  this.walletValue = element(by.css('div.main-item .value-amount'));
  this.loyaltyPoints = element(by.css('.content-right'));
  this.loyaltyValue = element(by.css('div.content-right .value-amount'));
  this.sidemenu = element(by.css('.sidebar'));
  this.availableBalance = element(by.xpath('.//*[@id="masterUI"]/div[1]/div[3]/div/div[1]/div[2]/balance-bar/aside/div[1]/div/p/span[2]'));

  //notification drop down
  //this.notifDropdown = element(by.css('div.content-dropdown v-tab[tabindex="0"]'));
	//this.notifDropdown = element(by.css('div.dropdown-content v-tab[tabindex="0"]'));
  this.notifDropdown = element(by.css('.notification-holder'));

  //this.notifDropdown = element.all(by.css('svg.icon')).get(2);

  //notification page
  this.header = element(by.css('.title-header h2'));
  this.headericon = element(by.css('.title-icon'));
  //this.notifTab = element(by.css('section.page v-tab[tabindex="0"]'));
  //this.newsTab = element(by.css('section.page v-tab[tabindex="-1"]'));
  this.notifTab = element.all(by.css('section.page mm-tab-item')).first();
  this.newsTab = element.all(by.css('section.page mm-tab-item')).last();


  //notiftab
  //this.notifItem = element(by.css('div.box-notification div.box-title'));
  //this.activityDetailslink = element(by.css('.link-tappable'));box-footer
  this.activityDetailslink = element(by.css('.box-footer'));
  //this.activityDetails = element(by.css('.box-footer .notification-detail'));
  //this.activityDetails = element(by.css('.box-footer .vAccordion--default'));
  //this.activityDetails = element(by.css('.box-footer .accordion'));
  this.activityDetails = element(by.css('.box-footer v-accordion'));



  //newstab
  this.newsItemImage = element(by.css('div.notification .item-notification img'));
  this.newstitle = element(by.css('div.box-notification .box-title'));
  //this.newsdetails = element(by.css('div.box-notification .box-content'));by.binding
  this.newsdetails = element(by.binding('item.description'));

  this.checkNotificationIfReactivateCardVisible = function(){

		element.all(by.repeater('notification in notifications | itemsPerPage: notificationPerPage')).then(function(posts) {
		var itemImage = posts[1].element(by.css('li.notify-group--Controller_Product_Users_Cards_Status svg use'));
		var itemTitle  = posts[1].element(by.css('.box-notification .box-title span'));
		var itemDesc  = posts[1].element(by.css('.box-notification .box-content p'));
		var activityDetailslink1 = posts[1].element(by.css('.box-footer'));
		//var activityDetails1 = posts[1].element(by.css('.box-footer .vAccordion--default'));


		expect(itemImage.isDisplayed()).toBe(true);
		expect(itemDesc.isDisplayed()).toBe(true);
		expect(itemTitle.isDisplayed()).toBe(true);
		expect(activityDetailslink1.isDisplayed()).toBe(true);
		//expect(activityDetails1	.isDisplayed()).toBe(true);

		})
  };

	this.checkNotificationIfSuspendCardVisible = function(){

		//element.all(by.repeater('notification in notifications | itemsPerPage: notificationPerPage')).then(function(posts) {
		//var itemImage = posts[2].element(by.css('li.notify-group--UsersWalletsCards svg use'));
		//var itemTitle  = posts[2].element(by.css('.box-notification .box-title span'));
		//var itemDesc  = posts[2].element(by.css('.box-notification .box-content p'));
		//var activityDetailslink1 = posts[1].element(by.css('.box-footer'));
		////var activityDetails1 = posts[1].element(by.css('.box-footer .vAccordion--default'));
		
		var itemImage = element.all(by.css('li.notify-group--UsersWalletsCards svg use'));
		expect(itemImage.count()).toBe(8);
		
		//expect(itemImage.isDisplayed()).toBe(true);
		//expect(itemDesc.isDisplayed()).toBe(true);
		//expect(itemTitle.isDisplayed()).toBe(true);
		//expect(activityDetailslink1.isDisplayed()).toBe(true);
		////expect(activityDetails1	.isDisplayed()).toBe(true);

		//})
  };

  this.checkNotificationIfCompleteDetailsVisible = function(){

		element.all(by.repeater('notification in notifications | itemsPerPage: notificationPerPage')).then(function(posts) {
		//var itemImage = posts[1].element(by.css('li.notify-group--Controller_Product_Users_Cards_Status svg use'));
		var itemTitle  = posts[1].element(by.css('.box-notification .box-title span'));
		var itemDesc  = posts[1].element(by.css('.box-notification .box-content p'));
		var activityDetailslink1 = posts[1].element(by.css('.box-footer'));
		//var activityDetails1 = posts[1].element(by.css('.box-footer .vAccordion--default'));


		//expect(itemImage.isDisplayed()).toBe(true);
		expect(itemDesc.isDisplayed()).toBe(true);
		expect(itemTitle.isDisplayed()).toBe(true);
		expect(activityDetailslink1.isDisplayed()).toBe(true);
		//expect(activityDetails1	.isDisplayed()).toBe(true);

		})
  };

  this.identityVerificationNotification = element(by.cssContainingText('p', 'Your identity verification document has been submitted'));
  this.moneyTransferNotification = element.all(by.cssContainingText('p', 'You have successfully transferred money from your wallet')).first();
  this.cancelNotification = element(by.cssContainingText('p', 'Your Money transfer was refunded to your account'));

};

module.exports = new NotificationPage();
