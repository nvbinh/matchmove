'use strict';
//var configFile = require('./protractor-config-files/SGMCconfig.json');
//var configFile = require('./protractor-config-files/MUTHOOTconfig.json');
//var configFile = require('./protractor-config-files/PAYASIAconfig.json');
//var configFile = require('./protractor-config-files/centrum.json');
var configFile = require('./e2e.json');

var LoadUnloadPage = function() {
	this.loadSuccessMessage = element(by.css('message-box[messagetype="success"]'));
	this.loadCardLink = element(by.css('a[ng-click="loadCard($event, card.id, $index)"]'));
	this.unloadCardLink = element(by.css('a[ng-click="unloadCard($event, card.id, $index)"]'));
	this.loadUnloadCardBtn = element(by.css('button.button-primary--medium')); //button-primary--medium ng-binding
	this.inputLoadAmount = element(by.model('load.amount'));
	this.closePopup = element(by.css('div.ngdialog-close'));
	this.unloadSuccessMessage = element(by.css('message-box[messagetype="success"]'));
	this.requireMessage = element(by.css('p[ng-message="required"]'));
	this.minMessage = element(by.css('p[ng-message="min"]'));
	this.greaterMessage = element(by.css('p[ng-message="max"]'));
	this.inputUnloadAmount = element(by.model('unload.amount'));
};

module.exports = new LoadUnloadPage();
