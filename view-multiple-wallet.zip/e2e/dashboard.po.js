/**
 * This file uses the Page Object pattern to define the main page for tests
 * https://docs.google.com/presentation/d/1B6manhG0zEXkC-H-tPo2vwU06JhL8w9-XCF9oehXzAQ
 */
require('./helppopup.po.js');
'use strict';

var DashboardPage = function() {

  this.popupNOtification = element(by.css('.btnClose'));


  this.bannerImg = element(by.css('.image__centered img'));
  this.pageTitle = element(by.css('.marketing__title h1'));
  this.pageMsg = element(by.css('.marketing__title p'));
  this.emailInput = element(by.css('input[type="email"]'));
  this.pwdInput = element(by.css('input[type="password"]'));
  this.submitBtn = element(by.css('form .section-action button'));
  this.loginBtn = element(by.css('.navbar .right .button-secondary--small'));
  this.signupBtn = element(by.css('.navbar .right .button-primary--small'));
  this.helpBtn = element(by.css('[ng-dialog-class="dialog-help"]'));
  this.errorBanner = element(by.css('.error-banner'));
  this.logoutLink = element(by.css('a[ng-click="logout()"]'));

  this.getFirstCardbutton = element(by.css('button[ng-click="getFirstCard();"]'));
  this.cardNumber = element(by.css('.number'));


  this.getFirstCard = function(){
	  this.getFirstCardbutton.click();
	  browser.sleep(5000);
  }

  this.logoutToApp = function(){
	  this.logoutLink.click();
	  browser.sleep(5000);
  }

  this.closeAfterloginPopup = function(){
  	this.popupNOtification.isPresent().then(function(result){
	if(popup == true){
		this.popupNOtification.click();
	}

});
	
  }

  this.contactUs = function() {
    return element(by.css('a[ng-dialog="app/components/help/partials/help.html"]'));
  };
  
  this.openContactUs = function() {
    this.contactUs().click();
    return require('./helppopup.po.js');
  };

  this.logOut = function() {
    return element(by.css('a[ng-click="logout()"]'));
  };

  this.menu = function() {
    return element(by.repeater('item in itemSidebar'));
  };

  this.balanceBar = function() {
    return element(by.css('.content-balance[wallet="wallet"]'));
  };

  this.topupMenu = element(by.linkText('Top up'));
  this.notificationBell = element(by.css('a.link-nav[ng-click="readAllNotification()"]'));
  this.goToNotification = element(by.css('a[ng-click="goToNotification()"]'));
  this.myWalletMenu = element(by.linkText('myWallet'));
  this.myCardsMenu = element(by.linkText('My Cards'));
  this.claimMenu = element(by.linkText('Claim'));
  this.historyMenu = element(by.linkText('History'));
  this.sendMenu = element(by.linkText('Send'));
  this.loyaltyMenu = element(by.linkText('Loyalty'));

};

module.exports = new DashboardPage();
