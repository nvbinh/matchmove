(function ()
{
    'use strict';

    angular
        .module('app.core')
        .run(runBlock);

    /** @ngInject */
    function runBlock(msUtils, appGenerator, appConfig, formlyConfig)
    {
        /**
         * Generate extra classes based on registered themes so we
         * can use same colors with non-angular-material elements
         */
        appGenerator.generate();

        /**
         * Disable md-ink-ripple effects on mobile
         * if 'disableMdInkRippleOnMobile' config enabled
         */
        if ( appConfig.getConfig('disableMdInkRippleOnMobile') && msUtils.isMobile() )
        {
            var bodyEl = angular.element('body');
            bodyEl.attr('md-no-ink', true);
        }

        /**
         * Put isMobile() to the html as a class
         */
        if ( msUtils.isMobile() )
        {
            angular.element('html').addClass('is-mobile');
        }

        /**
         * Put browser information to the html as a class
         */
        var browserInfo = msUtils.detectBrowser();
        if ( browserInfo )
        {
            var htmlClass = browserInfo.browser + ' ' + browserInfo.version + ' ' + browserInfo.os;
            angular.element('html').addClass(htmlClass);
        }

        formlyConfig.setType({
          name: 'input',
          template: '<input ng-model="model[options.key]">'
        });
        
        formlyConfig.setType({
          name: 'checkbox',
          template: '<md-checkbox ng-model="model[options.key]">{{to.label}}</md-checkbox>'
        });
        
        formlyConfig.setWrapper({
          name: 'mdLabel',
          types: ['input'],
          template: '<label>{{to.label}}</label><formly-transclude></formly-transclude>'
        });
        
        formlyConfig.setWrapper({
          name: 'mdInputContainer',
          types: ['input'],
          template: '<md-input-container><formly-transclude></formly-transclude></md-input-container>'
        });
        
        // having trouble getting icons to work.
        // Feel free to clone this jsbin, fix it, and make a PR to the website repo: https://github.com/formly-js/angular-formly-website
        formlyConfig.templateManipulators.preWrapper.push(function(template, options) {
          if (!options.data.icon) {
            return template;
          }
          return '<md-icon class="step" md-font-icon="icon-' + options.data.icon + '"></md-icon>' + template;
        });
    }
})();
