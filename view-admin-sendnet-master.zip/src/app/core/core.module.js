(function ()
{
    'use strict';

    angular
        .module('app.core',
            [
                'ngAnimate',
                'ngAria',
                'ngCookies',
                'ngMessages',
                'ngResource',
                'ngSanitize',
                'ngMaterial',
                'pascalprecht.translate',
                'ct.ui.router.extras.core',
                'ui.router',
                'ngIdle',
                'angular-storage',
                'md.data.table',
                // 'datatables',
                'formly',
                'ui.router',
                'ngCsv',
                'ngProgress',
                'vAccordion',
                'permission',
                'permission.ui'
            ]);
})();
