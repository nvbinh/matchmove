(function() {
    'use strict';

    angular
        .module('app.core')
        .directive('mmMessageBox', mmMessageBoxDirective);

    /** @ngInject */
    function mmMessageBoxDirective($document, $timeout) {
        return {
            restrict: 'E',
            scope: {},
            transclude: true,
            templateUrl: 'app/core/directives/mm-message-box/mm-message-box.html',
            link: function(scope, iElement) {
                var body = $document.find('body'),
                    bodyClass = 'mm-message-box-active';

                // Add body class
                body.addClass(bodyClass);

                /**
                 * Remove the info bar
                 */
                function removeMessageBox() {
                    body.removeClass(bodyClass);
                    iElement.remove();
                    scope.$destroy();
                }

                $timeout(function() {
                    removeMessageBox();
                }, 5000);

                // Expose functions
                scope.removeMessageBox = removeMessageBox;
            }
        };
    }
})();
