(function ()
{
    'use strict';

    angular
        .module('app.core')
        .controller('msActivityController', msActivityController)
        .directive('msActivity', msActivity);

    /** @ngInject */
    function msActivityController($scope)
    {
        var vm = this;
        

        // Methods

        /**
         * Initialize / Watch model changes
         */
        // $scope.$watch('ngModel', setSelectedColor);
        
    }

    /** @ngInject */
    function msActivity()
    {
        return {
            restrict   : 'E',
            scope      : {
                data: '=data'
            },
            controller : 'msActivityController as vm',
            templateUrl: 'app/core/directives/ms-activity/ms-activity.html',
            link       : function (scope, element, attrs, controllers, transclude)
            {
                switch (scope.data) {
                    case 'Notification:Activity:EmailVerified:Title':
                        scope.text = 'NOTIFICATION.ACTIVITY.EMAIL_VERIFIED';
                        break;
                    case 'Notification:Activity:WalletCreated:Title':
                        scope.text = 'NOTIFICATION.ACTIVITY.WALLET_CREATED';
                        break;
                    case 'Notification:Activity:AccountLogin:Title':
                        scope.text = 'NOTIFICATION.ACTIVITY.ACCOUNT_LOGIN';
                        break;
                    case 'Notification:Activity:EmailVerified:Text':
                        scope.text = 'NOTIFICATION.ACTIVITY.EMAIL_VERIFIED';
                        break;
                    case 'Notification:Activity:WalletCreated:Text':
                        scope.text = 'NOTIFICATION.ACTIVITY.WALLET_CREATED';
                        break;
                    case 'Notification:Activity:AccountLogin:Text':
                        scope.text = 'NOTIFICATION.ACTIVITY.ACCOUNT_LOGIN';
                        break;
                }
            }
        };
    }
})();
