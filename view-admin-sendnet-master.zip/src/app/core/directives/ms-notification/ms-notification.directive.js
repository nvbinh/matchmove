(function ()
{
    'use strict';

    angular
        .module('app.core')
        .controller('msNotificationController', msNotificationController)
        .directive('msNotification', msNotification);

    /** @ngInject */
    function msNotificationController($scope)
    {
        var vm = this;
        

        // Methods

        /**
         * Initialize / Watch model changes
         */
        // $scope.$watch('ngModel', setSelectedColor);
        
    }

    /** @ngInject */
    function msNotification()
    {
        return {
            restrict   : 'E',
            scope      : {
                data: '=data'
            },
            controller : 'msNotificationController as vm',
            templateUrl: 'app/core/directives/ms-notification/ms-notification.html',
            link       : function (scope, element, attrs, controllers, transclude)
            {
                scope.isAdmin = false;
                scope.isUser = false;
                if (attrs.notificationType === 'admin') {
                    scope.isAdmin = true;
                } else if (attrs.notificationType === 'user') {
                    scope.isUser = true;
                }
                scope.parseResponse = function(str) {
                    return JSON.parse(str);           
                }
            }
        };
    }
})();
