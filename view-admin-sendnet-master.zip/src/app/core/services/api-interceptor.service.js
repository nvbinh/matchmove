(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('apiInterceptor', apiInterceptorService);

    /** @ngInject */
    function apiInterceptorService($rootScope, $q, store, $location) {
        // var service = this;
        var service = {
            request: request,
            requestError: requestError,
            response: response,
            responseError: responseError
        };

        return service;

        function request(config) {
            // service.loading = true;
            return config || $q.when(config);
        }

        function requestError(request) {
            return $q.reject(request);
        }

        function response(r) {
            // service.loading = false;
            return r || $q.when(r);
        }

        function responseError(response) {
            if (response) {
                switch (response.status) {
                    case 401:
                        // Handle authentication issues / token or key expired
                        $rootScope.$broadcast('unauthorized');
                        break;
                    case 403:
                        // redirect to 403 error page
                        $rootScope.$broadcast('forbidden');
                        location.href = location.origin + '/errors/error-403';
                        break;
                    case 404:
                        // redirect to 404 error page
                        $rootScope.$broadcast('failed');
                        location.href = location.origin + '/errors/error-404';
                        break;
                    case 500:
                        // redirect to 500 error page
                        $rootScope.$broadcast('failed');
                        location.href = location.origin + '/errors/error-500';
                        break;
                    default:
                        // redirect to error error page
                        var msg = response.data ? response.data.message : "";
                        $rootScope.message = msg;
                        store.set('error', {
                            last_page_visited: location.href,
                            message: msg
                        });
                        break;
                }
            }

            return $q.reject(response);
        }

    }


})();
