(function() {
    'use strict';

    angular
        .module('app.core')
        .factory('mmPermission', mmPermissionService);

    /** @ngInject */
    function mmPermissionService($rootScope, $q, store, $location, PermPermissionStore, msApi, API_BASE, PermRoleStore, authSession, msUtils) {
        // var service = this;
        var service = {
            initialize: initialize,
            reInitialize: reInitialize,
            hasPermission: hasPermission
        };
        var permissions;

        return service;

        function initialize() {
            msApi.setBaseUrl(API_BASE);
            var vm = {
                apiUrl: 'api/admins/reports'
            }
            msApi.register('admins.roles', [vm.apiUrl]);
            initPermission();
        }

        function initPermission() {
            msApi.request('admins.roles@get', {},
                function(success) {
                    angular.forEach(success.data.response, function(roles) {
                        angular.forEach(roles, function(permissionCategory) {
                            permissions = [];
                            if (typeof permissionCategory == 'object') {

                                angular.forEach(permissionCategory, function(role) {
                                    setPermission(role, permissions)
                                });
                                angular.forEach(permissionCategory.actions, function(role) {
                                    setPermission(role.permissions, permissions)
                                });
                            }
                            if (permissions.length != 0) {
                                PermPermissionStore.definePermission(roles.name, permissions);
                            }
                        });
                    });
                    authSession.storePermissionId();
                    $rootScope.$broadcast('permission:stored');
                },
                function(error) {}
            );
        }

        function reInitialize() {
            var permStore = store.get('permission_ids');
            angular.forEach(permStore, function(permission) {
                console.log(permission.name)
                setPermissionPerm(permission, function() {
                    return true;
                });
            });
        }

        function setPermission(role, permissions) {
            angular.forEach(role, function(permission) {
                var id = permission.id;
                var name = permission.name;
                setPermissionPerm(permission.name, function() {
                    return authSession.hasPermissionId(name);
                });
            });
        }

        function setPermissionPerm(permission_name, block) {
            PermPermissionStore.definePermission(permission_name, block);
        }

        function hasPermission(permission_name) {
            var permStore = store.get('permission_ids');
            return msUtils.exists(permission_name, permStore);
        }
    }
})();
