(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('HelperFactory', helperFactory);

    /** @ngInject */
    function helperFactory($mdSidenav)
    {
        var service = {
          toISODate: toISODate,
          toggleSidenav: toggleSidenav
        };

        return service;

        //////////
        /**
         * returns iso format date
         * @param date
         */
        function toISODate(date)
        {
          return moment(date).format('YYYY-MM-DD')
        }

        /**
        * Toggle sidenav
        *
        * @param sidenavId
        */
        function toggleSidenav(sidenavId)
        {
          $mdSidenav(sidenavId).toggle();
        }

        }

})();
