(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('msGen', msGen);

    /** @ngInject */
    function msGen($window, $filter)
    {
        // Private variables
        var extension = 'csv';

        var service = {
            getFileName       : getFileName,
        };

        return service;

        //////////

        /**
         * Generate the file name by resource and parameters
         *
         * @param resouseName string
         * @param queryParams array
         * @returns {string}
         */
        function getFileName(resouseName, currentPage, totalPage, queryParams)
        {
            var fileName = '',
                elements = [];
            if (resouseName) {
                elements.push(resouseName);
                
            }

            if (currentPage) {
                elements.push(currentPage);
            }

            if (totalPage) {
                elements.push(totalPage);
            }

            
            var dateArray = getDateParams(queryParams);
            //replace special characters
            if (dateArray.length > 0) {
                elements = elements.concat(dateArray);
            }

            fileName = elements.join('_') + '.' + extension;

            return fileName;
        }

        function getDateParams(dateParams) {
            var dateArray = [];
            if (dateParams && dateParams.from_date && dateParams.to_date) {
                var fromDate = $filter('date')(dateParams.from_date, 'MM-dd-yyyy');
                var toDate = $filter('date')(dateParams.to_date, 'MM-dd-yyyy');
                dateArray.push(fromDate);
                dateArray.push(toDate);
            }
            return dateArray;
        }
    }
}());