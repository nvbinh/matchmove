(function ()
{
    'use strict';

    angular
        .module('app.cancellation.history')
        .controller('CancellationHistoryController', CancellationHistoryController);

    /** @ngInject */
    function CancellationHistoryController(msApi, store, API_BASE, $mdToast, $scope, CANCELLATION_CONSTANTS, cancellationService, HelperFactory, CURRENCIES, $mdDialog, $filter, msGen, REPORTS_ITEMS_PER_PAGE, Providers, PROVIDERS, COUNTRIES)
    {
        var vm = this;

        // Data
        vm.resourceName = "Cancellation History";
        vm.showDetails = false;
        vm.selected = [];
        vm.selected_ids = "";
        vm.fromCurrencies = CURRENCIES;
        vm.toCurrencies = CURRENCIES;
        vm.results = null;
        vm.csvData = [];
        vm.model = {};
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.countries = COUNTRIES;
        vm.csv_table_header = CANCELLATION_CONSTANTS.csv_cancellation_datatable_heading;
        vm.transaction_status = CANCELLATION_CONSTANTS.transaction_status;
        vm.cancellation_submission = CANCELLATION_CONSTANTS.cancellation_status;
        vm.providers = Providers.providers;
        vm.delivery_methods = PROVIDERS.Homesend;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };

        vm.filename = new Date().toString() + ".csv";
        vm.delivery_methods_description = {
          "N/A": "N/A"
        };

        angular.forEach(vm.providers, function(provider){
          angular.forEach(PROVIDERS[provider.code], function(value, key){
            vm.delivery_methods_description[key] = value
          });
        });

        vm.onSubmit = onSubmit;
        vm.toggleDetails = toggleDetails;
        vm.getDataForCsv = getDataForCsv;
        vm.toggleFilter = toggleFilter;
        vm.closeFilter = closeFilter;
        vm.changeProvider = changeProvider;
        vm.resetForm = resetForm;

        vm.countries_hash = {};
        angular.forEach(vm.countries, function(country){
          if(country.code !== ""){
            vm.countries_hash[country.code] = country.name
          }
        });

        var apiUrl = 'api/remittance/transaction/cancellation';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        vm.tables = {
          header: []
        }
        currentCancellation();

        function resetForm(form){
          vm.selected = [];
          vm.model = {};
          form.$pristine = false;
        }

        function changeProvider(){
          vm.model = {
            provider: vm.model.provider
          };
          vm.delivery_methods = PROVIDERS[vm.model.provider];
        }

        /**
         * Get CSV Data
         *
         * @param
        */
        function getDataForCsv() {
          vm.csvData = [];
          vm.results.forEach( function( el, ind, arr ) {
            var objItem = {};
            objItem.provider = el.provider;
            objItem.routing_param = (el.routing_param == 'null') ? 'N/A' : el.routing_param;
            objItem.reference_id = el.reference_id;
            objItem.transaction_code = el.transaction_code || 'N/A';
            objItem.transaction_id = el.transaction_id;
            objItem.type = el.type;
            objItem.status_code = el.status_code;
            objItem.transaction_status = el.transaction_status;
            objItem.date_added = el.date_added;
            objItem.date_expiry = el.date_expiry;
            objItem.send_amount = $filter('number')(el.send_amount, 2);
            objItem.send_currency = el.send_currency;
            objItem.receive_amount = $filter('number')(el.receive_amount, 2);
            objItem.receive_currency = el.receive_currency;
            objItem.receive_country = el.receive_country;
            objItem.provider_exchange_rate = $filter('number')(el.provider_exchange_rate, 2);
            objItem.total_transaction_amount = $filter('number')(el.total_transaction_amount, 2);
            objItem.provider_fixed_fee = $filter('number')(el.provider_fixed_fee, 2);
            objItem.customer_fx_percent = $filter('number')(el.customer_fx_percent, 2);
            objItem.crossrate = $filter('number')(el.crossrate, 2);
            objItem.provider_amount_fee = $filter('number')(el.provider_amount_fee, 2);
            objItem.provider_amount_fee_ccy = el.provider_amount_fee_ccy;
            objItem.delivery_method = el.delivery_method;
            objItem.payout_agent = el.payout_agent;
            objItem.customer_fixed_fee = $filter('number')(el.customer_fixed_fee, 2);
            objItem.provider_amount_to_send_ccy = el.provider_amount_to_send_ccy;
            objItem.actual_provider_amount_to_send_ccy = el.actual_provider_amount_to_send_ccy;
            objItem.send_amount_in_prefund_currency_before_fx = $filter('number')(el.send_amount_in_prefund_currency_before_fx, 2);
            objItem.send_amount_in_prefund_currency_after_fx = $filter('number')(el.send_amount_in_prefund_currency_after_fx, 2);
            vm.csvData.push(objItem);
          });
          return vm.csvData;
        }

        function toggleFilter(ev){
          if (vm.model) {
            vm.model.from = null;
            vm.model.to = null;
            vm.model.status = null;
          }
          $mdDialog.show({
            scope: $scope,
            preserveScope: true,
            resolve  : {
            },
            templateUrl : 'app/main/cancellation/history/filter-dialog/filter-dialog.html',
            clickOutsideToClose: true,
          });
        }

        function closeFilter(){
          $mdDialog.hide();
        }

        function toggleDetails(item, details)
        {
            vm.showDetails = true;
            vm.cancellationDetail = item;
            // vm.cancellationDetail.date_cancellation_added = new Date(vm.cancellationDetail.date_cancellation_added);
            // vm.cancellationDetail.date_expiry = new Date(vm.cancellationDetail.date_expiry);
            if(details === 'show'){
              HelperFactory.toggleSidenav('details-sidenav');
            }
        }

        function formatDate(date_from, date_to){
          return [moment(date_from).format('YYYY-MM-DD'), moment(date_to).format('YYYY-MM-DD')]
        }

        // function definition
        function onSubmit() {
          var queryStr = vm.model, apiUrl = 'api/remittance/transaction/cancellation';

          if(queryStr.date_added_from !== undefined && queryStr.date_added_to !== undefined){
            queryStr.date_cancellation_added = formatDate(queryStr.date_added_from, queryStr.date_added_to).toString();
            delete queryStr.date_added_from;
            delete queryStr.date_added_to;
          }

          if(queryStr.date_confirmed_from !== undefined && queryStr.date_confirmed_to !== undefined){
            queryStr.date_cancellation_confirmed = formatDate(queryStr.date_confirmed_from, queryStr.date_confirmed_to).toString();
            delete queryStr.date_confirmed_from;
            delete queryStr.date_confirmed_to;
          }

          queryStr.page = vm.query.page;
          queryStr.records_per_page = vm.query.limit;
          queryStr.offset = (vm.query.page - 1) * queryStr.records_per_page;
          queryStr.sort_type = 'desc';
          queryStr.sort_by = 'date_cancellation_added';
          if (!queryStr.cancellation_status) {
            queryStr.cancellation_status = 'approved,rejected,inactive';
          }

          vm.results = null;
          requestApi(queryStr);
          closeFilter();
        }

        function currentCancellation(){
          requestApi({
            records_per_page              : vm.query.limit,
            page                          : vm.query.page,
            cancellation_status           : 'approved,rejected,inactive',
            sort_type                     : 'desc',
            sort_by                       : 'date_cancellation_added'
          });
        }

        function toTimeParams(d){
          var curr_day= d.getDate();  //change day here
          var curr_month = d.getMonth() + 1;
          var curr_year = d.getFullYear();
          return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr){
          cancellationService.getCancellation(queryStr).then(
              function (success) {
                if(success instanceof Array){
                  vm.results = success;
                }
                else if(success.response instanceof Array){
                  vm.results = success.response;
                  if (vm.results) {
                    vm.results.total_records = success.pagination.total_records;
                  } else {
                    vm.results = [];
                  }
                }else{
                  vm.results = success.response.rates;
                  vm.results.total_records = success.pagination.total_records;
                }
                if(vm.results) {
                  vm.tables.header = CANCELLATION_CONSTANTS.cancellation_history_heading
                  angular.forEach(vm.results, function(rs, key){
                    vm.results[key].date_cancellation_added = new Date(rs.date_cancellation_added);
                    vm.results[key].date_expiry = new Date(rs.date_expiry);
                    vm.results[key].date_added = new Date(rs.date_added);
                    vm.results[key].date_cancellation_confirmed = new Date(rs.date_cancellation_confirmed);
                    vm.results[key].receive_country = vm.countries_hash[rs.receive_country];
                    vm.results[key].delivery_method = vm.delivery_methods_description[rs.delivery_method];
                  });
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
                vm.logPagination = success.pagination;
                var totalPage = (vm.logPagination && vm.logPagination.total_pages) ? vm.logPagination.total_pages : 0;
                vm.csvFilename = msGen.getFileName(vm.resourceName, vm.query.page, totalPage, vm.model);
              },
              function (response) {}
          );
        }

    }

})();
