(function ()
{
    'use strict';

    angular
        .module('app.cancellation.history', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.cancellation_history', {
            url      : '/cancellation/history',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cancellation/history/history.html',
                    controller : 'CancellationHistoryController as vm'
                }
            },
            resolve  : {
                Providers : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
                DeliveryMethods: function (msApi){
                    return msApi.resolve('builder.pricing_filter@get');
                }
            },
            bodyClass: 'cancellation history'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cancellation/history');
        msApiProvider.register('builder.pricing_filter', ['app/main/pricing/builder/price-filter.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('cancellation.history', {
            title : 'History',
            state : 'app.cancellation_history',
            weight: 2
        });
    }

})();
