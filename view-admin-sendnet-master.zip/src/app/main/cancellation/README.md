ng-modules-cancellation
This is the Cancellation module for SendNet.