(function ()
{
    'use strict';

    angular
        .module('app.cancellation.add', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.cancellation_add', {
            url      : '/cancellation/add',
            params: {
              provider: null,
              delivery_method: null,
              payout_agent: null,
              receive_country: null,
              status_text: null,
              send_amount: null,
              send_currency: null,
              routing_param: null,
              customer_fixed_fee: null,
              transaction_code: null,
              total_transaction_amount: null,
              reference_id: null,
              receive_amount: null,
              receive_currency: null,
              transaction_id: null
            },
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cancellation/add/add-cancellation.html',
                    controller : 'CancellationAddController as vm'
                }
            },
            resolve  : {
               
            },
            bodyClass: 'cancellation add'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cancellation/add');
    }

})();
