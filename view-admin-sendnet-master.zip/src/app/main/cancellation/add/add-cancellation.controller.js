(function() {
    'use strict';

    angular
        .module('app.cancellation.add')
        .controller('CancellationAddController', CancellationAddController);

    /** @ngInject */
    function CancellationAddController(store, msApi, API_BASE, $mdToast, $scope, $stateParams, cancellationService, $state, $filter, PROVIDER_CODES, PROVIDERS) {

        var vm = this;
        vm.fields1 = [];
        vm.onSubmit = onSubmit;

        msApi.setBaseUrl(API_BASE);

        if ($stateParams && $stateParams.transaction_id) {
            store.set('cancellationData', $stateParams);
        }
        vm.model = store.get('cancellationData');

        vm.delivery_methods_description = {
          "N/A": "N/A"
        };

        vm.providers = PROVIDER_CODES;
        angular.forEach(vm.providers, function(provider){
          angular.forEach(PROVIDERS[provider.code], function(value, key){
            vm.delivery_methods_description[key] = value
          });
        });

        if (vm.model) {
            if (vm.model.delivery_method) {
                vm.model.delivery_method = vm.delivery_methods_description[vm.model.delivery_method];
            }
            vm.model.payout_agent = (vm.model.payout_agent && vm.model.payout_agent != 'null') ? vm.model.payout_agent : 'N/A';
            vm.model.transaction_code = (vm.model.transaction_code && vm.model.transaction_code != 'null') ? vm.model.transaction_code : 'N/A';
            vm.model.routing_param = (vm.model.routing_param && vm.model.routing_param != 'null') ? vm.model.routing_param : 'N/A';
        }

        function onSubmit() {
            $mdToast.show(
                $mdToast.simple()
                .textContent('Adding Cancellation Submission...')
                .position('top center')
            );
            var data = {};
            if (vm.model.transaction_id && vm.model.reason) {
                data.transaction_id = vm.model.transaction_id;
                data.reason = vm.model.reason;
            }

            cancellationService.addCancellation(data).then(
                function(success) {
                    vm.model = {};
                    vm.cancellationForm.$setPristine();
                    vm.cancellationForm.$setUntouched();
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Success! Cancellation Submission added!')
                        .position('top center')
                    );
                    $state.go('app.logs_transactions');
                },
                function(error) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent("Transaction id could not be cancelled. Either it's pending or has been approved")
                        .position('top center')
                    );
                }
            );
        }
    }
})();
