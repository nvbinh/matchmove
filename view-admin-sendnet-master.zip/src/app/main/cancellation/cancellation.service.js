(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('cancellationService', cancellationService);

    /** @ngInject */
    function cancellationService($q, $log, api, store, $timeout, msApi, $mdToast, API_BASE, HTTP_HOST, APP_TYPE)
    {
        var service = {
          addCancellation: addCancellation,
          getCancellation: getCancellation,
          approve: approve,
          reject: reject
        };

        msApi.setBaseUrl(API_BASE);

        return service;

        /**
         * addCancellation api
         */
        function addCancellation(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/transaction/cancellation';

            msApi.register('add.cancellation', [apiUrl]);
            msApi.requestApi('add.cancellation@post', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

      

        /**
         * getCancellation api
         */
        function getCancellation(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/transaction/cancellation';

            msApi.register('query.history', [apiUrl]);
            msApi.requestApi('query.history@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * approve api
         */
        function approve(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/transaction/cancellation/approve';

            msApi.register('approve.cancellation', [apiUrl]);
            msApi.requestApi('approve.cancellation@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * reject api
         */
        function reject(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/transaction/cancellation/reject';

            msApi.register('reject.cancellation', [apiUrl]);
            msApi.requestApi('reject.cancellation@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

    }

})();
