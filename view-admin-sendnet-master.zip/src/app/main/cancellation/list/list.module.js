(function ()
{
    'use strict';

    angular
        .module('app.cancellation.list', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.cancellation_list', {
            url      : '/cancellation/list',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cancellation/list/list.html',
                    controller : 'CancellationListController as vm'
                }
            },
            resolve  : {
                Providers : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
                DeliveryMethods: function (msApi){
                    return msApi.resolve('builder.pricing_filter@get');
                }
            },
            bodyClass: 'cancellation list'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cancellation/list');
        msApiProvider.register('builder.pricing_filter', ['app/main/pricing/builder/price-filter.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('cancellation.list', {
            title : 'Pending Submission',
            state : 'app.cancellation_list',
            weight: 1
        });
    }

})();
