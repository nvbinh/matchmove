(function ()
{
    'use strict';

    angular
        .module('app.cancellation', [
            'app.cancellation.add',
            'app.cancellation.list',
            'app.cancellation.history'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('cancellation', {
            title : 'Cancellation',
            icon  : 'icon-cancel',
            weight: 4
        });
    }
})();
