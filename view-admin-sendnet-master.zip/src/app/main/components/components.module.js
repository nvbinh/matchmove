(function ()
{
    'use strict';

    angular
        .module('app.components', [
            'app.components.mmProviderBox',
            'app.components.mmRestrictInput'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
    }
})();
