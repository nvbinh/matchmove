(function ()
{
    'use strict';

    angular
        .module('app.components.mmProviderBox')
        .directive('mmProviderBox', mmProviderBoxDirective)
    /** @ngInject */
    function mmProviderBoxDirective($document, $timeout) {
      return {
        restrict: 'E',
          scope: {
            providerId: '@',
            useProviderCode: '@'
          },
          transclude: true,
          controller: 'mmProviderBoxController as vm',
          templateUrl: 'app/main/components/mm-provider-box/pages/rails-provider.html',
          link: function(scope, iElement, attrs) {
          }
      };
    }
})();
