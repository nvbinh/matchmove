(function ()
{
    'use strict';

    angular
        .module('app.components.mmProviderBox')
        .controller('mmProviderBoxController', mmProviderBoxDirectivesController);

    /** @ngInject */
    function mmProviderBoxDirectivesController(msApi, API_BASE, store, $scope)
    {
        var vm = this;
        // Data
        var apiUrl = '/api/remittance/rails';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.rails', [apiUrl]);
        var queryStr = {}
        queryStr.access_token = store.get('token_data').access_token;

        msApi.request('query.rails@get', queryStr,
          function (response) {
            vm.providers  = response.data.response;
          },
          function (response) {}
          );

        // Methods
        $scope.$watch('vm.selected_provider', function(p){
          $scope.$parent.selected_provider = vm.selected_provider;
        });

        //////////
        return vm;
    }
})();
