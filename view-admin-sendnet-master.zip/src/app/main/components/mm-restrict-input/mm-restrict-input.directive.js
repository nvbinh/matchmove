(function ()
{
    'use strict';

    angular
        .module('app.components.mmRestrictInput')
        .directive('mmRestrictInput', mmRestrictInputDirective)
    /** @ngInject */
    function mmRestrictInputDirective($filter) {
      return {
        restrict: 'A',
          scope: {
            pattern: '@',
          },
          transclude: true,
          link: function(scope, iElement, attrs) {
            var ele = iElement[0];
            var regex = RegExp(attrs.mmRestrictInput);
            var value = ele.value;

            ele.addEventListener('change',function(e){
                if (ele.value <= 0) {
                  ele.value = '';
                }
                if (regex.test(ele.value)){
                    value = ele.value;
                }else{
                    ele.value = value;
                }
            });

            ele.addEventListener('keyup',function(e){
                if (ele.value === '.') {
                  ele.value = '';
                }
                if (regex.test(ele.value)){
                    value = ele.value;
                }else{
                    ele.value = value;
                }
            });
          
          }
      };

    }
})();
