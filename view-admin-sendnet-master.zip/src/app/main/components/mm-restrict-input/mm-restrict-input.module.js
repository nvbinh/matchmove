(function ()
{
    'use strict';

    angular
        .module('app.components.mmRestrictInput', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, msNavigationServiceProvider)
    {
    }
})();
