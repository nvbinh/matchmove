(function ()
{
    'use strict';

    angular
        .module('app.components.mmRestrictInput')
        .controller('mmRestrictInputController', mmRestrictInputController);

    /** @ngInject */
    function mmRestrictInputController($scope)
    {
        var vm = this;
        // Data

        //////////
        return vm;
    }
})();
