(function ()
{
    'use strict';

    angular
        .module('app.pricing.approval', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.pricing_approval', {
            url      : '/pricing/approval',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/pricing/approval/approval.html',
                    controller : 'PricingApprovalController as vm'
                }
            },
            resolve  : {
                Providers : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
                PayoutAgents : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
                DeliveryMethods: function (msApi){
                    return msApi.resolve('builder.pricing_filter@get');
                }
            },
            bodyClass: 'pricing approval'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/pricing/approval');

        msApiProvider.register('builder.pricing_history', ['app/main/pricing/builder/price-history.json']);
        msApiProvider.register('builder.pricing_filter', ['app/main/pricing/builder/price-filter.json']);

        msNavigationServiceProvider.saveItem('pricing.approval', {
            group: 'Pricing',
            title: 'Pending Approval',
            state : 'app.pricing_approval',
            weight: 2
        });
    }

})();
