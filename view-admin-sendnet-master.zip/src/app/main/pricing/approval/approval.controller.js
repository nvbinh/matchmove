(function ()
{
	'use strict';

	angular
		.module('app.pricing.approval')
		.controller('PricingApprovalController', PricingApprovalController);

    /** @ngInject */
    function PricingApprovalController(msApi, store, API_BASE, $mdToast, $scope, PRICING_CONSTANTS, $mdSidenav, HelperFactory, priceService, sdService, APP_TYPE, $mdDialog, $document, Providers, $timeout, DELIVERY_METHODS, $log, $q, PROVIDERS, COUNTRIES, msGen, APP_CURRENCY, REPORTS_ITEMS_PER_PAGE, $filter)
    {
        var vm = this;

        // Data
        vm.resourceName = "Pricing Approval";
        vm.noCache = 'noCache';
        vm.showDetails = false;
        vm.selected = [];
        vm.selected_ids = "";
        vm.results = null;
        vm.app = APP_TYPE;
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.base_currency = APP_CURRENCY.base;
        vm.csv_table_header = PRICING_CONSTANTS.csv_approval_datatable_heading;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };
        vm.model = {};

        vm.filename = new Date().toString() + ".csv";
        vm.allPayoutAgent = " ";

        vm.providers = Providers.providers;
        vm.payout_agents = DELIVERY_METHODS;
        vm.countries = COUNTRIES;
        vm.delivery_methods = PROVIDERS.Homesend;
        vm.countries_hash = {};
        angular.forEach(vm.countries, function(country){
          if(country.code !== ""){
            vm.countries_hash[country.code] = country.name
          }
        });

        vm.onSubmit = onSubmit;
        vm.toggleDetails = toggleDetails;
        vm.changeClient = changeClient;
        vm.toggleFilter = toggleFilter;
        vm.closeFilter = closeFilter;
        vm.confirmItem = confirmItem;
        vm.confirmAllItems = confirmAllItems;
        vm.editPricing = editPricing;
        vm.updatePricing = updatePricing;
        vm.closeDialog = closeDialog;
        vm.changeProvider = changeProvider;

        vm.querySearch   = querySearch;
        vm.selectedItemChange = selectedItemChange;
        vm.searchTextChange  = searchTextChange;
        vm.loadAll = loadAll;
        vm.resetForm = resetForm;

        var apiUrl = 'api/remittance/price/history';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        vm.tables = {
          header: []
        }
        currentPricingHistory();

        $scope.$watchGroup(['vm.model.provider', 'vm.model.delivery_method', 'vm.model.receive_country'], function(){
          if(vm.model && vm.model.provider && vm.model.delivery_method && vm.model.receive_country){
            vm.model.payout_agent = null;
            vm.selectedItem = null;
            vm.model.country = vm.model.receive_country;
            getPayoutAgents();
          }
        });

        // sorts the table fields
        $scope.sortFilter = function(index, th) {
            switch (th) {
                case 'Customer Fixed Fee':
                    $scope.orderByField = 'fixed_fee';
                    $scope.reverseOrder = !$scope.reverseOrder;
                    break;
                case 'Customer FX%':
                    $scope.orderByField = 'fx_percentage';
                    $scope.reverseOrder = !$scope.reverseOrder;
                    break;
            }
        }

        function changeProvider(){
          vm.model = {
            provider: vm.model.provider
          };
          vm.delivery_methods = PROVIDERS[vm.model.provider]
        }

        function querySearch(query) {
            var deferred = $q.defer();
            if (!query) {
                deferred = searchAgent(query, deferred);
                return deferred.promise;
            } else {
                vm.model.name = query;
                vm.selectedItem = null;
                return getPayoutAgents(deferred, query);
            }
        }

        function getPayoutAgents(deferred, query) {
          priceService.getPayoutAgents(vm.model).then(function(success) {
              if (success && success.hasOwnProperty('response') && success.response.length > 0) {
                  var resTextArray = [];
                  angular.forEach(success.response, function(value, key) {
                      resTextArray.push(success.response[key]['name']);
                  });
                  vm.allPayoutAgent = resTextArray.toString();
                  
              } else if (success instanceof Array) {
                  vm.allPayoutAgent = " ";
              }
              if (deferred) {
                deferred = searchAgent(query, deferred);
              }
          }, function(err) {
              delete vm.model['payout_agent'];
              vm.allPayoutAgent = " ";
              if (deferred) {
                deferred.reject(err);
              }
          });
          if (deferred) {
            return deferred.promise;
          }
        }

        function searchAgent(query, deferred) {
            var results = query ? loadAll().filter(createFilterFor(query)) : loadAll();
            deferred.resolve(results);
            return deferred;
        }

        function resetForm(form){
          vm.allPayoutAgent = " ";
          vm.selected = [];
          vm.model = {};
          form.$pristine = false;
        }

         function searchTextChange(text) {
           $log.info('Text changed to ' + text);
         }

         function selectedItemChange(item) {
           $log.info('Item changed to ' + JSON.stringify(item));
           if(item){
             vm.model.payout_agent = item.display;
           }
         }

         /**
          * Create filter function for a query string
          */
         function createFilterFor(query) {
           var lowercaseQuery = angular.lowercase(query);

           return function filterFn(state) {
             return (state.value.indexOf(lowercaseQuery) === 0);
           };
         }

        function loadAll() {
          return vm.allPayoutAgent.split(/,+/g).map( function (state) {
            return {
              value: state.toLowerCase(),
              display: state
            };
          });
        }
        function closeFilter(){
          $mdDialog.hide();
        }

        function closeDialog(){
          vm.results = null;
          currentPricingHistory();
          closeFilter();
        }

        function showDialog(opt){
          closeFilter();
          $mdDialog.show({
            scope: $scope,
            preserveScope: true,
            resolve  : {
                // Providers : function (msApi)
                // {
                //     return msApi.resolve('builder.pricing_filter@get');
                // },
                // PayoutAgents : function (msApi)
                // {
                //     return msApi.resolve('builder.pricing_filter@get');
                // },
                // DeliveryMethods: function (msApi){
                //     return msApi.resolve('builder.pricing_filter@get');
                // }
            },
            templateUrl : opt.templateUrl,
            clickOutsideToClose: opt.clickToClose
          })
        }

        function toggleFilter(ev){
          showDialog({ templateUrl : 'app/main/pricing/list/dialog/filter-dialog/filter-dialog.html', clickToClose: true });
        }

        function editPricing(ev){
          showDialog({ templateUrl : 'app/main/pricing/list/dialog/edit-dialog/edit-dialog.html', clickToClose: true });
        }

        function updatePricing(){
          $scope.pricing_count = 0;
          vm.fail = false;
          vm.success = false;
          vm.hideloader = false;
          vm.pricing_list = angular.copy(vm.selected);
          showDialog({ templateUrl : 'app/main/pricing/approval/dialog/edit-dialog/_processing.html', clickToClose: false });
          $timeout(function(){
            $scope.$watch('pricing_count', function(){
              addPricing();
            });
          }, 3000);
        }

        function addPricing(){
          var pricing = vm.pricing_list.shift();
          if(pricing === undefined){
            vm.selected = [];
            return;
          }
          angular.merge(pricing, vm.model);
          pricing.receiving_currency = pricing.receive_currency;
          priceService.addPrice(pricing).then(
              function (response) {
                $scope.pricing_count++;
                vm.success = true;
                vm.hideloader = true;
              }, function (error){
                vm.pricing_list = [];
                vm.fail_pricing = pricing.id.slice(-12);
                $scope.pricing_count++;
                vm.fail = true;
                vm.hideloader = true;
              });
        }

        function changeClient(){
          currentPricingHistory();
        }

        function toggleDetails(item, details)
        {
            vm.showDetails = true;
            vm.pricingDetail = item;
            vm.pricingDetail.date_created = new Date(vm.pricingDetail.date_created);
            vm.pricingDetail.date_confirmed = new Date(vm.pricingDetail.date_confirmed);
            if(details === 'show'){
              HelperFactory.toggleSidenav('details-sidenav');
            }
        }

        // function definition
        function onSubmit() {
          var queryStr = vm.model, apiUrl = 'api/remittance/price/history';

          queryStr.page = vm.query.page;
          queryStr.records_per_page = vm.query.limit;
          queryStr.offset = (vm.query.page - 1) * queryStr.records_per_page;
          queryStr.sort_type = 'desc';
          queryStr.status = 'pending';
          if(queryStr.payout_agent === " "){
            queryStr.payout_agent = "";
          }

          vm.results = null;
          requestApi(queryStr);
          closeFilter();
        }

        function currentPricingHistory(){
          requestApi({
            records_per_page: vm.query.limit,
            status          : 'pending'
          });
        }

        function toTimeParams(d){
          var curr_day= d.getDate();  //change day here
          var curr_month = d.getMonth() + 1;
          var curr_year = d.getFullYear();
          return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr){
          queryStr.sort = '-date.created';
          priceService.getAllPriceHistory(queryStr).then(
              function (success) {
                if(success instanceof Array){
                  vm.results = success;
                }
                else if(success.response instanceof Array){
                  vm.results = success.response[0];
                  vm.results.total_records = success.pagination.total_records;
                  vm.logPagination = success.pagination;

                  vm.csv_results = angular.copy(vm.results);
                  angular.forEach(vm.csv_results, function(value, key){
                    vm.csv_results[key].delivery_method = value.delivery_method_description;
                    vm.csv_results[key].receive_country = vm.countries_hash[value.receive_country];
                    vm.csv_results[key].fixed_fee = vm.base_currency + ' ' + $filter('number')(value.fixed_fee, 2);
                    delete vm.csv_results[key]['date_confirmed'];
                    delete vm.csv_results[key]['delivery_method_description'];
                    delete vm.csv_results[key]['payout_agent_id'];
                    delete vm.csv_results[key]['receive_currency'];
                    delete vm.csv_results[key]['date_created'];
                  });
                  vm.csvFilename = msGen.getFileName(vm.resourceName, vm.query.page, vm.logPagination.total_pages, vm.model);
                }else{
                  if(success.response){
                    vm.results = success.response.data;
                  }
                }
                if(vm.results) {
                  vm.tables.header = PRICING_CONSTANTS.datatable_heading;
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
              },
              function (response) {
                if (response && response.data && response.data.message) {
                  if (response.data.message.indexOf('HTTP/1.1 400 Invalid remittance delivery method or channel') > -1) {
                    vm.results = [];
                    vm.tables === 'null';
                  }
                }
              }
          );
        }

        function confirmItem(item){
          var queryStr = {
            ids: item.id
          }
          priceService.confirmPriceHistory(queryStr).then(
              function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .textContent('Success! Pricing confirmed!')
                  .position('top center' )
                  );
                currentPricingHistory();
                if(!item.sideNavOpen){
                  HelperFactory.toggleSidenav('details-sidenav');
                }
              },
              function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .theme('warn')
                  .textContent('Unable to confirm pricing')
                  .position('top right' )
                  );
              }
          );
        }

        function confirmAllItems(){
          vm.selected_ids = "";
          angular.forEach(vm.selected, function(item){
            addPricingItem(item.id);
          });
          confirmItem({ id: vm.selected_ids, sideNavOpen: true });
        }

        function addPricingItem(item_id){
          if(vm.selected_ids.length === 0){
            vm.selected_ids += item_id;
          } else {
            vm.selected_ids += "," + item_id;
          }
        }

      }
})();
