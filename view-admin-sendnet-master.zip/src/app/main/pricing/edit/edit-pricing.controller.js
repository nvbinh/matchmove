    (function ()
{
    'use strict';

    angular
        .module('app.pricing.edit')
        .controller('PricingEditController', PricingEditController);

    /** @ngInject */
    function PricingEditController(PricingFields, store, msApi, API_BASE, $mdToast, $scope, $stateParams, Payouts, Channels, Currencies, priceService, sdService, APP_TYPE, Providers, PayoutAgents, DeliveryMethods, Countries, $state, $filter, APP_CURRENCY)
    {

        var vm = this;
        vm.historyId = $stateParams.number;
        vm.fields = PricingFields.data;
        vm.app = APP_TYPE;
        vm.providers = Providers.providers;
        vm.delivery_methods = Providers.delivery_methods;
        vm.payout_agents = Providers.payout_agents;
        vm.countries = Countries.countries;
        vm.payout_agents_params = {};

        msApi.setBaseUrl(API_BASE);
        msApi.register('admins.pricing', ['api/remittance/price/history']);
        msApi.register('admins.updatepricing', ['api/remittance/price/history/{history}']);

        if (vm.historyId) {
            fetchData();
        }

        vm.model = {
          selected_client: null,
          provider: 'moneygram'
        };

        vm.model = angular.merge($stateParams, { currency: APP_CURRENCY.base });
        if ($stateParams && $stateParams.provider && $stateParams.delivery_method && $stateParams.payout_agent) {
            store.set('pricingData', $stateParams);
        }
        vm.model = store.get('pricingData');

        if (vm.model.fixed_fee) {
            vm.model.fixed_fee = $filter('number')(vm.model.fixed_fee, 2);
        }

        if (!vm.model.payout_agent_id || !vm.model.payout_agent) {
            getPayoutAgentId();
        }

        function getPayoutAgentId() {
            vm.payout_agents_params.provider = vm.model.provider.toLowerCase();
            vm.payout_agents_params.delivery_method = vm.model.delivery_method;
            vm.payout_agents_params.country = vm.model.receive_country;
            vm.payout_agents_params.payout_agent = vm.model.payout_agent;

            priceService.getPayoutAgents(vm.payout_agents_params).then(function(success){
              if (success && success.hasOwnProperty('response') && success.response.length > 0) {
                if (success.response.length === 1) {
                    vm.model.payout_agent_id = success.response[0]['id'];
                } else {
                    var resTextArray = [];
                    angular.forEach(success.response, function(value, key){
                      if (success.response[key]['name'] === vm.payout_agents_params.payout_agent) {
                        vm.model.payout_agent_id = success.response[key]['id'];
                      }
                    });
                }
              }else if(success instanceof Array){
                vm.model.payout_agent_id = '';
              }
            }, function(err) {
              vm.model.payout_agent_id = '';
            });
        }

        vm.onSubmit = onSubmit;
        function onSubmit() {
          insertPricing();
        }

        function insertPricing() {
            if($scope.selected_provider){
                vm.model.provider_id = $scope.selected_provider
            }
            $mdToast.show(
              $mdToast.simple()
                .textContent('Creating the pricing...')
                .position('top center' )
            );
            priceService.addPrice(vm.model).then(
                function(success) {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Successfully created a new record')
                        .toastClass('toast-success')
                        .position('top center' )
                    );
                    $state.go('app.pricing_get');
                    vm.form.$setPristine();
                    vm.form.$setUntouched();
                },
                function(error) {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Pricing creation failed!')
                        .toastClass('toast-warning')
                        .position('top center' )
                    );
                }
            );
        }

        function fetchData() {
            msApi.register('pricing.detail', ['api/remittance/price']);
            msApi.request('pricing.detail@get', {
                    history: vm.historyId
                },
                function (success) {
                    if (success && success.data && success.data.response) {
                        vm.model = success.data.response[0];
                    }
                },
                function(error) {
                    vm.updateerror = error;
                }
            );
        }
    }
})();
