(function ()
{
    'use strict';

    angular
        .module('app.pricing.edit', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.pricing_edit', {
            url      : '/pricing/edit/:number',
            params: {
              provider: null,
              delivery_method: null,
              delivery_method_description: null,
              payout_agent: null,
              payout_agent_id: null,
              receive_country: null,
              receiving_currency: null,
              fixed_fee: null,
              fx_percentage: null,
              status: null
            },
            views    : {
                'content@app': {
                    templateUrl: 'app/main/pricing/edit/edit-pricing.html',
                    controller : 'PricingEditController as vm'
                }
            },
            resolve  : {
                PricingFields   : function(msApi){
                    return msApi.resolve('pricing.edit_price@get');
                },
                Payouts: function(sdService){
//                    var payouts = [];
//                    sdService.getPayouts().then(function(success){
//                        angular.forEach(success, function(payout){
//                            payouts.push(payout);
//                        });
//                    });
//                    return payouts;
                },
                Channels: function(sdService){
//                    var channels = [];
//                    sdService.getChannels({channel_id: 'all'}).then(function(success){
//                        angular.forEach(success.response, function(channel){
//                            channels.push(channel);
//                        });
//                    });
//                    return channels;
                },
                Currencies: function(sdService){
//                    var currencies = [];
//                    sdService.getCurrencies().then(function(success){
//                        angular.forEach(success, function(type){
//                            currencies.push(type);
//                        });
//                    });
//                    return currencies;
                },
                Providers : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
                PayoutAgents : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
                DeliveryMethods: function (msApi){
                    return msApi.resolve('builder.pricing_filter@get');
                },
                Countries: function (msApi){
                    return msApi.resolve('pricing.fields@get');
                }
            },
            bodyClass: 'pricing update'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/pricing/edit');

        msApiProvider.register('pricing.edit_price', ['app/main/pricing/builder/add-price.json']);
        msApiProvider.register('pricing.fields', ['app/main/pricing/builder/fields.json']);
    }

})();
