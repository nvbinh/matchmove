(function ()
{
    'use strict';

    angular
        .module('app.pricing.detail', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.pricing_detail', {
            url      : '/pricing/:number',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/pricing/detail/pricing.detail.html',
                    controller : 'PricingDetailController as vm'
                }
            },
            bodyClass: ' pricing detail'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/pricing/detail');

    }

})();
