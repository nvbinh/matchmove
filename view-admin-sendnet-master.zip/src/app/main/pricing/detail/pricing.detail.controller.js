(function ()
{
    'use strict';

    angular
        .module('app.pricing.detail')
        .controller('PricingDetailController', PricingDetailController);

    /** @ngInject */
    function PricingDetailController($stateParams, msApi, API_BASE)
    {

        var vm = this;

        vm.pricingDetail = {};
        vm.historyId = $stateParams.number;
        vm.updatesuccess = false;
        vm.updateerror = null;
        vm.updatesuccessmsg = null;
        msApi.setBaseUrl(API_BASE);

        vm.updateStatus = updateStatus;

        fetchData();

        function updateStatus() {
            if (vm.pricingDetail && vm.pricingDetail.id) {
                var data = {};
                // data.id = vm.pricingDetail.id;

                msApi.register('pricing.detailupdate', ['api/remittance/price/history/' + vm.pricingDetail.id + '/confirm']);

                msApi.requestApi('pricing.detailupdate@put', data,
                    function (success) {
                        if (success && success.message) {
                            vm.updatesuccessmsg = success.message;
                            vm.updatesuccess = true;
                        }
                    },
                    function(error) {
                        vm.updateerror = error;
                    }
                );
            }
        }

        function fetchData() {
            msApi.register('pricing.detail', ['api/remittance/price/history']);
            msApi.request('pricing.detail@get', {
                    history: vm.historyId
                },
                function (success) {
                    if (success && success.data && success.data.response) {
                        vm.pricingDetail = success.data.response[0];
                    }
                },
                function(error) {
                    vm.updateerror = error;
                }
            );
        }
    }

})();
