(function ()
{
    'use strict';

    angular
        .module('app.logs.prefunding', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.logs_prefunding', {
            url      : '/logs/prefunding',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/logs/prefunding/prefunding.html',
                    controller : 'LogsPrefundingController as vm'
                }
            },
            resolve  : {
            },
            bodyClass: 'logs prefunding'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/logs/prefunding');

        // Api
        msApiProvider.setBaseUrl('');
        msApiProvider.register('builder.prefund_history', ['app/data/builder/prefund-history.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('logs.prefunding', {
            title : 'Prefunding',
            state : 'app.logs_prefunding',
            icon  : 'icon-factory',
            weight: 1
        });
    }

})();
