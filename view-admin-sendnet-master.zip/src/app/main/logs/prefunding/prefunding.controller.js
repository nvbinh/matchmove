(function() {
    'use strict';

    angular
        .module('app.logs.prefunding')
        .controller('LogsPrefundingController', LogsPrefundingController);

    /** @ngInject */
    function LogsPrefundingController(msApi, store, API_BASE, $mdToast, $scope, TRANSACTION_CONSTANTS, sdService, REPORTS_ITEMS_PER_PAGE) {
        var vm = this;

        // Data
        vm.selected = [];
        vm.consumers = {};
        vm.providers = {};
        vm.clients = {};
        vm.calendarEvent = {};
        vm.results = null;
        // vm.tokens = Tokens.data;
        vm.query = {
            order: 'name',
            limit: 5,
            page: 1
        };

        vm.model = {};

        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;

        vm.originalFields = angular.copy(vm.fields);

        vm.onSubmit = onSubmit;
        vm.showSearchBox = showSearchBox;

        var apiUrl = 'api/remittance/rails';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        msApi.register('query.consumer', ['api/consumer']);
        vm.tables = {
            header: []
        }
        currentPrefundHistory();
        getConsumerInfo();
        getRailInfo();
        getClientInfo();

        $scope.selected_provider = null;

        // function definition
        function onSubmit() {
            var queryStr = vm.model,
                apiUrl = 'api/remittance/prefunds/history';
            queryStr.from_date = vm.calendarEvent.start;
            queryStr.to_date = vm.calendarEvent.end;
            queryStr.consumer_name = vm.selected_consumer;
            queryStr.provider_code = vm.selected_provider;
            if ($scope.selected_provider) {
                queryStr.provider_id = $scope.selected_provider;
            }
            $mdToast.show(
                $mdToast.simple()
                .textContent('Searching records...')
                .position('top center')
            );
            requestApi(queryStr);
        }

        function currentPrefundHistory() {
            var from_date = new Date(),
                to_date = new Date(),
                queryStr = {};

            from_date.setDate(from_date.getDate() - 10);

            queryStr.from_date = toTimeParams(from_date);
            queryStr.to_date = toTimeParams(to_date);
            requestApi(queryStr);
        }

        function getConsumerInfo() {
            sdService.getConsumer().then(
                function(success) {
                    if (typeof success == 'object') {
                        angular.forEach(success.response.data, function(consumer) {
                            vm.consumers[consumer.id] = consumer;
                        });
                    }
                },
                function(response) {}
            );
        }

        function getRailInfo() {
            sdService.getRails().then(
                function(success) {
                    if (typeof success == 'object') {
                        angular.forEach(success.response, function(rail) {
                            vm.providers[rail.id] = rail;
                        });
                    }
                },
                function(response) {}
            );
        }

        function getClientInfo() {
            sdService.getClients().then(
                function(success) {
                    if (typeof success == 'object') {
                        angular.forEach(success, function(client) {
                            vm.clients[client.id] = client;
                        });
                    }
                },
                function(response) {}
            );
        }

        function toTimeParams(d) {
            var curr_day = d.getDate(); //change day here
            var curr_month = d.getMonth() + 1;
            var curr_year = d.getFullYear();
            return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr) {
            msApi.request('query.builder@get', queryStr,
                function(response) {
                    vm.results = response.data.response;

                    if (vm.results && vm.results.length > 0) {
                        // vm.tables.header = Object.keys(vm.results[0]);
                        vm.tables.header = TRANSACTION_CONSTANTS.prefunding_datatable_heading;
                    } else {
                        vm.results = null;
                        vm.tables === 'null';
                    }
                },
                function(response) {}
            );
        }


        /**
         * Show Search Box
         *
         * @param
         */
        function showSearchBox() {
            vm.toggleSearch = !vm.toggleSearch;
        }

        // Methods

        //////////
    }

})();
