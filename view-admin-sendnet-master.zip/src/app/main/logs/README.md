# ng-module-logs #
git submodule add https://bitbucket.org:matchmove/ng-module-logs.git src/app/main/logs
