(function() {
    'use strict';

    angular
        .module('app.logs.transaction')
        .controller('LogsTransactionController', LogsTransactionController);

    /** @ngInject */
    function LogsTransactionController(msApi, store, API_BASE, $mdToast, $scope, TRANSACTION_CONSTANTS, sdService, DEFAULT_CLIENT, HelperFactory, APP_TYPE, msGen, $mdDialog, PROVIDERS, PROVIDER_CODES, TRANSACTION_STATUSES, COUNTRIES, $filter, REPORTS_ITEMS_PER_PAGE) {
        var vm = this;

        // Data
        vm.showDetails = false;
        vm.selected = [];
        vm.sendDetail = null;
        vm.receiveDetail = null;
        vm.consumers = {};
        vm.providers = {};
        vm.clients = {};
        vm.calendarEvent = {};
        vm.results = false;
        vm.resourceName = 'Transaction History';
        vm.app = APP_TYPE;
        vm.transaction_status = TRANSACTION_STATUSES;
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.csv_table_header = TRANSACTION_CONSTANTS.csv_transaction_datatable_heading;
        // vm.tokens = Tokens.data;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };

        vm.model = {
          selected_client: null
        };

        vm.countries_hash = {
          "N/A": "N/A"
        };
        vm.countries = COUNTRIES;
        angular.forEach(vm.countries, function(country){
          if(country.code !== ""){
            vm.countries_hash[country.code] = country.name
          }
        });

        vm.originalFields = angular.copy(vm.fields);

        vm.onSubmit = onSubmit;
        vm.showSearchBox = showSearchBox;
        vm.toggleDetails = toggleDetails;
        vm.changeClient = changeClient;
        vm.toggleFilter = toggleFilter;
        vm.closeFilter = closeFilter;
        vm.changeProvider = changeProvider;
        vm.resetForm = resetForm;

        var apiUrl = 'api/remittance/transactions';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        msApi.register('query.consumer', ['/api/consumer']);
        vm.tables = {
            header: []
        }
        currentTransactions();

        $scope.selected_provider = null;
        vm.providers = PROVIDER_CODES;
        vm.delivery_methods = PROVIDERS.Homesend;
        vm.delivery_methods_description = {
          "N/A": "N/A"
        };

        angular.forEach(vm.providers, function(provider){
          angular.forEach(PROVIDERS[provider.code], function(value, key){
            vm.delivery_methods_description[key] = value
          });
        });

        function changeProvider(){
          vm.model = {
            provider: vm.model.provider
          };
          vm.delivery_methods = PROVIDERS[vm.model.provider]
        }

        function changeClient(){
          currentTransactions();
        }

        function resetForm(form){
          vm.model = {};
          form.$pristine = false;
        }

        function closeFilter(){
          $mdDialog.hide();
        }

        function toggleDetails(item, details)
        {
          vm.transactionDetail = item;
          vm.showDetails = true;
          if(details === 'show'){
            HelperFactory.toggleSidenav('details-sidenav');
          }
        }

        function formatDate(date_from, date_to){
          return [moment(date_from).format('YYYYMMDD'), moment(date_to).format('YYYYMMDD')]
        }

        // function definition
        function onSubmit(params) {
            var queryStr = vm.model,
                apiUrl = 'api/remittance/transactions';

            if(queryStr.date_added_from !== undefined && queryStr.date_added_to !== undefined){
              queryStr.date_added = formatDate(queryStr.date_added_from, queryStr.date_added_to).toString();
            }
            if(queryStr.date_expired_from !== undefined && queryStr.date_expired_to !== undefined){
              queryStr.date_expiry = formatDate(queryStr.date_expired_from, queryStr.date_expired_to).toString();
            }
            queryStr.records_per_page = vm.query.limit;
            if(params.offset === 0){
              queryStr.offset = params.offset;
            }else{
              queryStr.offset = (vm.query.page - 1) * queryStr.records_per_page;
            }
            requestApi(queryStr);
            closeFilter();
        }

        function toggleFilter(ev){
          //closeFilter();
          $mdDialog.show({
            scope: $scope,
            preserveScope: true,
            resolve  : {
            },
            templateUrl : 'app/main/logs/transaction/filter-dialog/filter-dialog.html',
            clickOutsideToClose: true,
          })
        }

        function currentTransactions() {
            var from_date = new Date(),
                to_date = new Date(),
                queryStr = {};

            from_date.setDate(from_date.getDate() - 10);
            queryStr.sort = '-id';
            queryStr.client = DEFAULT_CLIENT;

            queryStr.from_date = toTimeParams(from_date);
            queryStr.to_date = toTimeParams(to_date);
            queryStr.records_per_page = vm.query.limit;
            queryStr.offset = (vm.query.page - 1) * queryStr.records_per_page;
            requestApi(queryStr);
        }

        function toTimeParams(d) {
            var curr_day = d.getDate(); //change day here
            var curr_month = d.getMonth() + 1;
            var curr_year = d.getFullYear();
            return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr) {
            var apiUrl = 'api/remittance/transactions';

            msApi.register('transaction', [apiUrl]);
            msApi.request('transaction@get', queryStr,
                function(response) {
                    vm.fields = [];

                    //trim field records to 33 so that table wont overload if field is 34 error occurs
                    if (response.data.response && response.data.response.length > 0) {
                        vm.fields = Object.keys(response.data.response[0]).slice(0, 33);
                        var results = [];
                        angular.forEach(response.data.response, function(transaction) {
                            var _transaction = {};
                            angular.forEach(vm.fields, function(field) {
                                _transaction[field] = transaction[field]
                            });
                            results.push(_transaction);
                            vm.results = results;
                        });
                    } else {
                        vm.results = null;
                        vm.tables === 'null';
                    }

                    if(response.data instanceof Array){
                      vm.results = response.data;
                    }
                    if (vm.results) {
                        // vm.tables.header = Object.keys(vm.results[0]);
                        vm.tables.header = TRANSACTION_CONSTANTS.transaction_datatable_heading;
                        vm.logPagination = response.data.pagination;
                        vm.totalRecord = vm.logPagination.total_records;
                    } else {
                        vm.results = null;
                        vm.tables === 'null';
                    }
                    vm.csv_results = angular.copy(vm.results);
                    vm.logPagination = response.data.pagination;
                    vm.csvFilename = msGen.getFileName(vm.resourceName, vm.query.page, vm.logPagination.total_pages, vm.model);
                    angular.forEach(vm.csv_results, function(value, key){
                      vm.csv_results[key].delivery_method = vm.delivery_methods_description[value.delivery_method];
                      vm.csv_results[key].receive_country = vm.countries_hash[value.receive_country];
                      vm.csv_results[key].customer_fx_percent = $filter('number')(value.customer_fx_percent * 100, 6);
                      vm.csv_results[key].routing_param = (value.routing_param == 'null') ? 'N/A' : value.routing_param;
                      vm.csv_results[key].provider_exchange_rate = $filter('number')(value.provider_exchange_rate, 2);
                    });
                },
                function(response) {
                  if(response.status === 400){
                    vm.results = [];
                  }else{
                    vm.results = [];
                  }
                }
            );
        }


        /**
         * Show Search Box
         *
         * @param
         */
        function showSearchBox() {
            vm.toggleSearch = !vm.toggleSearch;
        }

        // Methods

        //////////
    }

})();
