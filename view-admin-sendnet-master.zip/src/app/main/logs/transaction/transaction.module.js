(function ()
{
    'use strict';

    angular
        .module('app.logs.transaction', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.logs_transactions', {
            url      : '/logs/transactions',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/logs/transaction/transaction.html',
                    controller : 'LogsTransactionController as vm'
                }
            },
            resolve  : {
            },
            bodyClass: 'logs transaction'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/logs/transaction');

        // Api
        msApiProvider.setBaseUrl('');
        msApiProvider.register('builder.prefund_history', ['app/data/builder/prefund-history.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('logs.transaction', {
            title : 'Transaction History',
            state : 'app.logs_transactions',
            icon  : 'icon-factory',
            weight: 1
        });
    }

})();
