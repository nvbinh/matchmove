(function ()
{
    'use strict';

    angular
        .module('app.logs', [
            'app.logs.transaction'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('logs', {
            title : 'Transaction Logs',
            group : true,
            weight: 5
        });
    }
})();
