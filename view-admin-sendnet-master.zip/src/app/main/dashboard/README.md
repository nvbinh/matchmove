# ng-modules-dashboard

This is the dashboard module for VCard AdminNet only.