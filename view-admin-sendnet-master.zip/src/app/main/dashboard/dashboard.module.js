(function ()
{
    'use strict';

    angular
        .module('app.dashboard', [
            'app.dashboard.home',
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('dashboard', {
            title : 'DASHBOARD',
            group : true,
            weight: 1
        });
    }
})();
