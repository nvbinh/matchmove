(function ()
{
    'use strict';

    angular
        .module('app.dashboard.home')
        .controller('HomeController', HomeController);

    /** @ngInject */
    function HomeController(store, $rootScope, API_BASE, msApi)
    {

        var vm = this;
        if(store.get('token_data') === null){
          $rootScope.$broadcast('unauthorized');
        };

        vm.balance_homesend = 0;
        vm.balance_moneygram = 0;
        vm.balance_transferto = 0;

        var apiUrl = 'api/remittance/prefunding/all';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);

        currentPrefundBalance();

        function currentPrefundBalance(){
          requestApi({});
        }

        function requestApi(queryStr){
          queryStr.access_token = store.get('token_data').access_token;
          msApi.request('query.builder@get', queryStr,
              function (response) {
                vm.results = response.data;
                if(vm.results && vm.results.length > 0) {
                  angular.forEach(vm.results, function(rs, key){
                      var _client = vm.results[key].client;
                      if (_client.indexOf('Homesend') > 0) {
                          vm.balance_homesend = vm.results[key].balance;
                      } else if (_client.indexOf('Moneygram') > 0) {
                          vm.balance_moneygram = vm.results[key].balance;
                      } else if (_client.indexOf('Transferto') > 0) {
                          vm.balance_transferto = vm.results[key].balance;
                      }
                  });
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
              },
              function (response) {}
          );
        }

        // function requestApi(queryStr){
        //   vm.results = PrefundingBalance.data;
        //   if(vm.results && vm.results.length > 0) {
        //       angular.forEach(vm.results, function(rs, key){
        //           var _client = vm.results[key].client;
        //           if (_client.indexOf('Homesend') > 0) {
        //               vm.balance_homesend = vm.results[key].balance;
        //           } else if (_client.indexOf('Moneygram') > 0) {
        //               vm.balance_moneygram = vm.results[key].balance;
        //           } else if (_client.indexOf('Transferto') > 0) {
        //               vm.balance_transferto = vm.results[key].balance;
        //           }
        //       });
        //   }
        //   else {
        //     vm.results = null;
        //     vm.tables === 'null';
        //   }
        // }
    }

})();
