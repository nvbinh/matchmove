(function() {
    'use strict';

    angular
        .module('app.dashboard.home', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider) {
        $stateProvider.state('app.dashboard_home', {
            url: '/dashboard/home',
            views: {
                'content@app': {
                    templateUrl: 'app/main/dashboard/home/home.html',
                    controller: 'HomeController as vm'
                }
            },
            resolve: {
                
            },
            bodyClass: 'profile'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/dashboard/home');

        // Navigation
        msNavigationServiceProvider.saveItem('dashboard.home', {
            title: 'Home',
            icon: 'icon-home',
            state: 'app.dashboard_home',
            weight: 6
        });
    }

})();
