# ng-modules-fixed-fee

This is the Fixed Fee Management module for SendNet.
