(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee', [
            'app.fixed-fee.add',
            'app.fixed-fee.edit',
            'app.fixed-fee.approve',
            'app.fixed-fee.history'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('fixed-fee', {
            title : 'Fixed Fee',
            icon  : 'icon-cash',
            weight: 1
        });
    }
})();
