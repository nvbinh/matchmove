(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.edit')
        .controller('FixedFeeEditController', FixedFeeEditController);

    /** @ngInject */
    function FixedFeeEditController(FixedFeeFields, store, msApi, API_BASE, $mdToast, $scope, $stateParams, Channels, Countries, Currencies, Payouts, fixedFeeService)
    {

        var vm = this;
        vm.fields = [];
        vm.fields.push(
            {
                key: "country_id",
                type: "select",
                templateOptions: {
                label: "Country Id",
                placeholder: "Please enter country id",
                options: Countries,
                required :"true"
                }
            },{
                key: "channel_id",
                type: "select",
                templateOptions: {
                    label: "Channel Id",
                    placeholder: "Please enter channel",
                    options: Channels,
                    required:"true"
                }
            },{
                key: "payout_destination_id",
                type: "payout-select",
                templateOptions: {
                    label: "Payout Destination Id",
                    placeholder: "Please enter Payout destination",
                    options: Payouts,
                    required:"true"
                }
            });
        vm.fields = vm.fields.concat(FixedFeeFields.data);
        vm.onSubmit = onSubmit;

        msApi.setBaseUrl(API_BASE);
        msApi.register('admins.getfixedfee', ['api/remittance/fixed-fee/history/' + $stateParams.id]);

        function getFixedFee(){
          fixedFeeService.getFixedFeeHistoryById($stateParams).then(function(success){
            vm.model = success;
            }, function(error){
          });
        }

        getFixedFee();

        function onSubmit() {
          if($scope.selected_provider){
            vm.model.provider_id = $scope.selected_provider
          }else{
            $mdToast.show(
                $mdToast.simple()
                .textContent('Please Select Provider')
                .position('top center' )
                );
            return;
          }
          $mdToast.show(
              $mdToast.simple()
              .textContent('Editing Fixed Fee...')
              .position('top center' )
              );
          vm.model.selected_client = $stateParams.selected_client;
          fixedFeeService.editFixedFeeHistory(vm.model).then(
              function(success) {
                $mdToast.show(
                  $mdToast.simple()
                  .textContent('Success! Fixed fee edited!')
                  .position('top center' )
                  );
                  vm.model = {};
                  vm.form.$setPristine();
                  vm.form.$setUntouched();
                getFixedFee();
              },
              function(error) {
                $mdToast.show(
                  $mdToast.simple()
                  .textContent('Fixed Fee edit failed!')
                  .position('top center' )
                  );
              });
        }
    }
})();
