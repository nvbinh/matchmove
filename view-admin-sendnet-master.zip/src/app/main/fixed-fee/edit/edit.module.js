(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.edit', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.fixed-fee_edit', {
            url      : '/fixedfee/:id/edit',
            params   : { selected_client: null },
            views    : {
                'content@app': {
                    templateUrl: 'app/main/fixed-fee/edit/edit.html',
                    controller : 'FixedFeeEditController as vm'
                }
            },
            resolve  : {
                FixedFeeFields   : function(msApi){
                    return msApi.resolve('remittance.edit_fixedfee@get');
                },
                Countries: function(sdService){
                    var countries = [];
                    sdService.getCountries().then(function(success){
                        angular.forEach(success, function(country){
                            countries.push(country);
                        });
                    });
                    return countries;
                },
                Payouts: function(sdService){
                    var payouts = [];
                    sdService.getPayouts().then(function(success){
                        angular.forEach(success, function(payout){
                            payouts.push(payout);
                        });
                    });
                    return payouts;
                },
                Channels: function(sdService){
                    var channels = [];
                    sdService.getChannels({channel_id: 'all'}).then(function(success){
                        angular.forEach(success.response, function(channel){
                            channels.push(channel);
                        });
                    });
                    return channels;
                },
                Currencies: function(sdService){
                    var currencies = [];
                    sdService.getCurrencies().then(function(success){
                        angular.forEach(success, function(type){
                            currencies.push(type);
                        });
                    });
                    return currencies;
                }
            },
            bodyClass: 'remittance fixedfee edit'
        });

        msApiProvider.register('remittance.edit_fixedfee', ['app/main/fixed-fee/builder/add-fixed-fee.json']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/fixed-fee/edit');
    }

})();
