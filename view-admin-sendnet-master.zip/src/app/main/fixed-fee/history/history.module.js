(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.history', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.fixed-fee_history', {
            url      : '/fixedfee/history',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/fixed-fee/history/history.html',
                    controller : 'FixedFeeHistoryController as vm'
                }
            },
            resolve  : {
                FixedFeeHistory : function (msApi)
                {
                    return msApi.resolve('builder.fixedfee_history@get');
                }
            },
            bodyClass: 'remittance fixedfee history'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/fixed-fee/history');

        // Api
        msApiProvider.register('builder.fixedfee_history', ['app/main/fixed-fee/builder/fixed-fee-history.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('fixed-fee.history', {
            title : 'History',
            state : 'app.fixed-fee_history',
            weight: 1
        });
    }

})();
