(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.add')
        .controller('FixedFeeAddController', FixedFeeAddController);

    /** @ngInject */
    function FixedFeeAddController(FixedFeeFields, store, msApi, API_BASE, $mdToast, $scope, Currencies, Payouts, Channels, Countries, APP_TYPE, sdService, fixedFeeService)
    {

        var vm = this;
        vm.fields = [];
        vm.model = { selected_client: null };
        vm.app = APP_TYPE;
        vm.fields.push(
            {
                key: "country_id",
                type: "select",
                templateOptions: {
                label: "Country Id",
                placeholder: "Please enter country id",
                options: Countries,
                required :"true"
                }
            },{
                key: "channel_id",
                type: "select",
                templateOptions: {
                    label: "Channel Id",
                    placeholder: "Please enter channel",
                    options: Channels,
                    required:"true"
                }
            },{
                key: "payout_destination_id",
                type: "payout-select",
                templateOptions: {
                    label: "Payout Destination Id",
                    placeholder: "Please enter Payout destination",
                    options: Payouts,
                    required:"true"
                }
            });

        vm.fields = vm.fields.concat(FixedFeeFields.data);
        msApi.setBaseUrl(API_BASE);
        msApi.register('admins.fixedfee', ['api/remittance/fixed-fee/history']);

        sdService.getClients(vm.model).then(function(success){
          //master default for tier1
          vm.clients = [{ name: "master" }];
          vm.clients = vm.clients.concat(success);
        });

        vm.onSubmit = onSubmit;
        function onSubmit() {
          if($scope.selected_provider){
            vm.model.provider_id = $scope.selected_provider
          }
            $mdToast.show(
              $mdToast.simple()
                .textContent('Creating the fixed fee...')
                .position('top center' )
            );
            fixedFeeService.addFixedFeeHistory(vm.model).then(
                function(success) {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Success! Fixed fee created!')
                        .position('top center' )
                    );
                    vm.model = {};
                    vm.form.$setPristine();
                    vm.form.$setUntouched();
                },
                function(error) {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Fixed fee creation failed!')
                        .position('top center' )
                    );
                    // console.log(error);
                }
            );
        }
    }
})();
