(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.add', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.fixed-fee_add', {
            url      : '/fixedfee/add',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/fixed-fee/add/add.html',
                    controller : 'FixedFeeAddController as vm'
                }
            },
            resolve  : {
                FixedFeeFields   : function(msApi){
                    return msApi.resolve('remittance.add_fixedfee@get');
                },
                Countries: function(sdService){
                    var countries = [];
                    sdService.getCountries().then(function(success){
                        angular.forEach(success, function(country){
                            countries.push(country);
                        });
                    });
                    return countries;
                },
                Payouts: function(sdService){
                    var payouts = [];
                    sdService.getPayouts().then(function(success){
                        angular.forEach(success, function(payout){
                            payouts.push(payout);
                        });
                    });
                    return payouts;
                },
                Channels: function(sdService){
                    var channels = [];
                    sdService.getChannels({channel_id: 'all'}).then(function(success){
                        angular.forEach(success.response, function(channel){
                            channels.push(channel);
                        });
                    });
                    return channels;
                },
                Currencies: function(sdService){
                    var currencies = [];
                    sdService.getCurrencies().then(function(success){
                        angular.forEach(success, function(type){
                            currencies.push(type);
                        });
                    });
                    return currencies;
                }
            },
            bodyClass: 'remittance fixedfee add'
        });

        msApiProvider.register('remittance.add_fixedfee', ['app/main/fixed-fee/builder/add-fixed-fee.json']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/fixed-fee/add');

        msNavigationServiceProvider.saveItem('fixed-fee.add', {
          title : 'Add',
          state : 'app.fixed-fee_add',
          weight: 1
        });
    }

})();
