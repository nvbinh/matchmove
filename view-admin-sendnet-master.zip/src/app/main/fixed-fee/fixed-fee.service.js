(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('fixedFeeService', fixedfeeService);

    /** @ngInject */
    function fixedfeeService($q, $log, api, store, $timeout, msApi, $mdToast, API_BASE, HTTP_HOST, APP_TYPE)
    {
        var service = {
          addFixedFeeHistory: addFixedFeeHistory,
          getFixedFeeHistory: getFixedFeeHistory,
          getFixedFeeHistoryById: getFixedFeeHistoryById,
          editFixedFeeHistory: editFixedFeeHistory,
          confirmFixedFeeHistory: confirmFixedFeeHistory,
          rejectFixedFeeHistory: rejectFixedFeeHistory
        };

        msApi.setBaseUrl(API_BASE);

        return service;

        /**
         * addFixedFee api
         */
        function addFixedFeeHistory(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/fixed-fee/history';

            if(APP_TYPE === 'master' && params.selected_client !== null && params.selected_client.name !== 'master'){
              apiUrl = '/api/' + params.selected_client.code + '/remittance/fixed-fee/history';
            }

            msApi.register('add.fixedfee', [apiUrl]);
            msApi.requestApi('add.fixedfee@post', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }


        /**
         * getFixedFee api
         */
        function getFixedFeeHistory(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/fixed-fee/history';

            if(APP_TYPE === 'master' && params.selected_client !== null && params.selected_client.name !== 'master'){
              apiUrl = 'api/' + params.selected_client.code + '/remittance/fixed-fee/history';
            }
            console.log(apiUrl);

            msApi.register('query.history', [apiUrl]);
            msApi.requestApi('query.history@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * confirmFixedFee api
         */
        function confirmFixedFeeHistory(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/fixed-fee/history/' + params.id + '/confirm';

            if(APP_TYPE === 'master' && params.selected_client !== null && params.selected_client.name !== 'master'){
              apiUrl = 'api/' + params.selected_client.code + '/remittance/fixed-fee/history/' + params.id + '/confirm';
            }

            msApi.register('confirm.history', [apiUrl]);
            msApi.requestApi('confirm.history@put', params,
                function (success) {
                  console.log(success, 'servicceee');
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * getFixedFeeHistoryById api
         */
        function getFixedFeeHistoryById(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/fixed-fee/history/' + params.id;

            if(APP_TYPE === 'master' && params.selected_client !== null && params.selected_client.name !== 'master'){
              apiUrl = 'api/' + params.selected_client.code + '/remittance/fixed-fee/history/' + params.id;
            }

            msApi.register('retrieve.fixedfee', [apiUrl]);
            msApi.requestApi('retrieve.fixedfee@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * editFixedFeeHistory api
         */
        function editFixedFeeHistory(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/fixed-fee/history/' + params.id;

            if(APP_TYPE === 'master' && params.selected_client !== null && params.selected_client.name !== 'master'){
              apiUrl = 'api/' + params.selected_client.code + '/remittance/fixed-fee/history/' + params.id;
            }

            msApi.register('retrieve.fixedfee', [apiUrl]);
            msApi.requestApi('retrieve.fixedfee@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }


        /**
         * rejectFixedFeeHistory api
         */
        function rejectFixedFeeHistory(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/fixed-fee/history/' + params.id + '/reject';;

            if(APP_TYPE === 'master' && params.selected_client !== null && params.selected_client.name !== 'master'){
              apiUrl = 'api/' + params.selected_client.code + '/remittance/fixed-fee/history/' + params.id + '/reject';
            }

            msApi.register('reject.fixedfee', [apiUrl]);
            msApi.requestApi('reject.fixedfee@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

    }

})();
