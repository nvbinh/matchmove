(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.approve')
        .controller('FixedFeeApproveController', FixedFeeApproveController);

    /** @ngInject */
    function FixedFeeApproveController(msApi, FixedFeeHistory, store, API_BASE, $mdToast, $scope, FIXEDFEE_CONSTANTS, HelperFactory, fixedFeeService, sdService, APP_TYPE)
    {
        var vm = this;

        // Data
        vm.showDetails = false;
        vm.statuses = ['pending', 'confirmed'];
        vm.selected = [];
        vm.results = null;
        vm.app = APP_TYPE;
        // vm.tokens = Tokens.data;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };

        vm.model = {
          selected_client: null
        };

        sdService.getClients(vm.model).then(function(success){
          //master default for tier1
          vm.clients = [{ name: "master" }];
          vm.clients = vm.clients.concat(success);
        });

        vm.fields = FixedFeeHistory.data;

        vm.originalFields = angular.copy(vm.fields);

        vm.onSubmit = onSubmit;
        vm.confirmItem = confirmItem;
        vm.rejectFixedFee = rejectFixedFee;
        vm.toggleDetails = toggleDetails;
        vm.changeClient = changeClient;

        var apiUrl = 'api/remittance/fixed-fee/history';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        vm.tables = {
          header: []
        }
        currentPrefundHistory();

        function changeClient(){
          currentPrefundHistory();
        }

        function toggleDetails(item)
        {
            vm.selected = item;
            vm.showDetails = true;
            HelperFactory.toggleSidenav('details-sidenav');
        }

        // function definition
        function onSubmit() {
          var queryStr = vm.model, apiUrl = 'api/remittance/fixed-fee/history';
          if (vm.calendarEvent) {
            queryStr.start_date = vm.calendarEvent.start;
            queryStr.end_date = vm.calendarEvent.end;
          }
          if(vm.selected_status){
            queryStr.status = vm.selected_status;
          }
          if($scope.selected_provider){
            queryStr.provider_id = $scope.selected_provider;
          }
          queryStr.page = vm.query.page;
          queryStr.records_per_page = vm.query.limit;
          queryStr.sort_type = 'desc';
          vm.results = null;
          requestApi(queryStr);
        }

        function currentPrefundHistory(){
          var start_date = new Date(),
            end_date = new Date(),
            queryStr = {};

          start_date.setDate(start_date.getDate()-10);

          queryStr.start_date = toTimeParams(start_date);
          queryStr.end_date = toTimeParams(end_date);
          queryStr.status = 'pending';
          requestApi(queryStr);
        }

        function toTimeParams(d){
          var curr_day= d.getDate();  //change day here
          var curr_month = d.getMonth() + 1;
          var curr_year = d.getFullYear();
          return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr){
          queryStr.selected_client = vm.model.selected_client;
          fixedFeeService.getFixedFeeHistory(queryStr).then(function(success){
                if(success.response instanceof Array){
                  vm.results = success.response;
                }else{
                  vm.results = success.response.data;
                }

                if(vm.results) {
                  // vm.tables.header = Object.keys(vm.results[0]);
                  vm.tables.header = FIXEDFEE_CONSTANTS.fixedfee_history;
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
              });
        }

        function confirmItem(item){
          item.selected_client = vm.model.selected_client;
          fixedFeeService.confirmFixedFeeHistory(item).then(function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .textContent('Success! Fixed Fee confirmed!')
                  .position('top center' )
                  );
              },
              function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .theme('warn')
                  .textContent('Unable to confirm fixed fee')
                  .position('top right' )
                  );
              }
              );
        }

        function rejectFixedFee(item){
          item.selected_client = vm.model.selected_client;
          fixedFeeService.rejectFixedFeeHistory(item).then(function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .textContent('Success! Fixed Fee rejected!')
                  .position('top center' )
                  );
              },
              function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .theme('warn')
                  .textContent('Unable to reject fixed fee')
                  .position('top right' )
                  );
              }
              );
        }

        // Methods

        //////////
        }

})();
