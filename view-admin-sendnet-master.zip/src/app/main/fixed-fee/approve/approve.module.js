(function ()
{
    'use strict';

    angular
        .module('app.fixed-fee.approve', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.fixed-fee_approve', {
            url      : '/fixedfee/approve',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/fixed-fee/approve/approve.html',
                    controller : 'FixedFeeApproveController as vm'
                }
            },
            resolve  : {
                FixedFeeHistory : function (msApi)
                {
                    return msApi.resolve('builder.fixedfee_history@get');
                }
            },
            bodyClass: 'remittance fixedfee approve'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/fixed-fee/approve');

        // Api
        msApiProvider.register('builder.fixedfee_history', ['app/main/fixed-fee/builder/fixed-fee-history.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('fixed-fee.approve', {
            title : 'Approval',
            state : 'app.fixed-fee_approve',
            weight: 1
        });
    }

})();
