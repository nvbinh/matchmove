(function ()
{
    'use strict';

    angular
        .module('app.fx.edit', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.fx_edit', {
            url      : '/fx/:id/edit',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/fx/edit/edit-fx.html',
                    controller : 'FxEditController as vm'
                }
            },
            resolve  : {
                PrefundFields   : function(msApi){
                    return msApi.resolve('edit_fx@get');
                },
                Payouts: function(sdService){
                    var payouts = [];
                    sdService.getPayouts().then(function(success){
                        angular.forEach(success, function(payout){
                            payouts.push(payout);
                        });
                    });
                    return payouts;
                }
            },
            bodyClass: 'fx edit'
        });

        msApiProvider.register('edit_fx', ['app/main/fx/builder/add-fx.json']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/fx/edit');
    }

})();
