(function() {
    'use strict';

    angular
        .module('app.fx.edit')
        .controller('FxEditController', FxEditController);

    /** @ngInject */
    function FxEditController(PrefundFields, store, msApi, API_BASE, $mdToast, $scope, $stateParams, Payouts) {

        var vm = this;
        vm.fields = PrefundFields.data;
        vm.onSubmit = onSubmit;

        vm.fields.push({
            key: "payout_destination_id",
            type: "payout-select",
            templateOptions: {
                label: "Payout Destination Id",
                placeholder: "Please enter Payout destination",
                options: Payouts,
                required: "true"
            }
        });

        msApi.setBaseUrl(API_BASE);
        msApi.register('admins.fx_cost', ['api/remittance/fx/fixed-fee/cost']);

        function onSubmit() {
            if ($scope.selected_provider) {
                vm.model.fx_table = $scope.selected_provider
            } else {
                $mdToast.show(
                    $mdToast.simple()
                    .textContent('Please Select Provider')
                    .position('top center')
                );
                return;
            }
            vm.model.fx_table_id = $stateParams.id;
            $mdToast.show(
                $mdToast.simple()
                .textContent('Editing FX Cost...')
                .position('top center')
            );
            msApi.requestApi('admins.fx_cost@post', vm.model,
                function(success) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Success! FX Cost edited!')
                        .position('top center')
                    );
                    vm.model = {};
                    vm.form.$setPristine();
                    vm.form.$setUntouched();
                },
                function(error) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('FX Cost edit failed!')
                        .position('top center')
                    );
                }
            );
        }
    }
})();
