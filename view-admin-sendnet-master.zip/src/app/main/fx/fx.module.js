(function ()
{
    'use strict';

    angular
        .module('app.fx', [
            // 'app.fx.add',
            'app.fx.history',
            'app.fx.edit'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('fx', {
            title : 'FX Cost',
            icon  : 'icon-currency-usd',
            weight: 1
        });
    }
})();
