(function ()
{
    'use strict';

    angular
        .module('app.fx.history', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.fx_history', {
            url      : '/fx/history',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/fx/history/history.html',
                    controller : 'FxHistoryController as vm'
                }
            },
            resolve  : {
                PrefundHistory : function (msApi)
                {
                    return msApi.resolve('builder.fx_history@get');
                }
            },
            bodyClass: 'fx history'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/fx/history');

        // Api
        msApiProvider.register('builder.fx_history', ['app/main/fx/builder/prefund-history.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('fx.history', {
            title : 'History',
            state : 'app.fx_history',
            weight: 1
        });
    }

})();
