(function ()
{
    'use strict';

    angular
        .module('app.fx.history')
        .controller('FxHistoryController', FxHistoryController);

    /** @ngInject */
    function FxHistoryController(msApi, PrefundHistory, store, API_BASE, $mdToast, $scope, FX_COST_CONSTANTS)
    {
        var vm = this;

        // Data
        vm.selected = [];
        vm.results = null;
        // vm.tokens = Tokens.data;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };  

        vm.model = {
        };

        vm.fields = PrefundHistory.data;

        vm.originalFields = angular.copy(vm.fields);

        vm.onSubmit = onSubmit;
        vm.requestApi = requestApi;

        var apiUrl = 'api/remittance/fx';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        vm.tables = {
          header: []
        }
        currentPrefundHistory();

        // function definition
        function onSubmit() {
          var queryStr = vm.model, apiUrl = 'api/remittance/fx';
          //queryStr.start_date = vm.calendarEvent.start;
          //queryStr.end_date = vm.calendarEvent.end;
          if($scope.selected_provider){
            queryStr.provider_id = $scope.selected_provider;
          }
          queryStr.page = vm.query.page;
          queryStr.records_per_page = vm.query.limit;
          queryStr.sort_type = 'desc';
          vm.results = null;
          requestApi(queryStr);
        }

        function currentPrefundHistory(){
          var start_date = new Date(),
            end_date = new Date(),
            queryStr = {};

          requestApi(queryStr);
        }

        function toTimeParams(d){
          var curr_day= d.getDate();  //change day here
          var curr_month = d.getMonth() + 1;
          var curr_year = d.getFullYear();
          return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr){
          msApi.request('query.builder@get', queryStr,
              function (response) {
                vm.results = response.data.response;
                if(vm.results && vm.results.length > 0) {
                  //vm.tables.header = Object.keys(vm.results[0]);
                  vm.tables.header = FX_COST_CONSTANTS.datatable_heading;
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
              },
              function (response) {
                console.log(response);
              }
          );
        }

        // Methods

            //////////
        }

})();
