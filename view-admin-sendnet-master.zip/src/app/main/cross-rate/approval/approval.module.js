(function ()
{
    'use strict';

    angular
        .module('app.cross-rate.approval', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.cross-rate_approval', {
            url      : '/cross-rate/approval',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cross-rate/approval/approval.html',
                    controller : 'CrossRateApprovalController as vm'
                }
            },
            resolve  : {
                
            },
            bodyClass: 'cross-rate approval'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cross-rate/approval');

        // Navigation
        msNavigationServiceProvider.saveItem('cross-rate.approval', {
            title : 'Pending Approval',
            state : 'app.cross-rate_approval',
            weight: 2
        });
    }

})();
