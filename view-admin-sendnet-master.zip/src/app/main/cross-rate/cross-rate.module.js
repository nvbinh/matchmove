(function ()
{
    'use strict';

    angular
        .module('app.cross-rate', [
            'app.cross-rate.list',
            'app.cross-rate.approval',
            'app.cross-rate.history',
            'app.cross-rate.add',
            'app.cross-rate.edit'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('cross-rate', {
            title : 'Cross Rates',
            icon  : 'icon-chart-histogram',
            weight: 2
        });
    }
})();
