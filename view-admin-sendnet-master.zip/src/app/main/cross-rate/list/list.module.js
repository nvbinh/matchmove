(function ()
{
    'use strict';

    angular
        .module('app.cross-rate.list', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.cross-rate_list', {
            url      : '/cross-rate/list',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cross-rate/list/list.html',
                    controller : 'CrossRateListController as vm'
                }
            },
            resolve  : {
                
            },
            bodyClass: 'cross-rate list'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cross-rate/list');

        // Navigation
        msNavigationServiceProvider.saveItem('cross-rate.list', {
            title : 'List',
            state : 'app.cross-rate_list',
            weight: 1
        });
    }

})();
