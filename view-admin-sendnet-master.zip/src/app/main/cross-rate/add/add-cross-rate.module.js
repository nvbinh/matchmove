(function ()
{
    'use strict';

    angular
        .module('app.cross-rate.add', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.cross-rate_add', {
            url      : '/cross-rate/add',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cross-rate/add/add-cross-rate.html',
                    controller : 'CrossRateAddController as vm'
                }
            },
            resolve  : {
               
            },
            bodyClass: 'cross-rate add'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cross-rate/add');
    }

})();
