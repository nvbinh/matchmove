(function() {
    'use strict';

    angular
        .module('app.cross-rate.add')
        .controller('CrossRateAddController', CrossRateAddController);

    /** @ngInject */
    function CrossRateAddController(store, msApi, API_BASE, $mdToast, $scope, $stateParams, CURRENCIES, crossrateService, $state, $filter) {

        var vm = this;
        vm.fields1 = [];
        vm.onSubmit = onSubmit;
        vm.fromCurrencies = CURRENCIES;
        vm.toCurrencies = CURRENCIES;

        vm.changeFromCurrency = changeFromCurrency;
        vm.changeToCurrency = changeToCurrency;

        msApi.setBaseUrl(API_BASE);

        function changeFromCurrency() {
          if (!vm.model.from) {
            return;
          }
          var fromCurrency = '!' + vm.model.from;
          vm.toCurrencies = CURRENCIES;
          vm.toCurrencies = $filter('filter')(vm.toCurrencies, {code: fromCurrency});
        }

        function changeToCurrency() {
          if (!vm.model.to) {
            return;
          }
          var toCurrency = '!' + vm.model.to;
          vm.fromCurrencies = CURRENCIES;
          vm.fromCurrencies = $filter('filter')(vm.fromCurrencies, {code: toCurrency});
        }

        function onSubmit() {
            if (vm.model.rate <= 0) {
                vm.model.rate = '';
                return false;
            }
            $mdToast.show(
                $mdToast.simple()
                .textContent('Adding Cross Rate...')
                .position('top center')
            );

            crossrateService.addCrossRate(vm.model).then(
                function(success) {
                    vm.model = {};
                    vm.crossRateForm.$setPristine();
                    vm.crossRateForm.$setUntouched();
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Success! Cross Rate added!')
                        .position('top center')
                    );
                    $state.go('app.cross-rate_approval');
                },
                function(error) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Cross Rate add failed!')
                        .position('top center')
                    );
                }
            );
        }
    }
})();
