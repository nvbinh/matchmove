(function ()
{
    'use strict';

    angular
        .module('app.cross-rate.edit', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.cross-rate_edit', {
            url      : '/cross-rate/edit',
            params: {
              cross_rate: null,
              from: null,
              to: null,
              rate: null
            },
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cross-rate/edit/edit-cross-rate.html',
                    controller : 'CrossRateEditController as vm'
                }
            },
            resolve  : {
                
            },
            bodyClass: 'cross-rate edit'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cross-rate/edit');
    }

})();
