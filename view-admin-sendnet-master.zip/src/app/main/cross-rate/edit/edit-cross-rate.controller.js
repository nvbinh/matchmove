(function() {
    'use strict';

    angular
        .module('app.cross-rate.edit')
        .controller('CrossRateEditController', CrossRateEditController);

    /** @ngInject */
    function CrossRateEditController(store, msApi, API_BASE, $mdToast, $scope, $stateParams, CURRENCIES, $timeout, crossrateService, $state) {

        var vm = this;
        vm.fields1 = [];
        vm.onSubmit = onSubmit;
        vm.currencies = CURRENCIES;
        if ($stateParams && $stateParams.cross_rate && $stateParams.from && $stateParams.to && $stateParams.rate) {
            store.set('crossRateData', $stateParams);
        }
        vm.model = store.get('crossRateData');

        $timeout(function(){
            if (vm.model && vm.model.cross_rate && vm.model.rate && $stateParams.from && $stateParams.to) {
                vm.crossRateForm.$invalid = false;
                vm.crossRateForm.$pristine = false;
            }
        });

        msApi.setBaseUrl(API_BASE);

        function onSubmit() {
            if (vm.model.rate <= 0) {
                vm.model.rate = '';
                return false;
            }
            $mdToast.show(
                $mdToast.simple()
                .textContent('Editing Cross Rate...')
                .position('top center')
            );
            crossrateService.editCrossRate(vm.model).then(
                function(success) {
                    vm.model = {};
                    vm.crossRateForm.$setPristine();
                    vm.crossRateForm.$setUntouched();
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Success! Cross Rate edited!')
                        .position('top center')
                    );
                    $state.go('app.cross-rate_approval');
                },
                function(error) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Cross Rate edit failed!')
                        .position('top center')
                    );
                }
            );
        }
    }
})();
