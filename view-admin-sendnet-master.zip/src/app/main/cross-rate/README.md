# ng-modules-fx

This is the Foreign Exchange Rates Management module for SendNet.
