(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('crossrateService', crossrateService);

    /** @ngInject */
    function crossrateService($q, $log, api, store, $timeout, msApi, $mdToast, API_BASE, HTTP_HOST, APP_TYPE)
    {
        var service = {
          addCrossRate: addCrossRate,
          editCrossRate: editCrossRate,
          getAllCrossRate: getAllCrossRate,
          getCrossRateHistory: getCrossRateHistory,
          approve: approve,
          reject: reject
        };

        msApi.setBaseUrl(API_BASE);

        return service;

        /**
         * addCrossRate api
         */
        function addCrossRate(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate';

            msApi.register('add.cross-rate', [apiUrl]);
            msApi.requestApi('add.cross-rate@post', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * editCrossRate api
         */
        function editCrossRate(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate/';

            msApi.register('add.cross-rate', [apiUrl]);
            msApi.requestApi('add.cross-rate@post', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * getAllCrossRate api
         */
        function getAllCrossRate(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate';

            msApi.register('query.history', [apiUrl]);
            msApi.requestApi('query.history@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * getCrossRateHistory api
         */
        function getCrossRateHistory(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate/history';

            msApi.register('query.history', [apiUrl]);
            msApi.requestApi('query.history@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * approve api
         */
        function approve(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate/approve';

            msApi.register('approve.cross-rate', [apiUrl]);
            msApi.requestApi('approve.cross-rate@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * reject api
         */
        function reject(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate/reject';

            msApi.register('reject.cross-rate', [apiUrl]);
            msApi.requestApi('reject.cross-rate@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }


    }

})();
