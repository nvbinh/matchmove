(function ()
{
    'use strict';

    angular
        .module('app.cross-rate.history', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.cross-rate_history', {
            url      : '/cross-rate/history',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/cross-rate/history/history.html',
                    controller : 'CrossRateHistoryController as vm'
                }
            },
            resolve  : {
                
            },
            bodyClass: 'cross-rate history'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/cross-rate/history');

        // Navigation
        msNavigationServiceProvider.saveItem('cross-rate.history', {
            title : 'History',
            state : 'app.cross-rate_history',
            weight: 3
        });
    }

})();
