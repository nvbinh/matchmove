(function ()
{
    'use strict';

    angular
        .module('app.cross-rate.history')
        .controller('CrossRateHistoryController', CrossRateHistoryController);

    /** @ngInject */
    function CrossRateHistoryController(msApi, store, API_BASE, $mdToast, $scope, CROSS_RATE_CONSTANTS, crossrateService, HelperFactory, CURRENCIES, $mdDialog, $filter, msGen, REPORTS_ITEMS_PER_PAGE)
    {
        var vm = this;

        // Data
        vm.resourceName = "Cross Rate History";
        vm.showDetails = false;
        vm.selected = [];
        vm.selected_ids = "";
        vm.fromCurrencies = CURRENCIES;
        vm.toCurrencies = CURRENCIES;
        vm.results = null;
        vm.csvData = [];
        vm.model = {};
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.crossrateStatus = CROSS_RATE_CONSTANTS.history_status;
        vm.csv_table_header = CROSS_RATE_CONSTANTS.datatable_heading_history;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };

        vm.filename = new Date().toString() + ".csv";

        vm.onSubmit = onSubmit;
        vm.toggleDetails = toggleDetails;
        vm.getDataForCsv = getDataForCsv;
        vm.toggleFilter = toggleFilter;
        vm.closeFilter = closeFilter;
        vm.changeFromCurrency = changeFromCurrency;
        vm.changeToCurrency = changeToCurrency;

        var apiUrl = 'api/remittance/cross-rate/history';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        vm.tables = {
          header: []
        }
        currentCrossRate();

        function changeFromCurrency() {
          if (!vm.model.from) {
            return;
          }
          var fromCurrency = '!' + vm.model.from;
          vm.toCurrencies = CURRENCIES;
          vm.toCurrencies = $filter('filter')(vm.toCurrencies, {code: fromCurrency});
        }

        function changeToCurrency() {
          if (!vm.model.to) {
            return;
          }
          var toCurrency = '!' + vm.model.to;
          vm.fromCurrencies = CURRENCIES;
          vm.fromCurrencies = $filter('filter')(vm.fromCurrencies, {code: toCurrency});
        }

        /**
         * Get CSV Data
         *
         * @param
        */
        function getDataForCsv() {
          vm.csvData = [];
          vm.results.forEach( function( el, ind, arr ) {
            var objItem = {};
            objItem.id = el.id;
            objItem.created_at = el.created_at;
            objItem.updated_at = el.updated_at;
            objItem.from_currency = el.from_currency;
            objItem.to_currency = el.to_currency;
            objItem.rate = $filter('number')(el.rate, 2);
            objItem.status = el.is_active;
            vm.csvData.push(objItem);
          });
          return vm.csvData;
        }

        function toggleFilter(ev){
          vm.fromCurrencies = CURRENCIES;
          vm.toCurrencies = CURRENCIES;
          if (vm.model) {
            vm.model.from = null;
            vm.model.to = null;
            vm.model.status = null;
          }
          $mdDialog.show({
            scope: $scope,
            preserveScope: true,
            resolve  : {
            },
            templateUrl : 'app/main/cross-rate/history/filter-dialog/filter-dialog.html',
            clickOutsideToClose: true,
          });
        }

        function closeFilter(){
          $mdDialog.hide();
        }

        function toggleDetails(item, details)
        {
            vm.showDetails = true;
            vm.crossRateDetail = item;
            // vm.crossRateDetail.date.activated = new Date(vm.crossRateDetail.date.activated);
            // vm.crossRateDetail.date.added = new Date(vm.crossRateDetail.date.added);
            if(details === 'show'){
              HelperFactory.toggleSidenav('details-sidenav');
            }
        }

        // function definition
        function onSubmit() {
          var queryStr = vm.model, apiUrl = 'api/remittance/cross-rate/history';

          queryStr.page = vm.query.page;
          queryStr.records_per_page = vm.query.limit;
          queryStr.offset = (vm.query.page - 1) * queryStr.records_per_page;
          queryStr.sort_type = 'desc';
          queryStr.sort_by = 'created_at';
          if (!queryStr.status) {
            queryStr.status = 'approved,rejected,active';
          }

          vm.results = null;
          requestApi(queryStr);
          closeFilter();
        }

        function currentCrossRate(){
          requestApi({
            records_per_page: vm.query.limit,
            page            : vm.query.page,
            status          : 'approved,rejected,active',
            sort_type       : 'desc',
            sort_by       : 'created_at'
          });
        }

        function toTimeParams(d){
          var curr_day= d.getDate();  //change day here
          var curr_month = d.getMonth() + 1;
          var curr_year = d.getFullYear();
          return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr){
          crossrateService.getCrossRateHistory(queryStr).then(
              function (success) {
                if(success instanceof Array){
                  vm.results = success;
                }
                else if(success.response instanceof Array){
                  vm.results = success.response;
                  if (vm.results) {
                    vm.results.total_records = success.pagination.total_records;
                  } else {
                    vm.results = [];
                  }
                }else{
                  vm.results = success.response.rates;
                  vm.results.total_records = success.pagination.total_records;
                }
                if(vm.results) {
                  vm.tables.header = CROSS_RATE_CONSTANTS.datatable_heading_history
                  angular.forEach(vm.results, function(rs, key){
                    if (Number(rs.from_rate) === 1) {
                      vm.results[key].rate = rs.to_rate;
                    } else {
                      vm.results[key].rate = (1 / Number(rs.from_rate)).toFixed(8);
                    }
                    vm.results[key].created_at = new Date(rs.created_at);
                    vm.results[key].updated_at = new Date(rs.updated_at);
                  });
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
                vm.logPagination = success.pagination;
                var total_pages = 0;
                if (vm.logPagination && vm.logPagination.total_pages) {
                  total_pages = vm.logPagination.total_pages;
                }
                vm.csvFilename = msGen.getFileName(vm.resourceName, vm.query.page, total_pages, vm.model);
              },
              function (response) {}
          );
        }

    }

})();
