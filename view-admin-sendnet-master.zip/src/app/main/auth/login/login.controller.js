(function ()
{
    'use strict';

    angular
        .module('app.auth.login')
        .controller('LoginController', LoginController);

    /** @ngInject */
    function LoginController(BRANDING, apiResolver, api, store, $state, $rootScope, auth, CLIENT_ID, CLIENT_SECRET, GRANT_TYPE, mmPermission, $q, authSession, PermPermissionStore, $scope)
    {
        // Data
        var vm = this;
        vm.branding = BRANDING;
        vm.loginError = false;

        // ngProgress

        //remove any token_data
        store.remove('token_data');
        store.remove('username');
        store.remove('permission_ids');

        // Methods

        vm.doLogin = doLogin;

        function doLogin() {
              auth.login(vm.form, function(response) {
                  // error
                  vm.loginError = true;
                  vm.loginErrorMessage = response.data.message;
                  $rootScope.progressbar.complete();
              });
              $rootScope.$on('permission:ready', function(){
                  $state.go('app.dashboard_home', { reload: true });
              });
        }

        //////////
    }
})();
