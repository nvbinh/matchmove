(function() {
	'use strict';
	angular
        .module('app.core')
        .service('forgotPasswordService', forgotPasswordService);

    /** @ngInject */
    function forgotPasswordService($q, msApi, API_BASE, HTTP_HOST, RESET_PASSWORD_ENDPOINT, PRODUCT_NAME)
    {
        var service = {
            initiateForgotPassword: initiateForgotPassword,
            changePassword: changePassword
        };


        return service;

        //////////

        /**
         * Reset password and send the reset link to the email
         *
         * @returns {*}
         */
        function initiateForgotPassword(username, success, error)
        {
            // Emulate the api call and load new timeline items in
            var deferred = $q.defer();
            var parameters = {};
            parameters.username = username;
            parameters.product_name = PRODUCT_NAME;
            parameters.password_recovery_link = HTTP_HOST + RESET_PASSWORD_ENDPOINT;
            if ( !username )
            {
                // Reject the promise
                deferred.reject('No more pages');
            } else {

		        msApi.setBaseUrl(API_BASE);
		        msApi.register('auth.forgot.password', ['api/admins/{admin_id}/password']);
	        	msApi.requestApi('auth.forgot.password@post', parameters,
		            // Success
		            function (response)
		            {
		            	// Resolve the promise
		                deferred.resolve(response);
		                // Call the success function if there is one
                        if ( angular.isDefined(success) && angular.isFunction(success) )
                        {
                            success(response);
                        }
		            },
		            // ERROR
		            function (response)
		            {
		                // Reject the promise
		                deferred.reject(response);
		                // Call the error function if there is one
                        if ( angular.isDefined(error) && angular.isFunction(error) )
                        {
                            error(response);
                        }
		            }
		        );
        	}
        	return deferred.promise;
        }

        /**
         * Get registered palettes
         *
         * @returns {*}
         */
        function changePassword(parameters, success, error)
        {
            // Emulate the api call and load new timeline items in
            var deferred = $q.defer();

            if ( !parameters )
            {
                deferred.reject('No more pages');
            } else {

		        msApi.setBaseUrl(API_BASE);
		        msApi.register('auth.reset.password', ['api/admins/{admin_id}/password/{token}']);
	        	msApi.requestApi('auth.reset.password@put', parameters,
		            // Success
		            function (response)
		            {
		            	// Resolve the promise
		                deferred.resolve(response);
		                // Call the success function if there is one
                        if ( angular.isDefined(success) && angular.isFunction(success) )
                        {
                            success(response);
                        }
		            },
		            // ERROR
		            function (response)
		            {
		                // Reject the promise
		                deferred.reject(response);
		                // Call the error function if there is one
                        if ( angular.isDefined(error) && angular.isFunction(error) )
                        {
                            error(response);
                        }
		            }
		        );
        	}
        	return deferred.promise;
        }
    }
})();
