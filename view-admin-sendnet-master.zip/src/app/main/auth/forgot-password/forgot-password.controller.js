(function ()
{
    'use strict';

    angular
        .module('app.auth.forgot-password')
        .controller('ForgotPasswordController', ForgotPasswordController);

    /** @ngInject */
    function ForgotPasswordController(BRANDING, forgotPasswordService, msUtils)
    {
        var vm = this;
        vm.branding = BRANDING;
        vm.form = {};
        vm.resetPasswordSuccess = false;
        vm.resetPasswordSuccessMsg = '';
        vm.resetPasswordError = false;
        vm.resetPasswordErrorMsg = '';
        // Data

        //vm.passwordToken = PasswordToken.data;
        vm.forgotPassword = forgotPassword;
        vm.resend = resend;
        // Methods
        function forgotPassword() {
            var _email = vm.form.email;
            vm.resetPasswordError = false;
            // vm.resetPasswordSuccess = false;
            forgotPasswordService.initiateForgotPassword(_email,
                function (response) {
                    vm.resetPasswordMsg = response.message;
                    vm.resetPasswordSuccess = true;
                    msUtils.setStore('users', JSON.stringify(response.data));
                },
                function (response) {
                    vm.resetPasswordError = true;
                    vm.resetPasswordErrorMsg = response.data.message;
                }
            );
        }

        function resend() {
            vm.resetPasswordSuccess = true;
            forgotPassword();
        }
        //////////
    }
})();
