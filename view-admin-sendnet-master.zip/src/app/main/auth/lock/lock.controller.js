(function ()
{
    'use strict';

    angular
        .module('app.auth.lock')
        .controller('LockController', LockController);

    /** @ngInject */
    function LockController(BRANDING, $rootScope, store, auth, $state, $http)
    {
        var vm = this;
        vm.branding = BRANDING;
        vm.loginError = false;

        // Data
        vm.form = {
            username: store.get('username')
        };

        // Methods

        vm.unlock = unlock;

        if (!store.get('username')) {
            $state.go('app.auth_login');
        }

        store.remove('token_data');
        delete $http.defaults.headers.common.Authorization;
        delete $http.defaults.headers.common.Accept;

        function unlock(){
            auth.login(vm.form, function(response) {
                // error
                // console.log(response)
                vm.loginError = true;
                vm.loginErrorMessage = response.data.message;
                $rootScope.progressbar.complete();
            });
            $rootScope.$on('permission:ready', function(){
                $state.go('app.dashboard_home', { reload: true });
            });
        }

        //////////
    }
})();
