(function ()
{
    'use strict';

    angular
        .module('app.auth.verify')
        .controller('VerifyController', VerifyController);

    /** @ngInject */
    function VerifyController(BRANDING, AdminService, $location)
    {
        var vm = this;
        var params;
        vm.branding = BRANDING;

        vm.verify = verify;

        // Methods
        function verify() {
            vm.verifyUserSuccess = false;
            vm.verifyUserError = false;

            params = $location.search();

            var _object = {
                admin_id: params.admin_id,
                verification_id: params.verification_id,
                token: params.token
            };
            AdminService.verifyCreateAdmin(_object,
                function (response) {
                    vm.verifyUserMsg = response.message;
                    vm.verifyUserSuccess = true;
                },
                function (response) {
                    vm.verifyUserErrorMsg = response.data.message;
                    vm.verifyUserError = true;
                }
            );
        }
        //////////
    }
})();
