(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('authSession', authSessionService);

    /** @ngInject */
    function authSessionService($q, $log, api, store, $state, $rootScope, Idle, API_BASE, CLIENT_ID, CLIENT_SECRET, GRANT_TYPE, $timeout, msApi, PermPermissionStore)
    {
        var service = {
            hasPermissionId: hasPermissionId,
            checkPermission: checkPermission,
            storePermissionId: storePermissionId
        };

        msApi.setBaseUrl(API_BASE);

        return service;

        //////////
        /**
         * store permission ids
         */
        function storePermissionId(){
          store.remove('permission_ids');
          var permissions =  [];
          msApi.setBaseUrl(API_BASE);
          var vm = {
            apiUrl: 'api/admins/reports'
          }
          msApi.register('admins.permissions', [vm.apiUrl]);

          msApi.request('admins.permissions@get', {},
              function (success) {
                angular.forEach(success.data.response, function(roles){
                  angular.forEach(roles, function(permissionCategory){
                    if(typeof permissionCategory == 'object'){
                      if(permissionCategory.hasOwnProperty('permissions')){
                        angular.forEach(permissionCategory, function(role){
                          addPermission(role, permissions)
                        });
                      }
                      angular.forEach(permissionCategory.actions, function(role){
                        addPermission(role.permissions, permissions)
                      });
                    }
                  });
                });
                store.set('permission_ids', permissions);
                $rootScope.$broadcast('authorized');
                $rootScope.$broadcast('permission:ready');
              },
              function(error){
              }
              );
        }

        /**
         *
         */
        function checkPermission(permission_name){
            return hasPermissionId(permission_name);
        }

        /**
         * checks permission id
         */
        function hasPermissionId(id){
          return store.get('permission_ids').includes(id);
        }

        /**
         * adds permission id
         */
        function addPermission(role, permissions){
          angular.forEach(role, function(permission, permissionName){
            if(permission.id !== undefined){
              permissions.push(permission.name);
            }
          });
        }
    }

})();
