(function ()
{
    'use strict';

    angular
        .module('app.auth.reset-password')
        .controller('ResetPasswordController', ResetPasswordController);

    /** @ngInject */
    function ResetPasswordController(BRANDING, forgotPasswordService, msUtils)
    {
        var vm = this;
        vm.branding = BRANDING;
        vm.form = {};
        vm.resetPasswordMsg = '';
        // Data

        //vm.passwordToken = PasswordToken.data;
        vm.changePassword = changePassword;
        // Methods
        function changePassword() {
            vm.resetPasswordSuccess = false;
            vm.resetPasswordError = false;

            var users = JSON.parse(msUtils.getStore('users')) || {};
            var passwordError = "";
            var passwordConfirmError = "";
            var msg = {};
            var _object = {
                id: users.user_id,
                password: vm.form.password,
                password_confirmation: vm.form.passwordConfirm,
                token: users.token
            };
            forgotPasswordService.changePassword(_object,
                function (response) {
                    vm.resetPasswordMsg = response.message;
                    vm.resetPasswordSuccess = true;
                    store.remove('users');
                },
                function (response) {

                    vm.resetPasswordError = true;
                    msg = response.data.message;

                    if (typeof(msg) == 'object') {
                        passwordError = msg.password ? msg.password[0] : "";
                        passwordConfirmError = msg.password_confirmation ? msg.password_confirmation[0] : "";
                        vm.resetPasswordErrorMsg = passwordError + " " + passwordConfirmError;
                    } else {
                        vm.resetPasswordErrorMsg = msg;
                    }
                }
            );
        }
        //////////
    }
})();
