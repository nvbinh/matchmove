(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('auth', authService);

    /** @ngInject */
    function authService($q, $log, api, store, $state, $rootScope, Idle, API_BASE, CLIENT_ID, CLIENT_SECRET, GRANT_TYPE, $timeout, msApi, PermPermissionStore, authSession, mmPermission)
    {
        var service = {
            login: login,
            logout: logout
        };

        return service;

        //////////

        /**
         * Login api
         * @param parameters
         * @param errorCallback
         */
        function login(parameters, errorCallback)
        {
            var credentials = parameters,
                deferred = $q.defer(),
                token_data = store.get('token_data');

            $rootScope.loadingProgress = true;
            $rootScope.progressbar.start();

            msApi.register('auth.login', [ 'oauth/access_token']);

            $q.all([msApi.requestApi('auth.login@post',
                {
                    client_id: CLIENT_ID,
                    client_secret: CLIENT_SECRET,
                    grant_type: GRANT_TYPE,
                    password: parameters.password,
                    username: parameters.username
                },
                function(response) {
                    // success, set the client token for future api requests
                    store.set('token_data', response.data);
                    store.set('username', parameters.username);
                    deferred.resolve({});
                    mmPermission.initialize();
               }, errorCallback
            )]).then(function(){
            });
            return deferred.promise;
        }

        /**
         * Logout api
         */
        function logout() {
            $rootScope.$broadcast('userLoggedOut');
            PermPermissionStore.clearStore();
            store.remove('permission_ids');
            store.remove('username');
            store.remove('token_data');
            store.remove('error');
        }

    }

})();
