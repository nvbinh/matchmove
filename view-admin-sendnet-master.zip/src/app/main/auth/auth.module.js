(function ()
{
    'use strict';

    angular
        .module('app.auth', [
            'app.auth.login',
            'app.auth.lock',
            'app.auth.forgot-password',
            'app.auth.reset-password',
            'app.auth.verify'
        ])
        .config(config);

    /** @ngInject */
    function config()
    {

    }
})();
