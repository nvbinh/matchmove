# ng-modules-admin

This is the system administration module for AdminNet and other related products like SendNet.
