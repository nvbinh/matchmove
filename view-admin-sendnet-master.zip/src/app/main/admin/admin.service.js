(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('AdminService', adminService);

    /** @ngInject */
    function adminService($q, $log, api, store, $timeout, msApi, $mdToast, API_BASE, HTTP_HOST, USER_VERIFY_ENDPOINT)
    {
        var service = {
            getActions: getActions,
            getPermissions: getPermissions,
            getActionPermissions: getActionPermissions,
            getRoles: getRoles,
            createAdmin: createAdmin,
            verifyCreateAdmin: verifyCreateAdmin,
            getUserDetails: getUserDetails
        };

        msApi.setBaseUrl(API_BASE);

        return service;

        //////////
        /**
         * Login api
         * @param parameters
         * @param errorCallback
         */
        function getRoles()
        {

        }

        /**
         * createAdmin api
         */
        function createAdmin(params) {
            params.user_verify_link = HTTP_HOST + USER_VERIFY_ENDPOINT;
            var deferred = $q.defer();
            msApi.register('admins.create', ['api/admins']);
            msApi.requestApi('admins.create@post', params,
                function (success) {
                    deferred.resolve(success);
                },
                function(error){
                    deferred.reject(error);
                }
            );

            return deferred.promise;
        }

        /**
         * getActions api
         */
        function getActions() {
            var deferred = $q.defer();
            msApi.register('admins.actions', ['api/admins/permissions/action-groups']);
            msApi.requestApi('admins.actions@get',
                function (success) {
                    deferred.resolve(success);
                },
                function(error){
                    deferred.reject(error);
                }
            );

            return deferred.promise;
        }

        /**
         * getPermissions api
         */
        function getPermissions() {
            var deferred = $q.defer();
            msApi.register('admins.actions', ['api/admins/roles/all/permissions']);
            msApi.requestApi('admins.actions@get',
                function (success) {
                    deferred.resolve(success);
                },
                function(error){
                    deferred.reject(error);
                }
            );

            return deferred.promise;
        }

        /**
         * getActionPermissions api
         */
        function getActionPermissions(role_id) {
            var deferred = $q.defer();
            msApi.register('admins.actions', ['/api/admins/roles/' + role_id + '/permissions/all']);
            msApi.requestApi('admins.actions@get',
                function (success) {
                    deferred.resolve(success);
                },
                function(error){
                    deferred.reject(error);
                }
            );

            return deferred.promise;
        }

        function verifyCreateAdmin(params, success, error) {
            var deferred = $q.defer();
            msApi.register('admins.create.verify', ['api/admins/{admin_id}/verification/{verification_id}']);
            msApi.requestApi('admins.create.verify@put', params,
                // Success
                function (response)
                {
                    // Resolve the promise
                    deferred.resolve(response);
                    // Call the success function if there is one
                    if ( angular.isDefined(success) && angular.isFunction(success) )
                    {
                        success(response);
                    }
                },
                // ERROR
                function (response)
                {
                    // Reject the promise
                    deferred.reject(response);
                    // Call the error function if there is one
                    if ( angular.isDefined(error) && angular.isFunction(error) )
                    {
                        error(response);
                    }
                }
            );

            return deferred.promise;
        }

        // Get user details
        function getUserDetails(userId) {
            var deferred = $q.defer();

            msApi.register('admins.user', ["api/admins"]);
            msApi.requestApi('admins.user@get', {
                    admin_id: userId
                },
                function (success) {
                    deferred.resolve(success);
                },
                function(error){
                    deferred.reject(error);
                }
            );

            return deferred.promise;
        }

    }

})();
