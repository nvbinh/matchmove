(function() {
    'use strict';

    angular
        .module('app.admin.profile')
        .controller('AdminProfileController', ProfileController);

    /** @ngInject */
    function ProfileController($stateParams, msApi, $mdToast, API_BASE, $q, AdminService) {
        var vm = this;

        // Methods

        vm.onSubmit = onSubmit;
        vm.roles = [];
        vm.selected = [];
        msApi.setBaseUrl(API_BASE);
        vm.permissions = [];
        vm.selected = [];
        vm.noRoleWarning = false;

        // Get the current user role and show radio button
        msApi.register('admins.role', ['api/admins/'+$stateParams.id+'/roles/all']);
        msApi.request('admins.role@get', {},
            function(success) {
                if (success.data == 0){
                    vm.noRoleWarning = true;
                }
                vm.selected_role = success.data.response[0].role_id;
            }
        );

        msApi.register('admins.roles', ['api/admins/all/roles']);
        msApi.request('admins.roles@get', {},
            function(success) {
                angular.forEach(success.data.response, function(item) {
                    vm.roles.push({
                        id: item.role_id,
                        description: item.name
                    });
                });
            },
            function(error) {}
        );

        // Set the selected role
        function onSubmit() {
            vm.form.$setPristine();
            vm.model = {};
            var roles = []
            roles.push(vm.selected_role);
            msApi.register('admins.permission', ['api/admins/' + $stateParams.id + '/roles/{role_id}?role_id=' + encodeURIComponent("[" + roles.toString() + "]"),
                null, {
                    'update': {
                        method: 'PUT'
                    }
                }
            ]);

            vm.promise = msApi.request('admins.permission@update', {},
                function(success) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Success! User role edited!')
                        .position('top center')
                    );

                    vm.noRoleWarning=false;
                },
                function(error) {
                    $mdToast.show(
                        $mdToast.simple()
                        .theme('warn')
                        .textContent('Unable to edit user role')
                        .position('top center')
                    );
                }
            );
        }

        AdminService.getUserDetails($stateParams.id).then(
            function(success){
                console.log(success.data.response[0]);
                vm.userDetails = success.data.response[0]
            }
        );

        //////////
    }

})();
