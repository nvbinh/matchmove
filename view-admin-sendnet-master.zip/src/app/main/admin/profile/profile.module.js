(function ()
{
    'use strict';

    angular
        .module('app.admin.profile', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.admin_profile', {
            url      : '/admin/:id/profile',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/admin/profile/profile.html',
                    controller : 'AdminProfileController as vm'
                }
            },
            resolve  : {
            },
            bodyClass: 'profile'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/profile');

        // Api

        // Navigation
//        msNavigationServiceProvider.saveItem('admin.profile', {
//            title : 'Profile',
//            icon  : 'icon-account',
//            state : 'app.admin_profile',
//            weight: 6
//        });
    }

})();
