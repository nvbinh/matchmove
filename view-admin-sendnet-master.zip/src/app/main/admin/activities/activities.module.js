(function ()
{
    'use strict';

    angular
        .module('app.admin.activities', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.admin_activities', {
            url      : '/admin/activities',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/admin/activities/activities.html',
                    controller : 'AdminActivitiesController as vm'
                }
            },
            bodyClass: 'admin'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/activities');

        // Navigation
        msNavigationServiceProvider.saveItem('admin.activities', {
            title : 'Admin Activities',
            icon  : 'icon-pulse',
            state : 'app.admin_activities',
            weight: 5
        });
    }

})();
