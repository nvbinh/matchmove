(function ()
{
    'use strict';

    angular
        .module('app.admin.activities')
        .controller('AdminActivitiesController', AdminActivitiesController);

    /** @ngInject */
    function AdminActivitiesController($mdSidenav, store, msApi, $mdToast, $rootScope, $scope, $q, API_BASE, ADMINISTRATION_CONSTANTS, msGen, HelperFactory, BRANDING,REPORTS_ITEMS_PER_PAGE)
    {

      var vm = this;

      vm.showDetails = false;
      vm.toggleSearch = false;
      vm.searchInfo = {};
      vm.csvData = [];

      vm.resourceName = 'Admin_Activities';
      vm.csvFilename = vm.resourceName + '.csv';

      vm.tables = {};
      vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
      vm.page = 1;
      vm.limit = 10;
      vm.options = {
        rowSelection: true,
        multiSelect: true,
        autoSelect: true,
        decapitate: false,
        largeEditDialog: false,
        boundaryLinks: false,
        limitSelect: true,
        pageSelect: true
      };
      var queryStr =  {};
      msApi.setBaseUrl(API_BASE);
      queryStr.access_token = store.get('token_data').access_token;

      vm.adminactivityConstants = ADMINISTRATION_CONSTANTS;
      vm.csv_table_header = vm.adminactivityConstants.datatable_heading;
      vm.category = vm.adminactivityConstants.activity_types;
      vm.branding = BRANDING;
      // Fetch initial report data
      fetchReportingData(10,1);




      // Methods
      vm.getData = getData;
      vm.fetchReportingData = fetchReportingData;
      vm.showSearchBox = showSearchBox;
      vm.search = search;
      vm.processSuccesfulApiResponse = processSuccesfulApiResponse;
      vm.processErrorApiResponse = processErrorApiResponse;
      vm.getDataForCsv = getDataForCsv;


      /**
       * Get Data
       *
       * @param
       */
      function getData() {
        vm.promise = fetchReportingData(vm.limit,vm.page);
      }

      /**
       * Get CSV Data
       *
       * @param
      */
      function getDataForCsv() {
        vm.csvData = [];
        vm.adminactivityList.forEach( function( el, ind, arr ) {
          var objItem = {};
          objItem.id = el.id;
          objItem.admin_id = el.admin_id;
          objItem.category_id = el.category.id;
          objItem.category_name = el.category.name;
          objItem.details = JSON.stringify(el.details);
          objItem.created_at = el.created_at;
          objItem.updated_at = el.updated_at;
          objItem.first_name = el.first_name;
          objItem.last_name = el.last_name;
          objItem.email = el.email;
          vm.csvData.push(objItem);
        });
        // getData();
        return vm.csvData;
      }

      /**
       * Get Reporting Data
       *
       * @param limit, page
       */
      function fetchReportingData(limit,page) {
        $mdToast.show(
          $mdToast.simple()
            .textContent('Fetching Data')
            .position('top center' )
        );
        var deferred = $q.defer();
        $scope.promise = deferred.promise;
        vm.apiUrl = 'api/admins/{admin_id}/activities?sort_by=created_at' + '&';

        if (Object.keys(vm.searchInfo).length) {
            for(var key in vm.searchInfo) {
                if(key == 'from_date' || key == 'to_date'){
                    vm.apiUrl += key + '=' +  HelperFactory.toISODate(vm.searchInfo[key]) + '&';
                }
                else if (vm.searchInfo[key]) {
                    vm.apiUrl += key + '=' + encodeURIComponent(vm.searchInfo[key].toString()) + '&';
                }
            }
            vm.apiUrl = vm.apiUrl.slice(0, -1);
        }

        msApi.register('adminactivites.list', [vm.apiUrl]);
        vm.promise = msApi.request('adminactivites.list@get',
            {
              records_per_page: limit,
              page: page,
              sort_type:'desc',
              access_token: queryStr.access_token
            },
            function (success) {
              deferred.resolve();
              vm.processSuccesfulApiResponse(success);
            },
            function(error){
              vm.processErrorApiResponse(error);
            }
        );
      }


      /**
       * Show Search Box
       *
       * @param
       */
      function showSearchBox()
      {
          vm.toggleSearch = !vm.toggleSearch;
      }

      /**
       * Search
       *
       * @param
       */
      function search()
      {
         var page = 1 , limit = 10;
         var paramsOb = {};
         paramsOb.access_token = queryStr.access_token;
         vm.apiUrl = 'api/admins/{admin_id}/activities?records_per_page=' + limit + '&page=' + page + '&';
         if (Object.keys(vm.searchInfo).length) {
            for(var key in vm.searchInfo) {
                if(key == 'from_date' || key == 'to_date'){
                    vm.apiUrl += key + '=' +  HelperFactory.toISODate(vm.searchInfo[key]) + '&';
                }
                else if (vm.searchInfo[key]) {
                    vm.apiUrl += key + '=' + encodeURIComponent(vm.searchInfo[key].toString()) + '&';
                }
            }
            vm.apiUrl = vm.apiUrl.slice(0, -1);
         }

          var deferred = $q.defer();
          $scope.promise = deferred.promise;

          msApi.register('adminactivites.list', [vm.apiUrl]);
          vm.promise = msApi.request('adminactivites.list@get', paramsOb,
              function (success) {
                deferred.resolve();
                vm.processSuccesfulApiResponse(success);
                vm.page=1;
                vm.limit=10;
              },
              function(error){
                vm.processErrorApiResponse(error);
              }
          );
      }

      /**
       * Process succesfull response from the API server
       *
       * @param success
       */
      function processSuccesfulApiResponse(success) {
        vm.adminactivityList = success.data.response;
        //////////
        if(vm.adminactivityList) {
          vm.processedDataisEmpty = false;
          vm.adminactivityList = success.data.response;
          vm.logPagination = success.data.pagination;
          vm.page = vm.logPagination.page;
          vm.totalRecord = vm.logPagination.total_records;
          vm.tables.header = vm.adminactivityConstants.datatable_heading;
          vm.csvFilename = msGen.getFileName(vm.resourceName, vm.page, vm.logPagination.total_pages, vm.searchInfo);
        }
        else {
          vm.tables === 'null';
          vm.processedDataisEmpty = true;
        }
        $rootScope.$broadcast('msSplashScreen::remove');
        $mdToast.hide();
        $mdToast.show(
          $mdToast.simple()
            .textContent('List updated')
            .position('top center' )
        );
      }

      /**
       * Process failed response from the API server
       *
       * @param error
       */
      function processErrorApiResponse(error) {
        console.log(error);
        if (error.status === 400) {
          switch (error.statusText) {
            case 'Bad Request':
              $mdToast.show(
                $mdToast.simple()
                  .theme('warn')
                  .textContent('The parameters entered are incorect')
                  .position('top right' )
              );
          }
        } else if (error.status === 404) {
          switch (error.statusText) {
            case 'Not Found':
              $mdToast.show(
                $mdToast.simple()
                  .theme('warn')
                  .textContent('Unable to retrive the results')
                  .position('top right' )
              );
          }
        }
      }

    }

})();
