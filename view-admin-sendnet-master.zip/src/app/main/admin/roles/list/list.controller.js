(function ()
{
    'use strict';

    angular
        .module('app.admin.roles.list')
        .controller('AdminRolesListController', AdminRolesListController);

    /** @ngInject */
    function AdminRolesListController($mdSidenav, store, msApi, $mdToast, $rootScope, $scope, $q, API_BASE, $mdDialog, ADMINISTRATION_CONSTANTS, REPORTS_ITEMS_PER_PAGE)
    {

        var vm = this;

        vm.tables = {};
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.page = 1;
        vm.limit = 10;
        vm.options = {
            rowSelection: true,
            multiSelect: true,
            autoSelect: true,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };
        var queryStr =  {};

        msApi.setBaseUrl(API_BASE);

        // Fetch initial roles data
        fetchReportingData(10,1);

        // methods
        vm.getData = getData;
        vm.fetchReportingData = fetchReportingData;
        vm.processSuccesfulApiResponse = processSuccesfulApiResponse;
        vm.processErrorApiResponse = processErrorApiResponse;
        vm.callRoleDialog = callRoleDialog;
        vm.removeRole = removeRole;
        vm.search = search;

        function getData() {
            vm.promise = fetchReportingData(vm.limit,vm.page,vm.name);
        }

        function fetchReportingData(limit,page,name) {
            $mdToast.show(
                $mdToast.simple()
                .textContent('Fetching Data')
                .position('top center' )
            );
            var deferred = $q.defer();
            $scope.promise = deferred.promise;
            vm.apiUrl = 'api/admins/all/roles';
            msApi.register('roles.list', [vm.apiUrl]);
            vm.promise = msApi.request('roles.list@get',
                {
                    records_per_page: limit,
                    page: page,
                    name: name
                },
                function (success) {
                    deferred.resolve();
                    vm.processSuccesfulApiResponse(success);
                },
                function(error){
                    vm.processErrorApiResponse(error);
                }
            );
        }

        function processSuccesfulApiResponse(success) {
            vm.rolesList = success.data.response;
            vm.tables = {};
            //////////
            if(vm.rolesList) {
                vm.processedDataisEmpty = false;
                vm.rolesList = success.data.response;
                if (typeof success.data.pagination !== 'undefined') {
                    vm.logPagination = success.data.pagination;
                    vm.page = vm.logPagination.page;
                    vm.totalRecord = vm.logPagination.total_records;
                } else {
                    vm.logPagination = null;
                    vm.page = 1;
                    vm.totalRecord = vm.rolesList.length;
                }
                vm.tables.header = Object.keys(vm.rolesList[0]);
            } else {
                vm.tables === 'null';
                vm.processedDataisEmpty = true;
            }
            $rootScope.$broadcast('msSplashScreen::remove');
            $mdToast.hide();
            $mdToast.show(
                $mdToast.simple()
                    .textContent('Role info updated')
                    .position('top center' )
            );
        }

        function processErrorApiResponse(error) {
            if (error.status === 400) {
                switch (error.statusText) {
                    case 'Bad Request':
                        $mdToast.show(
                            $mdToast.simple()
                            .theme('warn')
                            .textContent('The parameters entered are incorect')
                            .position('top right' )
                        );
                    }
            }
        }


        function callRoleDialog (ev, roleName, actions) {
            // console.log(roleName, actions);
        }

        function removeRole(ev, admin){
        var confirm = $mdDialog.confirm()
          .title('Delete role')
          .textContent('Are you sure you want to delete this role?')
          .targetEvent(ev)
          .ok('yes')
          .cancel('cancel');

        vm.apiUrl = 'api/admins/admin_id/roles/' + admin.role_id;
        msApi.register('admins.role', [vm.apiUrl]);
        $mdDialog.show(confirm).then(function() {
          vm.promise = msApi.request('admins.role@delete', { access_token: queryStr.access_token, role_id: admin.role_id },
            function (success) {
                getData();
                $mdToast.show(
                    $mdToast.simple()
                    .textContent('Admin role status deleted')
                    .position('top center' )
                );
            },
            function(error){
              $mdToast.show(
                $mdToast.simple()
                  .theme('warn')
                  .textContent('Unable to delete role')
                  .position('top right' )
              );
            }
            );
        }, function() {
        });
        }
    }

})();
