(function ()
{
    'use strict';

    angular
        .module('app.admin.roles.list', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.admin.roles.list', {
            url      : '/list',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/admin/roles/list/list.html',
                    controller : 'AdminRolesListController as vm'
                }
            },
            resolve  : {
            },
            bodyClass: 'roles list'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/roles/list');


        // Navigation
        msNavigationServiceProvider.saveItem('admin.roles', {
            title : 'Roles',
            icon  : 'icon-account-multiple',
            state : 'app.admin.roles.list',
            weight: 4
        });
    }

})();
