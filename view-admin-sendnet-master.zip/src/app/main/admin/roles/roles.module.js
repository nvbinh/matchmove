(function ()
{
    'use strict';

    angular
        .module('app.admin.roles', [
            'app.admin.roles.list',
            'app.admin.roles.add',
            'app.admin.roles.edit'
        ])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.admin.roles', {
            abstract : true,
            url      : '/roles'
        });

    }

})();
