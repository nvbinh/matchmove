(function() {
    'use strict';

    angular
        .module('app.admin.roles.add', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider) {

        $stateProvider.state('app.admin.roles.add', {
            url: '/add',
            data: {
                permissions: {
                    only: ['store-admins-roles'],
                    redirectTo: 'app.errors_error-403'
                }
            },
            views: {
                'content@app': {
                    templateUrl: 'app/main/admin/roles/add/add-role.html',
                    controller: 'AdminRolesAddController as vm'
                }
            },
            resolve: {
                Admins: function(apiResolver) {
                    // return apiResolver.resolve('admins.list@get', {});
                    return {};
                },
                AdminAllPermissions: function(msApi) {
                    return {};
                },
                AdminRoleFields: function(msApi) {
                    return msApi.resolve('admin.admin_role_fields@get');
                }
            },
            bodyClass: 'admin add'
        });

        msApiProvider.register('admin.admin_role_fields', ['app/main/admin/roles/builder/admin_roles.json']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/roles/add');

        // Navigation
        // msNavigationServiceProvider.saveItem('admin.roles.add', {
        //     title : 'Add',
        //     state : 'app.admin_roles_add',
        //     weight: 2
        // });
    }

})();
