(function ()
{
    'use strict';

    angular
        .module('app.admin.roles.add')
        .controller('AdminRolesAddController', AdminRolesAddController);

    /** @ngInject */
    function AdminRolesAddController(AdminRoleFields, AdminAllPermissions, store, msApi, API_BASE, $mdToast)
    {

        var vm = this;
        vm.fields = AdminRoleFields.data;

        vm.toggle = toggle;
        vm.exists = exists;

        msApi.setBaseUrl(API_BASE);
        msApi.register('admins.roles', ['api/admins/{admin_id}/roles']);

        vm.onSubmit = onSubmit;
        vm.apiUrl = 'api/admins/roles/all/permissions';
        msApi.register('admins.list', [vm.apiUrl]);
        vm.permissions = [];
        vm.selected = [];
        vm.promise = msApi.request('admins.list@get', {},
            function (success) {
              angular.forEach(success.data.response, function(response){
                angular.forEach(response, function(item){
                  vm.permissions.push({ id: item.id, description: item.description });
                });
              });
            },
            function(error){
            }
        );

        function onSubmit() {
            $mdToast.show(
              $mdToast.simple()
                .textContent('Creating the account...')
                .position('top center' )
            );
            msApi.requestApi('admins.roles@post', vm.model,
                function(success) {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Success! Role created!')
                        .position('top center' )
                    );
                    vm.form.$setPristine();
                    vm.form.$setUntouched();
                    vm.model = {};
                    var permissions = []
                    angular.forEach(vm.selected, function(permission){
                      permissions.push(permission.id);
                    });
                    vm.apiUrl = 'api/admins/roles/' + success.data.role_id + '/permissions?' + 'permission_id=' + encodeURIComponent("[" + permissions.toString() + "]");
                    msApi.register('admins.permission', [vm.apiUrl]);

                    vm.promise = msApi.request('admins.permission@save',
                        {},
                        function (success) {
                          $mdToast.show(
                            $mdToast.simple()
                            .textContent('Success! Permission created!')
                            .position('top center' )
                            );
                        },
                        function(error){
                          $mdToast.show(
                            $mdToast.simple()
                            .theme('warn')
                            .textContent('Unable to create permissions to role')
                            .position('top center' )
                            );
                        }
                        );
                },
                function(error) {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Account creation failed!')
                        .position('top center' )
                    );
                    // console.log(error);
                }
            );
        }

        function toggle(item, list) {
          var idx = list.indexOf(item);
          if (idx > -1) {
            list.splice(idx, 1);
          }
          else {
            list.push(item);
          }
        };

        function exists(item, list) {
          return list.indexOf(item) > -1;
        };

    }

})();
