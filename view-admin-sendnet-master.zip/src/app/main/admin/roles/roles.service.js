// (function ()
// {
//     'use strict';
//
//     angular
//         .module('app.core')
//         .factory('roles', rolesService);
//
//     /** @ngInject */
//     function rolesService($q, $log, store, $state, msApi)
//     {
//         var service = {
//             addRole: addRole,
//             updateRole: updateRole,
//             listRole: listRole,
//             deleteRole: deleteRole
//         };
//
//         return service;
//
//         // CRUD
//
//         function listRole() {
//
//         }
//
//         function addRole() {
//
//         }
//
//         function updateRole() {
//
//         }
//
//         function deleteRole() {
//
//         }
//
//
//     }
//
// })():
