(function ()
{
    'use strict';

    angular
        .module('app.admin.roles.edit')
        .controller('AdminRolesEditController', AdminRolesEditController);

    /** @ngInject */
    function AdminRolesEditController(store, msApi, API_BASE, $mdToast, $stateParams, AdminRoleFields, AdminService, $state)
    {

        var vm = this;
        vm.fields = AdminRoleFields.data;
        vm.selectedList = []; //current role permissions to be edited
        vm.selected = [];
        vm.permissions = []; //general permissions list
        vm.permissionList = []; //action permissions and general permissions
        vm.action_permissions = {}; //action permissions list


        vm.toggle = toggle;
        vm.exists = exists;

        msApi.setBaseUrl(API_BASE);

        vm.onSubmit = onSubmit;

        //get all action permissions
        AdminService.getActionPermissions($stateParams.id).then(function(permissions){
          //get all permissions assign to a role
          angular.forEach(permissions.data.response["0"].permissions.permissions, function(permission){
            vm.selectedList.push(permission.id);
          });
          //get all action permissions assign to a role
          angular.forEach(permissions.data.response["0"].permissions.actions, function(permission){
            angular.forEach(permission.permissions, function(item){
              vm.selectedList.push(item.id);
            });
          });

          //get all permissions in actions
          AdminService.getPermissions().then(function(permission){
            angular.forEach(permission.data.response.actions, function(action){
              vm.permissionList.push(action);
              var name = action.description;
              vm.action_permissions[name]=[];
              angular.forEach(action.permissions, function(item){
                var x = { id: item.id, description: item.description, action: name };
                vm.action_permissions[name].push(x);
                if(vm.selectedList.includes(x.id)){
                  vm.selected.push(x);
                }
              });
            });
          });

          //get all general permissions
          vm.apiUrl = 'api/admins/roles/all/permissions';
          msApi.register('admins.permissions', [vm.apiUrl]);
          vm.permissions = [];
          vm.promise = msApi.request('admins.permissions@get', {},
              function (success) {
                angular.forEach(success.data.response, function(response){
                  angular.forEach(response, function(item){
                    if(item.id){
                      var x = { id: item.id, description: item.description };
                      vm.permissions.push(x);
                      if(vm.selectedList.includes(x.id)){
                        vm.selected.push(x);
                      }
                    }
                  });
                });
              },
              function(error){
              }
          );
        });

        function onSubmit() {
          vm.form.$setPristine();
          vm.model = {};

          var permissions = []
          angular.forEach(vm.selected, function(permission){
            permissions.push(permission.id);
          });
        vm.apiUrl = 'api/admins/roles/' + $stateParams.id + '/permissions?' + 'permission_id=' + encodeURIComponent("[" + permissions.toString() + "]");
        msApi.register('admins.permission', [vm.apiUrl]);

        vm.promise = msApi.request('admins.permission@save',
            {},
            function (success) {
              $mdToast.show(
                $mdToast.simple()
                .textContent('Success! Permissions edited!')
                .position('top center' )
                );
              $state.go('app.admin.roles.list');
            },
            function(error){
              $mdToast.show(
                $mdToast.simple()
                .theme('warn')
                .textContent('Unable to edit permissions to role')
                .position('top right' )
                );
            }
            );
        }

        function toggle(item, list) {
          var idx = list.indexOf(item);
          if (idx > -1) {
            list.splice(idx, 1);
          }
          else {
            list.push(item);
          }
        };

        function exists(item, list) {
          return list.indexOf(item) > -1;
        };
    }

})();
