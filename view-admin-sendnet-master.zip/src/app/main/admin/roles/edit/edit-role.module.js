(function ()
{
    'use strict';

    angular
        .module('app.admin.roles.edit', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.admin.roles.edit', {
            url      : '/:id/edit',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/admin/roles/edit/edit-role.html',
                    controller : 'AdminRolesEditController as vm'
                }
            },
          resolve: {
                     AdminRoleFields   : function(msApi){
                                           return msApi.resolve('admin.admin_role_fields@get');
                                         }
                   },
          bodyClass: 'roles edit'
        });

        msApiProvider.setBaseUrl('');
        msApiProvider.register('admin.admin_role_fields', ['app/main/admin/roles/builder/admin_roles.json']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/roles/edit');

        // msNavigationServiceProvider.saveItem('admin.roles.edit',{
        //     'title'     : 'Edit',
        //     'state'     : 'app.admin_roles_edit',
        //     'weight'    : 2
        // });
    }

})();
