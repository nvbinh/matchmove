(function ()
{
    'use strict';

    angular
        .module('app.admin', [
            'app.admin.list','app.admin.activities','app.admin.create','app.admin.roles','app.admin.profile'
        ])
        .config(config);

    /** @ngInject */
    function config($stateProvider, msNavigationServiceProvider)
    {

        $stateProvider.state('app.admin', {
            abstract: true,
            url     : '/admin'
        });

        // Navigation
        msNavigationServiceProvider.saveItem('admin', {
            title : 'ADMINISTRATION',
            group : true,
            weight: 10
        });
    }
})();
