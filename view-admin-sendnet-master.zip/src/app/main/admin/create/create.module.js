(function() {
    'use strict';

    angular
        .module('app.admin.create', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider) {
        $stateProvider.state('app.admin.create', {
            url: '/create',
           data: {
               permissions: {
                   only: ['add-admin'],
                   redirectTo: 'app.errors_error-403'
               }
           },
            views: {
                'content@app': {
                    templateUrl: 'app/main/admin/create/create.html',
                    controller: 'AdminCreateController as vm'
                }
            },
            resolve: {
                Admins: function(apiResolver) {
                    // return apiResolver.resolve('admins.list@get', {});
                    return {};
                },
                Captcha: function(apiResolver) {
                    // return apiResolver.resolve('admins.captcha@get', {});
                    return {};
                },
                AdminFields: function(msApi) {
                    return msApi.resolve('admin.admin_fields@get');
                }
            },
            bodyClass: 'admin'
        });

        msApiProvider.setBaseUrl('/');
        msApiProvider.register('admin.admin_fields', ['app/main/admin/builder/admins.json']);

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/create');

        // Navigation
        msNavigationServiceProvider.saveItem('admin.create', {
            title: 'Create Admin',
            icon: 'icon-account-plus',
            state: 'app.admin.create',
            weight: 2
        });
    }

})();
