(function ()
{
    'use strict';

    angular
        .module('app.admin.create')
        .controller('AdminCreateController', AdminCreateController);

    /** @ngInject */
    function AdminCreateController(Admins, Captcha, AdminFields, store, msApi, API_BASE, $mdToast, AdminService)
    {

        var vm = this;
        vm.fields = AdminFields.data;

        msApi.setBaseUrl(API_BASE);
        msApi.register('admins.create', ['api/admins/']);

        vm.onSubmit = onSubmit;

        function onSubmit() {
            $mdToast.show(
                $mdToast.simple()
                .textContent('Creating new administrator')
                .position('top center' )
                .hideDelay(2000)
            ).then(function() {
                AdminService.createAdmin(vm.model)
                    .then(function (success) {
                        vm.model = {};
                        vm.form.$setPristine();
                        vm.form.$setUntouched();

                        $mdToast.show(
                            $mdToast.simple()
                            .textContent(success.message)
                            .position('top center' )
                        );
                    }, function(error) {
                        var error = error.data.message;

                        if (error.email && error.password) {
                            $mdToast.show(
                                $mdToast.simple()
                                .textContent(error.email[0])
                                .position('top center' )
                                .hideDelay(2000)
                            ).then(function() {
                                if (error.password) {
                                    $mdToast.show(
                                        $mdToast.simple()
                                        .textContent(error.password[0])
                                        .position('top center' )
                                        .hideDelay(2000)
                                    );
                                }
                            });
                        } else if (error.email && !error.password) {
                            $mdToast.show(
                                $mdToast.simple()
                                .textContent(error.email[0])
                                .position('top center' )
                                .hideDelay(2000)
                            );
                        } else {
                            if (error.password) {
                                $mdToast.show(
                                    $mdToast.simple()
                                    .textContent(error.password[0])
                                    .position('top center' )
                                    .hideDelay(2000)
                                );
                            } else {
                                $mdToast.show(
                                    $mdToast.simple()
                                    .textContent(error)
                                    .position('top center' )
                                    .hideDelay(2000)
                                );
                            }
                        }
                    }
                );
            });
        }

    }

})();
