(function() {
    'use strict';

    angular
        .module('app.admin.list')
        .controller('AdminListController', AdminListController);

    /** @ngInject */
    function AdminListController($mdSidenav, store, msApi, $mdToast, $rootScope, $scope, $q, API_BASE, ADMINISTRATION_CONSTANTS, $mdDialog, msGen, HelperFactory, REPORTS_ITEMS_PER_PAGE) {

        var vm = this;

        vm.showDetails = false;
        vm.toggleSearch = false;
        vm.searchInfo = {};

        vm.resourceName = 'Admin_List';
        vm.csvFilename = vm.resourceName + '.csv';
        vm.filterDate = new Date();
        vm.minDate = new Date (
            this.filterDate.getFullYear() - 30,
            this.filterDate.getMonth(),
            this.filterDate.getDate()
        );
        vm.maxDate = new Date (
            this.filterDate.getFullYear(),
            this.filterDate.getMonth(),
            this.filterDate.getDate()
        );
        vm.minStartDate = vm.minDate;
        vm.maxStartDate = vm.maxDate;
        vm.minEndDate = vm.minDate;
        vm.maxEndDate = vm.maxDate;

        vm.tables = {};
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.page = 1;
        vm.limit = 10;
        vm.options = {
            rowSelection: true,
            multiSelect: true,
            autoSelect: true,
            decapitate: false,
            largeEditDialog: false,
            boundaryLinks: false,
            limitSelect: true,
            pageSelect: true
        };
        var queryStr = {};
        msApi.setBaseUrl(API_BASE);

        // Fetch initial report data
        fetchReportingData(10, 1);

        // Methods
        vm.getData = getData;
        vm.fetchReportingData = fetchReportingData;
        vm.showSearchBox = showSearchBox;
        vm.search = search;
        vm.processSuccesfulApiResponse = processSuccesfulApiResponse;
        vm.processErrorApiResponse = processErrorApiResponse;
        vm.removeAdmin = removeAdmin;
        vm.updateStartDate = updateStartDate;
        vm.updateEndDate = updateEndDate;


        /**
         * Get Data
         *
         * @param
         */
        function getData() {
            vm.promise = fetchReportingData(vm.limit, vm.page);
        }

        /**
         * Get Reporting Data
         *
         * @param limit, page
         */
        function fetchReportingData(limit, page) {

            vm.apiUrl = 'api/admins?';
            vm.limitVar = limit ? limit : vm.limit;
            vm.pageVar = page ? page : vm.page;

            if (Object.keys(vm.searchInfo).length) {
                for (var key in vm.searchInfo) {
                    if (key == 'from_date' || key == 'to_date') {
                        vm.apiUrl += key + '=' + HelperFactory.toISODate(vm.searchInfo[key]) + '&';
                    } else if (vm.searchInfo[key]) {
                        vm.apiUrl += key + '=' + encodeURIComponent(vm.searchInfo[key].toString()) + '&';
                    }
                }
                vm.apiUrl = vm.apiUrl.slice(0, -1);
            }

            var deferred = $q.defer();
            $scope.promise = deferred.promise;

            msApi.register('admins.list', [vm.apiUrl]);
            vm.promise = msApi.request('admins.list@get', {
                    records_per_page: vm.limitVar,
                    page: vm.pageVar,
                    sort_type: 'desc',
                    sort_by: 'created_at',
                    access_token: queryStr.access_token
                },
                function(success) {
                    deferred.resolve();
                    vm.processSuccesfulApiResponse(success);
                },
                function(error) {
                    vm.processErrorApiResponse(error);
                }
            );
        }


        /**
         * Show Search Box
         *
         * @param
         */
        function showSearchBox() {
            vm.toggleSearch = !vm.toggleSearch;
        }

        /**
         * Search
         *
         * @param
         */
        function search() {
            var page = 1,
                limit = 10;
            vm.apiUrl = 'api/admins?records_per_page=' + limit + '&page=' + page + '&';
            if (Object.keys(vm.searchInfo).length) {
                for (var key in vm.searchInfo) {
                    if (key == 'from_date' || key == 'to_date') {
                        vm.apiUrl += key + '=' + HelperFactory.toISODate(vm.searchInfo[key]) + '&';
                    } else if (vm.searchInfo[key]) {
                        vm.apiUrl += key + '=' + encodeURIComponent(vm.searchInfo[key].toString()) + '&';
                    }
                }
                vm.apiUrl = vm.apiUrl.slice(0, -1);
            }

            var deferred = $q.defer();
            $scope.promise = deferred.promise;

            msApi.register('admins.list', [vm.apiUrl]);
            vm.promise = msApi.request('admins.list@get', {
                    sort_type: 'desc',
                    sort_by: 'created_at',
                    access_token: queryStr.access_token
                },
                function(success) {
                    deferred.resolve();
                    vm.processSuccesfulApiResponse(success);
                },
                function(error) {
                    vm.processErrorApiResponse(error);
                }
            );
        }

        /**
         * Process succesfull response from the API server
         *
         * @param success
         */
        function processSuccesfulApiResponse(success) {
            vm.adminList = success.data.response;
            //////////
            if (vm.adminList) {
                vm.adminList = success.data.response;
                vm.logPagination = success.data.pagination;
                vm.page = vm.logPagination.page;
                vm.totalRecord = vm.logPagination.total_records;
                vm.csvFilename = msGen.getFileName(vm.resourceName, vm.page, vm.logPagination.total_records, vm.searchInfo);

                if (vm.adminList != 'null') {
                    vm.processedDataisEmpty = false;
                }
            } else {
                vm.adminList = [];
                vm.tables === 'null';
                vm.processedDataisEmpty = true;
            }
            $rootScope.$broadcast('msSplashScreen::remove');
        }

        /**
         * Process failed response from the API server
         *
         * @param error
         */
        function processErrorApiResponse(error) {
            if (error.status === 400) {
                switch (error.statusText) {
                    case 'Bad Request':
                        $mdToast.show(
                            $mdToast.simple()
                            .theme('warn')
                            .textContent('The parameters entered are incorect')
                            .position('top center')
                        );
                }
            } else if (error.status === 404) {
                switch (error.statusText) {
                    case 'Not Found':
                        $mdToast.show(
                            $mdToast.simple()
                            .theme('warn')
                            .textContent('Unable to retrive the results')
                            .position('top center')
                        );
                }
            }
        }

        /**
         * Delete Admin
         *
         * @param event, admin object
         */
        function removeAdmin(ev, admin) {
            var confirm = $mdDialog.confirm()
                .title('Would you like to delete user?')
                .textContent('You are about to delete user.')
                .targetEvent(ev)
                .ok('yes')
                .cancel('cancel');

            vm.apiUrl = 'api/admins/' + admin.admin_id;
            msApi.register('admins.list', [vm.apiUrl]);
            $mdDialog.show(confirm).then(function() {
                $scope.status = 'You decided to get rid of your debt.';
                vm.promise = msApi.request('admins.list@delete', {
                        access_token: queryStr.access_token
                    },
                    function(success) {
                        getData();
                        $mdToast.show(
                            $mdToast.simple()
                            .textContent('Admin user status updated')
                            .position('top center')
                        );
                    },
                    function(error) {
                        if (error && error.data && error.data.message) {
                            if (error.data.message.indexOf('Super Admin') > -1) {
                                $mdToast.show(
                                    $mdToast.simple()
                                    .theme('warn')
                                    .textContent('Super admins cannot be deleted. Please make this admin a non-super-admin before you delete this account.')
                                    .position('top center')
                                );
                            }
                        } else {
                            $mdToast.show(
                                $mdToast.simple()
                                .theme('warn')
                                .textContent('Unable to update status')
                                .position('top center')
                            );
                        }
                    }
                );
            }, function() {});
        }

        /**
         * Update filter -- start date's min and max date
         *
         */
        function updateStartDate() {
            if (vm.searchInfo.from_date) {
                vm.minEndDate = vm.searchInfo.from_date;
                vm.maxEndDate = vm.maxDate;
            }
        }

        /**
         * Update filter -- end date's min and max date
         *
         */
        function updateEndDate() {
            if (vm.searchInfo.to_date) {
                vm.minStartDate = vm.minDate;
                vm.maxStartDate = vm.searchInfo.to_date;
            }
        }
    }

})();
