(function ()
{
    'use strict';

    angular
        .module('app.admin.list', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider)
    {
        $stateProvider.state('app.admin.list', {
            url      : '/list',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/admin/list/list.html',
                    controller : 'AdminListController as vm'
                }
            },
            resolve  : {
                Admins   : function (apiResolver)
                {
                    //return apiResolver.resolve('admins.list@get', {});
                    return {};
                }
            },
            bodyClass: 'admin'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/admin/list');

        // Navigation
        msNavigationServiceProvider.saveItem('admin.list', {
            title : 'Admin Users',
            icon  : 'icon-account-key',
            state : 'app.admin.list',
            weight: 2
        });
    }

})();
