(function ()
{
    'use strict';

    angular
        .module('app.payout-agent', [
            'app.payout-agent.list',
            'app.payout-agent.history',
            'app.payout-agent.upload',
            'app.payout-agent.edit'
        ])
        .config(config);

    /** @ngInject */
    function config(msNavigationServiceProvider)
    {
        // Navigation
        msNavigationServiceProvider.saveItem('payout-agent', {
            title : 'Payout Agents',
            icon  : 'icon-people',
            weight: 4
        });
    }
})();
