(function() {
    'use strict';

    angular
        .module('app.payout-agent.upload')
        .controller('PayoutAgentUploadController', PayoutAgentUploadController);

    /** @ngInject */
    function PayoutAgentUploadController(store, msApi, API_BASE, $mdToast, $scope, $stateParams, mmErrorFormatter, $state, $filter, CSV_UPLOAD_FILE_PARAMS, md5, $translate, $mdDialog, $timeout, $base64, payoutagentService) {

        var vm = this;
        var fileHash = "";
        vm.submitResults = false;
        vm.model = {};
        vm.CsvHandler = CsvHandler;
        vm.resetFlags = resetFlags;
        vm.acceptTypeCallback = acceptTypeCallback;
        vm.payoutAgentSubmit = payoutAgentSubmit;
        vm.csvUploadFileParams = angular.fromJson(CSV_UPLOAD_FILE_PARAMS);

        vm.csv = {
          operation: 'PAYOUT_AGENT',
          content: null,
          header: true,
          headerVisible: false,
          enclosingQuotes: true,
          separator: ',',
          separatorVisible: false,
          result: null,
          encoding: 'ISO-8859-1',
          encodingVisible: false,
          acceptSize: vm.csvUploadFileParams.FILE_SIZE,
          allowedTypes: vm.csvUploadFileParams.ALLOWED_FILE_TYPES
        };

        msApi.setBaseUrl(API_BASE);
        var apiUrl = 'api/remittance/payout-agents/banks';
        msApi.register('app.payoutagent.bulk', [apiUrl]);

        vm.payout_agents = ['e369853df766fa44e1ed0ff613f563bd', ' 9bf31c7ff062936a96d3c8bd1f8f2ff3'];

        // payoutagentService.getPayoutagentId().then(
        //   function (response) {
        //     vm.payout_agents = response;
        //   }, function (error){
         
        // });

        function acceptTypeCallback(retObj) {
          //error in the file uploaded, display message
          vm.validData = false;
          vm.errorMessage = retObj.errorMessage;

        }

        function CsvHandler() {
          resetFlags();
          var now = new Date();
          fileHash = md5.createHash(vm.csv.result.filename + now.getTime());
          if (!vm.csv.result.validdata) {
            vm.errorMessage = $translate.instant('PAYOUT_AGENT.BULK.INVALID_RECORDS');
          }
        }

        function resetFlags() {
          vm.errorMessage = "";
          vm.submitClicked = false;
        }

        function payoutAgentSubmit (fileCsv) {
          var data = {};
          vm.progressIndicator = true;
          data.agent_id = vm.model.payout_agent;
          data.bank_details = $base64.encode(fileCsv);
          // vm.submitClicked = true;
          
          // var payoutAgentArr = [];
          // for (var i = 0; i < fileJson.length; i++) {
          //   var cashinObj = {};
          //   if (fileJson[i].data) {
          //     for (var j = 0; j < fileJson[i].data.length; j++) {
          //       cashinObj[fileJson[i].data[j].fld_name.toLowerCase()] = fileJson[i].data[j];
          //     }
          //     payoutAgentArr.push(cashinObj);
          //   }
          // }
          processTransaction(data);
        }

        function processTransaction(data) {

          msApi.requestApi('app.payoutagent.bulk@post', data,
            function (response) {

              vm.failedData = response.data.failed.details;
              vm.successData = response.data.successful.details;

              vm.progressIndicator = false;
              vm.submitResults = true;
              for (var item in response.results) {
                response.results[item].statusText.value = mmErrorFormatter.statusMessage(response.results[item].status.value, response.results[item].statusText.value);
              }
              angular.forEach(response.results, function (value, key) {
                this.push(angular.merge(value, vm.responseFields));
              }, vm.filteredResponse);

            }, function (error) {
              vm.progressIndicator = false;
              vm.loginPath = '.';
              var textmsg = mmErrorFormatter.statusMessage(error.status, error.statusText);
              vm.progressIndicator = false;
              if (error.status === 401) {
                $mdDialog.show(
                  $mdDialog.alert()
                    .parent(angular.element(document.querySelector('#popupContainer')))
                    .clickOutsideToClose(function () {
                      $mdDialog.hide();
                    })
                    .title($translate.instant('PAYOUT_AGENT.BULK.TITLE'))
                    .textContent(textmsg)
                    .ariaLabel('Bulk payout agent Failure Dialog')
                    .ok('OK')
                    .targetEvent(angular.element('#dialog-button').triggerHandler('click'))
                );
                $timeout(function () {
                  $state.go('app.auth_login', {}, { reload: true })
                }, 5000);
              }
            });
        }
    }
})();
