(function ()
{
    'use strict';

    angular
        .module('app.payout-agent.upload', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.payout-agent_upload', {
            url      : '/payout-agent/upload',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/payout-agent/upload/upload-payout-agent.html',
                    controller : 'PayoutAgentUploadController as vm'
                }
            },
            resolve  : {
               
            },
            bodyClass: 'payout-agent upload'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/payout-agent/upload');

        // Navigation
        msNavigationServiceProvider.saveItem('payout-agent.upload', {
            title : 'Upload',
            state : 'app.payout-agent_upload',
            weight: 2
        });
    }

})();
