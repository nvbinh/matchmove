(function ()
{
    'use strict';

    angular
        .module('app.payout-agent.edit', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider)
    {
        $stateProvider.state('app.payout-agent_edit', {
            url      : '/payout-agent/edit',
            params: {
                bank_id: null,
                provider: null,
                agent: null,
                name: null,
                swift_code: null,
                branch_name: null,
                branch_code: null,
                address: null,
                contact: null,
                city: null,
                district: null,
                state: null
            },
            views    : {
                'content@app': {
                    templateUrl: 'app/main/payout-agent/edit/edit-payout-agent.html',
                    controller : 'PayoutAgentEditController as vm'
                }
            },
            resolve  : {
                
            },
            bodyClass: 'payout-agent edit'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/payout-agent/edit');
    }

})();
