(function() {
    'use strict';

    angular
        .module('app.payout-agent.edit')
        .controller('PayoutAgentEditController', PayoutAgentEditController);

    /** @ngInject */
    function PayoutAgentEditController(store, msApi, API_BASE, $mdToast, $scope, $stateParams, $timeout, payoutagentService, $state) {

        var vm = this;
        vm.fields1 = [];
        vm.onSubmit = onSubmit;
        if ($stateParams && $stateParams.bank_id) {
            store.set('payoutAgentData', $stateParams);
        }
        vm.model = store.get('payoutAgentData');

        $timeout(function(){
            if (vm.model && vm.model.bank_id) {
                vm.payoutAgentEditForm.$invalid = false;
                vm.payoutAgentEditForm.$pristine = false;
            }
        });

        msApi.setBaseUrl(API_BASE);

        function onSubmit() {
            $mdToast.show(
                $mdToast.simple()
                .textContent('Editing Payout Agent...')
                .position('top center')
            );
            payoutagentService.editPayoutAgent(vm.model).then(
                function(success) {
                    vm.model = {};
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Success! Payout Agent edited!')
                        .position('top center')
                    );
                    vm.payoutAgentEditForm.$setPristine();
                    vm.payoutAgentEditForm.$setUntouched();
                    $state.go('app.payout-agent_list');
                },
                function(error) {
                    $mdToast.show(
                        $mdToast.simple()
                        .textContent('Payout Agent edit failed!')
                        .position('top center')
                    );
                }
            );
        }
    }
})();
