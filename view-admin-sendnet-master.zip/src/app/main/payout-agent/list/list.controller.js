(function ()
{
    'use strict';

    angular
        .module('app.payout-agent.list')
        .controller('PayoutAgentListController', PayoutAgentListController);

    /** @ngInject */
    function PayoutAgentListController(msApi, store, API_BASE, $mdToast, $scope, PAYOUT_AGENT_CONSTANTS, payoutagentService, HelperFactory, $mdDialog, $filter, msGen, REPORTS_ITEMS_PER_PAGE, Providers, $q, $timeout)
    {
        var vm = this;

        // Data
        vm.resourceName = "Payout Agent";
        vm.showDetails = false;
        vm.selected = [];
        vm.selected_ids = "";
        vm.results = null;
        vm.csvData = [];
        vm.model = {};
        vm.limitOptions = REPORTS_ITEMS_PER_PAGE;
        vm.csv_table_header = PAYOUT_AGENT_CONSTANTS.datatable_heading_list;
        vm.query = {
            order: 'name',
            limit: 10,
            page: 1
        };
        vm.allPayoutAgent = " ";

        vm.filename = new Date().toString() + ".csv";
        vm.providers = Providers.providers;

        vm.onSubmit = onSubmit;
        vm.toggleDetails = toggleDetails;
        vm.deletePayoutAgent = deletePayoutAgent;
        vm.getDataForCsv = getDataForCsv;
        vm.toggleFilter = toggleFilter;
        vm.closeFilter = closeFilter;
        vm.querySearch   = querySearch;
        vm.loadAll = loadAll;

        var apiUrl = 'api/remittance/payout-agents/banks';
        msApi.setBaseUrl(API_BASE);
        msApi.register('query.builder', [apiUrl]);
        vm.tables = {
          header: []
        }
        currentPayoutagent();

        /**
         * Get CSV Data
         *
         * @param
        */
        function getDataForCsv() {
          vm.csvData = [];
          vm.results.forEach( function( el, ind, arr ) {
            var objItem = {};
            objItem.id = el.id;
            objItem.created_at = el.created_at;
            objItem.from_currency = el.from_currency;
            objItem.to_currency = el.to_currency;
            objItem.rate = el.rate;
            objItem.status = el.is_active;
            vm.csvData.push(objItem);
          });
          return vm.csvData;
        }

        function toggleFilter(ev){
          $mdDialog.show({
            scope: $scope,
            preserveScope: true,
            resolve  : {
            },
            templateUrl : 'app/main/payout-agent/list/filter-dialog/filter-dialog.html',
            clickOutsideToClose: true,
          });
        }

        function closeFilter(){
          $mdDialog.hide();
        }

        function querySearch (query) {
          var results = query ? loadAll().filter( createFilterFor(query) ) : loadAll(),
              deferred;
          deferred = $q.defer();
          $timeout(function () { deferred.resolve( results ); }, Math.random() * 1000, false);
          return deferred.promise;
        }

        function loadAll() {
          return vm.allPayoutAgent.split(/,+/g).map( function (state) {
            return {
              value: state.toLowerCase(),
              display: state
            };
          });
        }

        function createFilterFor(query) {
           var lowercaseQuery = angular.lowercase(query);

           return function filterFn(state) {
             return (state.value.indexOf(lowercaseQuery) === 0);
           };
         }

        function toggleDetails(item, details)
        {
            vm.showDetails = true;
            vm.payoutAgentDetail = item;
            if(details === 'show'){
              HelperFactory.toggleSidenav('details-sidenav');
            }
        }

        // function definition
        function onSubmit() {
          var queryStr = vm.model, apiUrl = 'api/remittance/payout-agents/banks';

          queryStr.page = vm.query.page;
          queryStr.limit = vm.query.limit;
          queryStr.offset = (vm.query.page - 1) * queryStr.limit;
          queryStr.sort = '+name';
          // queryStr.sort_by = 'created_at';
          // queryStr.status = 'pending';

          vm.results = null;
          requestApi(queryStr);
          closeFilter();
        }

        function currentPayoutagent(){
          requestApi({
            limit: vm.query.limit,
            page            : vm.query.page,
            // status          : 'pending',
            // sort_type       : 'desc',
            sort_by       : '+name'
          });
        }

        function toTimeParams(d){
          var curr_day= d.getDate();  //change day here
          var curr_month = d.getMonth() + 1;
          var curr_year = d.getFullYear();
          return curr_year + "-" + curr_month + "-" + curr_day;
        }

        function requestApi(queryStr){
          payoutagentService.getPayoutagent(queryStr).then(
              function (success) {
                if(success instanceof Array){
                  vm.results = success;
                }
                else if(success.response instanceof Array){
                  vm.results = success.response;
                  if (vm.results) {
                    vm.results.total_records = success.pagination.total_records;
                  } else {
                    vm.results = [];
                  }
                }else{
                  vm.results = success.response.banks;
                  vm.results.total_records = success.pagination.total_records;
                }
                if(vm.results) {
                  var resTextArray = [];
                  vm.tables.header = PAYOUT_AGENT_CONSTANTS.datatable_heading_list
                  angular.forEach(vm.results, function(rs, key){
                    vm.results[key].date.added = new Date(rs.date.added);
                    resTextArray.push(rs.agent);
                  });
                  vm.allPayoutAgent = resTextArray.toString();
                }
                else {
                  vm.results = null;
                  vm.tables === 'null';
                }
                vm.logPagination = success.pagination;
                vm.csvFilename = msGen.getFileName(vm.resourceName, vm.query.page, vm.logPagination.total_pages, vm.model);
              },
              function (response) {}
          );
        }

        function pageBack() {
          if (vm.results && vm.results.length === 2 && vm.query.page > 1) {
            vm.query.page = vm.query.page - 1;
          }
        }

        function deletePayoutAgent(item){
          payoutagentService.deletePayoutAgent(item).then(
              function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .textContent('Success! Payout agent deleted!')
                  .position('top center' )
                  );
                pageBack();
                currentPayoutagent();
                HelperFactory.toggleSidenav('details-sidenav');
              },
              function (response) {
                $mdToast.show(
                  $mdToast.simple()
                  .theme('warn')
                  .textContent('Unable to delete payout agent')
                  .position('top right' )
                  );
              }
          );
        }

    }

})();
