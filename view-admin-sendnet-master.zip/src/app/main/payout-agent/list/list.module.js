(function ()
{
    'use strict';

    angular
        .module('app.payout-agent.list', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.payout-agent_list', {
            url      : '/payout-agent/list',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/payout-agent/list/list.html',
                    controller : 'PayoutAgentListController as vm'
                }
            },
            resolve  : {
                Providers : function (msApi)
                {
                    return msApi.resolve('builder.pricing_filter@get');
                },
            },
            bodyClass: 'payout-agent list'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/payout-agent/list');
        msApiProvider.register('builder.pricing_filter', ['app/main/pricing/builder/price-filter.json']);

        // Navigation
        msNavigationServiceProvider.saveItem('payout-agent.list', {
            title : 'List',
            state : 'app.payout-agent_list',
            weight: 1
        });
    }

})();
