(function ()
{
    'use strict';

    angular
        .module('app.payout-agent.history', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.payout-agent_history', {
            url      : '/payout-agent/history',
            views    : {
                'content@app': {
                    templateUrl: 'app/main/payout-agent/history/history.html',
                    controller : 'PayoutAgentHistoryController as vm'
                }
            },
            resolve  : {
                
            },
            bodyClass: 'payout-agent history'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/payout-agent/history');

        // Navigation
        // msNavigationServiceProvider.saveItem('payout-agent.history', {
        //     title : 'History',
        //     state : 'app.payout-agent_history',
        //     weight: 2
        // });
    }

})();
