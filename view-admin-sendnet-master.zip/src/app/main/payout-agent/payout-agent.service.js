(function ()
{
    'use strict';

    angular
        .module('app.core')
        .factory('payoutagentService', payoutagentService);

    /** @ngInject */
    function payoutagentService($q, $log, api, store, $timeout, msApi, $mdToast, API_BASE, HTTP_HOST, APP_TYPE)
    {
        var service = {
          addCrossRate: addCrossRate,
          editPayoutAgent: editPayoutAgent,
          deletePayoutAgent: deletePayoutAgent,
          getPayoutagentId: getPayoutagentId,
          getPayoutagent: getPayoutagent,
          approve: approve,
          reject: reject
        };

        msApi.setBaseUrl(API_BASE);

        return service;

        /**
         * addCrossRate api
         */
        function addCrossRate(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate';

            msApi.register('add.cross-rate', [apiUrl]);
            msApi.requestApi('add.cross-rate@post', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * editPayoutAgent api
         */
        function editPayoutAgent(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/payout-agents/banks/';
            if (params.bank_id) {
                apiUrl += params.bank_id;
            }
            var data = {};
            data.details = {};
            data.details.address = params.address || '';
            data.details.contact = params.contact || '';
            data.details.city = params.city || '';
            data.details.district = params.district || '';
            data.details.state = params.state || '';

            msApi.register('edit.record', [apiUrl]);
            msApi.requestApi('edit.record@put', data,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * editPayoutAgent api
         */
        function deletePayoutAgent(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/payout-agents/banks/';
            if (params.id) {
                apiUrl += params.id;
            }

            msApi.register('delete.record', [apiUrl]);
            msApi.requestApi('delete.record@delete', {},
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * getPayoutagentId api
         */
        function getPayoutagentId(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/payout-agents';

            msApi.register('query.payout-agentid', [apiUrl]);
            msApi.requestApi('query.payout-agentid@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * getPayoutagent api
         */
        function getPayoutagent(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/payout-agents/banks';

            msApi.register('query.list', [apiUrl]);
            msApi.requestApi('query.list@get', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * approve api
         */
        function approve(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate/approve';

            msApi.register('approve.cross-rate', [apiUrl]);
            msApi.requestApi('approve.cross-rate@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }

        /**
         * reject api
         */
        function reject(params) {
            var deferred = $q.defer();
            var apiUrl = 'api/remittance/cross-rate/reject';

            msApi.register('reject.cross-rate', [apiUrl]);
            msApi.requestApi('reject.cross-rate@put', params,
                function (success) {
                    deferred.resolve(success.data);
                },
                function(error){
                    deferred.reject(error);
                }
            );
            return deferred.promise;
        }


    }

})();
