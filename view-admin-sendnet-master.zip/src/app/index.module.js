(function ()
{
    'use strict';

    /**
     * Main module of the App
     * Define your application mdoules and external dependencies here.
     */
    angular
        .module('admin', [

            // Core
            'app.core',

            // Navigation
            'app.navigation',

            // Toolbar
            'app.toolbar',

            //Tempaltes
            'templates',

            // Errors
            'app.errors',

            // Components
            'app.components',

            //Dynamic submodules
            
            'app.admin',
            
            'app.auth',
            
            'app.cancellation',
            
            'app.cross-rate',
            
            'app.dashboard',
            
            'app.logs',
            
            'app.pricing',
            
            'app.remittance-prefund'
            

        ]);
})();
