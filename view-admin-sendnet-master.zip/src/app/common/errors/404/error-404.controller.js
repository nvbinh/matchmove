(function ()
{
    'use strict';

    angular
        .module('app.errors.error-404')
        .controller('Error404Controller', Error404Controller);

    /** @ngInject */
    function Error404Controller($window, $state)
    {
        var vm = this;

        // Methods

        vm.goBack = function() {
            $state.go('app.dashboard_home')
        }

        //////////
    }
})();
