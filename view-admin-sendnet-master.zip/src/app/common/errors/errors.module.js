(function ()
{
    'use strict';

    angular
        .module('app.errors', [
            'app.errors.error',
            'app.errors.error-403',
            'app.errors.error-404',
            'app.errors.error-500'
        ])
        .config(config);

    /** @ngInject */
    function config()
    {

    }
})();
