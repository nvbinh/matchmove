(function ()
{
    'use strict';

    angular
        .module('app.errors.error-500')
        .controller('Error500Controller', Error500Controller);

    /** @ngInject */
    function Error500Controller($window)
    {
        var vm = this;
        // Data

        // Methods

        vm.goBack = function() {
            $window.history.back();
        }

        //////////
    }
})();
