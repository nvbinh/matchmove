(function ()
{
    'use strict';

    angular
        .module('app.errors.error')
        .controller('ErrorController', ErrorController);

    /** @ngInject */
    function ErrorController($rootScope, store)
    {
        // Data
        var vm = this;
        vm.errorMessage = store.get('error').message;
        vm.lastPageVisited = store.get('error').last_page_visited;

        // Methods

        //////////
    }
})();
