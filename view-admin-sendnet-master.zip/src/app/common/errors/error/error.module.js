(function ()
{
    'use strict';

    angular
        .module('app.errors.error', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.errors_error', {
            url      : '/errors/error',
            views    : {
                'main@'                             : {
                    templateUrl: 'app/core/layouts/content-only.html',
                    controller : 'MainController as vm'
                },
                'content@app.errors_error': {
                    templateUrl: 'app/common/errors/error/error.html',
                    controller : 'ErrorController as vm'
                }
            },
            bodyClass: 'error'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/common/errors/error');
    }
})();
