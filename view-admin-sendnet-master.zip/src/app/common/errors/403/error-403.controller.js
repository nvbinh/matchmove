(function ()
{
    'use strict';

    angular
        .module('app.errors.error-403')
        .controller('Error403Controller', Error403Controller);

    /** @ngInject */
    function Error403Controller($window, $state)
    {
        var vm = this;

        // Methods

        vm.goBack = function() {
            $window.history.back();
        }

        //////////
    }
})();
