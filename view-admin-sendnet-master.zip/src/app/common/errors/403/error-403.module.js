(function ()
{
    'use strict';

    angular
        .module('app.errors.error-403', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider)
    {
        // State
        $stateProvider.state('app.errors_error-403', {
            url      : '/errors/error-403',
            views    : {
                'main@'                             : {
                    templateUrl: 'app/core/layouts/content-only.html',
                    controller : 'MainController as vm'
                },
                'content@app.errors_error-403': {
                    templateUrl: 'app/common/errors/403/error-403.html',
                    controller : 'Error403Controller as vm'
                }
            },
            bodyClass: 'error-403'
        });

        // Translation
        $translatePartialLoaderProvider.addPart('app/common/errors/403');
    }

})();
