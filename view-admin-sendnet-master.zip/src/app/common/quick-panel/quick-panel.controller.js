(function ()
{
    'use strict';

    angular
        .module('app.quick-panel')
        .controller('QuickPanelController', QuickPanelController);

    /** @ngInject */
    function QuickPanelController($q, $scope, msApi, API_BASE, store)
    {
        var vm = this;
        // Data
        vm.date = new Date();
        vm.settings = {
            notify: true,
            cloud : false,
            retro : true
        };

        // var access_token = store.get('token_data').access_token;
        msApi.setBaseUrl(API_BASE);

        vm.parseResponse = function(str) {
          return JSON.parse(str);
        }

        vm.activityapiUrl = 'api/admins/{admin_id}/activities';
        msApi.register('adminactivity.list', [vm.activityapiUrl]);

        vm.adminapiUrl = 'api/admins';
        msApi.register('admin.list', [vm.adminapiUrl]);

        msApi.request('adminactivity.list@get',
            // SUCCESS
            function (success)
            {
              vm.adminactivityList = success.data.response;
            },
            // ERROR
            function (error)
            {
                console.error(error.data)
            }
        );

        msApi.request('admin.list@get',
            // SUCCESS
            function (success)
            {
                vm.adminList = success.data.response;
                console.log(vm.adminList);
            },
            // ERROR
            function (error)
            {
                console.error(error.data)
            }
        );

        // Methods


        //////////
    }

})();
