(function ()
{
    'use strict';

    angular
        .module('admin')
        .factory('api', apiService);

    /** @ngInject */
    function apiService($resource, API_BASE, store, $state, $http)
    {
        /**
         *  For more information about how this works, visit:
         *  http://withinpixels.com/themes/fuse/documentation/working-with-fuse/fuse/api-services/method-1
         */

        var api = {};
        var token_data = {};

        // Base Url
        api.baseUrl = API_BASE;

        // OAUTH + Admin API
        api.oauth = {
            access_token: $resource(api.baseUrl + 'oauth/access_token', null,
                {
                    post: {
                        method: 'POST'
                    }
                }
            ),
        }

        // Wallets API
        api.wallets = {
            list     : $resource(api.baseUrl + 'api/users/wallets', null,
                {
                    get: {
                        method: 'GET'
                    }
                }
            ),
        }

        api.loyalties = {
          list     : $resource(api.baseUrl + 'api/users/loyalties', null,
              {
                  get: {
                      method: 'GET'
                  }
              }
          ),

        }
        // Cards API
        api.cards = {
            list     : $resource(api.baseUrl + 'api/users/wallets/cards', null,
                {
                    get: {
                        method: 'GET'
                    }
                }
            ),
        }

        // Users API
        api.users = {
            list    : $resource(api.baseUrl + 'api/users/', null,
                {
                    get: {
                        method: 'GET'
                    }
                })
        }

        // Transactions API
        api.transactions = {
            list    : $resource(api.baseUrl + 'api/users/transactions', null,
                {
                    get: {
                        method: 'GET'
                    }
                })
        }

        // Activities API
        api.activities = {
            list    : $resource(api.baseUrl + 'api/users/{user_id}/activities', null,
                {
                    get: {
                        method: 'GET',
                        params:{
                            "first_name":"",
                            "last_name":"",
                            "admin_id":"",
                            "email":"",
                            "status":"",
                            "category_id":"",
                            "from_date":"",
                            "to_date":"",
                            "sort_by":"",
                            "sort_type":"DESC",
                            "page":"",
                            "records_per_page":"",
                          }
                    }
                }),
            listById    : $resource(api.baseUrl + 'api/users/:id/activities', {id:'@id'},
                {
                    get: {
                        method: 'GET'
                    }
                })
        }
        api.admins = {
            list    : $resource(api.baseUrl + 'api/admins', null,
                {
                    get: {
                        method: 'GET'
                    }
                }),
            captcha    : $resource(api.baseUrl + 'api/admins/create', null,
                {
                    get: {
                        method: 'GET'
                    }
                })
        }
        api.adminActivities = {
            list    : $resource(api.baseUrl + 'api/admins/{admin_id}/activities', null,
                {
                    get: {
                        method: 'GET',
                        params:{
                            "first_name":"",
                            "last_name":"",
                            "admin_id":"",
                            "email":"",
                            "status":"",
                            "category_id":"",
                            "from_date":"",
                            "to_date":"",
                            "sort_by":"",
                            "sort_type":"DESC",
                            "page":"",
                            "records_per_page":"",
                          }
                    }
                }),
            listById    : $resource(api.baseUrl + 'api/admins/:id/activities', {id:'@id'},
                {
                    get: {
                        method: 'GET'
                    }
                })
        }

        api.prefundingBalance = {
            list    : $resource(api.baseUrl + 'api/remittance/prefunding/all', null,
                {
                    get: {
                        method: 'GET'
                    }
                })
        }

        return api;
    }

})();
