(function() {
    'use strict';

    angular
        .module('admin')
        .run(runBlock);

    /** @ngInject */
    function runBlock($rootScope, $timeout, $state, $interval, store, Idle, ngProgressFactory, mmPermission, authSession, PermPermissionStore, formlyConfig, msNavigationService, PERMISSIONS, SdPermissions) {
        formlyConfig.setType({
            name: 'select',
            template: '<md-input-container><md-select ng-model="model[options.key]"><md-option ng-repeat="type in to.options" value="{{type.id}}">{{type.name}}</md-option></md-select></md-input-container>'
        });

        formlyConfig.setType({
            name: 'ccy-select',
            template: '<md-input-container><md-select ng-model="model[options.key]"><md-option ng-repeat="type in to.options" value="{{type.code}}">{{type.name}}</md-option></md-select></md-input-container>'
        });

        formlyConfig.setType({
            name: 'payout-select',
            template: '<md-input-container><md-select ng-model="model[options.key]"><md-option ng-repeat="type in to.options" value="{{type.id}}">{{type.payout_destination}}</md-option></md-select></md-input-container>'
        });

        $rootScope.progressbar = ngProgressFactory.createInstance();
        $rootScope.progressbar.setColor("#09f");

        // Activate loading indicator
        // Check the permissions
        var stateChangeStartEvent = $rootScope.$on('$stateChangeStart', function(evt, toState, toParams, fromState, fromParams) {
            $rootScope.loadingProgress = true;
            $rootScope.progressbar.start();

            var permissions = PermPermissionStore.getStore();
            if (!store.get('permission_ids') && Object.keys(permissions).length == 0 ) {
                if (!(toState.name.indexOf('auth_') > -1)) {
                    mmPermission.initialize();
                    authSession.storePermissionId();

                    $rootScope.$broadcast('authorized');
                }
            } else {
                if ((toState.name.indexOf('auth_') === -1)) {
                    mmPermission.reInitialize();
                    SdPermissions.checkPermissions();
                }
            }

        });

        // De-activate loading indicator
        var stateChangeSuccessEvent = $rootScope.$on('$stateChangeSuccess', function(evt, toState, toParams, fromState, fromParams) {

            var permissions = PermPermissionStore.getStore();
            if (!store.get('permission_ids') && Object.keys(permissions).length == 0 ) {
                if (!(toState.name.indexOf('auth_') > -1)) {
                    mmPermission.initialize();
                    authSession.storePermissionId();

                    $rootScope.$broadcast('authorized');
                }
            } else {
                if ((toState.name.indexOf('auth_') === -1)) {
                    mmPermission.reInitialize();
                    SdPermissions.checkPermissions();
                }
            }

            if(store.get('token_data') === null){
              $rootScope.$broadcast('unauthorized');
            }

            $timeout(function() {
                $rootScope.loadingProgress = false;
                $rootScope.progressbar.complete();
            });
        });

        // Store state in the root scope for easy access
        $rootScope.state = $state;

        // Cleanup
        $rootScope.$on('$destroy', function() {
            stateChangeStartEvent();
            stateChangeSuccessEvent();
        });


        // set the timer after token expiration remove the token_data
        $rootScope.$on('authenticated', function(event, message) {
            var token_data = store.get('token_data');

            $timeout(function() {
                $rootScope.loadingProgress = false;
                store.remove('token_data');
            }, token_data.expires_in * 1000);

        });


        // Check token_data if not existing then
        // redirect to login page and kill the interval
        $rootScope.$on('userLoggedOut', function(event, message) {
            $state.go('app.auth_login');
            window.location.reload(true);
            Idle.unwatch();
        });

        if (store.get('token_data')) {
            Idle.watch();
        }

    }
})();
