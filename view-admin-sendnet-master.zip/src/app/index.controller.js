(function ()
{
    'use strict';

    angular
        .module('admin')
        .controller('IndexController', IndexController);

    /** @ngInject */
    function IndexController(appTheming, BRANDING, Idle, $state, $rootScope, store, $timeout, $location, PermPermissionStore, msNavigationService, PERMISSIONS, SdPermissions, $mdDialog)
    {
        var vm = this;
        vm.branding = BRANDING;
        // Data
        vm.themes = appTheming.themes;

        //////////
        // $rootScope.$on('IdleStart', function() {
        //     // the user appears to have gone idle
        //     Idle.watch();
        // });

        $rootScope.$on('IdleWarn', function(e, countdown) {
            // follows after the IdleStart event, but includes a countdown until the user is considered timed out
            // the countdown arg is the number of seconds remaining until then.
            // you can change the title or display a warning dialog from here.
            // you can let them resume their session by calling Idle.watch()
            store.remove('token_data');
            $state.go('app.auth_lock');
        });

        $rootScope.$on('IdleTimeout', function() {
            // the user has timed out (meaning idleDuration + timeout has passed without any activity)
            // this is where you'd log them
            $state.go('app.auth_login')
        });

        $rootScope.$on('IdleEnd', function() {
            // the user has come back from AFK and is doing stuff. if you are warning them, you can use this to hide the dialog
            // Idle.watch();
            $mdDialog.hide();
        });

        $rootScope.$on('unauthorized', function(event, message) {
            if (!$state.is('app.auth_lock') && !$state.is('app.auth_forgot-password')) {
                store.remove('token_data');
                store.remove('username');
                store.remove('permission_ids');
                $state.go('app.auth_login')
            }
        });

        if (!$state.is('app.auth_lock') || !$state.is('app.auth_login')) {
            $timeout(function(){
                store.remove('token_data');
                $state.go('app.auth_lock');
            }, 900 * 1000)
        }

        // users - used by reset password
        // token_data & username - set by auth
        if (!$state.is('app.auth_verify') && $location.path() !== '/auth/verify') {
            if (( !store.get('username') && !store.get('token_data') && !store.get('users') )) {
                $state.go('app.auth_login');
            }
        }

    }
})();
