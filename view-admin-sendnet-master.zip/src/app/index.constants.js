(function ()
{
    'use strict';

    angular
        .module('admin')
        
        .constant('API_BASE', "https://sgmc-sd-api-uat.mmvpay.com/")
    
        .constant('HTTP_HOST', "https://sgmc-sd-api-uat.mmvpay.com/")
    
        .constant('RESET_PASSWORD_ENDPOINT', "auth/reset-password")
    
        .constant('USER_VERIFY_ENDPOINT', "auth/verify")
    
        .constant('CLIENT_ID', "f3d259ddd3ed8ff3843839b")
    
        .constant('CLIENT_SECRET', "4c7f6f8fa93d59c45502c0ae8c4a95b")
    
        .constant('GRANT_TYPE', "password")
    
        .constant('DEFAULT_CLIENT', "sgmc")
    
        .constant('CARDHOLDER_CONSTANTS', {
	"status": [
		"inactive",
		"active",
		"pending activation",
		"locked"
	],
	"datatable_heading": [
		"ID",
		"Hash ID",
		"Processor Ref ID",
		"Status",
		"Email",
		"Birthday",
		"User Type",
		"Gender",
		"Title",
		"Date Added",
		"Name",
		"Mobile",
		"Identification"
	]
})
    
        .constant('WALLET_CONSTANTS', {
	"status": [
		"inactive",
		"active",
		"pending activation",
		"locked"
	],
	"datatable_heading": [
		"User ID",
		"Card ID",
		"Hash ID",
		"Processor Ref ID",
		"Status",
		"Proxy Number",
		"Card Number",
		"Date Added",
		"Name",
		"Authentication",
		"Balance"
	]
})
    
        .constant('CARD_CONSTANTS', {
	"card_types": [
		"havmcpcard"
	],
	"card_status": [
		"inactive",
		"active",
		"pending activation",
		"locked"
	],
	"datatable_heading": [
		"User ID",
		"Card Number",
		"Proxy Number",
		"Card ID",
		"Hash ID",
		"Processor Ref ID",
		"Card Status",
		"Card Type",
		"Balance"
	]
})
    
        .constant('DOCUMENTS_CONSTANTS', {
	"status": [
		"Credit",
		"debit"
	],
	"document_status": [
		"Transfer",
		"Topups",
		"Debits",
		"Credits",
		"Refunds"
	],
	"document_verification": [
		"Transfer",
		"Topups",
		"Debits",
		"Credits",
		"Refunds"
	],
	"datatable_heading": [
		"User ID",
		"Date",
		"Full Name",
		"Email",
		"Mobile Number",
		"Account Status"
	]
})
    
        .constant('CANCELLATION_CONSTANTS', {
	"cancellation_pending_heading": [
		"ID",
		"Date Added",
		"Date Expiry",
		"Date Cancellation Added",
		"Provider",
		"Delivery Method",
		"Send Amount",
		"Receive Amount",
		"Status"
	],
	"cancellation_history_heading": [
		"ID",
		"Date Added",
		"Date Expiry",
		"Provider",
		"Delivery Method",
		"Send Amount",
		"Receive Amount",
		"Status",
		"Cancellation Submission",
		"Date Cancellation Added",
		"Date Confirmed"
	],
	"csv_cancellation_datatable_heading": [
		"Provider",
		"Routing Params",
		"Reference ID",
		"Transaction Code",
		"Hash ID",
		"Type",
		"Status Code",
		"Status Text",
		"Date Added",
		"Date Expiry",
		"Send Amount",
		"Send Currency",
		"Receive Amount",
		"Receive Currency",
		"Receive Country",
		"Total Transaction Amount",
		"Provider Exchange Rate",
		"Provider Fixed Fee",
		"Customer FX%",
		"Crossrate",
		"Provider Amount Fee",
		"Provider Amount Fee Currency",
		"Delivery Method",
		"Payout Agent",
		"Customer Fixed Fee",
		"Provider Amount to Send Currency",
		"Actual Provider Amount to Send Currency",
		"Send Amount Before FX%",
		"Send Amount After FX%"
	],
	"cancellation_status": [
		"approved",
		"rejected",
		"inactive"
	],
	"transaction_status": [
		"processing",
		"transfer pending",
		"transfer failed",
		"refund failed",
		"refund succeeded",
		"available",
		"paid",
		"cancelled",
		"cancelled by user",
		"rejected"
	]
})
    
        .constant('TRANSACTION_CONSTANTS', {
	"type": [
		"Credit",
		"debit"
	],
	"transaction_types": [
		"Transfer",
		"Topups",
		"Debits",
		"Credits",
		"Refunds"
	],
	"datatable_heading": [
		"User ID",
		"Email",
		"Mobile",
		"Card Proxy Number",
		"Processor Ref ID",
		"Card Number",
		"Billing Amount Debit",
		"Billing Amount Credit",
		"Debit Credit Indicator",
		"Debit Credit Indicator Text",
		"Merchant Name",
		"MCC",
		"Terminal ID",
		"Description",
		"Transaction Date",
		"Card Balance",
		"Transaction Amount",
		"Transaction Ref Number",
		"Transaction Status",
		"Transaction Type",
		"Ref ID",
		"Ref Table"
	],
	"log_datatable_heading": [
		"No.",
		"Date Added",
		"Date Expiry",
		"Payment Mode",
		"Routing Type",
		"Routing Param",
		"Transaction Hash ID",
		"Transaction Code",
		"Reference Number",
		"Consumer Name",
		"Calculation Mode",
		"Amount To Send",
		"Amount To Receive",
		"Available Balance",
		"Total Transaction Amount",
		"Sender Currency",
		"Recepient Currency",
		"Recepient Country",
		"Rail Fixed Fee",
		"User Fixed Fee",
		"Rail FX%",
		"User FX%",
		"Cross rate",
		"Channel",
		"Base Channel Fees",
		"Channel Markup",
		"Net Channel Fee",
		"First Name",
		"Last Name",
		"City"
	],
	"prefunding_datatable_heading": [
		"ID",
		"Name",
		"Code",
		"Description",
		"Details",
		"Status",
		"Date Added",
		"Last Prefunding Amount",
		"Rate As Of Last Prefunding",
		"Last Prefunding Date",
		"Last Prefunding Currency From",
		"Last Prefunding Currency To",
		"Currency Prefund Balance",
		"Last Update Date",
		"Last Updated By",
		"Prefund Source",
		"Transaction Type"
	],
	"transaction_datatable_heading": [
		"ID",
		"Date Added",
		"Date Expiry",
		"Provider",
		"Delivery Method",
		"Send Amount",
		"Receive Amount",
		"Status",
		"Status Last Updated",
		"Cancellation Submission"
	],
	"csv_transaction_datatable_heading": [
		"Provider",
		"Routing Params",
		"Reference ID",
		"Transaction Code",
		"Hash ID",
		"Type",
		"Status Code",
		"Status Text",
		"Date Added",
		"Date Expiry",
		"Status Last Updated",
		"Send Amount",
		"Send Currency",
		"Receive Amount",
		"Receive Currency",
		"Receive Country",
		"Total Transaction Amount",
		"Provider Exchange Rate",
		"Provider Fixed Fee",
		"Customer FX%",
		"Crossrate",
		"Provider Amount Fee",
		"Provider Amount Fee Currency",
		"Delivery Method",
		"Payout Agent",
		"Customer Fixed Fee",
		"Provider Amount to Send Currency",
		"Actual Provider Amount to Send Currency",
		"Send Amount Before FX%",
		"Send Amount After FX%"
	]
})
    
        .constant('LOYALTY_CONSTANTS', {
	"type": [
		"Topups"
	],
	"accounting_types": [
		"debit",
		"credit"
	],
	"datatable_heading": [
		"Total Points",
		"User ID",
		"Email",
		"Processor Ref ID",
		"Status",
		"Date Added",
		"Mobile",
		"Points",
		"Loyalty Type",
		"Accounting Type",
		"Description"
	]
})
    
        .constant('PREFUND_CONSTANTS', {
	"datatable_heading": [
		"ID",
		"Date Created",
		"Client",
		"Prefund Amount",
		"Note",
		"Prefund Status"
	],
	"history_datatable_heading": [
		"ID",
		"Date Created",
		"Client",
		"Last Prefund Amount",
		"Total Prefund to Date",
		"Prefund Status"
	],
	"csv_datatable_heading": [
		"ID",
		"Date Created",
		"Client",
		"Prefund Amount",
		"Note",
		"Prefund Status"
	],
	"balance_datatable_heading": [
		"ID",
		"Client",
		"Prefund Balance",
		"Date Processed"
	]
})
    
        .constant('FX_COST_CONSTANTS', {
	"datatable_heading": [
		"Bank Code",
		"Base Value",
		"Delivery Method",
		"Flow Type",
		"Fx Rate",
		"Payout Agent",
		"Prefunding Currency",
		"Rail",
		"Rail Fixed Fee Cost",
		"Rail Fixed Fee Cost CCY",
		"Rail Fixed Fee Cost Id",
		"Rail Status",
		"Receiving Country",
		"Receiving Currency"
	]
})
    
        .constant('CROSS_RATE_CONSTANTS', {
	"datatable_heading_list": [
		"ID",
		"Date Created",
		"Date Updated",
		"From Currency",
		"To Currency",
		"Rate",
		"Status"
	],
	"datatable_heading_approval": [
		"ID",
		"Date Created",
		"From Currency",
		"To Currency",
		"Rate",
		"Status"
	],
	"datatable_heading_history": [
		"ID",
		"Date Created",
		"Date Updated",
		"From Currency",
		"To Currency",
		"Rate",
		"Status"
	],
	"history_status": [
		"approved",
		"rejected",
		"active"
	]
})
    
        .constant('PAYOUT_AGENT_CONSTANTS', {
	"datatable_heading_list": [
		"Provider",
		"Payout Agent",
		"Name",
		"Code",
		"Branch Name",
		"Branch Code",
		"Date Created"
	],
	"datatable_heading_history": [
		"Provider",
		"Payout Agent",
		"Name",
		"Code",
		"Branch Name",
		"Branch Code",
		"Date Created"
	],
	"history_status": [
		"approved",
		"rejected",
		"inactive",
		"active"
	]
})
    
        .constant('FIXEDFEE_CONSTANTS', {
	"fixedfee_history": [
		"No.",
		"Status",
		"Channel Id",
		"Country Id",
		"Provider Id",
		"Payput Destination Id",
		"Markup Percentage",
		"Markup Value",
		"Created Date",
		"Active"
	],
	"fixedfee_confirm": [
		"No.",
		"Status",
		"Channel Id",
		"Country Id",
		"Provider Id",
		"Payput Destination Id",
		"Markup Percentage",
		"Markup Value",
		"Created Date",
		"Active"
	]
})
    
        .constant('ADMINISTRATION_CONSTANTS', {
	"activity_types": [
		{
			"id": 1,
			"name": "XYZ"
		},
		{
			"id": 2,
			"name": "DAsds"
		},
		{
			"id": 3,
			"name": "Dasd "
		}
	],
	"datatable_heading": [
		"ID",
		"Admin ID",
		"Category ID",
		"Category Name",
		"Details",
		"Created At",
		"Updated At",
		"First Name",
		"Last Name",
		"Email"
	]
})
    
        .constant('TOPUP_PREFUND_CONSTANTS', {
	"datatable_heading": [
		"ID",
		"Client",
		"Last Prefund Amount",
		"Total Prefund to Date",
		"Prefund Status"
	]
})
    
        .constant('PRICING_CONSTANTS', {
	"datatable_heading": [
		"ID",
		"Provider",
		"Delivery Method",
		"Payout Agent",
		"Receive Country",
		"Customer Fixed Fee",
		"Customer FX%",
		"Status"
	],
	"list_datatable_heading": [
		"ID",
		"Provider",
		"Delivery Method",
		"Payout Agent",
		"Receive Country",
		"Customer Fixed Fee",
		"Customer FX%"
	],
	"csv_list_datatable_heading": [
		"ID",
		"Provider",
		"Delivery Method",
		"Payout Agent",
		"Receive Country",
		"Customer Fixed Fee",
		"Customer FX%"
	],
	"csv_history_datatable_heading": [
		"ID",
		"Provider",
		"Delivery Method",
		"Payout Agent",
		"Receive Country",
		"Customer Fixed Fee",
		"Customer FX%",
		"Status"
	],
	"csv_approval_datatable_heading": [
		"ID",
		"Provider",
		"Delivery Method",
		"Payout Agent",
		"Receive Country",
		"Customer Fixed Fee",
		"Customer FX%",
		"Status"
	]
})
    
        .constant('BRANDING', {
	"name": "MatchMove",
	"product": "SendNet",
	"colorPrimary": "#09f",
	"colorAccent": "#09f",
	"logo": "http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png",
	"loadingColor": "#09f",
	"logo_image": "S"
})
    
        .constant('PERMISSIONS', {})
    
        .constant('APP_TYPE', {})
    
        .constant('DELIVERY_METHODS', [
	{
		"id": 0,
		"code": "",
		"name": "All"
	},
	{
		"id": 1,
		"code": "Forex",
		"name": "Foreign Exchange (Forex)"
	},
	{
		"id": 2,
		"code": "OF",
		"name": "Cash Pickup (OF)"
	},
	{
		"id": 3,
		"code": "MBP",
		"name": "Mobile Payment (MBP)"
	},
	{
		"id": 4,
		"code": "HD",
		"name": "Home Delivery (HD)"
	},
	{
		"id": 5,
		"code": "BA",
		"name": "Bank Deposit (BA)"
	},
	{
		"id": 6,
		"code": "BAN",
		"name": "Bank Deposit (BAN)"
	},
	{
		"id": 7,
		"code": "IBAN",
		"name": "Bank Deposit (IBAN)"
	},
	{
		"id": 8,
		"code": "EWALLET",
		"name": "E-Wallet (EWALLET)"
	},
	{
		"id": 9,
		"code": "MWALLET",
		"name": "Mobile Wallet (MWALLET)"
	},
	{
		"id": 10,
		"code": "WILL_CALL",
		"name": "Mobile Wallet (WILL_CALL)"
	},
	{
		"id": 11,
		"code": "HOME_DELIVERY",
		"name": "Home Delivery (HOME_DELIVERY)"
	},
	{
		"id": 12,
		"code": "BANK_DEPOSIT",
		"name": "Bank Deposit (BANK_DEPOSIT)"
	}
])
    
        .constant('PROVIDERS', {
	"homesend": {
		"": "All",
		"MWALLET": "Mobile Payment",
		"EWALLET": "Electronic Wallet",
		"BAN": "Bank Deposit (BAN)"
	},
	"moneygram": {
		"": "All",
		"WILL_CALL": "Cash Pickup",
		"BANK_DEPOSIT": "Bank Account",
		"LTD_WILLCALL": "Cash Pickup Agents",
		"HOME_DELIVERY": "Home Delivery"
	},
	"transferto": {
		"": "All",
		"BA": "Bank Deposit (BA)",
		"MBP": "Mobile Payment",
		"OF": "Cash Pickup",
		"HD": "Home Delivery",
		"FS": "Family Support",
		"PPC": "Prepaid / Cash Card (PPC)",
		"PPR": "Prepaid / Cash Card (reload / topup ) (PPR)",
		"SSS": "Social Security System (loan) (SSS)",
		"SSR": "Social Security System (reloan) (SSR)",
		"SSP": "Social Security System payments "
	}
})
    
        .constant('COUNTRIES', [
	{
		"name": "All",
		"code": "",
		"country-code": ""
	},
	{
		"name": "Afghanistan",
		"code": "AFG",
		"country-code": "004"
	},
	{
		"name": "Åland Islands",
		"code": "ALA",
		"country-code": "248"
	},
	{
		"name": "Albania",
		"code": "ALB",
		"country-code": "008"
	},
	{
		"name": "Algeria",
		"code": "DZA",
		"country-code": "012"
	},
	{
		"name": "American Samoa",
		"code": "ASM",
		"country-code": "016"
	},
	{
		"name": "Andorra",
		"code": "AND",
		"country-code": "020"
	},
	{
		"name": "Angola",
		"code": "AGO",
		"country-code": "024"
	},
	{
		"name": "Anguilla",
		"code": "AIA",
		"country-code": "660"
	},
	{
		"name": "Antarctica",
		"code": "ATA",
		"country-code": "010"
	},
	{
		"name": "Antigua and Barbuda",
		"code": "ATG",
		"country-code": "028"
	},
	{
		"name": "Argentina",
		"code": "ARG",
		"country-code": "032"
	},
	{
		"name": "Armenia",
		"code": "ARM",
		"country-code": "051"
	},
	{
		"name": "Aruba",
		"code": "ABW",
		"country-code": "533"
	},
	{
		"name": "Australia",
		"code": "AUS",
		"country-code": "036"
	},
	{
		"name": "Austria",
		"code": "AUT",
		"country-code": "040"
	},
	{
		"name": "Azerbaijan",
		"code": "AZE",
		"country-code": "031"
	},
	{
		"name": "Bahamas",
		"code": "BHS",
		"country-code": "044"
	},
	{
		"name": "Bahrain",
		"code": "BHR",
		"country-code": "048"
	},
	{
		"name": "Bangladesh",
		"code": "BGD",
		"country-code": "050"
	},
	{
		"name": "Barbados",
		"code": "BRB",
		"country-code": "052"
	},
	{
		"name": "Belarus",
		"code": "BLR",
		"country-code": "112"
	},
	{
		"name": "Belgium",
		"code": "BEL",
		"country-code": "056"
	},
	{
		"name": "Belize",
		"code": "BLZ",
		"country-code": "084"
	},
	{
		"name": "Benin",
		"code": "BEN",
		"country-code": "204"
	},
	{
		"name": "Bermuda",
		"code": "BMU",
		"country-code": "060"
	},
	{
		"name": "Bhutan",
		"code": "BTN",
		"country-code": "064"
	},
	{
		"name": "Bolivia (Plurinational State of)",
		"code": "BOL",
		"country-code": "068"
	},
	{
		"name": "Bonaire, Sint Eustatius and Saba",
		"code": "BES",
		"country-code": "535"
	},
	{
		"name": "Bosnia and Herzegovina",
		"code": "BIH",
		"country-code": "070"
	},
	{
		"name": "Botswana",
		"code": "BWA",
		"country-code": "072"
	},
	{
		"name": "Bouvet Island",
		"code": "BVT",
		"country-code": "074"
	},
	{
		"name": "Brazil",
		"code": "BRA",
		"country-code": "076"
	},
	{
		"name": "British Indian Ocean Territory",
		"code": "IOT",
		"country-code": "086"
	},
	{
		"name": "Brunei Darussalam",
		"code": "BRN",
		"country-code": "096"
	},
	{
		"name": "Bulgaria",
		"code": "BGR",
		"country-code": "100"
	},
	{
		"name": "Burkina Faso",
		"code": "BFA",
		"country-code": "854"
	},
	{
		"name": "Burundi",
		"code": "BDI",
		"country-code": "108"
	},
	{
		"name": "Cambodia",
		"code": "KHM",
		"country-code": "116"
	},
	{
		"name": "Cameroon",
		"code": "CMR",
		"country-code": "120"
	},
	{
		"name": "Canada",
		"code": "CAN",
		"country-code": "124"
	},
	{
		"name": "Cabo Verde",
		"code": "CPV",
		"country-code": "132"
	},
	{
		"name": "Cayman Islands",
		"code": "CYM",
		"country-code": "136"
	},
	{
		"name": "Central African Republic",
		"code": "CAF",
		"country-code": "140"
	},
	{
		"name": "Chad",
		"code": "TCD",
		"country-code": "148"
	},
	{
		"name": "Chile",
		"code": "CHL",
		"country-code": "152"
	},
	{
		"name": "China",
		"code": "CHN",
		"country-code": "156"
	},
	{
		"name": "Christmas Island",
		"code": "CXR",
		"country-code": "162"
	},
	{
		"name": "Cocos (Keeling) Islands",
		"code": "CCK",
		"country-code": "166"
	},
	{
		"name": "Colombia",
		"code": "COL",
		"country-code": "170"
	},
	{
		"name": "Comoros",
		"code": "COM",
		"country-code": "174"
	},
	{
		"name": "Congo",
		"code": "COG",
		"country-code": "178"
	},
	{
		"name": "Congo (Democratic Republic of the)",
		"code": "COD",
		"country-code": "180"
	},
	{
		"name": "Cook Islands",
		"code": "COK",
		"country-code": "184"
	},
	{
		"name": "Costa Rica",
		"code": "CRI",
		"country-code": "188"
	},
	{
		"name": "Côte d'Ivoire",
		"code": "CIV",
		"country-code": "384"
	},
	{
		"name": "Croatia",
		"code": "HRV",
		"country-code": "191"
	},
	{
		"name": "Cuba",
		"code": "CUB",
		"country-code": "192"
	},
	{
		"name": "Curaçao",
		"code": "CUW",
		"country-code": "531"
	},
	{
		"name": "Cyprus",
		"code": "CYP",
		"country-code": "196"
	},
	{
		"name": "Czech Republic",
		"code": "CZE",
		"country-code": "203"
	},
	{
		"name": "Denmark",
		"code": "DNK",
		"country-code": "208"
	},
	{
		"name": "Djibouti",
		"code": "DJI",
		"country-code": "262"
	},
	{
		"name": "Dominica",
		"code": "DMA",
		"country-code": "212"
	},
	{
		"name": "Dominican Republic",
		"code": "DOM",
		"country-code": "214"
	},
	{
		"name": "Ecuador",
		"code": "ECU",
		"country-code": "218"
	},
	{
		"name": "Egypt",
		"code": "EGY",
		"country-code": "818"
	},
	{
		"name": "El Salvador",
		"code": "SLV",
		"country-code": "222"
	},
	{
		"name": "Equatorial Guinea",
		"code": "GNQ",
		"country-code": "226"
	},
	{
		"name": "Eritrea",
		"code": "ERI",
		"country-code": "232"
	},
	{
		"name": "Estonia",
		"code": "EST",
		"country-code": "233"
	},
	{
		"name": "Ethiopia",
		"code": "ETH",
		"country-code": "231"
	},
	{
		"name": "Falkland Islands (Malvinas)",
		"code": "FLK",
		"country-code": "238"
	},
	{
		"name": "Faroe Islands",
		"code": "FRO",
		"country-code": "234"
	},
	{
		"name": "Fiji",
		"code": "FJI",
		"country-code": "242"
	},
	{
		"name": "Finland",
		"code": "FIN",
		"country-code": "246"
	},
	{
		"name": "France",
		"code": "FRA",
		"country-code": "250"
	},
	{
		"name": "French Guiana",
		"code": "GUF",
		"country-code": "254"
	},
	{
		"name": "French Polynesia",
		"code": "PYF",
		"country-code": "258"
	},
	{
		"name": "French Southern Territories",
		"code": "ATF",
		"country-code": "260"
	},
	{
		"name": "Gabon",
		"code": "GAB",
		"country-code": "266"
	},
	{
		"name": "Gambia",
		"code": "GMB",
		"country-code": "270"
	},
	{
		"name": "Georgia",
		"code": "GEO",
		"country-code": "268"
	},
	{
		"name": "Germany",
		"code": "DEU",
		"country-code": "276"
	},
	{
		"name": "Ghana",
		"code": "GHA",
		"country-code": "288"
	},
	{
		"name": "Gibraltar",
		"code": "GIB",
		"country-code": "292"
	},
	{
		"name": "Greece",
		"code": "GRC",
		"country-code": "300"
	},
	{
		"name": "Greenland",
		"code": "GRL",
		"country-code": "304"
	},
	{
		"name": "Grenada",
		"code": "GRD",
		"country-code": "308"
	},
	{
		"name": "Guadeloupe",
		"code": "GLP",
		"country-code": "312"
	},
	{
		"name": "Guam",
		"code": "GUM",
		"country-code": "316"
	},
	{
		"name": "Guatemala",
		"code": "GTM",
		"country-code": "320"
	},
	{
		"name": "Guernsey",
		"code": "GGY",
		"country-code": "831"
	},
	{
		"name": "Guinea",
		"code": "GIN",
		"country-code": "324"
	},
	{
		"name": "Guinea-Bissau",
		"code": "GNB",
		"country-code": "624"
	},
	{
		"name": "Guyana",
		"code": "GUY",
		"country-code": "328"
	},
	{
		"name": "Haiti",
		"code": "HTI",
		"country-code": "332"
	},
	{
		"name": "Heard Island and McDonald Islands",
		"code": "HMD",
		"country-code": "334"
	},
	{
		"name": "Holy See",
		"code": "VAT",
		"country-code": "336"
	},
	{
		"name": "Honduras",
		"code": "HND",
		"country-code": "340"
	},
	{
		"name": "Hong Kong",
		"code": "HKG",
		"country-code": "344"
	},
	{
		"name": "Hungary",
		"code": "HUN",
		"country-code": "348"
	},
	{
		"name": "Iceland",
		"code": "ISL",
		"country-code": "352"
	},
	{
		"name": "India",
		"code": "IND",
		"country-code": "356"
	},
	{
		"name": "Indonesia",
		"code": "IDN",
		"country-code": "360"
	},
	{
		"name": "Iran (Islamic Republic of)",
		"code": "IRN",
		"country-code": "364"
	},
	{
		"name": "Iraq",
		"code": "IRQ",
		"country-code": "368"
	},
	{
		"name": "Ireland",
		"code": "IRL",
		"country-code": "372"
	},
	{
		"name": "Isle of Man",
		"code": "IMN",
		"country-code": "833"
	},
	{
		"name": "Israel",
		"code": "ISR",
		"country-code": "376"
	},
	{
		"name": "Italy",
		"code": "ITA",
		"country-code": "380"
	},
	{
		"name": "Jamaica",
		"code": "JAM",
		"country-code": "388"
	},
	{
		"name": "Japan",
		"code": "JPN",
		"country-code": "392"
	},
	{
		"name": "Jersey",
		"code": "JEY",
		"country-code": "832"
	},
	{
		"name": "Jordan",
		"code": "JOR",
		"country-code": "400"
	},
	{
		"name": "Kazakhstan",
		"code": "KAZ",
		"country-code": "398"
	},
	{
		"name": "Kenya",
		"code": "KEN",
		"country-code": "404"
	},
	{
		"name": "Kiribati",
		"code": "KIR",
		"country-code": "296"
	},
	{
		"name": "Korea (Democratic People's Republic of)",
		"code": "PRK",
		"country-code": "408"
	},
	{
		"name": "Korea (Republic of)",
		"code": "KOR",
		"country-code": "410"
	},
	{
		"name": "Kuwait",
		"code": "KWT",
		"country-code": "414"
	},
	{
		"name": "Kyrgyzstan",
		"code": "KGZ",
		"country-code": "417"
	},
	{
		"name": "Lao People's Democratic Republic",
		"code": "LAO",
		"country-code": "418"
	},
	{
		"name": "Latvia",
		"code": "LVA",
		"country-code": "428"
	},
	{
		"name": "Lebanon",
		"code": "LBN",
		"country-code": "422"
	},
	{
		"name": "Lesotho",
		"code": "LSO",
		"country-code": "426"
	},
	{
		"name": "Liberia",
		"code": "LBR",
		"country-code": "430"
	},
	{
		"name": "Libya",
		"code": "LBY",
		"country-code": "434"
	},
	{
		"name": "Liechtenstein",
		"code": "LIE",
		"country-code": "438"
	},
	{
		"name": "Lithuania",
		"code": "LTU",
		"country-code": "440"
	},
	{
		"name": "Luxembourg",
		"code": "LUX",
		"country-code": "442"
	},
	{
		"name": "Macao",
		"code": "MAC",
		"country-code": "446"
	},
	{
		"name": "Macedonia (the former Yugoslav Republic of)",
		"code": "MKD",
		"country-code": "807"
	},
	{
		"name": "Madagascar",
		"code": "MDG",
		"country-code": "450"
	},
	{
		"name": "Malawi",
		"code": "MWI",
		"country-code": "454"
	},
	{
		"name": "Malaysia",
		"code": "MYS",
		"country-code": "458"
	},
	{
		"name": "Maldives",
		"code": "MDV",
		"country-code": "462"
	},
	{
		"name": "Mali",
		"code": "MLI",
		"country-code": "466"
	},
	{
		"name": "Malta",
		"code": "MLT",
		"country-code": "470"
	},
	{
		"name": "Marshall Islands",
		"code": "MHL",
		"country-code": "584"
	},
	{
		"name": "Martinique",
		"code": "MTQ",
		"country-code": "474"
	},
	{
		"name": "Mauritania",
		"code": "MRT",
		"country-code": "478"
	},
	{
		"name": "Mauritius",
		"code": "MUS",
		"country-code": "480"
	},
	{
		"name": "Mayotte",
		"code": "MYT",
		"country-code": "175"
	},
	{
		"name": "Mexico",
		"code": "MEX",
		"country-code": "484"
	},
	{
		"name": "Micronesia (Federated States of)",
		"code": "FSM",
		"country-code": "583"
	},
	{
		"name": "Moldova (Republic of)",
		"code": "MDA",
		"country-code": "498"
	},
	{
		"name": "Monaco",
		"code": "MCO",
		"country-code": "492"
	},
	{
		"name": "Mongolia",
		"code": "MNG",
		"country-code": "496"
	},
	{
		"name": "Montenegro",
		"code": "MNE",
		"country-code": "499"
	},
	{
		"name": "Montserrat",
		"code": "MSR",
		"country-code": "500"
	},
	{
		"name": "Morocco",
		"code": "MAR",
		"country-code": "504"
	},
	{
		"name": "Mozambique",
		"code": "MOZ",
		"country-code": "508"
	},
	{
		"name": "Myanmar",
		"code": "MMR",
		"country-code": "104"
	},
	{
		"name": "Namibia",
		"code": "NAM",
		"country-code": "516"
	},
	{
		"name": "Nauru",
		"code": "NRU",
		"country-code": "520"
	},
	{
		"name": "Nepal",
		"code": "NPL",
		"country-code": "524"
	},
	{
		"name": "Netherlands",
		"code": "NLD",
		"country-code": "528"
	},
	{
		"name": "New Caledonia",
		"code": "NCL",
		"country-code": "540"
	},
	{
		"name": "New Zealand",
		"code": "NZL",
		"country-code": "554"
	},
	{
		"name": "Nicaragua",
		"code": "NIC",
		"country-code": "558"
	},
	{
		"name": "Niger",
		"code": "NER",
		"country-code": "562"
	},
	{
		"name": "Nigeria",
		"code": "NGA",
		"country-code": "566"
	},
	{
		"name": "Niue",
		"code": "NIU",
		"country-code": "570"
	},
	{
		"name": "Norfolk Island",
		"code": "NFK",
		"country-code": "574"
	},
	{
		"name": "Northern Mariana Islands",
		"code": "MNP",
		"country-code": "580"
	},
	{
		"name": "Norway",
		"code": "NOR",
		"country-code": "578"
	},
	{
		"name": "Oman",
		"code": "OMN",
		"country-code": "512"
	},
	{
		"name": "Pakistan",
		"code": "PAK",
		"country-code": "586"
	},
	{
		"name": "Palau",
		"code": "PLW",
		"country-code": "585"
	},
	{
		"name": "Palestine, State of",
		"code": "PSE",
		"country-code": "275"
	},
	{
		"name": "Panama",
		"code": "PAN",
		"country-code": "591"
	},
	{
		"name": "Papua New Guinea",
		"code": "PNG",
		"country-code": "598"
	},
	{
		"name": "Paraguay",
		"code": "PRY",
		"country-code": "600"
	},
	{
		"name": "Peru",
		"code": "PER",
		"country-code": "604"
	},
	{
		"name": "Philippines",
		"code": "PHL",
		"country-code": "608"
	},
	{
		"name": "Pitcairn",
		"code": "PCN",
		"country-code": "612"
	},
	{
		"name": "Poland",
		"code": "POL",
		"country-code": "616"
	},
	{
		"name": "Portugal",
		"code": "PRT",
		"country-code": "620"
	},
	{
		"name": "Puerto Rico",
		"code": "PRI",
		"country-code": "630"
	},
	{
		"name": "Qatar",
		"code": "QAT",
		"country-code": "634"
	},
	{
		"name": "Réunion",
		"code": "REU",
		"country-code": "638"
	},
	{
		"name": "Romania",
		"code": "ROU",
		"country-code": "642"
	},
	{
		"name": "Russian Federation",
		"code": "RUS",
		"country-code": "643"
	},
	{
		"name": "Rwanda",
		"code": "RWA",
		"country-code": "646"
	},
	{
		"name": "Saint Barthélemy",
		"code": "BLM",
		"country-code": "652"
	},
	{
		"name": "Saint Helena, Ascension and Tristan da Cunha",
		"code": "SHN",
		"country-code": "654"
	},
	{
		"name": "Saint Kitts and Nevis",
		"code": "KNA",
		"country-code": "659"
	},
	{
		"name": "Saint Lucia",
		"code": "LCA",
		"country-code": "662"
	},
	{
		"name": "Saint Martin (French part)",
		"code": "MAF",
		"country-code": "663"
	},
	{
		"name": "Saint Pierre and Miquelon",
		"code": "SPM",
		"country-code": "666"
	},
	{
		"name": "Saint Vincent and the Grenadines",
		"code": "VCT",
		"country-code": "670"
	},
	{
		"name": "Samoa",
		"code": "WSM",
		"country-code": "882"
	},
	{
		"name": "San Marino",
		"code": "SMR",
		"country-code": "674"
	},
	{
		"name": "Sao Tome and Principe",
		"code": "STP",
		"country-code": "678"
	},
	{
		"name": "Saudi Arabia",
		"code": "SAU",
		"country-code": "682"
	},
	{
		"name": "Senegal",
		"code": "SEN",
		"country-code": "686"
	},
	{
		"name": "Serbia",
		"code": "SRB",
		"country-code": "688"
	},
	{
		"name": "Seychelles",
		"code": "SYC",
		"country-code": "690"
	},
	{
		"name": "Sierra Leone",
		"code": "SLE",
		"country-code": "694"
	},
	{
		"name": "Singapore",
		"code": "SGP",
		"country-code": "702"
	},
	{
		"name": "Sint Maarten (Dutch part)",
		"code": "SXM",
		"country-code": "534"
	},
	{
		"name": "Slovakia",
		"code": "SVK",
		"country-code": "703"
	},
	{
		"name": "Slovenia",
		"code": "SVN",
		"country-code": "705"
	},
	{
		"name": "Solomon Islands",
		"code": "SLB",
		"country-code": "090"
	},
	{
		"name": "Somalia",
		"code": "SOM",
		"country-code": "706"
	},
	{
		"name": "South Africa",
		"code": "ZAF",
		"country-code": "710"
	},
	{
		"name": "South Georgia and the South Sandwich Islands",
		"code": "SGS",
		"country-code": "239"
	},
	{
		"name": "South Sudan",
		"code": "SSD",
		"country-code": "728"
	},
	{
		"name": "Spain",
		"code": "ESP",
		"country-code": "724"
	},
	{
		"name": "Sri Lanka",
		"code": "LKA",
		"country-code": "144"
	},
	{
		"name": "Sudan",
		"code": "SDN",
		"country-code": "729"
	},
	{
		"name": "Suriname",
		"code": "SUR",
		"country-code": "740"
	},
	{
		"name": "Svalbard and Jan Mayen",
		"code": "SJM",
		"country-code": "744"
	},
	{
		"name": "Swaziland",
		"code": "SWZ",
		"country-code": "748"
	},
	{
		"name": "Sweden",
		"code": "SWE",
		"country-code": "752"
	},
	{
		"name": "Switzerland",
		"code": "CHE",
		"country-code": "756"
	},
	{
		"name": "Syrian Arab Republic",
		"code": "SYR",
		"country-code": "760"
	},
	{
		"name": "Taiwan, Province of China",
		"code": "TWN",
		"country-code": "158"
	},
	{
		"name": "Tajikistan",
		"code": "TJK",
		"country-code": "762"
	},
	{
		"name": "Tanzania, United Republic of",
		"code": "TZA",
		"country-code": "834"
	},
	{
		"name": "Thailand",
		"code": "THA",
		"country-code": "764"
	},
	{
		"name": "Timor-Leste",
		"code": "TLS",
		"country-code": "626"
	},
	{
		"name": "Togo",
		"code": "TGO",
		"country-code": "768"
	},
	{
		"name": "Tokelau",
		"code": "TKL",
		"country-code": "772"
	},
	{
		"name": "Tonga",
		"code": "TON",
		"country-code": "776"
	},
	{
		"name": "Trinidad and Tobago",
		"code": "TTO",
		"country-code": "780"
	},
	{
		"name": "Tunisia",
		"code": "TUN",
		"country-code": "788"
	},
	{
		"name": "Turkey",
		"code": "TUR",
		"country-code": "792"
	},
	{
		"name": "Turkmenistan",
		"code": "TKM",
		"country-code": "795"
	},
	{
		"name": "Turks and Caicos Islands",
		"code": "TCA",
		"country-code": "796"
	},
	{
		"name": "Tuvalu",
		"code": "TUV",
		"country-code": "798"
	},
	{
		"name": "Uganda",
		"code": "UGA",
		"country-code": "800"
	},
	{
		"name": "Ukraine",
		"code": "UKR",
		"country-code": "804"
	},
	{
		"name": "United Arab Emirates",
		"code": "ARE",
		"country-code": "784"
	},
	{
		"name": "United Kingdom of Great Britain and Northern Ireland",
		"code": "GBR",
		"country-code": "826"
	},
	{
		"name": "United States of America",
		"code": "USA",
		"country-code": "840"
	},
	{
		"name": "United States Minor Outlying Islands",
		"code": "UMI",
		"country-code": "581"
	},
	{
		"name": "Uruguay",
		"code": "URY",
		"country-code": "858"
	},
	{
		"name": "Uzbekistan",
		"code": "UZB",
		"country-code": "860"
	},
	{
		"name": "Vanuatu",
		"code": "VUT",
		"country-code": "548"
	},
	{
		"name": "Venezuela (Bolivarian Republic of)",
		"code": "VEN",
		"country-code": "862"
	},
	{
		"name": "Viet Nam",
		"code": "VNM",
		"country-code": "704"
	},
	{
		"name": "Virgin Islands (British)",
		"code": "VGB",
		"country-code": "092"
	},
	{
		"name": "Virgin Islands (U.S.)",
		"code": "VIR",
		"country-code": "850"
	},
	{
		"name": "Wallis and Futuna",
		"code": "WLF",
		"country-code": "876"
	},
	{
		"name": "Western Sahara",
		"code": "ESH",
		"country-code": "732"
	},
	{
		"name": "Yemen",
		"code": "YEM",
		"country-code": "887"
	},
	{
		"name": "Zambia",
		"code": "ZMB",
		"country-code": "894"
	},
	{
		"name": "Zimbabwe",
		"code": "ZWE",
		"country-code": "716"
	}
])
    
        .constant('ROLES', {})
    
        .constant('CLIENTS', [
	{
		"name": "",
		"key": "",
		"currency": "SGD",
		"code": ""
	},
	{
		"name": "SGMC Moneygram",
		"key": "SGMC_MONEYGRAM",
		"currency": "SGD",
		"code": "rQdg7LnH799ePB2rgpV6u6KYDY5dZigj"
	},
	{
		"name": "SGMC Transferto",
		"key": "SGMC_TRANSFERTO",
		"currency": "SGD",
		"code": "7LhAGk7sY1OLONxHJCELzqsnSCQekCiu"
	},
	{
		"name": "SGMC Homesend",
		"key": "SGMC_HOMESEND",
		"currency": "SGD",
		"code": "WgfzcWvUm5ChOS25OYzSG0oYiMWlkgdd"
	}
])
    
        .constant('PROVIDER_CODES', [
	{
		"name": "",
		"code": ""
	},
	{
		"id": 1,
		"code": "transferto",
		"name": "TransferTo"
	},
	{
		"id": 2,
		"code": "homesend",
		"name": "Homesend"
	},
	{
		"id": 3,
		"code": "moneygram",
		"name": "MoneyGram"
	}
])
    
        .constant('APP_CURRENCY', {
	"base": "USD"
})
    
        .constant('TRANSACTION_STATUSES', {})
    
        .constant('REPORTS_ITEMS_PER_PAGE', [
	10,
	25,
	50,
	75,
	100
])
    
        .constant('WIDGET', {
	"stats": {
		"cards": true,
		"cards_holders": true,
		"wallet": true,
		"transactions": false
	},
	"activities": {
		"admin": true,
		"user": true
	}
})
    
        .constant('INPUT_FIELD_SPECS', {
	"PAYOUT_AGENT": [
		{
			"field_name": "NAME",
			"field_reqd": "yes",
			"field_validation": "[a-zA-Z0-9 $-_+&]{1,255}"
		},
		{
			"field_name": "BRANCH_NAME",
			"field_reqd": "yes",
			"field_validation": "[a-zA-Z0-9 $-_+&]{1,255}"
		},
		{
			"field_name": "SWIFT_CODE",
			"field_reqd": "yes",
			"field_validation": "[a-zA-Z0-9 $-_+&]{1,50}"
		},
		{
			"field_name": "BRANCH_CODE",
			"field_reqd": "yes",
			"field_validation": "[a-zA-Z0-9 $-_+&]{1,50}"
		},
		{
			"field_name": "MICR_CODE",
			"field_reqd": "no",
			"field_validation": ""
		},
		{
			"field_name": "ADDRESS",
			"field_reqd": "no",
			"field_validation": ""
		},
		{
			"field_name": "CITY",
			"field_reqd": "no",
			"field_validation": ""
		},
		{
			"field_name": "DISTRICT",
			"field_reqd": "no",
			"field_validation": ""
		},
		{
			"field_name": "STATE",
			"field_reqd": "no",
			"field_validation": ""
		},
		{
			"field_name": "CONTACT",
			"field_reqd": "no",
			"field_validation": ""
		}
	]
})
    
        .constant('CSV_UPLOAD_FILE_PARAMS', {
	"FILE_SIZE": "8388608",
	"ALLOWED_FILE_TYPES": [
		"text/csv",
		"application/vnd.ms-excel",
		"application/csv"
	]
})
    

})();
