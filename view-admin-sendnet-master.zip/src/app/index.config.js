(function ()
{
    'use strict';

    angular
        .module('admin')
        .config(config);

    /** @ngInject */
    function config(IdleProvider, $httpProvider)
    {
        // Put your custom configurations here
        IdleProvider.idle(900);
        IdleProvider.timeout(3600);

        $httpProvider.interceptors.push('apiInterceptor');

    }

})();
