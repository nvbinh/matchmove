(function ()
{
    'use strict';

    angular
        .module('admin')
        
        .constant('CURRENCIES', [
	{
		"name": "Singapore Dollars",
		"code": "SGD",
		"id": 2
	},
	{
		"name": "U.S. Dollars",
		"code": "USD",
		"id": 3
	},
	{
		"name": "Malaysian Ringgits",
		"code": "MYR",
		"id": 4
	},
	{
		"name": "Indonesian Rupiahs",
		"code": "IDR",
		"id": 5
	},
	{
		"name": "Vietnamese Dong",
		"code": "VND",
		"id": 6
	},
	{
		"name": "Brunei Dollars",
		"code": "BND",
		"id": 7
	},
	{
		"name": "Philippine Pesos",
		"code": "PHP",
		"id": 8
	},
	{
		"name": "Thai Baht",
		"code": "THB",
		"id": 9
	},
	{
		"name": "British Pounds",
		"code": "GBP",
		"id": 10
	},
	{
		"name": "Indian Rupees",
		"code": "INR",
		"id": 11
	},
	{
		"name": "Egyptian Pounds",
		"code": "EGP",
		"id": 12
	},
	{
		"name": "Saudi Riyals",
		"code": "SAR",
		"id": 13
	},
	{
		"name": "Jordanian Dinars",
		"code": "JOD",
		"id": 14
	},
	{
		"name": "Omani Rials",
		"code": "OMR",
		"id": 15
	},
	{
		"name": "Israeli New Sheqels",
		"code": "ILS",
		"id": 16
	},
	{
		"name": "Turkish Liras",
		"code": "TRY",
		"id": 17
	},
	{
		"name": "VCard Points Old",
		"code": "VCASH",
		"id": 18
	},
	{
		"name": "Bangladeshi Taka",
		"code": "BDT",
		"id": 19
	},
	{
		"name": "Sri Lanka Rupee",
		"code": "LKR",
		"id": 20
	},
	{
		"name": "Chinese Yen",
		"code": "CNY",
		"id": 21
	},
	{
		"name": "Euro",
		"code": "EUR",
		"id": 22
	}
])
    

})();
