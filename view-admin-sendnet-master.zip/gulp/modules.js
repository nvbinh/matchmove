'use strict';

var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');
var ejs = require("gulp-ejs");
var exec = require('child_process').exec;
var argv = require('yargs').argv;
var replace = require('gulp-replace');

var $ = require('gulp-load-plugins')({
    pattern: ['gulp-*', 'main-bower-files', 'uglify-save-license', 'del']
});

gulp.task('submodule:start',['submodule:init', 'submodule:load'],function(){
});

gulp.task('submodule:init', function () {
	exec('git submodule update --init --recursive');
});

gulp.task('submodule:load', function () {
    var modulePrefix = "";
    var moduleName = "";
    var deps = {
        constants: {}
    };

    modulePrefix = argv.prefix ? argv.prefix : 'app';
    moduleName = argv.moduleName ? argv.moduleName : 'admin';

    exec('git submodule foreach -q --recursive \'echo $name\'', function (error, stdout, stderr) {
        var names = stdout.split("\n");
        names.splice(-1, 1);

        for (var i = 0; i < names.length; i++) {
            var elements = names[i].split('/');
            var module = elements[elements.length - 1];

            if(module === 'services') continue;
            console.log("Adding new submodule: ", names[i]);

            deps.constants[module] = names[i];
        }

        return gulp.src('')
            .pipe($.ngConstant({
                name: moduleName,
                constants: deps.constants,
                templatePath: "gulp/modules.tpl.ejs"
            }))
            .pipe(replace('*app*', modulePrefix))
            .pipe($.rename('index.module.js'))
            .pipe(gulp.dest('src/app/'));
    })

});
