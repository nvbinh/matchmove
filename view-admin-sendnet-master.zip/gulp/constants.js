'use strict';

var path = require('path');
var gulp = require('gulp');
var conf = require('./conf');

var $ = require('gulp-load-plugins')({
    pattern: ['gulp-*', 'main-bower-files', 'uglify-save-license', 'del']
});

gulp.task('config:constants', function () {
    gulp.src('config.json')
        .pipe($.ngConstant({
            templatePath: "gulp/config.tpl.ejs"
        }))
        .pipe($.rename('index.constants.js'))
        .pipe(gulp.dest('src/app/'));
});

gulp.task('config:permissions', function () {
    gulp.src('config.permissions.json')
        .pipe($.ngConstant({
            templatePath: "gulp/config.tpl.ejs"
        }))
        .pipe($.rename('index.constants.permissions.js'))
        .pipe(gulp.dest('src/app/'));
});

gulp.task('config:currencies', function () {
    gulp.src('config.currencies.json')
        .pipe($.ngConstant({
            name: "admin",
            templatePath: "gulp/config.tpl.ejs"
        }))
        .pipe($.rename('index.constants.currencies.js'))
        .pipe(gulp.dest('src/app/'));
});

gulp.task('config:countries', function () {
    gulp.src('config.countries.json')
        .pipe($.ngConstant({
            name: "admin",
            templatePath: "gulp/config.tpl.ejs"
        }))
        .pipe($.rename('index.constants.countries.js'))
        .pipe(gulp.dest('src/app/'));
});

gulp.task('config', ['config:constants', 'config:permissions', 'config:currencies', 'config:countries']);
