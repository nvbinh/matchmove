# View Admin Starter README

This is your Vanilla AdminNet starter application. From this application you add your submodules according to your requirement. Whether you want a VCard AdminNet, a Compliance and Risk, a SendNet application, this is where you start.

## Installation

```
npm install
bower install
gulp submodule:start
```

## Submodule Notes

There are a lot of submodule notes and resources in the internet, for more information on how Git submodule works check this [link](https://git-scm.com/book/en/v2/Git-Tools-Submodules).

#### gulp submodule:start

This task reads the installed/added submodules to your app then updates your `index.module.js` file. This is exactly the same as running `git submodule update --init --recursive` then manually add the modules to your `index.module.js` file.

#### Updating your remote modules to latest

Run the submodule command `git submodule update --remote` (recommended). Another way of doing this is by running `git submodule foreach git pull origin master`.

#### Setting your remote submodule to track on a specific branch

Run the command: `git config -f .gitmodules submodule.<submodule_name>.branch stable`

## Sample Config (updated as of 8 December 2016)

The `config.json` do change a lot, so ask for this file from your team  lead or whoever has access to s3 config buckets.


```
{
    "name": "admin",
    "constants": {
        "API_BASE": "<API URL DEPENDENT ON YOUR APPLICATION>",
        "HTTP_HOST": "<API URL DEPENDENT ON YOUR APPLICATION>",
        "RESET_PASSWORD_ENDPOINT": "auth/reset-password",
        "USER_VERIFY_ENDPOINT": "auth/verify",
        "CLIENT_ID": "<Contact your administrator>",
        "CLIENT_SECRET": "<Contact your administrator>",
        "GRANT_TYPE": "password",
        "CARDHOLDER_CONSTANTS": {
          "status":["inactive","active","pending activation","locked"],
          "datatable_heading":["ID","Hash ID","Processor Ref ID", "Status", "Email", "Birthday", "User Type", "Gender", "Title", "Date Added", "Name", "Mobile", "Identification", "Links"]
        },
        "WALLET_CONSTANTS": {
          "status":["inactive","active","pending activation","locked"],
          "datatable_heading":["User ID", "Card ID", "Hash ID","Processor Ref ID", "Status", "Proxy Number", "Card Number", "Date Added", "Name", "Authentication", "Balance", "Links"]
        },
        "CARD_CONSTANTS": {
          "card_types":["havmcpcard"],
          "card_status":["inactive","active","pending activation","locked"],
          "datatable_heading":["User ID", "Card Number", "Proxy Number", "Card ID", "Hash ID", "Processor Ref ID", "Card Status", "Card Type", "Balance", "Links"]
        },
        "DOCUMENTS_CONSTANTS": {
          "status":["Credit","debit"],
          "document_status":["Transfer","Topups","Debits","Credits","Refunds"],
          "document_verification":["Transfer","Topups","Debits","Credits","Refunds"],
          "datatable_heading":["User ID", "Date", "Full Name", "Email", "Mobile Number", "Account Status"]
        },
        "TRANSACTION_CONSTANTS": {
          "type":["Credit","Debit"],
          "transaction_types":["Transfer","Topup","Debits","Credits","Refunds"],
          "datatable_heading":["User ID", "Email", "Mobile", "Card Proxy Number", "Processor Ref ID", "Card Number", "Billing Amount Debit", "Billing Amount Credit", "Debit Credit Indicator", "Debit Credit Indicator Text", "Merchant Name", "MCC", "Terminal ID", "Description", "Transaction Date", "Card Balance", "Transaction Amount", "Transaction Ref Number", "Transaction Status", "Transaction Type", "Ref ID", "Ref Table"]
        },
        "LOYALTY_CONSTANTS": {
          "type":["Topups"],
          "accounting_type":["debit","credit"],
          "datatable_heading":["Total Points", "User ID", "Email", "Processor Ref ID", "Status", "Date Added", "Mobile", "Points", "Loyalty Type", "Accounting Type", "Description"]
        },
        "ACTIVITY_CONSTANTS": {
          "card_types":["havmcpcard"],
          "card_status":["inactive","active","pending activation","locked"],
          "datatable_heading":["User ID", "Card Number", "Proxy Number", "Card ID", "Hash ID", "Processor Ref ID", "Card Status", "Card Type", "Balance", "Links"]
        },
        "ADMINISTRATION_CONSTANTS":{
          "activity_types":[
            {
              "id":1,
              "name":"XYZ"
            },
            {
              "id":2,
              "name":"DAsds"
            },
            {
              "id":3,
              "name":"Dasd "
            }
          ],
          "datatable_heading": ["Activity ID", "Admin ID", "Category ID", "Details", "Created At", "Updated At", "Email", "First Name", "Last Name", "Password", "Active", "Logins", "Last Login", "Last Login IP", "Login Attemps"]
        },
        "CARD_STATUS": {
            "notification_required": true,
            "notification_mode": true,
            "locked": ["lost", "stolen", "damaged"]
        },
        "KYC_STATUS": {
            "notification_required": true,
            "notification_mode": "email",
            "not_submitted": {
              "approved": false,
              "rejected": false
            },
            "submitted": {
              "approved": true,
              "rejected": true
            },
            "pending": {
              "approved": false,
              "rejected": false
            },
            "rejected": {
              "approved": false,
              "rejected": false
            },
            "approved": {
              "approved": false,
              "rejected": false
            }
        },
        "BRANDING": {
            "name":"MatchMove",
            "colorPrimary":"#09f",
            "colorAccent":"#09f",
            "logo":"http://matchmove.cards/app/themes/wp-theme-mastercard/images/logo_desktop.png"
        }
    }
}
```
