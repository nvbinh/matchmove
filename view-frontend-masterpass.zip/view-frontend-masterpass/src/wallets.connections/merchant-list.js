import React, { Component } from 'react';

import { deleteMerchantConnection, getConnections } from '../utils/merchants-api';
import { getUsers } from '../utils/users-api';
import { getCardID } from '../utils/cards-api';

import Toast from '../web.components/toast';


export default class MerchantList extends Component {
	
	constructor(props) {
		super(props);

		// dummy data. This would be replaced by the user data
		this.params = {
			'user_hash_id': '666525a25d1c371b17bf881b740f5c8e',
			'wallet_id': 'masterpass'	
		}

		this.merchantList = {};
		this.selectedMerchant = {};
		this.message = {
			success: '',
			failure: '',
			showMessage: false
		};
		this.showSideBar = false;

		getUsers().then((res) => {
			let params = {
				'user_hash_id': res.data.id,
				'wallet_id': getCardID()
			}

			///////////////////////////////////////////////////////////////////////////////////////////////////
			// As this particular user connections are empty. I am using dummy variable called params above  //
			///////////////////////////////////////////////////////////////////////////////////////////////////
			getConnections('get', this.params).then((resp) => {
				this.merchantList = resp.data.Connection;
				this.forceUpdate();
			});
		})


		this.deletePairing = this.deletePairing.bind(this);
		this.handleAcceptClick = this.handleAcceptClick.bind(this);
		this.handleDeclineClick = this.handleDeclineClick.bind(this);
		this.toggleSidebar = this.toggleSidebar.bind(this);
	}

	deletePairing(merchant, event) {
		this.message.showMessage = true;
		this.selectedMerchant = merchant;
		this.forceUpdate();
	}

	handleAcceptClick(e) {
		if(!!this.selectedMerchant.ConnectionId) {
			// delete the connection
			this.params['connection_id'] = this.selectedMerchant.ConnectionId;
			deleteMerchantConnection('delete', this.params).then((res) => {
				this.forceUpdate();
			})			

			this.message = {
				showMessage: false,
				success: this.selectedMerchant.MerchantName + ' successfully removed from your connection'
			};
			this.forceUpdate();
		}
		this.forceUpdate();
	}

	handleDeclineClick() {
		this.message = {
			showMessage: false,
			failure: 'Something went wrong while removing ' + this.selectedMerchant.MerchantName + ' from your connection'
		}
		this.forceUpdate();
	}

	toggleSidebar() {
		console.log(this.showSideBar);
		this.showSideBar = !this.showSideBar;
		console.log(this.showSideBar);
		this.forceUpdate();
	}


	render() {

		var generateConnectionList = (list) => {
			return (
				<li>
					<a className='rm-link' id={list.ConnectionId} onClick={this.deletePairing.bind(this, list)}>
						<label>Delete Pairing</label>
						<i className='material-icons md-18'>delete</i>
					</a>
					<figure>
						<img src={list.Logo.Url} />
						<hr/>
						<figcaption>{list.MerchantName}</figcaption>
					</figure>
				</li>
			);
		}

		var merchantListElements = () => {
			let mlist = [];
			if(this.merchantList.length != undefined) {
				for(let key in this.merchantList) {
					mlist.push(generateConnectionList(this.merchantList[key]));
				}
			} else if(Object.keys(this.merchantList).length != 0) {
				mlist.push(generateConnectionList(this.merchantList));
			}
			return mlist;
		}


		return (
			<article className='hm-ocont'>
				<Toast 
					header='Remove paired connection' 
					toggleLayout={this.message.showMessage}
					onClickAccept={this.handleAcceptClick} 
					onClickDecline={this.handleDeclineClick} 
					message={'Are you sure do you want to remove the paired connection with "' + this.selectedMerchant.MerchantName + '"?'}
				/>
				<section className='hm-menu-layout'>
					<div className='hm-menu-header'>
						<button className='hm-menu-btn' onClick={this.toggleSidebar}>
							<i className='material-icons'>{(this.showSideBar) ? 'close' : 'menu'}</i>
						</button>
					</div>
					<aside className={'hm-left-menu full-height ' + (this.showSideBar ? 'show' : 'hide')}>
						<div>
							<h4>My wallet</h4>
							<ul className='sl'>
								<li>
									<a>
										<i className='material-icons'>style</i>
										<label>Cards</label>
									</a>
								</li>
								<li>
									<a>
										<i className='material-icons'>directions</i>
										<label>Address</label>
									</a>
								</li>
							</ul>
							<hr/>
							<h4>My Account</h4>
							<ul className='sl'>
								<li>
									<a>
										<i className='material-icons'>face</i>
										<label>Profile</label>
									</a>
								</li>
								<li>
									<a className='active'>
										<i className='material-icons'>people</i>
										<label>Connections</label>
									</a>
								</li>
							</ul>
							<hr/>
							<h4>Legal</h4>
							<ul className='sl'>
								<li>
									<a>
										<i className='material-icons'>receipt</i>
										<label>Terms of use</label>
									</a>
								</li>
								<li>
									<a>
										<i className='material-icons'>lock</i>
										<label>privacy</label>
									</a>
								</li>
							</ul>
							<hr/>
							<ul className='sl'>
								<li className='logout'>
									<a>
										<i className='material-icons'>exit_to_app</i>
										<label>Sign out</label>
									</a>
								</li>
							</ul>
						</div>
					</aside>
					<div className='hm-container'>
						<h1>Connections</h1>
						<article className={'hm-message-block'}>
							<div className={'hm-message success '+ ((this.message.showMessage && !!this.message.success) ? 'show' : 'hide')} >
								{this.message.success}
							</div>
							<div className={'hm-message error '+ ((this.message.showMessage && !!this.message.failure) ? 'show' : 'hide')} >
								{this.message.failure}
							</div>
						</article>
						<p>
							You are permitting the following merchants and apps to receive wallet information for faster shopping.
							If you disconnect from a merchant or app, you must visit their site to reconnect.
						</p>
						<ul className='sl hm-connection-list'>
							{merchantListElements()}
						</ul>
					</div>
				</section>
			</article>
		);
	}
}
