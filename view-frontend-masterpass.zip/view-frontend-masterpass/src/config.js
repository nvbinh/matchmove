export default {
  API_BASE: "https://beta-ih.mmvpay.com/api/v1",
  OAUTH_CREDENTIALS: { key: 'sgmc-frontend', secret: 'NGZmMzRlYTRmMTY2NWQ1NjU4MmRhOGFhZTUzMzI5ODY3MjBmYTIxZDg4OTU2YTdlZmI1OGQ5ZTY1ZjUzMGE5Zg' },
  HTTP_HOST: "https://localhost/"
}
