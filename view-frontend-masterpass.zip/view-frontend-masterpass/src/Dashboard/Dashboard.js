import React, { Component } from 'react';

import CheckBox from 'grommet/components/CheckBox';
import Toast from '../web.components/toast';

class Dashboard extends Component {

	constructor(props) {
		super(props);
		this.showSideBar = false;
		this.toggleSidebar = this.toggleSidebar.bind(this);	

		this.showMessage = false;

		this.handleAcceptClick = this.handleAcceptClick.bind(this);
		this.handleDeclineClick = this.handleDeclineClick.bind(this);
		this.deleteCard = this.deleteCard.bind(this);
	}

	toggleSidebar() {
		this.showSideBar = !this.showSideBar;
		this.forceUpdate();
	}

	deleteCard() {
		this.showMessage = true;
		this.forceUpdate();
	}

	handleAcceptClick(e) {
		console.log('accepted');
		this.showMessage = false;
		this.forceUpdate();
	}

	handleDeclineClick(e) {
		console.log('decline');
		this.showMessage = false;
		this.forceUpdate();
	}

  	render() {
	    return (
	    	<article className='hm-ocont'>
	    		<Toast 
					header='Remove card' 
					toggleLayout={this.showMessage}
					onClickAccept={this.handleAcceptClick} 
					onClickDecline={this.handleDeclineClick} 
					message={'Are you sure do you want to remove the card?'}
				/>
	    		<section className='hm-menu-layout'>
	    			<div className='hm-menu-header'>
						<button className='hm-menu-btn' onClick={this.toggleSidebar}>
							<i className='material-icons'>{(this.showSideBar) ? 'close' : 'menu'}</i>
						</button>
					</div>
					<aside className={'hm-left-menu full-height ' + (this.showSideBar ? 'show' : 'hide')}>
						<div>
							<h4>My wallet</h4>
							<ul className='sl'>
								<li>
									<a className='active'>
										<i className='material-icons'>style</i>
										<label>Cards</label>
									</a>
								</li>
								<li>
									<a>
										<i className='material-icons'>directions</i>
										<label>Address</label>
									</a>
								</li>
							</ul>
							<hr/>
							<h4>My Account</h4>
							<ul className='sl'>
								<li>
									<a>
										<i className='material-icons'>face</i>
										<label>Profile</label>
									</a>
								</li>
								<li>
									<a>
										<i className='material-icons'>people</i>
										<label>Connections</label>
									</a>
								</li>
							</ul>
							<hr/>
							<h4>Legal</h4>
							<ul className='sl'>
								<li>
									<a>
										<i className='material-icons'>receipt</i>
										<label>Terms of use</label>
									</a>
								</li>
								<li>
									<a>
										<i className='material-icons'>lock</i>
										<label>privacy</label>
									</a>
								</li>
							</ul>
							<hr/>
							<ul className='sl'>
								<li className='logout'>
									<a>
										<i className='material-icons'>exit_to_app</i>
										<label>Sign out</label>
									</a>
								</li>
							</ul>

						</div>
					</aside>	

					<div className='hm-container'>
						<a className='floating-button'>
							<i className='material-icons'>add</i>
						</a>
						<h1>My Cards</h1>
						<ul className='sl hm-card-list'>
							<li>
								<figure className='sf'>
									<img src='http://mommypoints.boardingarea.com/wp-content/uploads/2015/08/New-SPG-Card-Design.png' />
								</figure>
								<div>
									<h3>$240 Amount </h3>
									<CheckBox label='Card selected'
										toggle={true}
										disabled={false}
										reverse={false}
										checked={true} 
										/>
								</div>
								<p>
									<a>View</a>
									<a onClick={this.deleteCard.bind(this)}>Delete</a>
								</p>
							</li>
							<li>
								<figure className='sf'>
									<img src='http://mommypoints.boardingarea.com/wp-content/uploads/2015/08/New-SPG-Card-Design.png' />
								</figure>
								<div>
									<h3>$240 Amount </h3>
									<CheckBox label='select Card'
										toggle={true}
										disabled={false}
										reverse={false}
										checked={false} 
										/>
								</div>
								<p>
									<a>View</a>
									<a>Delete</a>
								</p>
							</li>

							<li>
								<figure className='sf'>
									<img src='http://mommypoints.boardingarea.com/wp-content/uploads/2015/08/New-SPG-Card-Design.png' />
								</figure>
								<div>
									<h3>$240 Amount </h3>
									<CheckBox label='select Card'
										toggle={true}
										disabled={false}
										reverse={false}
										checked={false} 
										/>
								</div>
								<p>
									<a>View</a>
									<a>Delete</a>
								</p>
							</li>

							<li>
								<figure className='sf'>
									<img src='http://mommypoints.boardingarea.com/wp-content/uploads/2015/08/New-SPG-Card-Design.png' />
								</figure>
								<div>
									<h3>$240 Amount </h3>
									<CheckBox label='select Card'
										toggle={true}
										disabled={false}
										reverse={false}
										checked={false} 
										/>
								</div>
								<p>
									<a>View</a>
									<a>Delete</a>
								</p>
							</li>

							<li>
								<figure className='sf'>
									<img src='http://mommypoints.boardingarea.com/wp-content/uploads/2015/08/New-SPG-Card-Design.png' />
								</figure>
								<div>
									<h3>$240 Amount </h3>
									<CheckBox label='select Card'
										toggle={true}
										disabled={false}
										reverse={false}
										checked={false} 
										/>
								</div>
								<p>
									<a>View</a>
									<a>Delete</a>
								</p>
							</li>
						</ul>
					</div>

	    		</section>
	    	</article>
	    );
  	}
}
export default Dashboard;
