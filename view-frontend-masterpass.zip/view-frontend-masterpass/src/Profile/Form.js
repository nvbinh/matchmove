import React, { Component } from 'react';
import AddCardForm from '../components/AddCardForm';
import BillingAddressForm from '../components/BillingAddressForm';
import LoginForm from '../components/LoginForm';
import UserOtpForm from '../components/UserOtpForm';
import SignupFormPageOne from '../components/SignupFormPageOne';
import EditProfileForm from '../components/EditProfileForm';
import ShippingAddressForm from '../components/ShippingAddressForm';
import SuccessPage from '../components/SuccessPage';

import validator from '../utils/validator.js';

export default class SignupForm extends Component {
  constructor() {
    super();
      this.state = { 
            step: 1,
            fields: {
                mobileChanged      : false,
                emailChanged       : false,
                passwordChanged    : false,
                otherFieldsChanged : false
            }
      };
    this.nextStep = this.nextStep.bind(this);
    this.previousStep = this.previousStep.bind(this);
    this.initialStep = this.initialStep.bind(this);
    this.handleFormInput = this.handleFormInput.bind(this);
    this.onClose = this.onClose.bind(this);
  }

  nextStep() {
    this.setState({
      step: this.state.step + 1
    });
  }

  previousStep() {
    this.setState({
      step: this.state.step - 1
    });
  }

  initialStep() {
    this.setState({
      step: 1
    });
  }

  handleFormInput(event){
    const val = event.target;
    this.setState(Object.assign(this.state, { [val.id]: val.value }));
      //console.log(this.state);
  }

  onClose(){
    //this.isActive = false;
    this.setState({ ...this.state, isActive: false });
    //this.forceUpdate();
  }

  updateModifiedFields(nextState){
      console.log(nextState, 'wawaa');
      //Object.assign(this.state,{ fields: nextState.fields });
      Object.assign(this.state, nextState);
      console.log(this.state);
  }

  addOtpToken(nextState){
      Object.assign(this.state, nextState);
  }

  render() {
    let page;
    switch (this.state.step) {
      case 1:
        page = <LoginForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} _onClose={this.onClose}/>;
        break;
      case 2:
        page = <EditProfileForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} fields={this.state.fields} updateModifiedFields={this.updateModifiedFields.bind(this)} addOtpToken={this.addOtpToken.bind(this)} />;
        break;
      case 3:
        page = <UserOtpForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} previousStep={this.previousStep}/>;
        break;
      case 4:
        page = <SuccessPage nextStep={this.initialStep} />;
        break;
      default:
        return true;
    }
    return (page);
  }
}
