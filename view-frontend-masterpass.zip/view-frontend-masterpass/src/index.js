import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import style from './styles/main.scss';
//import '../node_modules/flexboxgrid-sass';
import '../node_modules/grommet-css';
import App from './App';
import Dashboard from './Dashboard/Dashboard';
import MerchantList from './wallets.connections/merchant-list';

import AddAnotherCardForm from './AddAnotherCard/Form';
import SignupForm from './Signup/Form';
import ProfileForm from './Profile/Form';
import registerServiceWorker from './registerServiceWorker';
import VerifyEmail from './components/VerifyEmail';

const element = document.getElementById('root');
ReactDOM.render(
  <Router>
    <Switch>
      <Route exact path='/' component={App} >
      </Route>
      <Route path='/addcard' component={AddAnotherCardForm}/>
      <Route path='/email/verify/:token' component={VerifyEmail}/>
      <Route exact path='/signup' component={SignupForm} />
      <Dashboard exact path='/dashboard' component={Dashboard} />
      <MerchantList exact path='/wallets/merchants' component={MerchantList} />
    </Switch>
  </Router>, element
);
document.body.classList.remove('loading');
registerServiceWorker();
