import consts from '../app-const.js';
import React, { Component } from 'react';


class Validator extends Component {

    constructor(props) {
        super(props);
        
    }

    static getPattern(pattern) {
        for(let key in consts.PATTERN) {
            if(consts.PATTERN[key] == pattern) {
                return consts.PATTERN[key];
            }   
        }
        return;
    }

    static getInnerPattern(input, arr) {
        let appPattern = consts;
        for(let i = 0; i <= arr.length - 1; i++) {
            appPattern = appPattern[arr[i].toUpperCase()];
        }
        return appPattern;
    }

    static hasMinOrMaxLength(length) {
        return (length != -1 && length != undefined);
    }

    static inspectForm(input, form) {
        let err = '';
        let dependent = input !== undefined ? input.dataset.dependent : null;
        let dependentEle = (!!dependent) ? form[dependent] : '';
        // let pattern = (!!input.pattern) ? this.getPattern(input.pattern) : '';
        let pattern = '';
        let countryCode = (!!dependentEle) ? dependentEle.value : '';


        if(input){
          if(!!input.pattern) {
            pattern = this.getPattern(input.pattern);
          } else if(!!input.dataset.pattern && form[dependent] && form[dependent].value != '') {
            pattern = this.getInnerPattern(input, (input.dataset.pattern).split('-'));
          } else {
            pattern = '';
          }

          if(!!dependent && form[dependent] && form[dependent].value == '') {
            err = dependent +' not selected';
          } else if(!input.value && input.required) {
            err = input.id + ' cannot be empty';
          } else if(this.hasMinOrMaxLength(input.minLength) && !(input.value.length >= input.minLength)) {
            err = input.id + ' cannot be more than ' + input.minLength + ' characters';
          } else if(this.hasMinOrMaxLength(input.maxLength) && !(input.value.length <= input.maxLength)) {
            err = input.id + ' cannot be less than ' + input.maxLength + ' characters';
          } else if(!!pattern && !pattern.test(input.value) && !!input.value) {
            err = input.id + ' is invalid';
          }
        }
        return err;
    }

    static inspectPrefilledForm(form, state) {
        let field = {};
        let errCount = 0;

        for(let key in state) {
            field[state[key]] = this.inspectForm(form[state[key]], form);
            if(field[state[key]] != '') {
                errCount++;
            }
        }
        field.invalidForm = (errCount > 0) ? true : false;
        return field;

    }

}

export default Validator;
