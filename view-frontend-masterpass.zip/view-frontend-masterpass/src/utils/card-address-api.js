import { dispatchRequest } from './http-helper';
import config from '../config.js';
import { getCardID } from './cards-api';
export { getBillingAddress, getBillingAddressById, addBillingAddress, addShippingAddress };

const API_BASE = config.API_BASE;

function addBillingAddress(params) {
  let hash_id = getCardID();
  const url = `${API_BASE}/users/wallets/cards/address/masterpass`;
  return dispatchRequest('post', url, Object.assign({hash_id, type: 'billing', address: JSON.stringify(params)}, params));
}

function addShippingAddress(params) {
  let hash_id = getCardID();
  const url = `${API_BASE}/users/wallets/cards/address/masterpass`;
  return dispatchRequest('post', url, Object.assign({hash_id, type: 'shipping', address: JSON.stringify(params) }, params));
}

function getBillingAddress(){
  let hash_id = getCardID();
  const url = `${API_BASE}/users/wallets/cards/address/masterpass/${hash_id}`;
  return dispatchRequest('get', url, {});
}

function getBillingAddressById(id){
  let hash_id = id;
  const url = `${API_BASE}/users/wallets/cards/address/masterpass/${hash_id}`;
  return dispatchRequest('get', url, {});
}
