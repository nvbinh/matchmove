import config from '../config.js';
import { dispatchRequest } from './http-helper'
export { addCard, getCard, getCardID, setCardID, setCards, getCards }

let hash_id, cards;
const API_BASE = config.API_BASE;

function addCard(params) {
  const url = `${API_BASE}/users/wallets/cards/masterpass`;
  return dispatchRequest('put', url, params);
}

function getCard(){
  const url = `${API_BASE}/users/wallets`;
  return dispatchRequest('get', url, {});
}

function setCardID(id){
  hash_id = id;
}

function getCardID(){
  return hash_id;
}

function setCards(allCards){
  cards = allCards;
}

function getCards(){
  return cards;
}
