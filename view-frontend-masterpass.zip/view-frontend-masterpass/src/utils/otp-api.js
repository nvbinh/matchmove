import axios from 'axios';
import config from '../config.js';
import qs from 'qs';
import { encode } from './rc4';
import { dispatchRequest } from './http-helper';
export { getOtpVerification, verifyOtp, verifyUserOtp };

const API_BASE = config.API_BASE;

function getOtpVerification(params) {
    const url = `${API_BASE}/users/wallets/cards/masterpass/verify`;
    return dispatchRequest('post', url, Object.assign(params));
}

function verifyOtp(token, otp) {
    const url = `${API_BASE}/users/wallets/cards/masterpass/verify`;
    return dispatchRequest('put', url, { token, otp: encode(token, otp) });
}

function verifyUserOtp(token, otp) {
    const url = `${API_BASE}/users/authentications/phone`;
    return dispatchRequest('put', url, { token, key: encode(token, otp) });
}
