import axios from 'axios';
import config from '../config.js';
import qs from 'qs';
import { getToken } from './auth-api';
export { dispatchRequest, dispatchRequestWithoutAuth };

function dispatchRequest(method, url, params) {
  let token = getToken();
  return axios({
    method,
    url,
    headers: { Authorization: `Bearer ${token}` },
    data: qs.stringify(params)
  });
}

// ajax function without OAuth2
function dispatchRequestWithoutAuth(method, url, params, header) {
	return axios({
		method,
		url,
		header,
		params
	})
}