import axios from 'axios';
import config from '../config.js';
import { encode } from './rc4';
import { dispatchRequest } from './http-helper'

const API_BASE = config.API_BASE;
const endpoint = config.HTTP_HOST;

export { changePassword, verifyChangePassword, verifyEmail, getUsers, getUserBillingAddress, getUserShippingAddress, postUser, updateUser, verifyUser };

function getUsers() {
  const url = `${API_BASE}/users`;
  return dispatchRequest('get', url, {});
}

function getUserBillingAddress() {
  const url = `${API_BASE}/users/addresses/billing`;
  return dispatchRequest('get', url, {});
}

function getUserShippingAddress() {
  const url = `${API_BASE}/users/addresses/shipping`;
  return dispatchRequest('get', url, {});
}

function postUser(params) {
  const url = `${API_BASE}/users/test`;
  return dispatchRequest('post', url, Object.assign({endpoint}, params));
}

function updateUser(params) {
  const url = `${API_BASE}/users`;
  return dispatchRequest('put', url, Object.assign({endpoint}, params));
}

function changePassword(params){
    const url = `${API_BASE}/users/authentications/password`;
    return dispatchRequest('post', url, params);
}

function verifyChangePassword(token, password){
    const url = `${API_BASE}/users/authentications/password`;
    return dispatchRequest('put', url, { token, key: encode(token, password) });
}

function verifyEmail(token, email){
    const url = `${API_BASE}/users/authentications/email`;
    return dispatchRequest('put', url, { token, key: encode(token, email) });
}

function verifyUser(params) {
  const url = `${API_BASE}/users/masterpass`;
  return dispatchRequest('post', url, Object.assign(params));
}
