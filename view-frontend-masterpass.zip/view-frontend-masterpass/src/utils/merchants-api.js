import config from '../config.js';
import { dispatchRequest, dispatchRequestWithoutAuth } from './http-helper'

import axios from 'axios';
import qs from 'qs';

export { deleteMerchantConnection, getConnections };


let hash_id;

const API_BASE = config.API_BASE;
const username = config.OAUTH_CREDENTIALS.key;
const password = config.OAUTH_CREDENTIALS.secret;


function getConnections(method, params) {
	const url = 'https://masterpass-ih-beta-uat.mmvpay.com/connected/merchants?';
	return dispatchRequestWithoutAuth(method, url, params);
}


function deleteMerchantConnection(method, params) {
	const url = 'https://masterpass-ih-beta-uat.mmvpay.com/pairing/delete';
	return axios({
		method,
		url,
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		},
		data: qs.stringify(params)
	});
}
