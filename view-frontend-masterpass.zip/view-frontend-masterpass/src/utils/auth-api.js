import axios from 'axios';
import config from '../config.js';
import { dispatchRequest } from './http-helper'
import qs from 'qs';

export { getAuth, getAuth2, getToken, setAuth }

const API_BASE = config.API_BASE;
const username = config.OAUTH_CREDENTIALS.key;
const password = config.OAUTH_CREDENTIALS.secret;
let token;

function getAuth(params) {
  const url = `${API_BASE}/users/test`;

  return axios({
    method: 'post',
    url,
    auth: {
      username,
      password
    },
    data: qs.stringify(Object.assign({
      grant_type: 'client_credentials'
    }, params))
  });
}

function getAuth2(params){
  const url = `${API_BASE}/auth`;

  return axios({
    method: 'post',
    url,
    auth: {
      username,
      password
    },
    data: qs.stringify(Object.assign({
      grant_type: 'client_credentials'
    }, params))
  });
}

function getToken(){
  return token;
}

function setAuth(accessToken) {
  token = accessToken;
}
