import React, { Component } from 'react';
import AddCardForm from '../components/AddCardForm';
import BillingAddressForm from '../components/BillingAddressForm';
import OtpForm from '../components/OtpForm';
import SignupFormPageOne from '../components/SignupFormPageOne';
import SignupFormPageTwo from '../components/SignupFormPageTwo';
import ShippingAddressForm from '../components/ShippingAddressForm';
import SuccessPage from '../components/SuccessPage';

import validator from '../utils/validator.js';

export default class SignupForm extends Component {
  constructor() {
    super();
    this.state = { step: 1 };
    this.nextStep = this.nextStep.bind(this);
    this.initialStep = this.initialStep.bind(this);
    this.handleFormInput = this.handleFormInput.bind(this);
  }

  nextStep() {
    this.setState({
      step: this.state.step + 1
    });
  }

  previousStep() {
    this.setState({
      step: this.state.step - 1
    });
  }

  initialStep() {
    this.setState({
      step: 1
    });
  }

  handleFormInput(event){
    const val = event.target;
    this.setState(Object.assign(this.state, { [val.id]: val.value }));
    // console.log(this.state);
  }

  render() {
    let page;
    switch (this.state.step) {
      case 1:
        page = <SignupFormPageOne nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} />;
        break;
      case 2:
        page = <SignupFormPageTwo nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} />;
        break;
      case 3:
        page = <AddCardForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} continueLabel='continue' />;
        break;
      case 4:
        page = <BillingAddressForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} headingLabel='Enter Billing Address Ending in 9193' />;
        break;
      case 5:
        page = <ShippingAddressForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} />;
        break;
      case 6:
        page = <OtpForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} />;
        break;
      case 7:
        page = <SuccessPage nextStep={this.initialStep} />;
        break;
      default:
        return true;
    }
    return (page);
  }
}
