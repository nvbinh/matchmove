import React, { Component } from 'react';
import SignupForm from './Signup/Form';
require('./styles/main.css');

export default class BasicApp extends Component {
  render() {
    return (
      <SignupForm />
    );
  }
}
