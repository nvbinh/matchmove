import React, { Component } from 'react';
import Anchor from 'grommet/components/Anchor';
import AddCardForm from '../components/AddCardForm';
import AddCardOtpForm from '../components/AddCardOtpForm';
import AddressList from '../components/AddressList';
import BillingAddressForm from '../components/BillingAddressForm';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import CardList from '../components/CardList';
import Footer from 'grommet/components/Footer';
import Header from 'grommet/components/Header';
import Menu from 'grommet/components/Menu';
import Sidebar from 'grommet/components/Sidebar';
import SignupFormPageOne from '../components/SignupFormPageOne';
import ShippingAddressForm from '../components/ShippingAddressForm';
import Split from 'grommet/components/Split';
import SuccessPage from '../components/SuccessPage';
import Title from 'grommet/components/Title';
import LoginForm from '../components/LoginForm';

export default class AddAnotherCardForm extends Component {
  constructor() {
    super();
    this.isActive = true;
    this.state = { step: 1 };
    this.nextStep = this.nextStep.bind(this);
    this.previousStep = this.previousStep.bind(this);
    this.initialStep = this.initialStep.bind(this);
    this.handleFormInput = this.handleFormInput.bind(this);
  }

  nextStep() {
    this.setState({
      step: this.state.step + 1
    });
  }

  previousStep() {
    this.setState({
      step: this.state.step - 1
    });
  }

  initialStep() {
    this.setState({
      step: 1
    });
  }

  handleFormInput(event){
    const val = event.target;
    this.setState(Object.assign(this.state, { [val.id]: val.value }));
    console.log(this.state);
  }

  setActive(){
    if(this.isActive === false){
      this.isActive = true;
    }else{
      this.isActive = false;
    }
  }

  _onClose(){
    this.isActive = false;
    this.forceUpdate();
  }

  toggleAddress(){
    this.addressClicked = !this.addressClicked;
  }

  render() {
    let page;
    switch (this.state.step) {
      case 1:
        page = <LoginForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} _onClose={this._onClose.bind(this)}/>;
        break;
      case 2:
        page = <CardList nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} continueLabel='Add Card' />;
        break;
      case 3:
        page = <AddCardForm previousStep={this.previousStep} nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} continueLabel='Add Billing Address' hasBackButton={true} />;
        break;
      case 4:
        page = <AddressList previousStep={this.previousStep} nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} continueLabel='continue' hasBackButton={true} />;
        break;
      case 5:
        page = <BillingAddressForm previousStep={this.previousStep} nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} headingLabel='Add New Address' hasBackButton={true} noShipping={true} />;
        break;
      case 6:
        page = <AddCardOtpForm nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} />;
        break;
      case 7:
        page = <SuccessPage nextStep={this.initialStep} />;
        break;
      default:
        return true;
    }
    var showLayer = () => {
      if(this.isActive){
        return page;
      }
    }
    var showAddresses = () => {
      if(this.addressClicked){
        return (<AddressList previousStep={this.previousStep} nextStep={this.nextStep} onHandleInput={this.handleFormInput} accountInfo={this.state} continueLabel='continue' hasBackButton={true} />);
      }
    }
    return (
      <Split>
        <Sidebar colorIndex='neutral-1'>
          <Header pad='medium'
            justify='between'>
            <Title>
              MY WALLET
            </Title>
          </Header>
          <Box flex='grow'
            justify='start'>
            <Menu primary={true}>
              <Anchor href='#'
                onClick={this.setActive.bind(this)}
                className='active'>
                Cards
              </Anchor>
              <Anchor href='#'
                onClick={this.toggleAddress.bind(this)}>
                Addresses
              </Anchor>
            </Menu>
          </Box>
          <Footer pad='medium'>
          </Footer>
        </Sidebar>
        <Box>
          {showAddresses()}
        </Box>
        {showLayer()}
      </Split>
      );
  }
}
