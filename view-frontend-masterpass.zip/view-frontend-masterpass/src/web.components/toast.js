import React, { Component } from 'react';

class Toast extends Component {

	render() {
		return (

			<aside className={'hm-toast-layout '+(this.props.toggleLayout ? 'show': 'hide')} >
				<div className='hm-toast-cont'>
					<h2 className='hm-toast-header'>{this.props.header}</h2>
					<p className='hm-toast-msg'>{this.props.message}</p>
					<hr/>
					<button className='primary' onClick={this.props.onClickAccept}>Yes</button>
					<button className='plain' onClick={this.props.onClickDecline}>No</button>
				</div>
			</aside>

		);	
	}
}

Toast.propTypes = {
	header: React.PropTypes.string,
	message: React.PropTypes.string,
	toggleLayout: React.PropTypes.bool,
	onClickAccept: React.PropTypes.func,
	onClickDecline: React.PropTypes.func
}

export default Toast;