import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Section from 'grommet/components/Section';
import Card from 'grommet/components/Card';
import FormField from 'grommet/components/FormField';
import FormFields from 'grommet/components/FormFields';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import { getUsers } from '../utils/users-api';
import { getAuth, setAuth, getToken } from '../utils/auth-api';

import Toast from 'grommet/components/Toast';
import 'react-notifications/lib/notifications.css';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

export default class SignupFormPageOne extends Component {
    constructor() {
        super();
        this.state = {
            err: {}
        };
        
        this.isError = false;
        this.errorMsg = '';

        this.formControlList = ['mobile_country_code', 'mobile', 'password' ];
        this.pattern = consts.PATTERN;
        this.appConst = consts;
        this.saveAndContinue = this.saveAndContinue.bind(this);
        this.handleForm = this.handleForm.bind(this);
    }

    saveAndContinue(e) {
        e.preventDefault();

        this.state.err = validator.inspectPrefilledForm(this.refs.signupFormOne, this.formControlList);
        this.forceUpdate();


        if(!this.state.err.invalidForm) {

            getAuth(this.props.accountInfo).then((resp) => {
                setAuth(resp.data.access_details.access_token);
                getUsers().then((response) => {
                    this.props.nextStep();
                });
            }).catch((err) => {
                this.isError = true;
                this.errorMsg = err.response.statusText;
                this.forceUpdate();
            });

        }

    }

    handleForm(e) {
        this.state.err[e.target.id] = validator.inspectForm(e.target, this.refs.signupFormOne);
        this.props.onHandleInput(e);
    }

    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            }
        }
        return (
            <Box id='box'>
                <Layer align='center' className='box-layer'>
                        <h5>Signup for Masterpass</h5>
                        <form id='signupformpageone' ref='signupFormOne'>
                            <div className="row">
                                <div className="col-md-3">
                                    <select id='mobile_country_code' onChange={this.handleForm} required>
                                        <option value=''/>
                                        <option value='65'>SG +65</option>
                                    </select>
                                </div>
                                <div className="col-md-9">
                                    <input placeholder='Mobile Number' id='mobile' data-pattern={['country', this.props.accountInfo.mobile_country_code, 'mobile'].join('-')} data-dependent='mobile_country_code' onChange={this.handleForm}  required/>
                                    <span className='text-error'>{this.state.err.mobile}</span>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">    
                                    <input type='password' placeholder='Password' id='password' onChange={this.handleForm} required pattern={this.pattern.PASSWORD}/>
                                    <span className='text-error'>{this.state.err.password}</span>
                                </div>
                            </div>
                            <Section className="action action-signup">
                                <div className="row">
                                    <div className='col-md-12'>
                                        <p>Master Pass User? <a>Signup</a></p>
                                        <Button label='Signup'
                                            onClick={this.saveAndContinue}
                                            href='#'
                                            className='btn'
                                            primary={true}
                                            secondary={false}
                                            accent={false}
                                            critical={false}
                                            plain={false} />      
                                    </div> 
                                </div>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <p><a>Privacy </a> <a>Terms of Use</a></p>
                                    </div> 
                                </div>
                            </Section>
                        </form>
                </Layer>
                { toast() }
            </Box>
        );
    }
}

SignupFormPageOne.propTypes = {
    nextStep: PropTypes.func
};
