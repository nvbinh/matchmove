import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import FormField from 'grommet/components/FormField';
import FormFields from 'grommet/components/FormFields';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import { getUsers } from '../utils/users-api';
import { getAuth2, setAuth, getToken } from '../utils/auth-api';

import Toast from 'grommet/components/Toast';
import 'react-notifications/lib/notifications.css';

import consts from '../app-const.js';
import validator from '../utils/validator.js';
import SignupFormPageOne from './SignupFormPageOne';

export default class LoginForm extends SignupFormPageOne {
    constructor(){
        super();
        this.state.isActive= true;
    }
    saveAndContinue(e) {
        e.preventDefault();

        this.state.err = validator.inspectPrefilledForm(this.refs.signupFormOne, this.formControlList);
        this.forceUpdate();


        if(!this.state.err.invalidForm) {

          var params = this.props.accountInfo;
            getAuth2({ username: params.mobile, password: params.password, device_signature: '123'}).then((resp) => {
                setAuth(resp.data.access_token);
                this.props.nextStep();
            }).catch((err) => {
                this.isError = true;
                this.errorMsg = err.response.statusText;
                this.forceUpdate();
            });
        }
    }

    _onClose(){
        this.setState({ ...this.state,  isActive: !this.state.isActive});
    }
    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            }
        }
        var showLayer = () => {
            if(this.state.isActive){
                return (
                    <Layer align='center' onClose={this._onClose.bind(this)} closer={true} >
                    <Card heading='Sign in to  Masterpass'>
                        <form id='signupformpageone' ref='signupFormOne'>

                            <FormFields>

                                <FormField>
                                    <input placeholder='mobile' id='mobile' data-pattern={['country', this.props.accountInfo.mobile_country_code, 'mobile'].join('-')} data-dependent='mobile_country_code' onChange={this.handleForm}  required/>
                                    <span>{this.state.err.mobile}</span>
                                </FormField>
                                
                                <FormField>
                                    <input type='password' placeholder='password' id='password' onChange={this.handleForm} required pattern={this.pattern.PASSWORD}/>
                                    <span>{this.state.err.password}</span>
                                </FormField>
                                
                            </FormFields>

                            <p>Master Pass User?<a>Signup</a></p>
                            <Button label='Sign In'
                                onClick={this.saveAndContinue}
                                href='#'
                                primary={true}
                                secondary={false}
                                accent={false}
                                critical={false}
                                plain={false} />
                        </form>
                    </Card>
                </Layer>
            );
            }
        }
        return (
            <Box id='box'>
                {showLayer()}
                { toast() }
            </Box>
        );
    }
}

LoginForm.propTypes = {
    nextStep: PropTypes.func
};
