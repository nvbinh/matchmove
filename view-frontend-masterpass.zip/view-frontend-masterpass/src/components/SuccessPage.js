import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import Section from 'grommet/components/Section';
import PropTypes from 'prop-types';

export default class SuccessPage extends Component {
  constructor() {
    super();

    // this.handleFormInput = this.handleFormInput.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.done = this.done.bind(this);
  }

  done() {
    this.props.nextStep();
  }

  handleFormInput(name, event) {
    const field = {};
    const val = event.target;
    field[val.id] = val.value;
    this.setState(Object.assign(this.state, field));
    // this.setState({...this.state, [name]: event.target.value});
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log(this.state);
  }

  render() {
    return (
      <Box>
        <Layer align='center'>
          <Card heading=''>
            <p>You have successfully signed up for Masterpass Kotak Mahindra Bank </p>
            <input type='button' value='Add New Card' />
          </Card>
          <Section>
            <input type='button' value='Done' onClick={this.done} />
          </Section>
        </Layer>
      </Box>
    );
  }
}

SuccessPage.propTypes = {
  nextStep: PropTypes.func
};
