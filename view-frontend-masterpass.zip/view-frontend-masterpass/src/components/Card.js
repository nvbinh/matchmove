import React, { Component } from 'react';


export default class MMCard extends Component {
  render() {
    var cardFund = (card) => {
      if(card.funds){
        return (<span>{card.funds.available.currency} {card.funds.available.amount}</span>)
      }
    }
    return (
      <span>
        {cardFund(this.props.card)}
        <div>{this.props.card.id}</div>
        <img src={this.props.card_image} />
      </span>
    )
  }
}
