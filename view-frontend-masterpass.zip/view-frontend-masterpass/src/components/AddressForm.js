import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import { addBillingAddress, addShippingAddress } from '../utils/card-address-api';
import { getUserBillingAddress } from '../utils/users-api';
import Toast from 'grommet/components/Toast';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

export default class AddressForm extends Component {
  constructor(props){
    super();
    this.state = {
      err: props.err
    }
    this.formControlList = ['address_1', 'address_2', 'address_3', 'country', 'zipcode', 'sameAsShippingAddress' ];
    this.saveAndContinue = this.saveAndContinue.bind(this);
  }
  saveAndContinue(e) {
    e.preventDefault();

    this.state.err = validator.inspectPrefilledForm(this.refs.billingAddressForm, this.formControlList);
    this.forceUpdate();
    if(!this.state.err.invalidForm) {
      this.props.saveAndContinue(e);
    }
  }
  render() {
    var toast = () => {
      if(this.props.isError){
        return (<Toast status='critical' value>
          <span>
          {this.props.errorMsg}
          </span>
        </Toast>)
      }
    }
    var backButton = () => {
      if(this.props.hasBackButton){
        return (
          <span><Button label='back'
              onClick={this.props.previousStep}
              type='submit'
              primary={true}
              secondary={false}
              accent={false}
              critical={false}
              plain={false} /></span>);
      }
    }
    var shippingOption = () => {
      if(this.props.hasAddressOption){
        return (
          <div>
            <input type='checkbox' id='sameAsShippingAddress' checked={this.state.sameAsShippingAddress}
              onChange={this.props.checkSameAddress}
            />
            <label htmlFor='addAddress'>Add this Address as a shipping option</label>
          </div>
        )
      }
    }
    return ( 
            <Box>
                <Layer align='center'>
                    <Card heading={this.props.headingLabel}>
                        <form ref='billingAddressForm'>
                            <div>
                                <input type='text' name='address_1' pattern={consts.PATTERN.ADDRESS} value={this.props.accountInfo.address_1} required placeholder='Street Address Line 1' onChange={this.props.handleForm} id='address_1' />
                                <span>{this.state.err.address_1}</span>
                            </div>
                            <div>
                                <input type='text' name='address_2' pattern={consts.PATTERN.ADDRESS} value={this.props.accountInfo.address_2} required placeholder='Street Address Line 2' onChange={this.props.handleForm} id='address_2' />
                                <span>{this.state.err.address_2}</span>
                            </div>
                            <div>
                                <input type='text' name='address_3' pattern={consts.PATTERN.ADDRESS} placeholder='Street Address Line 3 (optional)' id='address_3'  onChange={this.props.handleForm}/>
                                <span>{this.state.err.address_3}</span>
                            </div>
                            <div>
                                <input type='text' name='country'  pattern={consts.PATTERN.NAME} value={this.props.accountInfo.country} required placeholder='Country' onChange={this.props.handleForm} id='country' />
                                <span>{this.state.err.country}</span>
                            </div>
                            <div>
                                <input type='text' name='zipcode' data-dependent='country' value={this.props.accountInfo.zipcode} data-pattern={['country', '91', 'zipcode'].join('-')} required placeholder='Zipcode' onChange={this.props.handleForm} id='zipcode' />
                                <span>{this.state.err.zipcode}</span>
                            </div>
                            <div>
                                <input type='checkbox' id='sameAsShippingAddress' checked={this.props.sameAsShippingAddress} onChange={this.props.checkSameAddress} />
                                <label htmlFor='addAddress'>Add this Address as a shipping option</label>
                            </div>
                            {backButton()}
                            <Button label='Continue'
                                onClick={this.saveAndContinue}
                                type='submit'
                                primary={true}
                                secondary={false}
                                accent={false}
                                critical={false}
                                plain={false} />
                        </form>
                    </Card>
                    { toast() }
                </Layer>
            </Box>
        );
  }
}
