import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import config from '../config.js';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import Section from 'grommet/components/Section';
import Toast from 'grommet/components/Toast';
import { changePassword, verifyChangePassword, verifyUser, updateUser } from '../utils/users-api';
import { getOtpVerification, verifyOtp, verifyUserOtp } from '../utils/otp-api';
import OtpForm from './OtpForm';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

const endpoint = config.HTTP_HOST;

export default class UserOtpForm extends OtpForm {
    constructor(){
        super();
    }

    componentDidMount(){
    }

    resendOtp() {
        updateUser({ mobile: this.props.accountInfo.mobile, mobile_country_code: this.props.accountInfo.mobile_country_code }).then((resp) => {
            this.token = resp.data.token;
            this.isSuccess = true;
            this.isError = false;
            this.successMsg = 'new otp successfully sent!';
            this.forceUpdate();
        });
    }

    updatePassword(){
        changePassword({ endpoint: endpoint, email: this.props.accountInfo.email }).then((resp) => {
            verifyChangePassword(resp.data.token, this.props.accountInfo.password).then((resp) => {
                this.isSuccess = true;
                this.isError = false;
                this.successMsg = 'info successfully updated';
                this.forceUpdate();
            });
        });
    }

    updateEmail(){
        //update email then on success
        updateUser({ endpoint: endpoint + '/email/verify', email: this.props.accountInfo.email }).then((resp) => {
            console.log(resp);
        });
    }

    updateOtherInfo(){
        updateUser({ id_number: this.props.accountInfo.id_number, id_type: this.props.accountInfo.id_type, nationality: this.props.accountInfo.nationality }).then((resp) => {
            console.log(resp);
            this.isSuccess = true;
            this.isError = false;
            this.successMsg = 'info successfully updated';
            this.forceUpdate();
        });
    }

    saveAndContinue(e) {
        e.preventDefault();
        
        this.state.err = validator.inspectPrefilledForm(this.refs.otpForm, this.formControlList);
        this.forceUpdate();
        
        if(!this.state.err.invalidForm) {
                    this.updateOtherInfo();
                    if(this.props.accountInfo.fields.emailChanged){
                        this.updateEmail();
                    }
            if (this.props.accountInfo.token && this.props.accountInfo.otp) {
                verifyUserOtp(this.props.accountInfo.token, this.props.accountInfo.otp).then((resp) => {
                    if(this.props.accountInfo.fields.passwordChanged){
                        this.updatePassword();
                    }
                    this.props.previousStep();
                }).catch((err) => {
                    this.isError = true;
                    this.errorMsg = err.response.statusText;
                    this.forceUpdate();
                });
            } else {
                this.isError = true;
                this.errorMsg = 'something went wrong';
                this.forceUpdate();
            }
        }
    }

    handleForm(e) {
        this.state.err[e.target.id] = validator.inspectForm(e.target, this.refs.otpForm);
        this.props.onHandleInput(e);
    }

    handleSubmit(e) {
        e.preventDefault();
    }

    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            } else if(this.isSuccess){
              return (<Toast status='ok'>
                <span>
                  {this.successMsg}
                </span>
              </Toast>)
            }
        }
        return (
            <Box>
                <Layer align='center'>
                    <Card heading='Enter One Time Password'>
                        <p>One Time Password(OTP) has been successfully sent to your mobile {this.props.accountInfo.mobile} and expires in 23 Seconds</p>
                        <form ref='otpForm'>
                            <div>
                                <input type='text' name='otp' pattern={consts.PATTERN.OTP} required id='otp' onChange={this.handleForm} />
                                <span>{this.state.err.otp}</span>
                            </div>
                            <div>
                                <a onClick={this.resendOtp}>Resend</a>
                            </div>
                            <div>
                                <Button 
                                    label='Continue' 
                                    onClick={this.saveAndContinue} 
                                    type='submit' 
                                    primary={true} 
                                    secondary={false} 
                                    accent={false} 
                                    critical={false} 
                                    plain={false} />
                            </div>
                        </form>
                    </Card>
                    { toast() }
                </Layer>
            </Box>
        );
    }
}

UserOtpForm.propTypes = {
    nextStep: PropTypes.func
};
