import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import MMCard from './Card';
import Section from 'grommet/components/Section';
import PropTypes from 'prop-types';
import { dispatchRequest } from '../utils/http-helper';
import { addCard, getCard, setCardID } from '../utils/cards-api';
import Toast from 'grommet/components/Toast';
import Spinner from 'react-spinkit';
import Split from 'grommet/components/Split';

export default class AddCardForm extends Component {
  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
    this.saveAndContinue = this.saveAndContinue.bind(this);
    this.handleForm = this.handleForm.bind(this);
    this.isLoaded = false;

    getCard().then((resp)=> {
      this.card_image = resp.data.image.large;
      this.cards = resp.data.cards;
      this.cards.forEach((item, index) => {
        dispatchRequest('get', item.links[0].href, {}).then((response)=>{
          Object.assign(this.cards[index], response.data);
          if(this.cards.length === index + 1){
            this.isLoaded = true;
            this.forceUpdate();
          }
        })
      });
    }).catch((err) => {
      setTimeout(()=>{
      this.isLoaded = true;
      this.forceUpdate(); }, 5000);
      });
  }

  saveAndContinue(e) {
    e.preventDefault();
    setCardID(this.props.accountInfo.card_hash_id);
    addCard(this.props.accountInfo).then((resp)=>{
      this.props.nextStep();
    }).catch((err) => {
      this.isError = true;
      if(err.response !== undefined){
        this.errorMsg = err.response.statusText;
        this.forceUpdate();
      }
    });
  }

  handleSubmit(event) {
    event.preventDefault();
  }

  handleForm(e) {
    this.props.onHandleInput(e);
  }

  render() {
    var toast = () => {
      if(this.isError){
        return (<Toast status='critical' value>
          <span>
          {this.errorMsg}
          </span>
        </Toast>)
      }
    }
    if(this.cards){
      var cardList = this.cards.map((card)=> {
        if(card.mp_status && card.status && !card.mp_status.is_added && card.status.is_active){
          return (
            <span>
              <input type='radio' name='card' key={card.id} value={card.id} id='card_hash_id' onChange={this.handleForm}/>
              <MMCard card={card} handleForm={this.handleForm} card_image={this.card_image} />
            </span>
          );
        }
      });

    }
    var spinner = () => {
      if(!this.isLoaded){
        return (
          <Section>
            <Box align='center' style="display: flex;
              justify-content: center;">
              <Spinner name="ball-spin-fade-loader" />
            </Box>
          </Section>
        );
      }
    };
    var preferredCard = () => {
      if(!this.isLoaded){
        return (
          <div>
            <input type='checkbox' id='sameCard'
              onChange={this.handleForm}
            />
            <label htmlFor='sameCard'>The selected card will be my preferred card</label>
          </div>
        );
      }
    }
    var backButton = () => {
      if(this.props.hasBackButton){
        return (
          <Section><Button label='back'
              onClick={this.props.previousStep}
              type='submit'
              primary={true}
              secondary={false}
              accent={false}
              critical={false}
              plain={false} /></Section>);
      }
    }
    var continueButton = () => {
      if(this.isLoaded){
        return (
          <Section>
          {backButton()}
          <Button label={this.props.continueLabel}
            onClick={this.saveAndContinue}
            type='submit'
            primary={true}
            secondary={false}
            accent={false}
            critical={false}
            plain={false} />
        </Section>
        );
      }
    }
    return (
      <Box>
        <Layer align='center'>
          <Card heading='Add Card'>
            <form onSubmit={this.handleSubmit}>
              <Section>
                {spinner()}
                {cardList}
              </Section>
              <Section>
                {preferredCard}
              </Section>
              {continueButton()}
            </form>
          </Card>
          { toast() }
        </Layer>
      </Box>
    );
  }
}

AddCardForm.propTypes = {
  nextStep: PropTypes.func
};
