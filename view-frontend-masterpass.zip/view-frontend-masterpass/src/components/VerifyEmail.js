import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import FormField from 'grommet/components/FormField';
import FormFields from 'grommet/components/FormFields';
import Layer from 'grommet/components/Layer';
import LoginForm from './LoginForm';
import PropTypes from 'prop-types';
import { getUsers, verifyEmail } from '../utils/users-api';
import { getAuth2, setAuth, getToken } from '../utils/auth-api';

import Toast from 'grommet/components/Toast';
import 'react-notifications/lib/notifications.css';

import consts from '../app-const.js';
import validator from '../utils/validator.js';
import SignupFormPageOne from './SignupFormPageOne';

export default class VerifyEmail extends Component {
    constructor(){
        super();
        this.state = {
            accountInfo: {},
            err: {}
        }

        this.isError = false;
        this.errorMsg = '';

        this.formControlList = ['mobile_country_code', 'mobile', 'password' ];
        this.pattern = consts.PATTERN;
        this.appConst = consts;

        this.handleInput = this.handleInput.bind(this);
    }

    componentDidMount(){
        this.state.accountInfo.token = this.props.match.params.token;
    }
    
    handleInput(event){
        const val = event.target;
        this.setState(Object.assign(this.state, { accountInfo: { ...this.state.accountInfo, [val.id]: val.value } }));
    }

    verifyEmail(e) {
        e.preventDefault();

        this.state.err = validator.inspectPrefilledForm(this.refs.signupFormOne, this.formControlList);
        this.forceUpdate();

        if(!this.state.err.invalidForm) {

          var params = this.state.accountInfo;
            getAuth2({ username: params.mobile, password: params.password, device_signature: '123'}).then((resp) => {
                setAuth(resp.data.access_token);
                verifyEmail(params.token, params.mobile).then((resp) => {
                    this.isSuccess = true;
                    this.isError = false;
                    this.successMsg = 'email successfully verified';
                    this.forceUpdate();
                });
            }).catch((err) => {
                this.isError = true;
                this.errorMsg = err.response.statusText;
                this.forceUpdate();
            });
        }
    }

    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            } else if(this.isSuccess){
              return (<Toast status='ok'>
                <span>
                  {this.successMsg}
                </span>
              </Toast>)
            }
        }
        return (
            <Box id='box'>
                <Layer align='center' onClose={this.props._onClose} closer={true} >
                    <Card heading='Verify Email'>
                        <form id='signupformpageone' ref='signupFormOne'>

                            <FormFields>

                                <FormField>
                                    <input placeholder='email/mobile' id='mobile' data-pattern={['country', this.state.accountInfo.mobile_country_code, 'mobile'].join('-')} data-dependent='mobile_country_code' onChange={this.handleInput}  required/>
                                    <span>{this.state.err.mobile}</span>
                                </FormField>
                                
                                <FormField>
                                    <input type='password' placeholder='password' id='password' onChange={this.handleInput} required pattern={this.pattern.PASSWORD}/>
                                    <span>{this.state.err.password}</span>
                                </FormField>
                                
                            </FormFields>

                            <br/>
                            <Button label='Verify'
                                onClick={this.verifyEmail.bind(this)}
                                href='#'
                                primary={true}
                                secondary={false}
                                accent={false}
                                critical={false}
                                plain={false} />
                        </form>
                    </Card>
                </Layer>
                { toast() }
            </Box>
        );
    }
}

VerifyEmail.propTypes = {
    nextStep: PropTypes.func
};
