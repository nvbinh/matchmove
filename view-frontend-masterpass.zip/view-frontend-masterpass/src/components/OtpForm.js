import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import Section from 'grommet/components/Section';
import Toast from 'grommet/components/Toast';
import { verifyUser } from '../utils/users-api';
import { getOtpVerification, verifyOtp } from '../utils/otp-api';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

export default class OtpForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            err: {}
        };
        this.formControlList = ['otp'];
        this.handleSubmit = this.handleSubmit.bind(this);
        this.saveAndContinue = this.saveAndContinue.bind(this);
        this.handleForm = this.handleForm.bind(this);
        this.resendOtp = this.resendOtp.bind(this);
    }

    componentDidMount(){
        getOtpVerification(this.props.accountInfo).then((resp) => {
            this.token = resp.data.token;
        });
    }

    resendOtp() {
      getOtpVerification(this.props.accountInfo).then((resp)=>{
        this.token = resp.data.token;
        this.isSuccess = true;
        this.isError = false;
        this.successMsg = 'new otp successfully sent!';
        this.forceUpdate();
      });
    }

    saveAndContinue(e) {
        e.preventDefault();
        
        this.state.err = validator.inspectPrefilledForm(this.refs.otpForm, this.formControlList);
        this.forceUpdate();
        
        if(!this.state.err.invalidForm) {
            if (this.token && this.props.accountInfo.otp) {
                verifyOtp(this.token, this.props.accountInfo.otp).then((resp) => {
                    verifyUser(this.props.accountInfo).then((response) => {
                        this.props.nextStep();
                    });
                }).catch((err) => {
                    this.isError = true;
                    this.errorMsg = err.response.statusText;
                    this.forceUpdate();
                });
            } else {
                this.isError = true;
                this.errorMsg = 'something went wrong';
                this.forceUpdate();
            }
        }
    }

    handleForm(e) {
        this.state.err[e.target.id] = validator.inspectForm(e.target, this.refs.otpForm);
        this.props.onHandleInput(e);
    }

    handleSubmit(e) {
        e.preventDefault();
    }

    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            } else if(this.isSuccess){
              return (<Toast status='ok'>
                <span>
                  {this.successMsg}
                </span>
              </Toast>)
            }
        }
        return (
            <Box>
                <Layer align='center'>
                    <Card heading='Enter One Time Password'>
                        <p>One Time Password(OTP) has been successfully sent to your mobile {this.props.accountInfo.mobile} and expires in 23 Seconds</p>
                        <form ref='otpForm'>
                            <div>
                                <input type='text' name='otp' pattern={consts.PATTERN.OTP} required id='otp' onChange={this.handleForm} />
                                <span>{this.state.err.otp}</span>
                            </div>
                            <div>
                                <a onClick={this.resendOtp}>Resend</a>
                            </div>
                            <div>
                                <Button 
                                    label='Continue' 
                                    onClick={this.saveAndContinue} 
                                    type='submit' 
                                    primary={true} 
                                    secondary={false} 
                                    accent={false} 
                                    critical={false} 
                                    plain={false} />
                            </div>
                        </form>
                    </Card>
                    { toast() }
                </Layer>
            </Box>
        );
    }
}

OtpForm.propTypes = {
    nextStep: PropTypes.func
};
