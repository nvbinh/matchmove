import React, { Component } from 'react';

import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import { addShippingAddress } from '../utils/card-address-api';
import { getUserShippingAddress } from '../utils/users-api';
import Toast from 'grommet/components/Toast';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

export default class ShippingAddress extends Component {
    constructor() {
        super();
        this.state = {
            err: {}
        };
        this.formControlList = ['address_1', 'address_2', 'address_3', 'country', 'zipcode' ];
        this.handleSubmit = this.handleSubmit.bind(this);
        this.saveAndContinue = this.saveAndContinue.bind(this);
        this.handleForm = this.handleForm.bind(this);
        getUserShippingAddress().then((response) => {
            this.props.accountInfo.address_1 = response.data.address_1;
            this.props.accountInfo.address_2 = response.data.address_2;
            this.props.accountInfo.country = response.data.country;
            this.props.accountInfo.zipcode = response.data.zipcode;
            this.forceUpdate();
        });
    }

    saveAndContinue(e) {
        e.preventDefault();

        this.state.err = validator.inspectPrefilledForm(this.refs.shippingAddressForm, this.formControlList);
        this.forceUpdate();

        if(!this.state.err.invalidForm) {

            addShippingAddress(this.props.accountInfo).then((resp) => {
                this.props.nextStep();
            }).catch((err) => {
                this.isError = true;
                this.errorMsg = err.response.statusText;
                this.forceUpdate();
            });
        }
                        this.props.nextStep();
    }

    handleSubmit(event) {
        event.preventDefault();
    }

    handleForm(e) {
        this.props.onHandleInput(e);
        this.state.err[e.target.id] = validator.inspectForm(e.target, this.refs.shippingAddressForm);
    }

    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            }
        }
        return (
            <Box>
                <Layer align='center'>
                    <Card heading='Enter Shipping Address'>
                        <form ref='shippingAddressForm'>
                           <div>
                                <input type='text' name='address_1' pattern={consts.PATTERN.ADDRESS} value={this.props.accountInfo.address_1} required placeholder='Street Address Line 1' onChange={this.handleForm} id='address_1' />
                                <span>{this.state.err.address_1}</span>
                            </div>
                            <div>
                                <input type='text' name='address_2' pattern={consts.PATTERN.ADDRESS} value={this.props.accountInfo.address_2} required placeholder='Street Address Line 2' onChange={this.handleForm} id='address_2' />
                                <span>{this.state.err.address_2}</span>
                            </div>
                            <div>
                                <input type='text' name='address_3' pattern={consts.PATTERN.ADDRESS} placeholder='Street Address Line 3 (optional)' id='address_3' />
                                <span>{this.state.err.address_3}</span>
                            </div>
                            <div>
                                <input type='text' name='country'  pattern={consts.PATTERN.NAME} value={this.props.accountInfo.country} required placeholder='Country' onChange={this.handleForm} id='country' />
                                <span>{this.state.err.country}</span>
                            </div>
                            <div>
                                <input type='text' name='zipcode' data-dependent='country' value={this.props.accountInfo.zipcode} data-pattern={['country', '91', 'zipcode'].join('-')} required placeholder='Zipcode' onChange={this.handleForm} id='zipcode' />
                                <span>{this.state.err.zipcode}</span>
                            </div>
                            <Button label='Continue' onClick={this.saveAndContinue} type='submit' primary={true} secondary={false} accent={false} critical={false} plain={false} />
                        </form>
                    </Card>
                    { toast() }
                </Layer>
            </Box>
        );
    }
}

ShippingAddress.propTypes = {
    nextStep: PropTypes.func
};
