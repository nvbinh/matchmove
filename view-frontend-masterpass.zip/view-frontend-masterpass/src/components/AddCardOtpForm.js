import React, { Component } from 'react';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import Section from 'grommet/components/Section';
import Toast from 'grommet/components/Toast';
import { verifyUser } from '../utils/users-api';
import { getOtpVerification, verifyOtp } from '../utils/otp-api';
import OtpForm from './OtpForm';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

export default class AddCardOtpForm extends OtpForm {
    saveAndContinue(e) {
        e.preventDefault();
        
        this.state.err = validator.inspectPrefilledForm(this.refs.otpForm, this.formControlList);
        this.forceUpdate();
        
        if(!this.state.err.invalidForm) {
            if (this.token && this.props.accountInfo.otp) {
                verifyOtp(this.token, this.props.accountInfo.otp).then((resp) => {
                    verifyUser({}).then((response) => {
                        this.props.nextStep();
                    });
                }).catch((err) => {
                    this.isError = true;
                    this.errorMsg = err.response.statusText;
                    this.forceUpdate();
                });
            } else {
                this.isError = true;
                this.errorMsg = 'something went wrong';
                this.forceUpdate();
            }
        }
    }
}

AddCardOtpForm.propTypes = {
    nextStep: PropTypes.func
};
