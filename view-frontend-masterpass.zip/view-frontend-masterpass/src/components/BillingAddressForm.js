import React, { Component } from 'react';
import AddressForm from './AddressForm';
import Box from 'grommet/components/Box';
import Button from 'grommet/components/Button';
import Card from 'grommet/components/Card';
import Layer from 'grommet/components/Layer';
import PropTypes from 'prop-types';
import { addBillingAddress, addShippingAddress } from '../utils/card-address-api';
import { getUserBillingAddress } from '../utils/users-api';
import Toast from 'grommet/components/Toast';

import consts from '../app-const.js';
import validator from '../utils/validator.js';

export default class BillingAddressForm extends Component {
    
    constructor() {
        super();
        this.state = {
            sameAsShippingAddress: false
        };
        this.state = {
          err: {
            address_1: '',
            address_2: '',
            zipcode: '',
            country: ''
          }
        };

        this.handleSubmit = this.handleSubmit.bind(this);
        this.saveAndContinue = this.saveAndContinue.bind(this);
        this.handleForm = this.handleForm.bind(this);
        getUserBillingAddress().then((response) => {
            this.props.accountInfo.address_1 = response.data.address_1;
            this.props.accountInfo.address_2 = response.data.address_2;
            this.props.accountInfo.country = response.data.country;
            this.props.accountInfo.zipcode = response.data.zipcode;
            this.forceUpdate();
        });
    }

    saveAndContinue(e) {
        e.preventDefault();

        if(!this.state.err.invalidForm) {
            addBillingAddress(this.props.accountInfo).then((resp) => {
                this.props.nextStep();
                if (this.state.sameAsShippingAddress) {
                    addShippingAddress(this.props.accountInfo).then((resp) => {
                      if(!this.props.noShipping){
                        this.props.nextStep();
                      }
                    });
                }
            }).catch((err) => {
                this.isError = true;
                this.errorMsg = err.response.statusText;
                this.forceUpdate();
            });
        } 
    }

    handleFormInput(name, e) {
        const field = {};
        const val = e.target;

        this.state.err[e.target.id] = validator.inspectForm(e.target, this.refs.billingAddressForm);

        field[val.id] = val.value;
        this.setState(Object.assign(this.state, field));
        // this.setState({this.state, [name]: e.target.value});
    }
    
    handleSubmit(e) {
        e.preventDefault();
    }

    handleForm(e) {
        this.state.err[e.target.id] = validator.inspectForm(e.target, this.refs.billingAddressForm);
        this.props.onHandleInput(e);
    }

    checkSameAddress(e) {
        if (e.id === 'sameAsShippingAddress') {
            e.target.value = !this.state.sameAsShippingAddress;
        }
        this.setState({
            sameAsShippingAddress: !this.state.sameAsShippingAddress
        });
    }

    render() {
        var toast = () => {
            if(this.isError){
                return (
                    <Toast status='critical' value>
                        <span>{this.errorMsg}</span>
                    </Toast>
                );
            }
        }

    return (
      <AddressForm accountInfo={this.props.accountInfo} checkSameAddress={this.checkSameAddress.bind(this)} headingLabel={this.props.headingLabel} err={this.state.err} saveAndContinue={this.saveAndContinue} isError={this.isError} errorMsg={this.errorMsg} handleForm={this.handleForm} ref='billingAddressForm' hasBackButton={this.props.hasBackButton} previousStep={this.props.previousStep} />
    );
    }
}

BillingAddressForm.propTypes = {
    nextStep: PropTypes.func
};
